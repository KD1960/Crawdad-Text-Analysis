/*
 * Crawdad 2026 — M1 parser benchmark (Node only).
 * Compares wink-nlp vs compromise on the gold fixture.
 * Both adapters use the SAME chunking rule so the benchmark isolates
 * POS-tagging quality:
 *   noun phrase = maximal contiguous run of {adjective, noun, proper noun}
 *   containing at least one noun/proper noun; determiners, pronouns,
 *   numerals, verbs excluded.
 *
 * Run:  node tests/benchmark-parsers.js   (needs npm i wink-nlp
 *       wink-eng-lite-web-model compromise in a reachable node_modules)
 */
'use strict';

var FIXTURE = require('./fixture-parser.js');

/* ---------- adapter: wink-nlp (UPOS tags) ---------- */
function winkAdapter() {
  var winkNLP = require('wink-nlp');
  var model = require('wink-eng-lite-web-model');
  var nlp = winkNLP(model);
  var its = nlp.its;
  return function (sentence) {
    var doc = nlp.readDoc(sentence);
    var toks = [];
    doc.tokens().each(function (t) {
      toks.push({ w: t.out().toLowerCase(), pos: t.out(its.pos) });
    });
    return chunk(toks, function (p) { return p === 'ADJ'; },
                       function (p) { return p === 'NOUN' || p === 'PROPN'; });
  };
}

/* ---------- adapter: compromise (its own tags) ---------- */
function compromiseAdapter() {
  var c = require('compromise');
  return function (sentence) {
    var json = c(sentence).json()[0];
    var toks = (json ? json.terms : []).map(function (t) {
      var tags = t.tags || [];
      var pos = 'X';
      if (tags.indexOf('Pronoun') !== -1) { pos = 'PRON'; }
      else if (tags.indexOf('Determiner') !== -1) { pos = 'DET'; }
      else if (tags.indexOf('Value') !== -1 || tags.indexOf('Cardinal') !== -1) { pos = 'NUM'; }
      else if (tags.indexOf('Verb') !== -1) { pos = 'VERB'; }
      else if (tags.indexOf('Adjective') !== -1) { pos = 'ADJ'; }
      else if (tags.indexOf('Noun') !== -1) { pos = 'NOUN'; }
      return { w: t.text.toLowerCase().replace(/[^a-z0-9'-]/g, ''), pos: pos };
    });
    return chunk(toks, function (p) { return p === 'ADJ'; },
                       function (p) { return p === 'NOUN'; });
  };
}

/* ---------- shared chunker ---------- */
function chunk(toks, isAdj, isNoun) {
  var phrases = [], cur = [], hasNoun = false;
  function flush() {
    if (cur.length && hasNoun) { phrases.push(cur); }
    cur = []; hasNoun = false;
  }
  toks.forEach(function (t) {
    if (!t.w) { flush(); return; }
    if (isNoun(t.pos)) { cur.push(t.w); hasNoun = true; }
    else if (isAdj(t.pos)) { cur.push(t.w); }
    else { flush(); }
  });
  flush();
  // drop leading adjectives is NOT done: adjectives belong to the NP.
  return phrases;
}

/* ---------- scoring: word-level multiset P/R/F1 per sentence ---------- */
function toBag(phrases) {
  var bag = {};
  phrases.forEach(function (p) {
    p.forEach(function (w) { bag[w] = (bag[w] || 0) + 1; });
  });
  return bag;
}
function score(goldPhrases, predPhrases) {
  var g = toBag(goldPhrases), p = toBag(predPhrases);
  var tp = 0, predN = 0, goldN = 0, k;
  for (k in p) { predN += p[k]; if (g[k]) { tp += Math.min(g[k], p[k]); } }
  for (k in g) { goldN += g[k]; }
  return { tp: tp, predN: predN, goldN: goldN };
}

function run(name, adapter) {
  var tot = { tp: 0, predN: 0, goldN: 0 };
  var diffs = [];
  FIXTURE.forEach(function (fx, i) {
    var pred = adapter(fx.s);
    var sc = score(fx.gold, pred);
    tot.tp += sc.tp; tot.predN += sc.predN; tot.goldN += sc.goldN;
    var goldStr = JSON.stringify(fx.gold);
    var predStr = JSON.stringify(pred);
    if (goldStr !== predStr) {
      diffs.push({ i: i + 1, s: fx.s, gold: goldStr, pred: predStr });
    }
  });
  var P = tot.tp / tot.predN, R = tot.tp / tot.goldN;
  var F1 = 2 * P * R / (P + R);
  return { name: name, P: P, R: R, F1: F1, diffs: diffs };
}

var results = [
  run('wink-nlp', winkAdapter()),
  run('compromise', compromiseAdapter())
];

console.log('=== M1 parser benchmark: word-level extraction vs gold (20 sentences) ===\n');
results.forEach(function (r) {
  console.log(r.name.padEnd(12) +
    '  P=' + r.P.toFixed(3) + '  R=' + r.R.toFixed(3) + '  F1=' + r.F1.toFixed(3) +
    '  sentences-with-any-diff=' + r.diffs.length + '/20');
});
console.log('\n--- Disagreements (phrase-level, for Kevin\'s review) ---');
results.forEach(function (r) {
  console.log('\n[' + r.name + ']');
  r.diffs.forEach(function (d) {
    console.log('S' + d.i + ': ' + d.s + '\n  gold: ' + d.gold + '\n  pred: ' + d.pred);
  });
});
