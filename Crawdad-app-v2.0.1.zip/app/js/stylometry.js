/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M5 — Stylometry module (Build Spec V2 §6.1).
 *
 * Burrows's Delta (Burrows, 2002) and Cosine Delta (Evert et al., 2017 —
 * the variant their evaluation found most reliable) over a most-frequent-
 * words (MFW) profile computed from each file's schema-2.0
 * `surfaceFrequencies` block. Definitions (stylo conventions, recorded):
 *
 *   - MFW ranking: mean relative frequency across documents (equal
 *     document weighting), ties alphabetical; size user-set 100–500.
 *   - Culling: a word must appear in at least `culling`% of documents.
 *   - z-scores per word over the document set, sample SD (n−1 — R's sd()).
 *   - Burrows Delta(D1,D2) = mean over MFW of |z(D1) − z(D2)|.
 *   - Cosine Delta(D1,D2) = 1 − cosine(z(D1), z(D2)).
 *
 * NCD (Li et al., 2004; Cilibrasi & Vitányi, 2005) as an assumption-free
 * cross-check: NCD(x,y) = (C(xy) − min(Cx,Cy)) / max(Cx,Cy) with C = the
 * vendored deflate implementation's output size (pako 3.0.1) — NCD values
 * are COMPRESSOR-RELATIVE and every output says which compressor. NCD
 * needs the byte sequences, which _cra.md files do not carry, so it runs
 * only on optionally supplied source texts matched to the loaded files.
 *
 * Honest-use rules baked into every report: Delta attributes among the
 * candidates given — it never verifies authorship absolutely; documents
 * under ~1,500 running tokens are flagged (Eder's minimum-sample
 * findings). Rolling stylometry is Phase 2 (spec).
 */
(function (root) {
  'use strict';

  var EDER_MIN_TOKENS = 1500;

  function round(x, p) { var m = Math.pow(10, p); return Math.round(x * m) / m; }

  /* ------------------------------------------------------------------ *
   * MFW profile + z-scores
   * ------------------------------------------------------------------ */

  /**
   * docs: [{name, n, counts}] (counts: word -> surface count; from
   * surfaceFrequencies). opts: { mfw (200), culling (0, percent 0-100) }.
   * Returns { words, rel (docs x words), means, sds, z (docs x words) }.
   */
  function mfwProfile(docs, opts) {
    opts = opts || {};
    var mfw = opts.mfw === undefined ? 200 : opts.mfw;
    var culling = opts.culling === undefined ? 0 : opts.culling;
    var nDocs = docs.length;

    var meanRel = Object.create(null), docFreq = Object.create(null);
    docs.forEach(function (d) {
      Object.keys(d.counts).forEach(function (w) {
        meanRel[w] = (meanRel[w] || 0) + (d.counts[w] / d.n) / nDocs;
        docFreq[w] = (docFreq[w] || 0) + 1;
      });
    });
    var minDocs = Math.ceil(culling / 100 * nDocs);
    var words = Object.keys(meanRel)
      .filter(function (w) { return docFreq[w] >= minDocs; })
      .sort(function (a, b) {
        return meanRel[b] - meanRel[a] || (a < b ? -1 : 1);
      })
      .slice(0, mfw);

    var rel = docs.map(function (d) {
      return words.map(function (w) { return (d.counts[w] || 0) / d.n; });
    });
    var means = [], sds = [];
    for (var j = 0; j < words.length; j++) {
      var s = 0;
      for (var i = 0; i < nDocs; i++) { s += rel[i][j]; }
      var mu = s / nDocs;
      var v = 0;
      for (i = 0; i < nDocs; i++) { v += (rel[i][j] - mu) * (rel[i][j] - mu); }
      means.push(mu);
      sds.push(nDocs > 1 ? Math.sqrt(v / (nDocs - 1)) : 0); // sample SD (stylo)
    }
    var z = rel.map(function (row) {
      return row.map(function (x, j) {
        return sds[j] > 0 ? (x - means[j]) / sds[j] : 0;
      });
    });
    return { words: words, rel: rel, means: means, sds: sds, z: z };
  }

  /* ------------------------------------------------------------------ *
   * Distance matrices
   * ------------------------------------------------------------------ */

  function burrowsDelta(z) {
    var n = z.length, W = z[0].length;
    var D = [];
    for (var i = 0; i < n; i++) { D.push(new Array(n).fill(0)); }
    for (i = 0; i < n; i++) {
      for (var j = i + 1; j < n; j++) {
        var s = 0;
        for (var w = 0; w < W; w++) { s += Math.abs(z[i][w] - z[j][w]); }
        D[i][j] = D[j][i] = s / W;
      }
    }
    return D;
  }

  function cosineDelta(z) {
    var n = z.length, W = z[0].length;
    var norm = z.map(function (row) {
      var s = 0;
      for (var w = 0; w < W; w++) { s += row[w] * row[w]; }
      return Math.sqrt(s);
    });
    var D = [];
    for (var i = 0; i < n; i++) { D.push(new Array(n).fill(0)); }
    for (i = 0; i < n; i++) {
      for (var j = i + 1; j < n; j++) {
        var dot = 0;
        for (var w = 0; w < W; w++) { dot += z[i][w] * z[j][w]; }
        // near-zero-norm z vectors (a document at the corpus average) have no
        // meaningful direction — distance 1 by convention; the 1e-10 guard
        // covers FP residue like z = 5.5e-16 (caught by the hand-worked test)
        var d = (norm[i] > 1e-10 && norm[j] > 1e-10)
          ? 1 - dot / (norm[i] * norm[j]) : 1;
        D[i][j] = D[j][i] = d;
      }
    }
    return D;
  }

  /* ------------------------------------------------------------------ *
   * NCD (compressor-pinned)
   * ------------------------------------------------------------------ */

  function toBytes(str) {
    if (typeof TextEncoder !== 'undefined') { return new TextEncoder().encode(str); }
    // Node fallback
    return new Uint8Array(Buffer.from(str, 'utf8'));
  }

  /** NCD matrix over raw text strings; deflateFn: Uint8Array -> Uint8Array. */
  function ncdMatrix(texts, deflateFn) {
    var n = texts.length;
    var bytes = texts.map(toBytes);
    var C = bytes.map(function (b) { return deflateFn(b).length; });
    var D = [];
    for (var i = 0; i < n; i++) { D.push(new Array(n).fill(0)); }
    for (i = 0; i < n; i++) {
      for (var j = i + 1; j < n; j++) {
        var cat = new Uint8Array(bytes[i].length + bytes[j].length);
        cat.set(bytes[i], 0); cat.set(bytes[j], bytes[i].length);
        var cxy = deflateFn(cat).length;
        var d = (cxy - Math.min(C[i], C[j])) / Math.max(C[i], C[j]);
        D[i][j] = D[j][i] = round(d, 5);
      }
    }
    return { D: D, sizes: C };
  }

  /* ------------------------------------------------------------------ *
   * Full module run
   * ------------------------------------------------------------------ */

  function docFromCra(name, data) {
    var sf = data && data.surfaceFrequencies;
    if (!sf || !sf.totalTokens || !sf.tokens) { return null; }
    var counts = Object.create(null);
    sf.tokens.forEach(function (t) { counts[t[0]] = t[1]; });
    return { name: name, n: sf.totalTokens, counts: counts };
  }

  /**
   * datas/names: loaded craData + names.
   * opts: { mfw, culling, sourceTexts: {name -> raw text} (optional, NCD) }
   * deps: { deflateFn (optional), deflateLabel }
   */
  function stylometry(datas, names, opts, deps) {
    opts = opts || {}; deps = deps || {};
    var docs = [], used = [], excluded = [];
    datas.forEach(function (d, i) {
      var doc = docFromCra(names[i], d);
      if (doc) { docs.push(doc); used.push(names[i]); }
      else { excluded.push(names[i]); }
    });
    if (docs.length < 3) {
      throw new Error('Stylometry needs at least 3 files with surface frequencies (have ' +
        docs.length + ').');
    }
    var mfw = Math.max(10, Math.min(500, opts.mfw === undefined ? 200 : opts.mfw));
    var culling = Math.max(0, Math.min(100, opts.culling === undefined ? 50 : opts.culling));
    var prof = mfwProfile(docs, { mfw: mfw, culling: culling });
    var delta = burrowsDelta(prof.z).map(function (r) {
      return r.map(function (x) { return round(x, 5); });
    });
    var cosine = cosineDelta(prof.z).map(function (r) {
      return r.map(function (x) { return round(x, 5); });
    });
    var warnings = docs.filter(function (d) { return d.n < EDER_MIN_TOKENS; })
      .map(function (d) {
        return d.name + ' has ' + d.n + ' running tokens (< ' + EDER_MIN_TOKENS +
          '): Delta is unstable at this length (Eder).';
      });

    var ncd = null;
    if (opts.sourceTexts && deps.deflateFn) {
      var withSrc = [], srcNames = [];
      used.forEach(function (nm) {
        var key = nm.replace(/_cra\.md$/i, '');
        var t = opts.sourceTexts[key] || opts.sourceTexts[nm];
        if (t !== undefined) { withSrc.push(t); srcNames.push(nm); }
      });
      if (withSrc.length >= 3) {
        var m = ncdMatrix(withSrc, deps.deflateFn);
        ncd = { names: srcNames, D: m.D, sizes: m.sizes,
          compressor: deps.deflateLabel || 'deflate (vendored)' };
      }
    }

    return {
      parameters: { mfw: prof.words.length, mfwRequested: mfw, culling: culling,
        ranking: 'mean relative frequency across documents',
        zScores: 'sample SD (n-1)',
        ederMinTokens: EDER_MIN_TOKENS },
      names: used, excluded: excluded, warnings: warnings,
      mfwWords: prof.words,
      z: prof.z,
      delta: delta, cosine: cosine, ncd: ncd
    };
  }

  /* ------------------------------------------------------------------ *
   * Report
   * ------------------------------------------------------------------ */

  function matrixLines(L, title, names, D) {
    L.push('## ' + title);
    L.push('');
    L.push('| | ' + names.map(function (nm) { return nm; }).join(' | ') + ' |');
    L.push('|---|' + names.map(function () { return '---|'; }).join(''));
    names.forEach(function (nm, i) {
      L.push('| **' + nm + '** | ' + D[i].map(function (x) { return x; }).join(' | ') + ' |');
    });
    L.push('');
  }

  function serializeReport(res, citationBlock) {
    var L = [];
    L.push('# Crawdad Stylometry: ' + res.names.length + ' texts');
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- MFW profile: ' + res.parameters.mfw + ' words (requested ' +
      res.parameters.mfwRequested + '), culling ' + res.parameters.culling +
      '% of documents, ranking = ' + res.parameters.ranking + ', z-scores with ' +
      res.parameters.zScores + '.');
    if (res.excluded.length) {
      L.push('- Excluded (no surface frequencies; regenerate with 2.0.0-M1+): ' +
        res.excluded.join(', '));
    }
    L.push('');
    L.push('HONEST-USE NOTE: Delta attributes among the candidate texts GIVEN — it');
    L.push('measures which candidate profile a text sits closest to, and cannot verify');
    L.push('authorship absolutely. Distances are profile distances, not probabilities.');
    if (res.warnings.length) {
      L.push('');
      L.push('**Sample-size warnings (Eder):**');
      L.push('');
      res.warnings.forEach(function (w) { L.push('- ⚠ ' + w); });
    }
    L.push('');
    matrixLines(L, 'Burrows Delta (Burrows, 2002)', res.names, res.delta);
    matrixLines(L, 'Cosine Delta (Evert et al., 2017)', res.names, res.cosine);
    if (res.ncd) {
      L.push('## NCD cross-check (' + res.ncd.compressor + ')');
      L.push('');
      L.push('Normalized compression distance (Li et al., 2004; Cilibrasi & Vitányi,');
      L.push('2005) on the supplied source texts. NCD values are compressor-relative:');
      L.push('comparable within this table, not across compressors.');
      L.push('');
      matrixLines(L, 'NCD matrix', res.ncd.names, res.ncd.D);
    } else {
      L.push('## NCD cross-check');
      L.push('');
      L.push('Not computed: NCD needs the source byte sequences, which _cra.md files');
      L.push('do not carry. Load the original .txt files on the Stylometry screen to');
      L.push('add it.');
      L.push('');
    }
    L.push('Top of the MFW list: ' + res.mfwWords.slice(0, 30).join(', ') +
      (res.mfwWords.length > 30 ? ', …' : ''));
    L.push('');
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-stylometry', schemaVersion: '1.0',
      parameters: res.parameters, names: res.names, excluded: res.excluded,
      warnings: res.warnings, mfwWords: res.mfwWords,
      delta: res.delta, cosine: res.cosine,
      ncd: res.ncd ? { names: res.ncd.names, D: res.ncd.D,
        compressor: res.ncd.compressor } : null }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    String(citationBlock || '').split('\n\n').forEach(function (c) {
      if (c) { L.push('*' + c + '*'); L.push(''); }
    });
    return L.join('\n');
  }

  var api = {
    EDER_MIN_TOKENS: EDER_MIN_TOKENS,
    mfwProfile: mfwProfile,
    burrowsDelta: burrowsDelta,
    cosineDelta: cosineDelta,
    ncdMatrix: ncdMatrix,
    docFromCra: docFromCra,
    stylometry: stylometry,
    serializeReport: serializeReport
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadStylometry = api; }
})(typeof self !== 'undefined' ? self : this);
