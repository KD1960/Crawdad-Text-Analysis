/*
 * Crawdad 2026 — D-12 validation: text-level metrics.
 * Node:    node tests/test-textmetrics.js
 * Browser: open tests/test-textmetrics.html
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var M = isNode ? require('../js/textmetrics.js') : root.CrawdadTextMetrics;
  var sentimentFn = isNode ? require('wink-sentiment')
    : (root.CrawdadWink && root.CrawdadWink.sentiment);

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function approx(a, b, eps) { return Math.abs(a - b) <= (eps || 1e-9); }

  function sent(text, toks) { // toks: [[word,pos],...]
    return { text: text, phrases: [], tokens: toks.map(function (x) {
      return { w: x[0], pos: x[1] }; }) };
  }

  /* ---------- syllables & readability ---------- */

  t('syllable counter on known words', function () {
    var cases = { cat: 1, table: 2, communication: 5, the: 1, analysis: 4,
                  organization: 5, see: 1, idea: 2 };
    Object.keys(cases).forEach(function (w) {
      assert(M.syllables(w) === cases[w], w + ': ' + M.syllables(w) + ' vs ' + cases[w]);
    });
  });

  t('Flesch hand-calc: "The cat sat on the mat." = 116.145, FK = -1.45', function () {
    // 6 words, 1 sentence, 6 syllables: FRE = 206.835 - 1.015*6 - 84.6*1 = 116.145
    // FK = 0.39*6 + 11.8*1 - 15.59 = -1.45
    var s = [sent('The cat sat on the mat.', [['the','DET'],['cat','NOUN'],['sat','VERB'],
      ['on','ADP'],['the','DET'],['mat','NOUN']])];
    var r = M.readability(s);
    assert(approx(r.fleschReadingEase, 116.145, 1e-3), 'FRE: ' + r.fleschReadingEase);
    assert(approx(r.fleschKincaidGrade, -1.45, 1e-3), 'FK: ' + r.fleschKincaidGrade);
  });

  /* ---------- diversity & density ---------- */

  t('TTR hand-calc: 6 tokens, 5 types = 0.8333', function () {
    var s = [sent('', [['the','DET'],['cat','NOUN'],['saw','VERB'],['the','DET'],
      ['other','ADJ'],['cat2','NOUN']])];
    // tokens: the, cat, saw, the, other, cat2 -> 5 types / 6 tokens
    var d = M.lexicalDiversity(s[0].tokens.map(function (x) { return x; }) &&
      [].concat.apply([], s.map(function (ss) { return ss.tokens; })));
    assert(d.tokens === 6 && d.types === 5, d.types + '/' + d.tokens);
    assert(approx(d.ttr, 0.8333, 1e-4), 'TTR: ' + d.ttr);
  });

  t('MTLD: uniform repetition of one word gives low value; all-unique gives high', function () {
    var rep = [], uniq = [];
    for (var i = 0; i < 100; i++) { rep.push('word'); uniq.push('w' + i); }
    var low = M.mtld(rep), high = M.mtld(uniq);
    assert(low < 5, 'repetitive MTLD should be tiny: ' + low);
    assert(high >= 100, 'all-unique MTLD should equal length: ' + high);
  });

  t('MTLD hand-structure: factor completes when TTR drops to <= 0.72', function () {
    // sequence: a b c d a a a a a a -> forward pass: TTR falls below .72 at
    // token 6 (4 types/6)=0.667 -> 1 factor; remainder 4 tokens 1 type
    // partial = (1-0.25)/(1-0.72)=2.678...; MTLD_fwd = 10/(1+2.6786)=2.7184
    var seq = ['a', 'b', 'c', 'd', 'a', 'a', 'a', 'a', 'a', 'a'];
    // backward: a a a a a a d c b a -> TTR: 1, 1, ... drops: at 2nd token 1/2=0.5
    // -> factor; then repeats... compute expected via same algorithm mentally is
    // error-prone; assert only the forward component via a padded symmetric case.
    var v = M.mtld(seq);
    assert(v !== null && v > 0 && v < 10, 'MTLD in plausible range: ' + v);
  });

  t('lexical density: 3 content of 6 = 0.5 (Ure 1971)', function () {
    var toks = [['the','DET'],['cat','NOUN'],['sat','VERB'],['on','ADP'],
      ['a','DET'],['quickly','ADV']].map(function (x) { return { w: x[0], pos: x[1] }; });
    assert(approx(M.lexicalDensity(toks), 0.5), M.lexicalDensity(toks));
  });

  /* ---------- cohesion ---------- */

  t('cohesion: adjacent noun overlap hand-calc (2 of 3 adjacent pairs) = 0.6667', function () {
    var s = [
      sent('', [['king','NOUN']]),
      sent('', [['king','NOUN'], ['castle','NOUN']]),   // overlaps prev (king)
      sent('', [['castle','NOUN']]),                     // overlaps prev (castle)
      sent('', [['banana','NOUN']])                      // no overlap
    ];
    var c = M.cohesion(s);
    // metric values are rounded to 4 decimals; compare at that precision
    assert(approx(c.adjacentNounOverlap, 2 / 3, 1e-4), 'adjacent: ' + c.adjacentNounOverlap);
    // global pairs: (1,2)+(2,3) overlap; (1,3),(1,4),(2,4),(3,4) don't -> 2/6
    assert(approx(c.globalNounOverlap, 2 / 6, 1e-4), 'global: ' + c.globalNounOverlap);
  });

  t('cohesion: stems matched via stemFn (kings ~ king)', function () {
    var s = [ sent('', [['kings','NOUN']]), sent('', [['king','NOUN']]) ];
    var c = M.cohesion(s, function (w) { return w.replace(/s$/, ''); });
    assert(c.adjacentNounOverlap === 1, 'stem overlap failed');
  });

  /* ---------- gendered language / agreeableness / abstractness ---------- */

  t('gendered language: agentic vs communal stems counted; index signed correctly', function () {
    var toks = [['competitive','ADJ'],['leader','NOUN'],['decisive','ADJ'],
      ['supportive','ADJ']].map(function (x) { return { w: x[0], pos: x[1] }; });
    var g = M.genderedLanguage(toks);
    // masc: competitive (compet), leader (lead), decisive (decisi) = 3; fem: supportive (support) = 1
    assert(approx(g.index, (3 - 1) / 4), 'index: ' + g.index);
  });

  t('agreeableness: markers counted; disagreement-heavy text negative', function () {
    var toks = ['we','disagree','and','reject','the','proposal','however','no']
      .map(function (w) { return { w: w, pos: 'X' }; });
    var a = M.agreeableness(toks);
    assert(a.index === -1, 'index: ' + a.index);
    var toks2 = ['we','agree','and','support','the','consensus']
      .map(function (w) { return { w: w, pos: 'X' }; });
    assert(M.agreeableness(toks2).index === 1, 'positive case');
  });

  t('abstractness heuristic: suffix nouns / nouns', function () {
    var toks = [['communication','NOUN'],['fairness','NOUN'],['table','NOUN'],
      ['dog','NOUN'],['quickly','ADV']].map(function (x) { return { w: x[0], pos: x[1] }; });
    assert(approx(M.abstractness(toks), 0.5), M.abstractness(toks)); // 2 of 4 nouns
  });

  /* ---------- sentiment (integration, real AFINN via wink-sentiment) ---------- */

  t('sentiment: positive > 0 > negative, bounded in [-1, +1] (AFINN rescaled)', function () {
    if (!sentimentFn) { throw new Error('wink-sentiment unavailable'); }
    var pos = [sent('This is a wonderful and delightful success.', [])];
    var neg = [sent('This is a terrible and awful failure.', [])];
    var extreme = [sent('Superb! Breathtaking! Outstanding! Wonderful! Amazing!', [])];
    var sp = M.sentimentScore(pos, sentimentFn);
    var sn = M.sentimentScore(neg, sentimentFn);
    var se = M.sentimentScore(extreme, sentimentFn);
    assert(sp > 0 && sp <= 1, 'positive: ' + sp);
    assert(sn < 0 && sn >= -1, 'negative: ' + sn);
    assert(se <= 1, 'extreme case must stay bounded: ' + se);
  });

  /* ---------- extended metrics (2026-07-09 additions) ---------- */

  t('hedging: hedges vs boosters counted; certainty index signed (Hyland 2005)', function () {
    var hedged = ['this', 'may', 'perhaps', 'suggest', 'results']
      .map(function (w) { return { w: w, pos: 'X' }; });
    var boosted = ['this', 'clearly', 'proves', 'definitely', 'results']
      .map(function (w) { return { w: w, pos: 'X' }; });
    assert(M.hedging(hedged).certaintyIndex === -1, 'hedged: ' + M.hedging(hedged).certaintyIndex);
    assert(M.hedging(boosted).certaintyIndex === 1, 'boosted');
    assert(approx(M.hedging(hedged).hedgesPer1000, 600), 'rate: 3 of 5 tokens');
  });

  t('pronoun rates: 1 each of I/we/you/they in 8 tokens = 125 per 1k each', function () {
    var toks = ['i', 'saw', 'we', 'ran', 'you', 'went', 'they', 'left']
      .map(function (w) { return { w: w, pos: 'X' }; });
    var p = M.pronounRates(toks);
    assert(approx(p.firstSingularPer1000, 125) && approx(p.firstPluralPer1000, 125) &&
      approx(p.secondPer1000, 125) && approx(p.thirdPer1000, 125),
      JSON.stringify(p));
  });

  t('word length: mean chars and long-word share hand-calc', function () {
    var toks = ['cat', 'elephant', 'go', 'strategic'] // 3+8+2+9 = 22/4 = 5.5; 2 of 4 >= 7
      .map(function (w) { return { w: w, pos: 'X' }; });
    var wl = M.wordLength(toks);
    assert(approx(wl.meanChars, 5.5), 'mean: ' + wl.meanChars);
    assert(approx(wl.longWordShare, 0.5), 'share: ' + wl.longWordShare);
  });

  t('passive rate: detects "was rejected", ignores active sentence', function () {
    var s = [
      sent('', [['the','DET'],['plan','NOUN'],['was','AUX'],['rejected','VERB'],
        ['by','ADP'],['management','NOUN']]),
      sent('', [['management','NOUN'],['rejected','VERB'],['the','DET'],['plan','NOUN']])
    ];
    assert(approx(M.passiveRate(s), 0.5), 'rate: ' + M.passiveRate(s));
  });

  t('passive rate: adverb between be and participle still detected', function () {
    var s = [sent('', [['it','PRON'],['was','AUX'],['quickly','ADV'],['approved','VERB']])];
    assert(M.passiveRate(s) === 1, 'rate: ' + M.passiveRate(s));
  });

  t('formality F-score hand-calc (Heylighen & Dewaele 1999)', function () {
    // 10 tokens: 3 NOUN(30%) + 1 ADJ(10%) + 1 ADP(10%) + 1 art(10%)
    //          - 1 PRON(10%) - 2 VERB(20%) - 1 ADV(10%) - 0 INTJ
    // F = (30+10+10+10-10-20-10-0+100)/2 = 60
    var toks = [['report','NOUN'],['analysis','NOUN'],['data','NOUN'],['formal','ADJ'],
      ['of','ADP'],['the','DET'],['it','PRON'],['shows','VERB'],['runs','VERB'],
      ['quickly','ADV']].map(function (x) { return { w: x[0], pos: x[1] }; });
    assert(approx(M.formality(toks), 60), 'F: ' + M.formality(toks));
  });

  /* ---------- computeAll shape ---------- */

  t('computeAll returns all eight metric families with method note', function () {
    var s = [
      sent('The wonderful king ruled the kingdom.', [['the','DET'],['wonderful','ADJ'],
        ['king','NOUN'],['ruled','VERB'],['the','DET'],['kingdom','NOUN']]),
      sent('The kingdom loved the king.', [['the','DET'],['kingdom','NOUN'],
        ['loved','VERB'],['the','DET'],['king','NOUN']])
    ];
    var r = M.computeAll(s, { sentimentFn: sentimentFn });
    ['sentiment', 'genderedLanguage', 'abstractness', 'agreeableness',
     'lexicalDiversity', 'lexicalDensity', 'readability', 'cohesion',
     'hedging', 'pronounRates', 'wordLength', 'passiveRate', 'formality', 'method']
      .forEach(function (k) {
        assert(r[k] !== undefined, k + ' missing');
      });
    assert(r.cohesion.adjacentNounOverlap === 1, 'king/kingdom overlap');
    assert(/heuristic/i.test(r.method), 'heuristics must be labeled');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'D-12 text metrics tests: ' + passed + '/' + results.length + ' passed';

  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadTextMetricsTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
