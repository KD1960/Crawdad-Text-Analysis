/*
 * Crawdad 2026 — M1 parser module (spec §3.1)
 * Sentence segmentation, POS tagging, and CRA noun-phrase extraction.
 *
 * Engine: wink-nlp + wink-eng-lite-web-model (chosen in the M1 benchmark:
 * F1 = 0.970 on the 20-sentence gold fixture; errors are modifier misses,
 * never head-noun losses — see tests/benchmark-parsers.js).
 *
 * Chunking rule (CRA, JHC pp. 174-175):
 *   noun phrase = maximal contiguous run of {ADJ, NOUN, PROPN} containing
 *   at least one NOUN/PROPN. DET, PRON (default), NUM, VERB, ADV, etc. break
 *   phrases and are excluded.
 *
 * Browser: requires vendor/wink-bundle.js loaded first (window.CrawdadWink).
 * Node (tests): pass winkNLP + model to createParser().
 */
(function (root) {
  'use strict';

  function createParser(winkNLP, model, options) {
    var nlp = winkNLP(model);
    var its = nlp.its;
    var keepPronouns = !!(options && options.keepPronouns); // spec §3.1 toggle

    function isNounPos(pos) { return pos === 'NOUN' || pos === 'PROPN'; }
    function isAdjPos(pos) { return pos === 'ADJ'; }
    function isPronoun(pos) { return pos === 'PRON'; }

    /**
     * Parse text into sentences of CRA noun phrases.
     * Returns { sentences: [ { text, phrases: [ [word, ...], ... ] } ] }
     * Words are lowercased surface forms; stemming happens downstream (§3.5).
     */
    function parse(text) {
      var doc = nlp.readDoc(text);
      var sentences = [];
      doc.sentences().each(function (sent) {
        var phrases = [];
        var cur = [];
        var hasNoun = false;
        function flush() {
          if (cur.length && hasNoun) { phrases.push(cur); }
          cur = []; hasNoun = false;
        }
        sent.tokens().each(function (t) {
          var pos = t.out(its.pos);
          var w = t.out().toLowerCase();
          // keep letters/digits/internal hyphens & apostrophes only
          w = w.replace(/[^a-z0-9'-]/g, '');
          // drop single-character tokens (citation initials "j", "r", etc.)
          if (!w || w.length < 2) { flush(); return; }
          if (isNounPos(pos) || (keepPronouns && isPronoun(pos))) {
            cur.push(w); hasNoun = true;
          } else if (isAdjPos(pos)) {
            cur.push(w);
          } else {
            flush();
          }
        });
        flush();
        sentences.push({ text: sent.out(), phrases: phrases });
      });
      return { sentences: sentences };
    }

    /** Debug helper: token/POS listing for a sentence (M1 acceptance review). */
    function tagView(text) {
      var doc = nlp.readDoc(text);
      var out = [];
      doc.tokens().each(function (t) {
        out.push({ token: t.out(), pos: t.out(its.pos) });
      });
      return out;
    }

    return { parse: parse, tagView: tagView, engine: 'wink-nlp' };
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { createParser: createParser };   // Node (tests)
  } else {
    if (!root.CrawdadWink) {
      throw new Error('vendor/wink-bundle.js must be loaded before js/parser.js');
    }
    root.CrawdadParser = {
      createParser: function (options) {
        return createParser(root.CrawdadWink.winkNLP, root.CrawdadWink.model, options);
      }
    };
  }
})(typeof self !== 'undefined' ? self : this);
