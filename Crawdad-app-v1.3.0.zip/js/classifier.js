/*
 * Crawdad 2026 — M5: Classifier (spec §7.3)
 *  - n×n pairwise WR' matrix (PR' also computed for reference)
 *  - K-means (k-means++, DETERMINISTIC seeded PRNG, 10 restarts) on matrix rows
 *  - best K by mean silhouette over K = 2..min(8, n-1); all K reported
 *  - classical MDS on d = 1 − WR' for the 2-D plot (D-6)
 */
(function (root) {
  'use strict';

  var SEED = 20260709; // fixed: identical inputs -> identical clustering

  /* ---------------- seeded PRNG (mulberry32) ---------------- */
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---------------- resonance matrices ---------------- */

  /** datas: array of parsed _cra.md objects. Needs CrawdadResonance. */
  function resonanceMatrices(datas, R) {
    var n = datas.length;
    var wrs = [], prs = [], i, j;
    for (i = 0; i < n; i++) { wrs.push(new Array(n).fill(0)); prs.push(new Array(n).fill(0)); }
    for (i = 0; i < n; i++) {
      wrs[i][i] = 1; prs[i][i] = 1;
      for (j = i + 1; j < n; j++) {
        var w = R.wordResonance(datas[i], datas[j]).WRs;
        var p = R.pairResonance(datas[i], datas[j]).PRs;
        wrs[i][j] = wrs[j][i] = w;
        prs[i][j] = prs[j][i] = p;
      }
    }
    return { wrs: wrs, prs: prs };
  }

  /* ---------------- k-means (Lloyd + k-means++ init) ---------------- */

  function dist2(a, b) {
    var s = 0;
    for (var i = 0; i < a.length; i++) { var d = a[i] - b[i]; s += d * d; }
    return s;
  }

  function kmeansOnce(rows, k, rand) {
    var n = rows.length, dim = rows[0].length;
    // k-means++ init
    var centers = [rows[Math.floor(rand() * n)].slice()];
    while (centers.length < k) {
      var d2 = rows.map(function (r) {
        return Math.min.apply(null, centers.map(function (c) { return dist2(r, c); }));
      });
      var sum = d2.reduce(function (a, b) { return a + b; }, 0);
      if (sum === 0) { centers.push(rows[Math.floor(rand() * n)].slice()); continue; }
      var target = rand() * sum, acc = 0, pick = 0;
      for (var i = 0; i < n; i++) { acc += d2[i]; if (acc >= target) { pick = i; break; } }
      centers.push(rows[pick].slice());
    }
    var labels = new Array(n).fill(-1);
    for (var iter = 0; iter < 100; iter++) {
      var changed = false;
      for (var p = 0; p < n; p++) {
        var best = 0, bd = Infinity;
        for (var c = 0; c < k; c++) {
          var d = dist2(rows[p], centers[c]);
          if (d < bd) { bd = d; best = c; }
        }
        if (labels[p] !== best) { labels[p] = best; changed = true; }
      }
      // recompute centers
      var sums = [], counts = new Array(k).fill(0);
      for (c = 0; c < k; c++) { sums.push(new Array(dim).fill(0)); }
      for (p = 0; p < n; p++) {
        counts[labels[p]]++;
        for (var q = 0; q < dim; q++) { sums[labels[p]][q] += rows[p][q]; }
      }
      for (c = 0; c < k; c++) {
        if (counts[c] === 0) { // empty cluster: reseed at farthest point
          var far = 0, fd = -1;
          for (p = 0; p < n; p++) {
            var dd = dist2(rows[p], centers[labels[p]]);
            if (dd > fd) { fd = dd; far = p; }
          }
          centers[c] = rows[far].slice();
        } else {
          for (q = 0; q < dim; q++) { centers[c][q] = sums[c][q] / counts[c]; }
        }
      }
      if (!changed) { break; }
    }
    var inertia = 0;
    for (p = 0; p < n; p++) { inertia += dist2(rows[p], centers[labels[p]]); }
    return { labels: labels, inertia: inertia };
  }

  /** Deterministic k-means: fixed seed, 10 restarts, best inertia. */
  function kmeans(rows, k, seed) {
    var rand = rng(seed === undefined ? SEED : seed);
    var best = null;
    for (var r = 0; r < 10; r++) {
      var res = kmeansOnce(rows, k, rand);
      if (!best || res.inertia < best.inertia) { best = res; }
    }
    // canonicalize label numbering by first occurrence (stable across runs)
    var map = {}, next = 0;
    var labels = best.labels.map(function (l) {
      if (map[l] === undefined) { map[l] = next++; }
      return map[l];
    });
    return { labels: labels, inertia: best.inertia };
  }

  /* ---------------- silhouette ---------------- */

  function silhouette(rows, labels) {
    var n = rows.length;
    var s = new Array(n).fill(0);
    for (var i = 0; i < n; i++) {
      var own = labels[i];
      var byCluster = {};
      for (var j = 0; j < n; j++) {
        if (j === i) { continue; }
        var d = Math.sqrt(dist2(rows[i], rows[j]));
        (byCluster[labels[j]] = byCluster[labels[j]] || []).push(d);
      }
      var ownArr = byCluster[own] || [];
      if (ownArr.length === 0) { s[i] = 0; continue; } // singleton convention
      var a = ownArr.reduce(function (x, y) { return x + y; }, 0) / ownArr.length;
      var b = Infinity;
      Object.keys(byCluster).forEach(function (c) {
        if (+c === own) { return; }
        var arr = byCluster[c];
        var m = arr.reduce(function (x, y) { return x + y; }, 0) / arr.length;
        if (m < b) { b = m; }
      });
      s[i] = (b - a) / Math.max(a, b);
    }
    return { values: s, mean: s.reduce(function (x, y) { return x + y; }, 0) / n };
  }

  /**
   * Try K = 2..min(8, n-1) and select K.
   *
   * Selection rule (decision 2026-07-09, D-8): raw silhouette maximization
   * often favors degenerate small-K splits (e.g., 8-vs-1), which are
   * uninformative. So:
   *   1. target K0 = round(sqrt(n))
   *   2. accept K0 if silhouette(K0) >= max silhouette - TOLERANCE
   *   3. otherwise fall back to the best-silhouette K, preferring
   *      non-degenerate solutions (no singleton cluster) when within
   *      TOLERANCE of the maximum.
   * opts.forceK overrides everything (UI manual choice).
   */
  var SQRT_RULE_TOLERANCE = 0.10;

  function clusterSizes(labels, k) {
    var sizes = new Array(k).fill(0);
    labels.forEach(function (l) { sizes[l]++; });
    return sizes;
  }

  function classify(rows, seed, opts) {
    var n = rows.length;
    var kMax = Math.min(8, n - 1);
    var tried = [];
    for (var k = 2; k <= kMax; k++) {
      var km = kmeans(rows, k, seed);
      var sil = silhouette(rows, km.labels);
      var sizes = clusterSizes(km.labels, k);
      tried.push({
        k: k, labels: km.labels, inertia: km.inertia, silhouette: sil.mean,
        sizes: sizes, hasSingleton: Math.min.apply(null, sizes) === 1
      });
    }
    var byK = {};
    tried.forEach(function (t) { byK[t.k] = t; });
    var maxSil = Math.max.apply(null, tried.map(function (t) { return t.silhouette; }));

    var best, rule;
    var forceK = opts && opts.forceK;
    if (forceK && byK[forceK]) {
      best = byK[forceK];
      rule = 'K = ' + forceK + ' set manually by user.';
    } else {
      var k0 = Math.max(2, Math.min(kMax, Math.round(Math.sqrt(n))));
      var target = byK[k0];
      if (target && target.silhouette >= maxSil - SQRT_RULE_TOLERANCE) {
        best = target;
        rule = 'sqrt(n) rule: K = round(sqrt(' + n + ')) = ' + k0 +
          '; silhouette ' + target.silhouette.toFixed(4) +
          ' is within ' + SQRT_RULE_TOLERANCE + ' of the maximum (' + maxSil.toFixed(4) + ').';
      } else {
        // fallback: best silhouette, preferring non-degenerate within tolerance
        var ok = tried.filter(function (t) {
          return !t.hasSingleton && t.silhouette >= maxSil - SQRT_RULE_TOLERANCE;
        });
        var pool = ok.length ? ok : tried;
        best = pool.slice().sort(function (a, b) {
          return b.silhouette - a.silhouette || a.k - b.k;
        })[0];
        rule = 'sqrt(n) target K = ' + k0 + ' rejected (silhouette ' +
          (target ? target.silhouette.toFixed(4) : 'n/a') + ' vs max ' + maxSil.toFixed(4) +
          ', beyond tolerance ' + SQRT_RULE_TOLERANCE + '); using best ' +
          (ok.length ? 'non-degenerate ' : '') + 'K = ' + best.k + '.';
      }
    }
    return { tried: tried, best: best, rule: rule };
  }

  /* ---------------- hierarchical agglomerative clustering (D-13) ------- */

  /**
   * Average-linkage HAC on a symmetric distance matrix D (e.g., 1 - WR').
   * Returns { merges: [{a, b, height, id, size}], root, leafOrder, maxHeight,
   *           cutAt(height) -> labels[] (0-based, canonical order) }.
   * Node ids: 0..n-1 = leaves; n..2n-2 = internal merge nodes.
   * Average linkage is monotonic (no dendrogram inversions).
   */
  function hac(D) {
    var n = D.length;
    if (n < 2) { throw new Error('HAC needs at least 2 items'); }
    // active clusters: id -> { members: [leafIdx...] }
    var members = {}, active = [], i, j;
    for (i = 0; i < n; i++) { members[i] = [i]; active.push(i); }
    var nextId = n;
    var merges = [];
    var children = {}; // internal id -> [a, b]
    var heights = {};  // internal id -> height

    function clusterDist(aId, bId) {
      var A = members[aId], B = members[bId], s = 0;
      for (var x = 0; x < A.length; x++) {
        for (var y = 0; y < B.length; y++) { s += D[A[x]][B[y]]; }
      }
      return s / (A.length * B.length);
    }

    while (active.length > 1) {
      var best = null;
      for (i = 0; i < active.length - 1; i++) {
        for (j = i + 1; j < active.length; j++) {
          var d = clusterDist(active[i], active[j]);
          if (!best || d < best.d ||
              (d === best.d && (active[i] < best.a ||
                (active[i] === best.a && active[j] < best.b)))) {
            best = { a: active[i], b: active[j], d: d };
          }
        }
      }
      var id = nextId++;
      members[id] = members[best.a].concat(members[best.b]);
      children[id] = [best.a, best.b];
      heights[id] = best.d;
      merges.push({ a: best.a, b: best.b, height: best.d, id: id,
                    size: members[id].length });
      active = active.filter(function (x) { return x !== best.a && x !== best.b; });
      active.push(id);
    }
    var root = active[0];

    // leaf order by depth-first traversal (standard dendrogram layout)
    var leafOrder = [];
    (function walk(id) {
      if (id < n) { leafOrder.push(id); return; }
      walk(children[id][0]); walk(children[id][1]);
    })(root);

    function cutAt(h) {
      // clusters = maximal subtrees whose merge height <= h
      var labels = new Array(n).fill(-1);
      var next = 0;
      (function assign(id, clusterId) {
        if (id < n) {
          if (clusterId === -1) { clusterId = next++; }
          labels[id] = clusterId;
          return;
        }
        if (heights[id] <= h) {
          if (clusterId === -1) { clusterId = next++; }
          assign(children[id][0], clusterId);
          assign(children[id][1], clusterId);
        } else {
          assign(children[id][0], -1);
          assign(children[id][1], -1);
        }
      })(root, -1);
      // canonicalize: renumber by first occurrence
      var map = {}, k = 0;
      return labels.map(function (l) {
        if (map[l] === undefined) { map[l] = k++; }
        return map[l];
      });
    }

    return { merges: merges, root: root, leafOrder: leafOrder,
             children: children, heights: heights, n: n,
             maxHeight: merges.length ? merges[merges.length - 1].height : 0,
             cutAt: cutAt };
  }

  /* ---------------- classical MDS (D-6) ---------------- */

  /** D: symmetric distance matrix. Returns { points: [[x,y],...], eigenvalues: [l1,l2] } */
  function classicalMDS(D) {
    var n = D.length, i, j;
    // B = -0.5 * J * D^2 * J   (double centering)
    var rowMean = new Array(n).fill(0), total = 0;
    var D2 = [];
    for (i = 0; i < n; i++) {
      D2.push(new Array(n));
      for (j = 0; j < n; j++) { D2[i][j] = D[i][j] * D[i][j]; }
    }
    for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++) { rowMean[i] += D2[i][j]; }
      rowMean[i] /= n; total += rowMean[i];
    }
    total /= n;
    var B = [];
    for (i = 0; i < n; i++) {
      B.push(new Array(n));
      for (j = 0; j < n; j++) {
        B[i][j] = -0.5 * (D2[i][j] - rowMean[i] - rowMean[j] + total);
      }
    }
    // top-2 eigenpairs by power iteration with deflation.
    // Each call uses a DIFFERENT seeded start vector: with repeated
    // eigenvalues, reusing the start vector that produced the first
    // eigenvector leaves zero component along the remaining eigendirection
    // (deflation annihilates it) and the iteration collapses.
    function eig(Bm, salt) {
      for (var attempt = 0; attempt < 5; attempt++) {
        var rand = rng((salt + attempt * 101) * 9973 + 7);
        var v = new Array(n).fill(0).map(function () { return rand() - 0.5; });
        var collapsed = false;
        for (var it = 0; it < 1000; it++) {
          var w = new Array(n).fill(0);
          for (var a = 0; a < n; a++) {
            for (var b = 0; b < n; b++) { w[a] += Bm[a][b] * v[b]; }
          }
          var norm = Math.sqrt(w.reduce(function (x, y) { return x + y * y; }, 0));
          if (norm < 1e-14) { collapsed = (it === 0); break; }
          var diff = 0;
          for (a = 0; a < n; a++) { w[a] /= norm; diff += Math.abs(w[a] - v[a]); }
          v = w;
          if (diff < 1e-13) { break; }
        }
        if (collapsed) { continue; } // unlucky start vector; reseed
        // Rayleigh quotient for signed eigenvalue (w.r.t. Bm)
        var Bv = new Array(n).fill(0);
        for (var a2 = 0; a2 < n; a2++) {
          for (var b2 = 0; b2 < n; b2++) { Bv[a2] += Bm[a2][b2] * v[b2]; }
        }
        var rq = 0;
        for (a2 = 0; a2 < n; a2++) { rq += v[a2] * Bv[a2]; }
        return { value: rq, vector: v };
      }
      return { value: 0, vector: new Array(n).fill(0) }; // genuinely rank-deficient
    }
    var e1 = eig(B, 1);
    // deflate
    var B2m = [];
    for (i = 0; i < n; i++) {
      B2m.push(new Array(n));
      for (j = 0; j < n; j++) { B2m[i][j] = B[i][j] - e1.value * e1.vector[i] * e1.vector[j]; }
    }
    var e2 = eig(B2m, 2);
    var l1 = Math.max(e1.value, 0), l2 = Math.max(e2.value, 0);
    var points = [];
    for (i = 0; i < n; i++) {
      points.push([e1.vector[i] * Math.sqrt(l1), e2.vector[i] * Math.sqrt(l2)]);
    }
    return { points: points, eigenvalues: [l1, l2] };
  }

  /* ---------------- report (spec §7.3) ---------------- */

  function shade(v) {
    // white (0) -> crawdad red (1) background for heat-shading
    var g = Math.round(255 - 140 * Math.max(0, Math.min(1, v)));
    return 'background-color: rgb(255,' + g + ',' + g + ')';
  }

  function matrixHtml(names, M, label) {
    var h = ['<table><thead><tr><th>' + label + '</th>'];
    names.forEach(function (nm) { h.push('<th>' + nm + '</th>'); });
    h.push('</tr></thead><tbody>');
    M.forEach(function (row, i) {
      h.push('<tr><th>' + names[i] + '</th>');
      row.forEach(function (v, j) {
        h.push('<td style="' + (i === j ? '' : shade(v)) + '">' + v.toFixed(4) + '</td>');
      });
      h.push('</tr>');
    });
    h.push('</tbody></table>');
    return h.join('');
  }

  function buildReport(names, matrices, classification, mds, citation, hac) {
    var L = [];
    var best = classification.best;
    L.push('# Crawdad Classifier: ' + names.length + ' texts');
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- Clustering: K-means (k-means++, deterministic seed) on rows of the WR\' matrix; ' +
           'K selection by sqrt(n) rule with silhouette check (spec §7.3, D-8).');
    L.push('- Selected K = ' + best.k + ' (mean silhouette ' + best.silhouette.toFixed(4) +
           '; cluster sizes: ' + best.sizes.join(', ') + ')');
    L.push('- Selection: ' + classification.rule);
    if (best.hasSingleton) {
      L.push('- **Note: the chosen solution contains a singleton cluster** — one text stands ' +
             'alone. Inspect whether it is a true outlier or an artifact.');
    }
    L.push('');
    L.push('## Cluster membership (K = ' + best.k + ')');
    L.push('');
    L.push('| Text | Cluster |');
    L.push('|---|---|');
    names.forEach(function (nm, i) { L.push('| ' + nm + ' | ' + (best.labels[i] + 1) + ' |'); });
    L.push('');
    L.push('## Silhouette by K');
    L.push('');
    L.push('| K | Mean silhouette | Cluster sizes | Singleton? |');
    L.push('|---|---|---|---|');
    classification.tried.forEach(function (t) {
      L.push('| ' + t.k + (t.k === best.k ? ' (selected)' : '') + ' | ' +
        t.silhouette.toFixed(4) + ' | ' + t.sizes.join(', ') + ' | ' +
        (t.hasSingleton ? 'yes' : 'no') + ' |');
    });
    L.push('');
    L.push('## Word resonance matrix (WR\', standardized)');
    L.push('');
    L.push(matrixHtml(names, matrices.wrs, 'WR\''));
    L.push('');
    L.push('## Pair resonance matrix (PR\', standardized — reference)');
    L.push('');
    L.push(matrixHtml(names, matrices.prs, 'PR\''));
    L.push('');
    if (mds) {
      L.push('## MDS coordinates (classical MDS on 1 − WR\')');
      L.push('');
      L.push('| Text | Dim 1 | Dim 2 | Cluster |');
      L.push('|---|---|---|---|');
      names.forEach(function (nm, i) {
        L.push('| ' + nm + ' | ' + mds.points[i][0].toFixed(4) + ' | ' +
          mds.points[i][1].toFixed(4) + ' | ' + (best.labels[i] + 1) + ' |');
      });
      L.push('');
    }
    if (hac) {
      L.push('## Hierarchical clustering (average linkage, interactive cut — D-13)');
      L.push('');
      L.push('- Distance: 1 − WR\'; linkage: average (UPGMA).');
      L.push('- Cut height: ' + hac.height.toFixed(4) + ' → K = ' + hac.k +
             '; cluster sizes: ' + hac.sizes.join(', ') +
             '; mean silhouette: ' + (hac.silhouette === null || hac.silhouette === undefined
               ? 'n/a' : hac.silhouette.toFixed(4)));
      L.push('');
      L.push('| Text | HAC cluster |');
      L.push('|---|---|');
      names.forEach(function (nm, i) {
        L.push('| ' + nm + ' | ' + (hac.labels[i] + 1) + ' |');
      });
      L.push('');
    }
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-classification', schemaVersion: '1.1',
      names: names, wrs: matrices.wrs, prs: matrices.prs,
      tried: classification.tried, selectedK: best.k, labels: best.labels,
      selectionRule: classification.rule,
      hac: hac ? { linkage: 'average', distance: '1-WRs', height: hac.height,
        k: hac.k, labels: hac.labels, sizes: hac.sizes,
        silhouette: hac.silhouette } : null,
      mds: mds ? mds.points : null }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    L.push('*' + citation + '*');
    L.push('');
    return L.join('\n');
  }

  var api = {
    SEED: SEED,
    rng: rng,
    resonanceMatrices: resonanceMatrices,
    hac: hac,
    kmeans: kmeans,
    silhouette: silhouette,
    classify: classify,
    classicalMDS: classicalMDS,
    matrixHtml: matrixHtml,
    buildReport: buildReport
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadClassifier = api; }
})(typeof self !== 'undefined' ? self : this);
