/*
 * Crawdad 2026 — M2 validation (spec §11, M2)
 * Node:    node tests/test-network.js
 * Browser: open tests/test-network.html
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var NET, GEN, SCHEMA, CLEAN, STOP, parser, porter2;

  if (isNode) {
    NET = require('../js/network.js');
    GEN = require('../js/generator.js');
    SCHEMA = require('../js/craschema.js');
    CLEAN = require('../js/textclean.js');
    STOP = require('../js/stopwords.js');
    porter2 = require('wink-porter2-stemmer');
    parser = require('../js/parser.js').createParser(require('wink-nlp'), require('wink-eng-lite-web-model'), { compromise: require('compromise') });
  } else {
    NET = root.CrawdadNetwork; GEN = root.CrawdadGenerator; SCHEMA = root.CrawdadSchema;
    CLEAN = root.CrawdadTextClean; STOP = root.CrawdadStopWords;
    porter2 = root.CrawdadWink.porter2;
    parser = root.CrawdadParser.createParser();
  }
  var deps = { parser: parser, porter2: porter2, isStopWord: STOP.isStopWord,
               schema: SCHEMA, network: NET, textclean: CLEAN };

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function approx(a, b, eps) { return Math.abs(a - b) <= (eps || 1e-9); }

  /* Helper: build network from hand-specified phrases (bypasses POS tagger). */
  function netFromPhrases(sentPhrases, options) {
    var sentences = sentPhrases.map(function (p) { return { text: '', phrases: p }; });
    return NET.buildNetwork(sentences, options || {});
  }
  function edgeMap(net) {
    var m = {};
    net.edges.forEach(function (e) {
      m[net.words[e.source] + '|' + net.words[e.target]] = e.weight;
      m[net.words[e.target] + '|' + net.words[e.source]] = e.weight;
    });
    return m;
  }

  /* ---------- linking rules ---------- */

  t('L2: JHC p.176 example — "complex discursive system" links all 3 pairs', function () {
    var net = netFromPhrases([[['complex', 'discursive', 'system']]]);
    var em = edgeMap(net);
    assert(em['complex|discursive'] === 1, 'complex-discursive missing');
    assert(em['discursive|system'] === 1, 'discursive-system missing');
    assert(em['complex|system'] === 1, 'complex-system (non-adjacent) missing');
    assert(net.edges.length === 3, 'expected exactly 3 edges, got ' + net.edges.length);
  });

  t('L2 counts once per occurrence: adjacent pair weight stays 1 (L1 not double-counted)', function () {
    var net = netFromPhrases([[['complex', 'discursive', 'system']]]);
    var em = edgeMap(net);
    assert(em['complex|discursive'] === 1, 'adjacent pair double-counted: F=' + em['complex|discursive']);
  });

  t('L1: sequential link across phrases within a sentence', function () {
    // "old house" ... "river" -> house-river link (sequential stream)
    var net = netFromPhrases([[['old', 'house'], ['river']]]);
    var em = edgeMap(net);
    assert(em['old|house'] === 1 && em['house|river'] === 1, 'sequential links wrong');
    assert(!em['old|river'], 'old-river should NOT link (2-word phrase, different phrases)');
  });

  t('L3: inter-sentence bridge OFF by default (D-17, was on per D-1)', function () {
    var net = netFromPhrases([ [['king']], [['queen']] ]);
    assert(net.edges.length === 0, 'default should be JHC 2002 (no bridge)');
  });

  t('L3: bridge present when explicitly enabled', function () {
    var net = netFromPhrases([ [['king']], [['queen']] ], { interSentenceLinking: true });
    var em = edgeMap(net);
    assert(em['king|queen'] === 1, 'bridge missing');
  });

  t('L3: JHC 2002 mode disables inter-sentence bridge', function () {
    var net = netFromPhrases([ [['king']], [['queen']] ], { interSentenceLinking: false });
    assert(net.edges.length === 0, 'bridge should be absent');
  });

  t('L3: bridge skips sentences with no centers', function () {
    var net = netFromPhrases([ [['king']], [], [['queen']] ],
      { interSentenceLinking: true });
    var em = edgeMap(net);
    assert(em['king|queen'] === 1, 'bridge should skip empty sentence');
  });

  t('valued edges: repeated links accumulate F_ij (JHC mode isolates L1)', function () {
    var net = netFromPhrases([ [['supply', 'chain']], [['supply', 'chain']] ],
      { interSentenceLinking: false });
    var em = edgeMap(net);
    assert(em['supply|chain'] === 2, 'expected F=2, got ' + em['supply|chain']);
  });

  t('valued edges: L3 bridge adds to F_ij of an existing pair (chain->supply)', function () {
    var net = netFromPhrases([ [['supply', 'chain']], [['supply', 'chain']] ],
      { interSentenceLinking: true });
    var em = edgeMap(net);
    assert(em['supply|chain'] === 3, 'expected F=3 (2xL1 + 1xL3), got ' + em['supply|chain']);
  });

  t('no self-loops when stemming collapses adjacent words', function () {
    var net = netFromPhrases([[['system', 'system']]]);
    assert(net.edges.length === 0, 'self-loop created');
  });

  /* ---------- influence: reference betweenness values ---------- */

  t('star K1,4: center influence 1.0, leaves 0 (Freeman reference)', function () {
    // node 0 = center
    var edges = [1, 2, 3, 4].map(function (i) { return { source: 0, target: i, weight: 1 }; });
    var infl = NET.influence(5, edges);
    assert(approx(infl[0], 1), 'center: ' + infl[0]);
    [1, 2, 3, 4].forEach(function (i) { assert(approx(infl[i], 0), 'leaf ' + i); });
  });

  t('path P4 (a-b-c-d): ends 0, middles 2/3', function () {
    var edges = [{ source: 0, target: 1, weight: 1 }, { source: 1, target: 2, weight: 1 },
                 { source: 2, target: 3, weight: 1 }];
    var infl = NET.influence(4, edges);
    assert(approx(infl[0], 0) && approx(infl[3], 0), 'ends nonzero');
    assert(approx(infl[1], 2 / 3), 'b: ' + infl[1]);
    assert(approx(infl[2], 2 / 3), 'c: ' + infl[2]);
  });

  t('cycle C5: all nodes equal influence 1/6', function () {
    // Each node lies on 1 of the shortest paths for exactly one non-adjacent pair:
    // raw betweenness 0.5+0.5=1 per node / denom 6 = 1/6
    var edges = [];
    for (var i = 0; i < 5; i++) { edges.push({ source: i, target: (i + 1) % 5, weight: 1 }); }
    var infl = NET.influence(5, edges);
    infl.forEach(function (x, i) { assert(approx(x, 1 / 6), 'node ' + i + ': ' + x); });
  });

  t('disconnected graph: influence computed, unreachable pairs contribute 0', function () {
    // two separate paths of 3: middles have raw 1 / denom (5*4/2)=10
    var edges = [{ source: 0, target: 1, weight: 1 }, { source: 1, target: 2, weight: 1 },
                 { source: 3, target: 4, weight: 1 }, { source: 4, target: 5, weight: 1 }];
    var infl = NET.influence(6, edges);
    assert(approx(infl[1], 0.1), 'middle 1: ' + infl[1]);
    assert(approx(infl[4], 0.1), 'middle 4: ' + infl[4]);
    assert(approx(infl[0], 0), 'end');
  });

  t('star K1,4 summary: degree/betweenness/closeness centralization = 1', function () {
    var edges = [1, 2, 3, 4].map(function (i) { return { source: 0, target: i, weight: 1 }; });
    var infl = NET.influence(5, edges);
    var s = NET.summaryStats(5, edges, infl);
    assert(approx(s.centralization.degree, 1, 1e-5), 'degree: ' + s.centralization.degree);
    assert(approx(s.centralization.betweenness, 1, 1e-5), 'betweenness: ' + s.centralization.betweenness);
    assert(approx(s.centralization.closeness, 1, 1e-5), 'closeness: ' + s.centralization.closeness);
  });

  t('fragmentation: component count and largest-component share in summary', function () {
    // two disjoint paths of 3 -> 2 components, largest share 0.5
    var edges = [{ source: 0, target: 1, weight: 1 }, { source: 1, target: 2, weight: 1 },
                 { source: 3, target: 4, weight: 1 }, { source: 4, target: 5, weight: 1 }];
    var infl = NET.influence(6, edges);
    var s = NET.summaryStats(6, edges, infl);
    assert(s.componentCount === 2, 'components: ' + s.componentCount);
    assert(approx(s.largestComponentShare, 0.5, 1e-5), 'share: ' + s.largestComponentShare);
  });

  t('regression: _cra.md human table shows numeric centralization values, not n/a', function () {
    var text = 'The old king ruled the northern kingdom. The kingdom prospered ' +
      'under wise leadership. Wise leadership requires patient judgment.';
    var res = GEN.generate('toy.txt', text, {}, deps);
    var human = res.craMd.split('```json')[0];
    ['Degree centralization', 'Betweenness centralization',
     'Closeness centralization', 'Eigenvector centralization',
     'Mean influence'].forEach(function (label) {
      var m = human.match(new RegExp('\\| ' + label + ' \\| ([^|]+) \\|'));
      assert(m, label + ' row missing');
      assert(/^\d/.test(m[1].trim()), label + ' is not numeric: "' + m[1].trim() + '"');
    });
  });

  /* ---------- normalization ---------- */

  t('porter stemming merges "systems"/"system"; JHC connect/disconnect stay distinct', function () {
    assert(porter2('systems') === porter2('system'), 'plural not merged');
    assert(porter2('disconnect') !== porter2('connected'),
      'connect/disconnect conflated (JHC p. 175 concern)');
  });

  t('minimal stem: plural -s/-es only', function () {
    assert(NET.minimalStem('systems') === 'system');
    assert(NET.minimalStem('boxes') === 'box');
    assert(NET.minimalStem('analysis') === 'analysi' || NET.minimalStem('analysis') === 'analysis',
      'edge case tolerated');
    assert(NET.minimalStem('glass') === 'glass', '-ss must not strip');
  });

  t('display form = most frequent surface form', function () {
    var sentences = [
      { text: '', phrases: [['systems'], ['systems'], ['system']] }
    ];
    var norm = NET.normalize(sentences, { stemming: 'porter' },
      { porter2: porter2, isStopWord: STOP.isStopWord });
    assert(norm.displayForms[porter2('system')] === 'systems',
      'expected "systems" (2x) over "system" (1x)');
  });

  /* ---------- cleaning ---------- */

  t('cleaning: hyphenation repaired, page numbers and repeated headers dropped', function () {
    var raw = 'HEADER LINE JOURNAL\nThe organiza-\ntion performed well.\n42\n' +
      'HEADER LINE JOURNAL\nMore text here.\n43\nHEADER LINE JOURNAL\nEnd.\n44\nHEADER LINE JOURNAL\n';
    var c = CLEAN.cleanText(raw);
    assert(c.text.indexOf('organization') !== -1, 'hyphenation not repaired');
    assert(c.text.indexOf('HEADER LINE JOURNAL') === -1, 'running header kept');
    assert(!/^4[234]$/m.test(c.text), 'page numbers kept');
  });

  t('D-14b: "chased" auto-arbitrated as verb — no exclusion list needed', function () {
    // Kevin's bug report: verbs must be ignored automatically. wink tags
    // "chased" NOUN; the compromise second opinion corrects it.
    var text = 'White dog chased black cat. Dog was hungry.';
    var a = GEN.generate('t.txt', text, {}, deps);
    var words = a.craData.network.nodes.map(function (n) { return n.word; });
    assert(words.indexOf(porter2('chased')) === -1, '"chased" became a node');
    assert(words.indexOf(porter2('hungry')) !== -1, 'predicate adjective must be a node (WF 2h.i)');
    assert(words.indexOf(porter2('dog')) !== -1 && words.indexOf(porter2('cat')) !== -1,
      'real nouns must survive arbitration');
  });

  t('excludeWords option removes listed words and is recorded (D-14 escape hatch)', function () {
    var text = 'White dog chased black cat. Dog was hungry.';
    var b = GEN.generate('t.txt', text, { excludeWords: ['cat'] }, deps);
    var wordsB = b.craData.network.nodes.map(function (n) { return n.word; });
    assert(wordsB.indexOf(porter2('cat')) === -1, 'excluded word still a node');
    assert(b.craData.parameters.excludeWords[0] === 'cat', 'exclusion not recorded');
  });

  t('regression: "et al." and parenthetical citations produce no nodes', function () {
    var text = 'Centering theory guides the method (Grosz, Weinstein, & Joshi, 1995). ' +
      'Corman et al. developed the approach. Later work by Kuhn et al (2002a) extended it. ' +
      'The theory explains coherent communication.';
    var res = GEN.generate('cites.txt', text, {}, deps);
    var words = res.craData.network.nodes.map(function (n) { return n.word; });
    assert(words.indexOf('al') === -1, '"al" node created');
    assert(words.indexOf(porter2('grosz')) === -1, 'parenthetical citation author leaked');
    assert(words.indexOf(porter2('theory')) !== -1, 'real content lost');
  });

  t('stopword backstop: "al" filtered even if cleaning missed it', function () {
    assert(STOP.isStopWord('al') && STOP.isStopWord('ibid') && STOP.isStopWord('doi'));
    assert(!STOP.isStopWord('analysis') && !STOP.isStopWord('communication'));
  });

  t('tokenization: longest-first, case-insensitive, whole word', function () {
    var r = CLEAN.applySubstitutions(
      'Supply chain management and supply chain issues.',
      [['supply chain', 'SC'], ['supply chain management', 'SCM']]);
    assert(r.text.indexOf('SCM') !== -1, 'longest match not preferred');
    assert(r.text.indexOf('SC issues') !== -1, 'shorter match not applied');
  });

  /* ---------- end-to-end ---------- */

  t('end-to-end: generate() produces schema-valid, round-trippable _cra.md', function () {
    var text = 'The old king ruled the northern kingdom. The kingdom prospered ' +
      'under wise leadership. Wise leadership requires patient judgment.';
    var res = GEN.generate('toy.txt', text, {}, deps);
    var v = SCHEMA.validateCra(res.craData);
    assert(v.ok, v.errors.join('; '));
    var back = SCHEMA.parseCra(res.craMd);
    assert(back.ok, 'round-trip failed');
    assert(back.data.network.nodes.length === res.craData.network.nodes.length);
    var flat = res.craData.network.nodes.map(function (n) { return n.word; });
    assert(flat.indexOf(porter2('kingdom')) !== -1, 'kingdom node missing');
  });

  t('end-to-end: all influences in [0,1]; kingdom/leadership bridge words score high', function () {
    var text = 'The old king ruled the northern kingdom. The kingdom prospered ' +
      'under wise leadership. Wise leadership requires patient judgment.';
    var res = GEN.generate('toy.txt', text, {}, deps);
    res.craData.network.nodes.forEach(function (n) {
      assert(n.influence >= 0 && n.influence <= 1, n.word + ': ' + n.influence);
    });
    var byWord = {};
    res.craData.network.nodes.forEach(function (n) { byWord[n.word] = n; });
    var kingdom = byWord[porter2('kingdom')], king = byWord[porter2('king')];
    assert(kingdom.influence > king.influence,
      'kingdom (bridging) should outrank king (peripheral): ' +
      kingdom.influence + ' vs ' + king.influence);
  });

  t('end-to-end: tokenization file merges compounds into single nodes (fix 2026-08-09)', function () {
    var text = 'The supply chain fails often. Supply chain decisions matter. ' +
      'Managers improve the supply chain daily.';
    var res = GEN.generate('t.txt', text,
      { tokPairs: [['supply chain', 'supply_chain']], tokFileName: 'tok.csv' }, deps);
    var words = res.craData.network.nodes.map(function (n) { return n.word; });
    assert(words.indexOf('supply_chain') !== -1, 'compound node missing: ' + words.join(','));
    assert(words.indexOf('chain') === -1, 'compound split back apart: ' + words.join(','));
    // compounds are user-defined tokens: never stemmed
    var node = res.craData.network.nodes.filter(function (n) { return n.word === 'supply_chain'; })[0];
    assert(node.display === 'supply_chain', 'display form altered: ' + node.display);
  });

  t('end-to-end: reference list and citations stripped before parsing (2026-08-09)', function () {
    var text = 'Water systems need investment (Dooley et al. 2017). ' +
      'Investment shapes outcomes [12]. Outcomes matter for water systems. ' +
      'Systems thinking helps water research. Research needs careful methods. ' +
      'Methods define good research questions. Questions drive the field forward.\n\n' +
      'References\n\n' +
      'Thornbrugh, D., & Schloesser, J. T. (2019). Eutrophication. Aquatic Journal, 3(1), 1-20.\n' +
      'Scott, A. J. (2020). Infrastructure economics. Journal of Infrastructure, 8(4), 100-120.\n';
    var res = GEN.generate('t.txt', text, {}, deps);
    var words = res.craData.network.nodes.map(function (n) { return n.word; });
    assert(words.indexOf('thornbrugh') === -1 && words.indexOf('schloesser') === -1,
      'reference-list author names became nodes: ' + words.join(','));
    assert((res.craData.cleaningNotes || []).some(function (n) { return /reference list/i.test(n); }),
      'cleaning note for reference list missing');
  });

  t('end-to-end: adjacent co-occurrence tokenization suggestions (2026-08-09)', function () {
    var text = 'The supply chain fails. Supply chain decisions matter. ' +
      'The supply chain literature grows. Supply chain views differ.';
    var res = GEN.generate('t.txt', text, {}, deps);
    var sugg = res.craData.tokenSuggestions || [];
    assert(sugg.some(function (s) { return s.phrase === 'supply chain'; }),
      'expected "supply chain" suggestion, got: ' + JSON.stringify(sugg));
    assert(sugg.every(function (s) { return s.replacement.indexOf(' ') === -1; }),
      'replacements must be single tokens');
    // once applied, the pair is no longer suggested
    var res2 = GEN.generate('t.txt', text,
      { tokPairs: [['supply chain', 'supply_chain']] }, deps);
    assert(!(res2.craData.tokenSuggestions || []).some(function (s) { return s.phrase === 'supply chain'; }),
      'applied pair should not be re-suggested');
  });

  t('end-to-end: JHC 2002 mode yields fewer or equal edges', function () {
    var text = 'The king ruled. The queen watched. The castle stood.';
    var a = GEN.generate('t.txt', text, { interSentenceLinking: true }, deps);
    var b = GEN.generate('t.txt', text, { interSentenceLinking: false }, deps);
    assert(b.craData.network.edges.length < a.craData.network.edges.length,
      'expected fewer edges in JHC mode: ' + b.craData.network.edges.length +
      ' vs ' + a.craData.network.edges.length);
  });

  /* ---------- report ---------- */
  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'M2 network tests: ' + passed + '/' + results.length + ' passed';

  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadNetworkTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
