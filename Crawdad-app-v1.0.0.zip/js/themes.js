/*
 * Crawdad 2026 — M6: Theme Identifier + Latent Theme Identifier
 * (spec §7.4–§7.5; WF 7–8)
 *
 * Theme Identifier:
 *   - summed TOTAL influence per word across texts (zeros count; WF 7b)
 *   - top 50 words -> word-by-text influence matrix
 *   - PCA (D-7): words = observations, texts = variables. Components are
 *     extracted from the n×n correlation matrix of texts (Jacobi
 *     eigendecomposition — deterministic, all eigenpairs). Loadings
 *     a_ij = v_ij * sqrt(lambda_j); word scores = Z v_j identify the words
 *     defining each theme.
 *
 * Latent Theme Identifier:
 *   - user dictionary (theme, word) rows; words stemmed with the SAME
 *     pipeline settings as the _cra.md files; summed total influence per
 *     theme per text; coverage report for unmatched code words.
 */
(function (root) {
  'use strict';

  var TOP_WORDS = 50;

  /* ---------------- summed influence + matrix (WF 7b) ---------------- */

  function influenceMap(craData) {
    var m = {};
    craData.network.nodes.forEach(function (n) { m[n.word] = n.influence; });
    return m;
  }

  function displayMap(craData) {
    var m = {};
    craData.network.nodes.forEach(function (n) {
      if (!m[n.word]) { m[n.word] = n.display || n.word; }
    });
    return m;
  }

  /**
   * Build the top-N word-by-text influence matrix.
   * Returns { words: [{word, display, sum}], matrix: m×n, names: [...] }
   */
  function wordTextMatrix(datas, names, topN) {
    topN = topN || TOP_WORDS;
    var maps = datas.map(influenceMap);
    var disp = {};
    datas.forEach(function (d) {
      var dm = displayMap(d);
      Object.keys(dm).forEach(function (w) { if (!disp[w]) { disp[w] = dm[w]; } });
    });
    var sums = {};
    maps.forEach(function (m) {
      Object.keys(m).forEach(function (w) { sums[w] = (sums[w] || 0) + m[w]; });
    });
    var words = Object.keys(sums).map(function (w) {
      return { word: w, display: disp[w] || w, sum: sums[w] };
    }).sort(function (a, b) { return b.sum - a.sum || (a.word < b.word ? -1 : 1); })
      .slice(0, topN);
    var matrix = words.map(function (wr) {
      return maps.map(function (m) { return m[wr.word] || 0; });
    });
    return { words: words, matrix: matrix, names: names };
  }

  /* ---------------- PCA on correlation matrix of texts ---------------- */

  function correlationMatrix(matrix) {
    // columns = variables (texts), rows = observations (words)
    var m = matrix.length, n = matrix[0].length, i, j, k;
    var mean = new Array(n).fill(0), sd = new Array(n).fill(0);
    for (j = 0; j < n; j++) {
      for (i = 0; i < m; i++) { mean[j] += matrix[i][j]; }
      mean[j] /= m;
      for (i = 0; i < m; i++) { sd[j] += Math.pow(matrix[i][j] - mean[j], 2); }
      sd[j] = Math.sqrt(sd[j] / (m - 1));
    }
    var Z = [];
    for (i = 0; i < m; i++) {
      Z.push(new Array(n));
      for (j = 0; j < n; j++) {
        Z[i][j] = sd[j] > 0 ? (matrix[i][j] - mean[j]) / sd[j] : 0;
      }
    }
    var R = [];
    for (j = 0; j < n; j++) { R.push(new Array(n).fill(0)); }
    for (j = 0; j < n; j++) {
      for (k = j; k < n; k++) {
        var s = 0;
        for (i = 0; i < m; i++) { s += Z[i][j] * Z[i][k]; }
        s /= (m - 1);
        R[j][k] = s; R[k][j] = s;
      }
    }
    return { R: R, Z: Z, zeroVariance: sd.map(function (x) { return x === 0; }) };
  }

  /** Cyclic Jacobi eigendecomposition for symmetric matrices (deterministic). */
  function jacobiEig(Ain) {
    var n = Ain.length, i, j, p, q;
    var A = Ain.map(function (r) { return r.slice(); });
    var V = [];
    for (i = 0; i < n; i++) {
      V.push(new Array(n).fill(0)); V[i][i] = 1;
    }
    for (var sweep = 0; sweep < 100; sweep++) {
      var off = 0;
      for (p = 0; p < n; p++) {
        for (q = p + 1; q < n; q++) { off += A[p][q] * A[p][q]; }
      }
      if (off < 1e-22) { break; }
      for (p = 0; p < n - 1; p++) {
        for (q = p + 1; q < n; q++) {
          if (Math.abs(A[p][q]) < 1e-15) { continue; }
          var theta = (A[q][q] - A[p][p]) / (2 * A[p][q]);
          var t = (theta >= 0 ? 1 : -1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
          var c = 1 / Math.sqrt(t * t + 1), s = t * c;
          for (i = 0; i < n; i++) {
            var aip = A[i][p], aiq = A[i][q];
            A[i][p] = c * aip - s * aiq;
            A[i][q] = s * aip + c * aiq;
          }
          for (i = 0; i < n; i++) {
            var api = A[p][i], aqi = A[q][i];
            A[p][i] = c * api - s * aqi;
            A[q][i] = s * api + c * aqi;
          }
          for (i = 0; i < n; i++) {
            var vip = V[i][p], viq = V[i][q];
            V[i][p] = c * vip - s * viq;
            V[i][q] = s * vip + c * viq;
          }
        }
      }
    }
    var pairs = [];
    for (i = 0; i < n; i++) {
      var vec = [];
      for (j = 0; j < n; j++) { vec.push(V[j][i]); }
      pairs.push({ value: A[i][i], vector: vec });
    }
    pairs.sort(function (a, b) { return b.value - a.value; });
    // sign convention: largest-|.| element positive (matches test reference)
    pairs.forEach(function (pr) {
      var mi = 0;
      for (i = 1; i < n; i++) { if (Math.abs(pr.vector[i]) > Math.abs(pr.vector[mi])) { mi = i; } }
      if (pr.vector[mi] < 0) { pr.vector = pr.vector.map(function (x) { return -x; }); }
    });
    return pairs;
  }

  /* ---------------- varimax rotation (D-9) ---------------- */

  /**
   * Varimax rotation with Kaiser normalization (pairwise-rotation algorithm).
   * A: loadings matrix (n rows × k columns), k >= 2.
   * Returns { loadings, rotation (k×k), sweeps }.
   */
  function varimax(Ain) {
    var n = Ain.length, k = Ain[0].length, i, p, q;
    if (k < 2) { return { loadings: Ain.map(function (r) { return r.slice(); }),
                          rotation: [[1]], sweeps: 0 }; }
    // Kaiser normalization: scale rows to unit communality
    var h = Ain.map(function (r) {
      var s = Math.sqrt(r.reduce(function (a, v) { return a + v * v; }, 0));
      return s > 0 ? s : 1;
    });
    var A = Ain.map(function (r, ri) { return r.map(function (v) { return v / h[ri]; }); });
    var R = [];
    for (i = 0; i < k; i++) { R.push(new Array(k).fill(0)); R[i][i] = 1; }

    var sweeps;
    for (sweeps = 0; sweeps < 1000; sweeps++) {
      var totalAngle = 0;
      for (p = 0; p < k - 1; p++) {
        for (q = p + 1; q < k; q++) {
          var su = 0, sv = 0, suv = 0, su2v2 = 0;
          for (i = 0; i < n; i++) {
            var u = A[i][p] * A[i][p] - A[i][q] * A[i][q];
            var v = 2 * A[i][p] * A[i][q];
            su += u; sv += v; suv += u * v; su2v2 += u * u - v * v;
          }
          var num = 2 * (suv - su * sv / n);
          var den = su2v2 - (su * su - sv * sv) / n;
          var phi = 0.25 * Math.atan2(num, den);
          if (Math.abs(phi) < 1e-12) { continue; }
          totalAngle += Math.abs(phi);
          var c = Math.cos(phi), s = Math.sin(phi);
          for (i = 0; i < n; i++) {
            var ap = A[i][p], aq = A[i][q];
            A[i][p] = c * ap + s * aq;
            A[i][q] = -s * ap + c * aq;
          }
          for (i = 0; i < k; i++) {
            var rp = R[i][p], rq = R[i][q];
            R[i][p] = c * rp + s * rq;
            R[i][q] = -s * rp + c * rq;
          }
        }
      }
      if (totalAngle < 1e-14) { break; }
    }
    // denormalize
    var L = A.map(function (r, ri) { return r.map(function (v) { return v * h[ri]; }); });
    return { loadings: L, rotation: R, sweeps: sweeps };
  }

  /** Canonical presentation: order columns by SS loadings desc, largest-|.| positive. */
  function canonicalize(L, alsoRotate) {
    var k = L[0].length;
    var ss = [];
    for (var j = 0; j < k; j++) {
      var s = 0;
      for (var i = 0; i < L.length; i++) { s += L[i][j] * L[i][j]; }
      ss.push({ j: j, ss: s });
    }
    ss.sort(function (a, b) { return b.ss - a.ss; });
    var signs = ss.map(function (o) {
      var mi = 0;
      for (var i = 1; i < L.length; i++) {
        if (Math.abs(L[i][o.j]) > Math.abs(L[mi][o.j])) { mi = i; }
      }
      return L[mi][o.j] < 0 ? -1 : 1;
    });
    function apply(M) {
      return M.map(function (r) {
        return ss.map(function (o, jj) { return r[o.j] * signs[jj]; });
      });
    }
    return { loadings: apply(L), ssLoadings: ss.map(function (o) { return o.ss; }),
             apply: apply };
  }

  /**
   * PCA per D-7. Returns { eigenvalues, loadings (n×n: text i on comp j),
   * wordScores (m×n: word i on comp j, standardized), zeroVariance,
   * rotated: null | { k, loadings (n×k), ssLoadings, wordScores (m×k) } }
   * Rotation (D-9): varimax on components with eigenvalue > 1 (Kaiser
   * criterion); requires k >= 2, else rotated = null.
   */
  function pca(matrix) {
    var cm = correlationMatrix(matrix);
    var pairs = jacobiEig(cm.R);
    var n = cm.R.length, m = matrix.length;
    var eigenvalues = pairs.map(function (p) { return p.value; });
    var loadings = [];
    for (var i = 0; i < n; i++) {
      loadings.push(pairs.map(function (p) {
        return p.vector[i] * Math.sqrt(Math.max(p.value, 0));
      }));
    }
    // Word scores STANDARDIZED to z-units: raw component scores t = Z v have
    // variance lambda across words, so t / sqrt(lambda) has unit variance.
    // (Raw scores are unbounded and were misread as loadings; loadings are
    // the text columns and are bounded by 1.)
    var wordScores = [];
    for (var w = 0; w < m; w++) {
      wordScores.push(pairs.map(function (p) {
        var s = 0;
        for (var j = 0; j < n; j++) { s += cm.Z[w][j] * p.vector[j]; }
        return p.value > 1e-12 ? s / Math.sqrt(p.value) : 0;
      }));
    }
    // ---- varimax on eigenvalue > 1 components (D-9) ----
    var kRetain = eigenvalues.filter(function (ev) { return ev > 1.0; }).length;
    var rotated = null;
    if (kRetain >= 2) {
      var Asub = loadings.map(function (r) { return r.slice(0, kRetain); });
      var vr = varimax(Asub);
      var canon = canonicalize(vr.loadings);
      // rotate the standardized word scores by the same rotation, then apply
      // the same column ordering/signs (orthogonal rotation of unit-variance
      // uncorrelated scores keeps them unit-variance)
      var scoresSub = wordScores.map(function (r) {
        var out = new Array(kRetain).fill(0);
        for (var j = 0; j < kRetain; j++) {
          for (var jj = 0; jj < kRetain; jj++) { out[j] += r[jj] * vr.rotation[jj][j]; }
        }
        return out;
      });
      rotated = {
        k: kRetain,
        loadings: canon.loadings,
        ssLoadings: canon.ssLoadings,
        wordScores: canon.apply(scoresSub)
      };
    }

    return { eigenvalues: eigenvalues, loadings: loadings,
             wordScores: wordScores, zeroVariance: cm.zeroVariance,
             rotated: rotated };
  }

  /* ---------------- Theme report (WF 7d) ---------------- */

  function fmt(x) { return Number(x).toFixed(4); }

  function themeReport(datas, names, citation, topN) {
    var wtm = wordTextMatrix(datas, names, topN);
    var res = pca(wtm.matrix);
    var n = names.length;
    var L = [];
    L.push('# Crawdad Theme Identifier: ' + n + ' texts');
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- Method: summed total influence per word (zeros included); top ' +
      wtm.words.length + ' words; PCA on the correlation matrix of texts ' +
      '(words = observations, texts = variables; spec D-7).');
    L.push('- Color coding: eigenvalue > 1.0 and |loading| > 0.4 (WF 7d).');
    if (res.zeroVariance.some(Boolean)) {
      L.push('- **Warning:** text(s) with zero variance across the top words: ' +
        names.filter(function (_, i) { return res.zeroVariance[i]; }).join(', ') +
        ' — their correlations are undefined and set to 0.');
    }
    L.push('');
    L.push('## Components (ordered by eigenvalue)');
    L.push('');
    var head = '<table><thead><tr><th>Component</th><th>Eigenvalue</th><th>% variance</th>';
    names.forEach(function (nm) { head += '<th>' + nm + ' loading</th>'; });
    head += '</tr></thead><tbody>';
    var rows = [head];
    var totVar = res.eigenvalues.reduce(function (a, b) { return a + Math.max(b, 0); }, 0);
    for (var j = 0; j < n; j++) {
      var ev = res.eigenvalues[j];
      var r = '<tr><td>Theme ' + (j + 1) + '</td>' +
        '<td style="' + (ev > 1 ? 'background-color:#ffe08a;font-weight:bold' : '') + '">' +
        fmt(ev) + '</td><td>' + (totVar > 0 ? (100 * Math.max(ev, 0) / totVar).toFixed(1) : '0') + '%</td>';
      for (var i = 0; i < n; i++) {
        var ld = res.loadings[i][j];
        r += '<td style="' + (Math.abs(ld) > 0.4 ? 'background-color:#f6c3bc;font-weight:bold' : '') +
          '">' + fmt(ld) + '</td>';
      }
      rows.push(r + '</tr>');
    }
    rows.push('</tbody></table>');
    L.push(rows.join(''));
    L.push('');
    // ---- varimax-rotated solution (D-9) ----
    if (res.rotated) {
      var rot = res.rotated;
      L.push('## Varimax-rotated solution (' + rot.k +
        ' components with eigenvalue > 1, Kaiser criterion)');
      L.push('');
      L.push('*Orthogonal rotation for simple structure: themes remain uncorrelated, ' +
        'loadings are redistributed so each text/word loads on as few themes as possible.*');
      L.push('');
      var rh = '<table><thead><tr><th>Rotated theme</th><th>SS loadings</th><th>% variance</th>';
      names.forEach(function (nm) { rh += '<th>' + nm + ' loading</th>'; });
      rh += '</tr></thead><tbody>';
      var rrows = [rh];
      for (j = 0; j < rot.k; j++) {
        var rr = '<tr><td>Rotated theme ' + (j + 1) + '</td><td>' + fmt(rot.ssLoadings[j]) +
          '</td><td>' + (totVar > 0 ? (100 * rot.ssLoadings[j] / totVar).toFixed(1) : '0') + '%</td>';
        for (i = 0; i < n; i++) {
          var rld = rot.loadings[i][j];
          rr += '<td style="' + (Math.abs(rld) > 0.4 ? 'background-color:#f6c3bc;font-weight:bold' : '') +
            '">' + fmt(rld) + '</td>';
        }
        rrows.push(rr + '</tr>');
      }
      rrows.push('</tbody></table>');
      L.push(rrows.join(''));
      L.push('');
      L.push('*(After rotation, eigenvalues become sums of squared loadings; they no longer ' +
        'decrease as steeply because variance is redistributed across rotated themes.)*');
      L.push('');
    } else {
      L.push('*Varimax rotation not applicable: fewer than 2 components have eigenvalue > 1.*');
      L.push('');
    }

    var scoreSource = res.rotated ? res.rotated.wordScores : res.wordScores;
    var scoreCount = res.rotated ? res.rotated.k : n;
    var scoreLabel = res.rotated ? 'rotated theme' : 'component';
    L.push('## Defining words per ' + scoreLabel + ' (top 10 by |standardized word score|)');
    L.push('');
    L.push('*Word scores are standardized component scores (z-units, typically within ±3); ' +
      'they are NOT loadings. Loadings — bounded by 1 — are the text columns in the tables above.*');
    L.push('');
    for (j = 0; j < scoreCount; j++) {
      var scored = wtm.words.map(function (wr, wi) {
        return { display: wr.display, score: scoreSource[wi][j] };
      }).sort(function (a, b) { return Math.abs(b.score) - Math.abs(a.score); }).slice(0, 10);
      L.push('- **' + (res.rotated ? 'Rotated theme ' : 'Theme ') + (j + 1) + '**: ' +
        scored.map(function (s) {
          return s.display + ' (' + (s.score >= 0 ? '+' : '') + s.score.toFixed(2) + ')';
        }).join(', '));
    }
    L.push('');
    L.push('## Top ' + wtm.words.length + ' words by summed total influence');
    L.push('');
    var h2 = '| Word | Summed influence |' + names.map(function (nm) { return ' ' + nm + ' |'; }).join('');
    L.push(h2);
    L.push('|---|---|' + names.map(function () { return '---|'; }).join(''));
    wtm.words.forEach(function (wr, wi) {
      L.push('| ' + wr.display + ' | ' + wr.sum.toFixed(5) + ' |' +
        wtm.matrix[wi].map(function (v) { return ' ' + v.toFixed(5) + ' |'; }).join(''));
    });
    L.push('');
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-themes', schemaVersion: '1.0',
      names: names, words: wtm.words, matrix: wtm.matrix,
      eigenvalues: res.eigenvalues, loadings: res.loadings,
      rotated: res.rotated ? { k: res.rotated.k, loadings: res.rotated.loadings,
        ssLoadings: res.rotated.ssLoadings } : null }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    L.push('*' + citation + '*');
    L.push('');
    return { markdown: L.join('\n'), wtm: wtm, pca: res };
  }

  /* ---------------- Latent Theme Identifier (WF 8) ---------------- */

  /**
   * rows: [[theme, wordOrCommaList], ...]  ->  { themeName: [stemmedWords] }
   * stemFn applied to each word (must match the files' stemming setting).
   */
  function parseLatentCodes(rows, stemFn) {
    var themes = {};
    rows.forEach(function (r) {
      var theme = String(r[0] || '').trim();
      if (!theme) { return; }
      String(r[1] || '').split(/[,;]/).forEach(function (w) {
        w = w.trim().toLowerCase();
        if (!w) { return; }
        (themes[theme] = themes[theme] || []).push(stemFn(w));
      });
    });
    return themes;
  }

  /**
   * Summed total influence of each theme's words in each text (absent = 0).
   * Returns { table: {theme: [perText]}, coverage: {found:[], missing:[]} }
   */
  function latentScores(datas, themes) {
    var maps = datas.map(influenceMap);
    var table = {}, found = {}, missing = {};
    Object.keys(themes).forEach(function (t) {
      table[t] = datas.map(function () { return 0; });
      themes[t].forEach(function (w) {
        var hit = false;
        maps.forEach(function (m, i) {
          if (m.hasOwnProperty(w)) { table[t][i] += m[w]; hit = true; }
        });
        (hit ? found : missing)[w] = true;
      });
    });
    return { table: table,
      coverage: { found: Object.keys(found).sort(), missing: Object.keys(missing).sort() } };
  }

  function latentReport(datas, names, themes, citation, stemModeNote) {
    var res = latentScores(datas, themes);
    var L = [];
    L.push('# Crawdad Latent Theme Identifier: ' + names.length + ' text(s), ' +
      Object.keys(themes).length + ' theme(s)');
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- Scoring: summed total influence of each theme\'s words per text (absent words contribute 0).');
    if (stemModeNote) { L.push('- ' + stemModeNote); }
    L.push('');
    L.push('## Theme scores');
    L.push('');
    L.push('| Theme |' + names.map(function (nm) { return ' ' + nm + ' |'; }).join(''));
    L.push('|---|' + names.map(function () { return '---|'; }).join(''));
    Object.keys(themes).forEach(function (t) {
      L.push('| ' + t + ' |' + res.table[t].map(function (v) {
        return ' ' + v.toFixed(5) + ' |'; }).join(''));
    });
    L.push('');
    L.push('## Coverage');
    L.push('');
    L.push('- Code words found in at least one text: ' + res.coverage.found.length);
    L.push('- Code words found in NO text: ' + res.coverage.missing.length +
      (res.coverage.missing.length
        ? ' — **' + res.coverage.missing.join(', ') + '** (check spelling/stemming; ' +
          'silent zero-matching is a validity trap)'
        : ''));
    L.push('');
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-latent-themes', schemaVersion: '1.0',
      names: names, themes: themes, table: res.table, coverage: res.coverage }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    L.push('*' + citation + '*');
    L.push('');
    return { markdown: L.join('\n'), result: res };
  }

  /* ---------------- Summarizer (spec §7.6; WF 9) ---------------- */

  function summarizerReport(datas, names, citation) {
    var wtm = wordTextMatrix(datas, names);
    var L = [];
    L.push('# Crawdad Summarizer: ' + names.length + ' texts');
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- Method: top ' + wtm.words.length + ' words by summed total influence across all ' +
      'texts (zeros included), with each word\'s influence per text (WF 9 / Theme Identifier step b).');
    L.push('');
    L.push('## Most influential words across the corpus');
    L.push('');
    L.push('| Rank | Word | Summed influence |' +
      names.map(function (nm) { return ' ' + nm + ' |'; }).join(''));
    L.push('|---|---|---|' + names.map(function () { return '---|'; }).join(''));
    wtm.words.forEach(function (wr, wi) {
      L.push('| ' + (wi + 1) + ' | ' + wr.display + ' | ' + wr.sum.toFixed(5) + ' |' +
        wtm.matrix[wi].map(function (v) { return ' ' + v.toFixed(5) + ' |'; }).join(''));
    });
    L.push('');
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-summary', schemaVersion: '1.0',
      names: names, words: wtm.words, matrix: wtm.matrix }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    L.push('*' + citation + '*');
    L.push('');
    return { markdown: L.join('\n'), wtm: wtm };
  }

  var api = {
    TOP_WORDS: TOP_WORDS,
    summarizerReport: summarizerReport,
    wordTextMatrix: wordTextMatrix,
    correlationMatrix: correlationMatrix,
    jacobiEig: jacobiEig,
    varimax: varimax,
    pca: pca,
    themeReport: themeReport,
    parseLatentCodes: parseLatentCodes,
    latentScores: latentScores,
    latentReport: latentReport
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadThemes = api; }
})(typeof self !== 'undefined' ? self : this);
