/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M1 — custom dictionary loader tests.
 * Node:    node tests/test-lexicons.js
 * Browser: open tests/test-lexicons.html
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var L = isNode ? require('../js/lexicons.js') : root.CrawdadLexicons;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function toks(words) { return words.map(function (w) { return { w: w, pos: 'NOUN' }; }); }

  /* ---- SHA-256 (NIST vectors) ---- */
  t('sha256: NIST test vectors', function () {
    assert(L.sha256Hex('abc') ===
      'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', 'abc');
    assert(L.sha256Hex('') ===
      'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'empty');
    assert(L.sha256Hex('abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq') ===
      '248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1', '448-bit');
  });

  t('sha256: multibyte UTF-8', function () {
    // echo -n "Iridium — ✓" | sha256sum
    assert(L.sha256Hex('Iridium — ✓').length === 64, 'hex length');
    assert(L.sha256Hex('é') !== L.sha256Hex('e'), 'multibyte distinct');
  });

  /* ---- parsing ---- */
  t('scored shape detected via non-numeric header + numeric rows', function () {
    var d = L.parseDictionary([['word', 'valence', 'arousal'],
      ['calm', '0.2', '0.1'], ['panic', '-0.8', '0.9']]);
    assert(d.type === 'scored', 'type: ' + d.type);
    assert(d.columns.join(',') === 'valence,arousal', 'columns: ' + d.columns);
    assert(d.entries.length === 2 && d.entries[1].values[1] === 0.9, 'entries');
  });

  t('categorical shape detected when second column is not numeric', function () {
    var d = L.parseDictionary([['profit', 'Finance'], ['loss', 'Finance'], ['rocket', 'Tech']]);
    assert(d.type === 'categorical', 'type: ' + d.type);
    assert(d.entries.length === 3 && d.entries[2].category === 'Tech', 'entries');
  });

  t('rows without a category are skipped with an error', function () {
    var d = L.parseDictionary([['profit', 'Finance'], ['orphan'], ['loss', 'Finance']]);
    assert(d.entries.length === 2 && d.errors.length === 1, JSON.stringify(d.errors));
  });

  /* ---- application ---- */
  t('scored: mean over matched tokens; coverage computed', function () {
    var d = L.parseDictionary([['word', 'v'], ['good', '2'], ['bad', '-2']]);
    var r = L.applyDictionary(toks(['good', 'bad', 'good', 'table']), d, { mode: 'exact' });
    assert(r.metrics.v.mean === 0.6667, 'mean (4 dp): ' + r.metrics.v.mean);
    assert(r.coverage === 0.75 && r.matchedTokens === 3, 'coverage: ' + r.coverage);
  });

  t('categorical: rate per 1000 tokens', function () {
    var d = L.parseDictionary([['profit', 'Finance'], ['rocket', 'Tech']]);
    var r = L.applyDictionary(toks(['profit', 'rocket', 'profit', 'x', 'y']), d, { mode: 'exact' });
    assert(r.metrics.Finance.per1000 === 400 && r.metrics.Tech.per1000 === 200,
      JSON.stringify(r.metrics));
  });

  t('trailing * gives prefix matching, longest prefix wins', function () {
    var d = L.parseDictionary([['negoti*', 'Deal'], ['negotiator*', 'People']]);
    var r = L.applyDictionary(toks(['negotiation', 'negotiators', 'nothing']), d, { mode: 'exact' });
    assert(r.metrics.Deal.n === 1 && r.metrics.People.n === 1, JSON.stringify(r.metrics));
  });

  t('stemmed matching uses supplied stemmer', function () {
    var stem = function (w) { return w.replace(/s$/, ''); };
    var d = L.parseDictionary([['satellites', 'Tech']]);
    assert(d.type === 'categorical', 'single-row file reads as categorical');
    var r = L.applyDictionary(toks(['satellite', 'satellites']), d,
      { mode: 'stem', stemFn: stem });
    assert(r.metrics.Tech.n === 2, 'both should match via stem: ' + JSON.stringify(r.metrics));
  });

  t('low coverage flagged below 60%', function () {
    var d = L.parseDictionary([['rare', 'X']]);
    var r = L.applyDictionary(toks(['rare', 'a', 'b', 'c', 'd']), d, { mode: 'exact' });
    assert(r.lowCoverage === true && r.coverage === 0.2, JSON.stringify(r));
  });

  t('Object.prototype key words are safe dictionary entries', function () {
    var d = L.parseDictionary([['constructor', 'Meta'], ['valueof', 'Meta']]);
    var r = L.applyDictionary(toks(['constructor', 'plain']), d, { mode: 'exact' });
    assert(r.metrics.Meta.n === 1 && r.coverage === 0.5, JSON.stringify(r));
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M1 dictionary tests: ' + passed + '/' + results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadLexiconTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
