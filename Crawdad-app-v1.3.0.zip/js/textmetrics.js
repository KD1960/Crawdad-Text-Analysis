/*
 * Crawdad 2026 — D-12: text-level metrics for _cra.md files.
 *
 * Methods and citations (documented per metric; heuristics labeled):
 *  - Sentiment: AFINN-165 word list via wink-sentiment (Nielsen, 2011).
 *    Mean of per-sentence normalized scores; > 0 positive, < 0 negative.
 *  - Gendered (masculine vs. feminine) language: agentic/communal word-stem
 *    lists from Gaucher, Friesen, & Kay (2011, JPSP). Index in [-1, 1]:
 *    +1 all masculine-coded, -1 all feminine-coded.
 *  - Abstract vs. concrete: HEURISTIC PROXY — proportion of nouns carrying
 *    abstract-forming suffixes (-tion, -ness, -ity, ...). For research-grade
 *    measurement use the Brysbaert, Warriner, & Kuperman (2014) norms; those
 *    40k ratings are too large to bundle here. Index in [0, 1]: higher = more abstract.
 *  - Agreeableness vs. disagreeableness: HEURISTIC — no validated public
 *    lexicon exists (LIWC is proprietary). Counts agreement vs. disagreement/
 *    adversative markers. Index in [-1, 1]: + agreeable, - disagreeable.
 *  - Lexical diversity: MTLD (McCarthy & Jarvis, 2010), length-robust;
 *    TTR reported for reference (length-sensitive).
 *  - Lexical density: content words (N, V, ADJ, ADV, PROPN) / all words
 *    (Ure, 1971).
 *  - Readability: Flesch Reading Ease + Flesch-Kincaid grade (Kincaid et al.,
 *    1975), heuristic syllable counter.
 *  - Cohesion: Coh-Metrix-style referential cohesion (Graesser, McNamara,
 *    Louwerse, & Cai, 2004): proportion of adjacent sentence pairs sharing
 *    >= 1 noun (stem match), plus global (all-pairs) overlap.
 */
(function (root) {
  'use strict';

  /* ---------------- lexicons ---------------- */

  // Gaucher, Friesen & Kay (2011) — agentic (masculine-coded) and communal
  // (feminine-coded) word STEMS (prefix match).
  var MASCULINE_STEMS = ['activ', 'adventur', 'aggress', 'ambitio', 'analy', 'assert',
    'athlet', 'autonom', 'boast', 'challeng', 'compet', 'confident', 'courag',
    'decid', 'decisi', 'determin', 'dominan', 'domina', 'force', 'greedy',
    'headstrong', 'hierarch', 'hostil', 'impulsive', 'independen', 'individual',
    'intellect', 'lead', 'logic', 'masculine', 'objective', 'opinion', 'outspoken',
    'persist', 'principle', 'reckless', 'selfconfiden', 'self-confiden', 'selfrelian',
    'self-relian', 'selfsufficien', 'self-sufficien', 'stubborn', 'superior'];
  var FEMININE_STEMS = ['affectionate', 'childr', 'cheer', 'commit', 'communal',
    'compassion', 'connect', 'considerate', 'cooperat', 'depend', 'emotiona',
    'empath', 'feminine', 'flatterable', 'gentle', 'honest', 'interpersonal',
    'interdependen', 'kind', 'kinship', 'loyal', 'modesty', 'nag', 'nurtur',
    'pleasant', 'polite', 'quiet', 'respon', 'sensitiv', 'submissive', 'support',
    'sympath', 'tender', 'together', 'trust', 'understand', 'warm', 'whin',
    'yield'];

  var AGREE_WORDS = ['agree', 'agrees', 'agreed', 'agreement', 'accept', 'accepts',
    'accepted', 'support', 'supports', 'supported', 'endorse', 'endorses', 'endorsed',
    'concur', 'concurs', 'concurred', 'consensus', 'cooperate', 'cooperates',
    'cooperated', 'cooperation', 'collaborate', 'collaboration', 'welcome', 'welcomes',
    'welcomed', 'approve', 'approves', 'approved', 'approval', 'affirm', 'affirms',
    'affirmed', 'yes', 'indeed', 'certainly', 'absolutely'];
  var DISAGREE_WORDS = ['disagree', 'disagrees', 'disagreed', 'disagreement', 'reject',
    'rejects', 'rejected', 'rejection', 'refuse', 'refuses', 'refused', 'refusal',
    'oppose', 'opposes', 'opposed', 'opposition', 'deny', 'denies', 'denied', 'denial',
    'dispute', 'disputes', 'disputed', 'object', 'objects', 'objected', 'objection',
    'conflict', 'conflicts', 'contradict', 'contradicts', 'contradicted', 'however',
    'nevertheless', 'nonetheless', 'contrary', 'wrong', 'incorrect', 'false', 'fault',
    'blame', 'blames', 'blamed', 'criticize', 'criticizes', 'criticized', 'criticism',
    'no', 'not', 'never'];

  var ABSTRACT_SUFFIX = /(tion|sion|ness|ity|ism|ment|ance|ence|ship|hood|acy|ology|ability|ibility)s?$/;

  // Hyland (2005) — representative hedges and boosters (certainty markers)
  var HEDGE_WORDS = ['may', 'might', 'could', 'would', 'perhaps', 'possibly', 'possible',
    'probably', 'probable', 'likely', 'unlikely', 'suggest', 'suggests', 'suggested',
    'seem', 'seems', 'seemed', 'appear', 'appears', 'appeared', 'indicate', 'indicates',
    'indicated', 'assume', 'assumes', 'assumed', 'estimate', 'estimated', 'approximately',
    'roughly', 'about', 'around', 'somewhat', 'relatively', 'fairly', 'quite', 'rather',
    'generally', 'usually', 'often', 'sometimes', 'occasionally', 'tend', 'tends',
    'tended', 'apparently', 'arguably', 'presumably', 'supposedly', 'allegedly',
    'reportedly', 'largely', 'mainly', 'mostly', 'partially', 'potentially', 'typical',
    'typically', 'plausible', 'plausibly', 'uncertain', 'unclear'];
  var BOOSTER_WORDS = ['certainly', 'certain', 'definitely', 'definite', 'clearly',
    'clear', 'obviously', 'obvious', 'undoubtedly', 'doubtless', 'always', 'never',
    'must', 'prove', 'proves', 'proved', 'proven', 'demonstrate', 'demonstrates',
    'demonstrated', 'establish', 'establishes', 'established', 'conclusively',
    'absolutely', 'surely', 'indeed', 'unquestionably', 'invariably', 'undeniably',
    'evident', 'evidently', 'truly', 'actually', 'really', 'know', 'knows', 'known',
    'show', 'shows', 'showed', 'shown', 'fact', 'facts'];

  var PRON_FIRST_SG = { i: 1, me: 1, my: 1, mine: 1, myself: 1 };
  var PRON_FIRST_PL = { we: 1, us: 1, our: 1, ours: 1, ourselves: 1 };
  var PRON_SECOND = { you: 1, your: 1, yours: 1, yourself: 1, yourselves: 1 };
  var PRON_THIRD = { he: 1, she: 1, him: 1, her: 1, his: 1, hers: 1, himself: 1,
    herself: 1, they: 1, them: 1, their: 1, theirs: 1, themselves: 1, it: 1, its: 1,
    itself: 1 };

  var BE_FORMS = { be: 1, is: 1, are: 1, was: 1, were: 1, been: 1, being: 1, am: 1,
    "isn't": 1, "aren't": 1, "wasn't": 1, "weren't": 1 };
  var ARTICLES = { the: 1, a: 1, an: 1 };

  /* ---------------- helpers ---------------- */

  function allTokens(sentences) {
    var out = [];
    sentences.forEach(function (s) {
      (s.tokens || []).forEach(function (t) { out.push(t); });
    });
    return out;
  }

  /** Heuristic English syllable counter (standard vowel-group method). */
  function syllables(word) {
    var w = word.toLowerCase().replace(/[^a-z]/g, '');
    if (w.length <= 3) { return w.length > 0 ? 1 : 0; }
    // silent final e dropped, EXCEPT consonant+le ("table", "little") which
    // forms its own syllable
    if (!/[^aeiouy]le$/.test(w)) { w = w.replace(/e$/, ''); }
    var groups = w.match(/[aeiouy]{1,2}/g);
    return Math.max(1, groups ? groups.length : 1);
  }

  function round4(x) { return Math.round(x * 1e4) / 1e4; }

  /* ---------------- individual metrics ---------------- */

  function sentimentScore(sentences, sentimentFn) {
    if (!sentimentFn) { return null; }
    var scores = [];
    sentences.forEach(function (s) {
      if (s.text && s.text.trim()) {
        // wink-sentiment normalizedScore = mean AFINN valence of sentiment
        // words, on AFINN's native -5..+5 scale; divide by 5 to report on
        // the conventional -1..+1 scale
        scores.push((sentimentFn(s.text).normalizedScore || 0) / 5);
      }
    });
    if (!scores.length) { return null; }
    var mean = scores.reduce(function (a, b) { return a + b; }, 0) / scores.length;
    return round4(Math.max(-1, Math.min(1, mean)));
  }

  function genderedLanguage(tokens) {
    var m = 0, f = 0;
    tokens.forEach(function (t) {
      var w = t.w;
      for (var i = 0; i < MASCULINE_STEMS.length; i++) {
        if (w.indexOf(MASCULINE_STEMS[i]) === 0) { m++; return; }
      }
      for (i = 0; i < FEMININE_STEMS.length; i++) {
        if (w.indexOf(FEMININE_STEMS[i]) === 0) { f++; return; }
      }
    });
    var n = tokens.length || 1;
    return {
      masculinePer1000: round4(1000 * m / n),
      femininePer1000: round4(1000 * f / n),
      index: (m + f) > 0 ? round4((m - f) / (m + f)) : 0
    };
  }

  function abstractness(tokens) {
    var nouns = tokens.filter(function (t) { return t.pos === 'NOUN'; });
    if (!nouns.length) { return null; }
    var abs = nouns.filter(function (t) { return ABSTRACT_SUFFIX.test(t.w); }).length;
    return round4(abs / nouns.length);
  }

  function agreeableness(tokens) {
    var a = 0, d = 0;
    var A = {}, D = {};
    AGREE_WORDS.forEach(function (w) { A[w] = true; });
    DISAGREE_WORDS.forEach(function (w) { D[w] = true; });
    tokens.forEach(function (t) {
      if (A[t.w]) { a++; } else if (D[t.w]) { d++; }
    });
    var n = tokens.length || 1;
    return {
      agreePer1000: round4(1000 * a / n),
      disagreePer1000: round4(1000 * d / n),
      index: (a + d) > 0 ? round4((a - d) / (a + d)) : 0
    };
  }

  /** MTLD (McCarthy & Jarvis 2010): mean of forward and backward passes. */
  function mtld(words, threshold) {
    threshold = threshold || 0.72;
    if (words.length < 10) { return null; }
    function pass(seq) {
      var factors = 0, types = {}, typeCount = 0, tokenCount = 0;
      for (var i = 0; i < seq.length; i++) {
        tokenCount++;
        if (!types[seq[i]]) { types[seq[i]] = true; typeCount++; }
        var ttr = typeCount / tokenCount;
        if (ttr <= threshold) {
          factors++; types = {}; typeCount = 0; tokenCount = 0;
        }
      }
      if (tokenCount > 0) { // partial factor
        var pttr = typeCount / tokenCount;
        factors += (1 - pttr) / (1 - threshold);
      }
      return factors > 0 ? seq.length / factors : seq.length;
    }
    var fwd = pass(words);
    var bwd = pass(words.slice().reverse());
    return round4((fwd + bwd) / 2);
  }

  function lexicalDiversity(tokens) {
    var words = tokens.map(function (t) { return t.w; });
    var types = {};
    words.forEach(function (w) { types[w] = true; });
    return {
      mtld: mtld(words),
      ttr: words.length ? round4(Object.keys(types).length / words.length) : null,
      types: Object.keys(types).length,
      tokens: words.length
    };
  }

  var CONTENT_POS = { NOUN: 1, PROPN: 1, VERB: 1, ADJ: 1, ADV: 1 };
  function lexicalDensity(tokens) {
    if (!tokens.length) { return null; }
    var c = tokens.filter(function (t) { return CONTENT_POS[t.pos]; }).length;
    return round4(c / tokens.length);
  }

  function readability(sentences) {
    var nSent = 0, nWords = 0, nSyll = 0;
    sentences.forEach(function (s) {
      var toks = s.tokens || [];
      if (!toks.length) { return; }
      nSent++;
      toks.forEach(function (t) { nWords++; nSyll += syllables(t.w); });
    });
    if (nSent === 0 || nWords === 0) { return null; }
    var wps = nWords / nSent, spw = nSyll / nWords;
    return {
      fleschReadingEase: round4(206.835 - 1.015 * wps - 84.6 * spw),
      fleschKincaidGrade: round4(0.39 * wps + 11.8 * spw - 15.59),
      meanWordsPerSentence: round4(wps),
      meanSyllablesPerWord: round4(spw)
    };
  }

  /** Referential cohesion via noun-stem overlap between sentences. */
  function cohesion(sentences, stemFn) {
    stemFn = stemFn || function (w) { return w; };
    var nounSets = sentences.map(function (s) {
      var set = {};
      (s.tokens || []).forEach(function (t) {
        if (t.pos === 'NOUN' || t.pos === 'PROPN') { set[stemFn(t.w)] = true; }
      });
      return set;
    }).filter(function (set) { return Object.keys(set).length > 0; });
    if (nounSets.length < 2) { return null; }
    function overlap(a, b) {
      for (var k in a) { if (b[k]) { return 1; } }
      return 0;
    }
    var adj = 0;
    for (var i = 1; i < nounSets.length; i++) { adj += overlap(nounSets[i - 1], nounSets[i]); }
    var glob = 0, pairs = 0;
    for (i = 0; i < nounSets.length; i++) {
      for (var j = i + 1; j < nounSets.length; j++) { glob += overlap(nounSets[i], nounSets[j]); pairs++; }
    }
    return {
      adjacentNounOverlap: round4(adj / (nounSets.length - 1)),
      globalNounOverlap: round4(glob / pairs)
    };
  }

  /** Hedging vs. certainty (Hyland, 2005). Index: + certain, - hedged. */
  function hedging(tokens) {
    var H = {}, B = {};
    HEDGE_WORDS.forEach(function (w) { H[w] = true; });
    BOOSTER_WORDS.forEach(function (w) { B[w] = true; });
    var h = 0, b = 0;
    tokens.forEach(function (t) {
      if (H[t.w]) { h++; } else if (B[t.w]) { b++; }
    });
    var n = tokens.length || 1;
    return {
      hedgesPer1000: round4(1000 * h / n),
      boostersPer1000: round4(1000 * b / n),
      certaintyIndex: (h + b) > 0 ? round4((b - h) / (b + h)) : 0
    };
  }

  /** Pronoun person rates per 1000 words (computed BEFORE CRA pronoun drop). */
  function pronounRates(tokens) {
    var c = { firstSingular: 0, firstPlural: 0, second: 0, third: 0 };
    tokens.forEach(function (t) {
      if (PRON_FIRST_SG[t.w]) { c.firstSingular++; }
      else if (PRON_FIRST_PL[t.w]) { c.firstPlural++; }
      else if (PRON_SECOND[t.w]) { c.second++; }
      else if (PRON_THIRD[t.w]) { c.third++; }
    });
    var n = tokens.length || 1;
    return {
      firstSingularPer1000: round4(1000 * c.firstSingular / n),
      firstPluralPer1000: round4(1000 * c.firstPlural / n),
      secondPer1000: round4(1000 * c.second / n),
      thirdPer1000: round4(1000 * c.third / n)
    };
  }

  /** Word length / sophistication proxy: mean chars, share of long words (>= 7 chars). */
  function wordLength(tokens) {
    if (!tokens.length) { return null; }
    var chars = 0, longWords = 0;
    tokens.forEach(function (t) {
      chars += t.w.length;
      if (t.w.length >= 7) { longWords++; }
    });
    return {
      meanChars: round4(chars / tokens.length),
      longWordShare: round4(longWords / tokens.length)
    };
  }

  /**
   * Passive voice rate — HEURISTIC: a form of "be" followed within two tokens
   * by a verb ending in -ed/-en/irregular participle shape. Reported as the
   * proportion of sentences containing at least one such construction.
   */
  function passiveRate(sentences) {
    var nSent = 0, passive = 0;
    sentences.forEach(function (s) {
      var toks = s.tokens || [];
      if (!toks.length) { return; }
      nSent++;
      for (var i = 0; i < toks.length - 1; i++) {
        if (!BE_FORMS[toks[i].w]) { continue; }
        for (var j = i + 1; j <= Math.min(i + 2, toks.length - 1); j++) {
          var t = toks[j];
          if ((t.pos === 'VERB' || t.pos === 'ADJ') && /(ed|en)$/.test(t.w) && t.w.length > 3) {
            passive++; i = toks.length; break;
          }
        }
      }
    });
    return nSent ? round4(passive / nSent) : null;
  }

  /**
   * Formality F-score (Heylighen & Dewaele, 1999):
   * F = (noun% + adjective% + preposition% + article%
   *      - pronoun% - verb% - adverb% - interjection% + 100) / 2
   * ~50 neutral; higher = more formal/nominal, lower = more involved/verbal.
   */
  function formality(tokens) {
    if (!tokens.length) { return null; }
    var n = tokens.length;
    var cnt = { noun: 0, adj: 0, prep: 0, art: 0, pron: 0, verb: 0, adv: 0, intj: 0 };
    tokens.forEach(function (t) {
      if (t.pos === 'NOUN' || t.pos === 'PROPN') { cnt.noun++; }
      else if (t.pos === 'ADJ') { cnt.adj++; }
      else if (t.pos === 'ADP') { cnt.prep++; }
      else if (t.pos === 'DET' && ARTICLES[t.w]) { cnt.art++; }
      else if (t.pos === 'PRON') { cnt.pron++; }
      else if (t.pos === 'VERB' || t.pos === 'AUX') { cnt.verb++; }
      else if (t.pos === 'ADV') { cnt.adv++; }
      else if (t.pos === 'INTJ') { cnt.intj++; }
    });
    function pct(x) { return 100 * x / n; }
    return round4((pct(cnt.noun) + pct(cnt.adj) + pct(cnt.prep) + pct(cnt.art) -
      pct(cnt.pron) - pct(cnt.verb) - pct(cnt.adv) - pct(cnt.intj) + 100) / 2);
  }

  /* ---------------- top-level ---------------- */

  /**
   * sentences: parser output (with .tokens). deps: { sentimentFn, stemFn }.
   * Returns the textMetrics object stored in _cra.md.
   */
  function computeAll(sentences, deps) {
    deps = deps || {};
    var tokens = allTokens(sentences);
    return {
      method: 'Crawdad text metrics v1 (see js/textmetrics.js header for methods & citations; ' +
        'abstractness and agreeableness are labeled heuristics)',
      sentiment: sentimentScore(sentences, deps.sentimentFn),
      genderedLanguage: genderedLanguage(tokens),
      abstractness: abstractness(tokens),
      agreeableness: agreeableness(tokens),
      lexicalDiversity: lexicalDiversity(tokens),
      lexicalDensity: lexicalDensity(tokens),
      readability: readability(sentences),
      cohesion: cohesion(sentences, deps.stemFn),
      hedging: hedging(tokens),
      pronounRates: pronounRates(tokens),
      wordLength: wordLength(tokens),
      passiveRate: passiveRate(sentences),
      formality: formality(tokens)
    };
  }

  var api = {
    computeAll: computeAll,
    syllables: syllables,
    mtld: mtld,
    genderedLanguage: genderedLanguage,
    abstractness: abstractness,
    agreeableness: agreeableness,
    lexicalDiversity: lexicalDiversity,
    lexicalDensity: lexicalDensity,
    readability: readability,
    cohesion: cohesion,
    sentimentScore: sentimentScore,
    hedging: hedging,
    pronounRates: pronounRates,
    wordLength: wordLength,
    passiveRate: passiveRate,
    formality: formality
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadTextMetrics = api; }
})(typeof self !== 'undefined' ? self : this);
