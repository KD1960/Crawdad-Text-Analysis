/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M6 tests — Dynamics (Build Spec V2 §6.2, §11; D-V2-13/14).
 * Node:    NODE_PATH=... node tests/test-dynamics.js
 * Browser: open tests/test-dynamics.html
 * Oracles: the Iridium dynamics pilot (13 yearly windows) as the designated
 *          fixture (fixture-iridium-dyn.json); statsmodels ACF/PACF/Yule-
 *          Walker at 1e-9 and ruptures PELT breakpoint equality
 *          (fixture-dynstats.json); hand-worked KL and DCT identities.
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var D = isNode ? require('../js/dynamics.js') : root.CrawdadDynamics;
  var TH = isNode ? require('../js/themes.js') : root.CrawdadThemes;
  var RES = isNode ? require('../js/resonance.js') : root.CrawdadResonance;
  var FIX_S = isNode ? require('./fixture-dynstats.json') : root.CrawdadFixture_dynstats;
  var FIX_I = isNode ? require('./fixture-iridium-dyn.json') : root.CrawdadFixture_iridiumDyn;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function close(a, b, tol, m) {
    if (Math.abs(a - b) > tol) { throw new Error((m || '') + ' |' + a + ' - ' + b + '| > ' + tol); }
  }

  /* ---------------- series numerics vs statsmodels/ruptures ---------------- */

  t('ACF matches statsmodels (adjusted=False) at 1e-9', function () {
    var r = D.acf(FIX_S.x, 8);
    FIX_S.refAcf.forEach(function (ref, i) { close(r[i], ref, 1e-9, 'lag ' + (i + 1)); });
  });

  t('PACF (Durbin–Levinson) matches statsmodels method=ywm at 1e-9', function () {
    var r = D.pacf(FIX_S.x, 8);
    FIX_S.refPacf.forEach(function (ref, i) { close(r[i], ref, 1e-9, 'lag ' + (i + 1)); });
  });

  t('Yule–Walker AR(1..3) matches statsmodels method=mle at 1e-9', function () {
    for (var p = 1; p <= 3; p++) {
      var yw = D.yuleWalker(FIX_S.x, p);
      var ref = FIX_S.refYW[String(p)];
      ref.phi.forEach(function (f, i) { close(yw.phi[i], f, 1e-9, 'p=' + p + ' phi' + i); });
      close(yw.sigma2, ref.sigma2, 1e-9, 'p=' + p + ' sigma2');
    }
  });

  t('PELT breakpoints equal ruptures (model=l2, min_size=2, same penalty)', function () {
    var r = D.pelt(FIX_S.peltSeries, 1);
    assert(JSON.stringify(r.changePoints) === JSON.stringify(FIX_S.refPeltBkps),
      JSON.stringify(r.changePoints) + ' vs ' + JSON.stringify(FIX_S.refPeltBkps));
  });

  t('PELT penalty is visible and scales: higher mult finds fewer change points', function () {
    var lo = D.pelt(FIX_S.peltSeries, 0.2).changePoints.length;
    var hi = D.pelt(FIX_S.peltSeries, 50).changePoints.length;
    assert(lo >= D.pelt(FIX_S.peltSeries, 1).changePoints.length, 'low penalty >= default');
    assert(hi === 0, 'huge penalty finds none');
  });

  /* ---------------- MA(1) innovations + AICc identification ---------------- */

  t('innovations MA(1) recovers a positive theta from an MA-generated series', function () {
    // deterministic MA(1) with theta=0.7 from a seeded LCG
    var s = 99; var rnd = function () { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648 - 0.5; };
    var e = [], x = [];
    for (var i = 0; i < 200; i++) { e.push(rnd()); }
    for (i = 1; i < 200; i++) { x.push(e[i] + 0.7 * e[i - 1]); }
    var ma = D.innovationsMA1(x);
    assert(ma.theta > 0.4 && ma.theta < 1.0, 'theta ' + ma.theta);
  });

  t('AICc identification: strong AR(1) beats white noise; interpretive reading attached', function () {
    var x = [];
    var v = 1;
    var s2 = 7; var rnd2 = function () { s2 = (s2 * 1103515245 + 12345) % 2147483648; return s2 / 2147483648 - 0.5; };
    for (var i = 0; i < 60; i++) { v = 0.8 * v + rnd2() * 0.2; x.push(v); }
    var id = D.identifyModel(x);
    assert(/^AR/.test(id.best.model), 'chose ' + id.best.model);
    assert(/persistence|alternation/.test(id.reading), 'reading present');
    // effectively-uncorrelated deterministic noise (LCG streams carry serial
    // correlation; frac(sin) does not at this length)
    var flat = [];
    for (i = 1; i <= 60; i++) {
      var f = Math.sin(i) * 10000;
      flat.push(f - Math.floor(f) - 0.5);
    }
    var id2 = D.identifyModel(flat);
    assert(id2.best.model === 'white noise', 'white noise on iid: ' + id2.best.model);
    assert(/independent drivers/.test(id2.reading), 'WN reading');
  });

  /* ---------------- KL / novelty (hand-worked) ---------------- */

  t('KL hand-worked: identical distributions give 0; known asymmetric value', function () {
    var p = { counts: { a: 3, b: 1 }, tot: 4 };
    var q = { counts: { a: 1, b: 3 }, tot: 4 };
    var vocab = ['a', 'b'];
    close(D.klBits(p, p, vocab, 0.01), 0, 1e-12, 'KL(p||p)');
    // alpha=0.01,V=2: p=(3.01/4.02, 1.01/4.02), q mirrored
    var pa = 3.01 / 4.02, pb = 1.01 / 4.02;
    var hand = pa * Math.log2(pa / pb) + pb * Math.log2(pb / pa);
    close(D.klBits(p, q, vocab, 0.01), hand, 1e-12, 'hand value');
    assert(D.klBits(p, q, vocab, 0.01) > 0, 'positive');
  });

  t('noveltyTransience: first window has no novelty, last no transience; Barron note present', function () {
    function win(name, counts, tot) {
      return { name: name, data: { surfaceFrequencies: { totalTokens: tot,
        tokens: Object.keys(counts).map(function (k) { return [k, counts[k]]; }) } } };
    }
    var ws = [win('w1', { a: 5, b: 5 }, 10), win('w2', { a: 8, b: 2 }, 10),
      win('w3', { a: 2, b: 8 }, 10), win('w4', { c: 9, a: 1 }, 10)];
    var ntr = D.noveltyTransience(ws, 1, 0.01);
    assert(ntr.rows[0].novelty === null && ntr.rows[0].transience !== null, 'first row');
    assert(ntr.rows[3].transience === null && ntr.rows[3].novelty !== null, 'last row');
    assert(ntr.rows[3].novelty > ntr.rows[1].novelty, 'vocabulary shift raises novelty');
    assert(/Barron/.test(D.BARRON_NOTE) && /UNRELATED to CRA resonance/.test(D.BARRON_NOTE),
      'disambiguation note (D-V2-9)');
  });

  /* ---------------- Iridium pilot reproduction (designated oracle) -------- */

  function pilotWindows() {
    return FIX_I.windows.map(function (w) {
      return { name: w.name, data: { network: {
        nodes: w.nodes.map(function (n) {
          return { id: n[0], word: n[1], display: n[2], degree: 0, influence: n[3] };
        }),
        edges: w.edges.map(function (e) {
          return { source: e[0], target: e[1], weight: e[2] };
        }) } } };
    });
  }

  t('Iridium pilot reproduced: word admission, themes (k=5), series (1e-4)', function () {
    var res = D.runDynamics(pilotWindows(), { evCut: 4.0, topWords: 50 },
      { themes: TH, resonance: RES });
    assert(res.kRetain === FIX_I.expected.kRetain, 'kRetain ' + res.kRetain);
    assert(JSON.stringify(res.words) === JSON.stringify(FIX_I.expected.words), 'word list');
    var maxd = 0;
    for (var t2 = 0; t2 < FIX_I.expected.series.length; t2++) {
      for (var i = 0; i < FIX_I.expected.series[t2].length; i++) {
        maxd = Math.max(maxd, Math.abs(res.series[t2][i] - FIX_I.expected.series[t2][i]));
      }
    }
    assert(maxd < 1e-4, 'series maxdiff ' + maxd);
  });

  t('Iridium pilot reproduced: PELT change points 1992/1996/1998 per theme', function () {
    var res = D.runDynamics(pilotWindows(), { evCut: 4.0, topWords: 50 },
      { themes: TH, resonance: RES });
    var mine = res.diagnostics.map(function (d) { return d.changePointLabels.join('/'); });
    var pilot = FIX_I.expected.cps.map(function (c) { return c.join('/'); });
    assert(JSON.stringify(mine) === JSON.stringify(pilot),
      mine.join(' | ') + ' vs ' + pilot.join(' | '));
  });

  t('Iridium pilot reproduced: sequential WR′ turnover exactly (1e-9)', function () {
    var res = D.runDynamics(pilotWindows(), { evCut: 4.0, topWords: 50 },
      { themes: TH, resonance: RES });
    FIX_I.expected.seqWR.forEach(function (ref, i) {
      close(res.seqWR[i].wrp, ref, 1e-9, 'step ' + i);
    });
  });

  t('engine is deterministic on the pilot input', function () {
    var a = D.runDynamics(pilotWindows(), { evCut: 4.0, topWords: 50 },
      { themes: TH, resonance: RES });
    var b = D.runDynamics(pilotWindows(), { evCut: 4.0, topWords: 50 },
      { themes: TH, resonance: RES });
    assert(JSON.stringify(a.series) === JSON.stringify(b.series) &&
      JSON.stringify(a.themes) === JSON.stringify(b.themes), 'nondeterminism');
  });

  /* ---------------- stage transitions (D-V2-14) ---------------- */

  t('stage transitions: >= k themes within ±1 window promote; singletons do not', function () {
    // theme cps: T1 at 5, T2 at 6, T3 at 10 -> windows 5 and 6 have 2 themes
    var tr = D.stageTransitions([[5], [6], [10]], 2, 13);
    assert(tr.length >= 1, 'promoted');
    assert(tr.some(function (x) { return x.window === 5 || x.window === 6; }), 'at 5/6');
    assert(!tr.some(function (x) { return x.window === 10; }), 'lone T3 cp not promoted');
    var none = D.stageTransitions([[2], [7], [11]], 2, 13);
    assert(none.length === 0, 'no coincidences -> none');
  });

  /* ---------------- windowing helpers ---------------- */

  t('bucketize: year buckets, equal document weighting, empty handling reported', function () {
    function f(name, words) {
      return { name: name, data: { network: { nodes: words.map(function (w, i) {
        return { id: i, word: w[0], display: w[0], influence: w[1] };
      }), edges: [] } } };
    }
    var files = [
      f('19900101a', [['alpha', 0.4]]), f('19900601b', [['alpha', 0.2]]),
      f('19930101c', [['beta', 0.3]])
    ];
    var bz = D.bucketize(files, { bucketRule: 'year', emptyBucket: 'skip' });
    assert(bz.windows.length === 2, 'two non-empty year buckets');
    var w90 = bz.windows[0];
    close(w90.data.network.nodes[0].influence, 0.3, 1e-12, 'mean of .4/.2');
    var bz2 = D.bucketize(files, { bucketRule: 'year', emptyBucket: 'zero' });
    assert(bz2.windows.length === 4, '1990..1993 with zeros kept');
    assert(bz2.windows[1].empty === true, '1991 empty flagged');
  });

  t('fixedWindows splits and merges a sub-half tail', function () {
    var toks = [];
    for (var i = 0; i < 2400; i++) { toks.push('t' + i); }
    var ws = D.fixedWindows(toks, 1000);
    assert(ws.length === 2, '2400/1000 -> 2 windows (400-token tail merged)');
    assert(ws[1].length === 1400, 'tail merged into last window');
    var toks2 = [];
    for (i = 0; i < 2500; i++) { toks2.push('u' + i); }
    var ws2 = D.fixedWindows(toks2, 1000);
    assert(ws2.length === 3 && ws2[2].length === 500,
      'exact-half tail stands alone');
  });

  t('TextTiling: two lexically disjoint halves produce a boundary near the seam', function () {
    var toks = [];
    for (var i = 0; i < 400; i++) { toks.push(['ship', 'sea', 'sail', 'wave'][i % 4]); }
    for (i = 0; i < 400; i++) { toks.push(['court', 'law', 'judge', 'trial'][i % 4]); }
    var tt = D.textTiling(toks, {});
    assert(tt.boundaries.length >= 1, 'at least one boundary');
    var nearSeam = tt.boundaries.some(function (b) { return Math.abs(b - 400) <= 100; });
    assert(nearSeam, 'boundary near 400, got ' + JSON.stringify(tt.boundaries));
  });

  t('DCT low-pass: keep=n reproduces the series; keep=1 gives the mean', function () {
    var x = [0.1, 0.5, -0.2, 0.3, 0.9, -0.4];
    var full = D.dctLowPass(x, 6);
    x.forEach(function (v, i) { close(full.smoothed[i], v, 1e-4, 'identity at ' + i); });
    var one = D.dctLowPass(x, 1);
    var mu = x.reduce(function (a, b) { return a + b; }, 0) / x.length;
    one.smoothed.forEach(function (v) { close(v, mu, 1e-4, 'mean'); });
  });

  /* ---------------- report ---------------- */

  t('report: caution verbatim-adjacent, parameters, all sections, JSON block', function () {
    var res = D.runDynamics(pilotWindows(), { evCut: 4.0, topWords: 50 },
      { themes: TH, resonance: RES });
    var md = D.serializeReport(res, 'CITE-1\n\nCITE-2\n\nDISC');
    assert(/production timescale/.test(md) && /279–281/.test(md), 'caution present');
    assert(/## Dynamic themes/.test(md) && /## Series diagnostics/.test(md) &&
      /## Stage transitions/.test(md) && /## Lagged cross-correlations/.test(md) &&
      /## Sequential resonance WR′/.test(md), 'sections');
    assert(/PELT \(Killick et al\., 2012\), penalty mult 1/.test(md), 'penalty visible');
    assert(/Daneke & Dooley 2007 rule/.test(md), 'coincidence rule cited');
    assert(/"crawdad-dynamics"/.test(md), 'machine block');
    assert(/CITE-1/.test(md) && /DISC/.test(md), 'citations');
    // pilot files lack surfaceFrequencies -> NTR section explains why
    assert(/lack the surface-frequency block/.test(md), 'NTR absence explained');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M6 dynamics tests: ' + passed + '/' + results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadDynamicsTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
