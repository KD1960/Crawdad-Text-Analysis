# CRA Analysis: macbeth-sample.txt

- Processed: 2026-07-09T17:04:00.853Z
- App version: 0.1.0-M0
- Parameters: stemming=porter, pronouns=dropped, inter-sentence linking=on, tokenization file=none

## Network summary

| Measure | Value |
|---|---|
| Nodes | 5 |
| Edges | 4 |
| Degree centralization | 0.58000 |
| Betweenness centralization | 0.41000 |
| Closeness centralization | 0.50000 |
| Eigenvector centralization | 0.60000 |

## Influential words (influence > 0.005)

| Word | Degree | Influence | Connected to |
|---|---|---|---|
| king | 3 | 0.41000 | blood, dagger, night |
| blood | 2 | 0.12000 | king, night |
| night | 2 | 0.00600 | blood, king |

## Data (machine-readable — do not edit)

```json
{
 "schema": "crawdad-cra",
 "schemaVersion": "1.0",
 "source": {
  "filename": "macbeth-sample.txt",
  "processedAt": "2026-07-09T17:04:00.853Z",
  "appVersion": "0.1.0-M0"
 },
 "parameters": {
  "stemming": "porter",
  "pronouns": false,
  "interSentenceLinking": true,
  "tokenizationFile": null,
  "stopWordList": "default"
 },
 "network": {
  "nodes": [
   {
    "id": 0,
    "word": "king",
    "display": "king",
    "degree": 3,
    "influence": 0.41
   },
   {
    "id": 1,
    "word": "blood",
    "display": "blood",
    "degree": 2,
    "influence": 0.12
   },
   {
    "id": 2,
    "word": "night",
    "display": "night",
    "degree": 2,
    "influence": 0.006
   },
   {
    "id": 3,
    "word": "dagger",
    "display": "dagger",
    "degree": 1,
    "influence": 0.004
   },
   {
    "id": 4,
    "word": "sleep",
    "display": "sleep",
    "degree": 0,
    "influence": 0
   }
  ],
  "edges": [
   {
    "source": 0,
    "target": 1,
    "weight": 4
   },
   {
    "source": 0,
    "target": 2,
    "weight": 1
   },
   {
    "source": 0,
    "target": 3,
    "weight": 2
   },
   {
    "source": 1,
    "target": 2,
    "weight": 1
   }
  ]
 },
 "summary": {
  "nodeCount": 5,
  "edgeCount": 4,
  "centralization": {
   "degree": 0.58,
   "betweenness": 0.41,
   "closeness": 0.5,
   "eigenvector": 0.6
  }
 }
}
```

---
*Please cite: Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002). Studying complex discursive systems: Centering Resonance Analysis of organizational communication. Human Communication Research, 28(2), 157-206.*
