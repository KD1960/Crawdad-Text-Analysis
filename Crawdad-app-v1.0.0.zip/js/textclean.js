/*
 * Crawdad 2026 — deterministic text cleaning + tokenization substitutions
 * (spec §6 step 2-3, §4.2). LLM-assisted cleaning is a separate optional
 * feature (§10 L-1); everything here is rule-based and reproducible.
 */
(function (root) {
  'use strict';

  /**
   * Rule-based cleaning:
   *  - strip markdown/HTML artifacts (headings, emphasis, links, code, tables, images)
   *  - repair words hyphenated across line breaks ("organiza-\ntion")
   *  - drop lines that are page numbers or repeated running headers/footers
   *  - normalize whitespace
   * Returns { text, notes: string[] } — notes describe what was removed.
   */
  function cleanText(raw) {
    var notes = [];
    var text = String(raw);

    // Normalize line endings
    text = text.replace(/\r\n?/g, '\n');

    // Academic citation artifacts (would otherwise become spurious nodes,
    // e.g. "al" from "et al."):
    var etal = (text.match(/\bet\s+al\.?/gi) || []).length;
    if (etal) {
      text = text.replace(/\bet\s+al\.?/gi, '');
      notes.push('Removed ' + etal + ' "et al." citation fragment(s).');
    }
    // Parenthetical citations containing a year, e.g. "(Grosz, Weinstein, & Joshi, 1995)"
    var cites = (text.match(/\([^()]*\b(1[5-9]\d{2}|20\d{2})[a-z]?\b[^()]*\)/g) || []).length;
    if (cites) {
      text = text.replace(/\([^()]*\b(1[5-9]\d{2}|20\d{2})[a-z]?\b[^()]*\)/g, ' ');
      notes.push('Removed ' + cites + ' parenthetical citation(s) containing a year.');
    }

    // Repair hyphenation across line breaks BEFORE other line surgery
    var hyphens = (text.match(/([a-z])-\n\s*([a-z])/g) || []).length;
    if (hyphens) {
      text = text.replace(/([a-z])-\n\s*([a-z])/g, '$1$2');
      notes.push('Rejoined ' + hyphens + ' line-break hyphenation(s).');
    }

    // Markdown/HTML artifacts
    text = text
      .replace(/```[\s\S]*?```/g, ' ')            // fenced code blocks
      .replace(/^\s{0,3}#{1,6}\s+/gm, '')         // heading markers (keep heading text)
      .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')      // images
      .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')    // links -> link text
      .replace(/^[|].*[|]\s*$/gm, ' ')            // markdown table rows
      .replace(/^[-=*_]{3,}\s*$/gm, ' ')          // horizontal rules
      .replace(/[*_]{1,3}([^*_]+)[*_]{1,3}/g, '$1') // emphasis
      .replace(/<[^>\n]{1,80}>/g, ' ');           // inline HTML tags

    var lines = text.split('\n');

    // Detect repeated running headers/footers: identical non-trivial lines
    // appearing 4+ times (e.g., journal headers on every PDF page).
    var freq = {};
    lines.forEach(function (ln) {
      var key = ln.trim();
      if (key.length >= 8) { freq[key] = (freq[key] || 0) + 1; }
    });
    var headerKeys = Object.keys(freq).filter(function (k) { return freq[k] >= 4; });
    if (headerKeys.length) {
      notes.push('Removed repeated running header/footer line(s): ' +
        headerKeys.map(function (k) { return '"' + k.slice(0, 60) + '" x' + freq[k]; }).join('; '));
    }
    var headerSet = {};
    headerKeys.forEach(function (k) { headerSet[k] = true; });

    var pageNums = 0;
    lines = lines.filter(function (ln) {
      var s = ln.trim();
      if (headerSet[s]) { return false; }
      if (/^\d{1,4}$/.test(s)) { pageNums++; return false; }  // bare page numbers
      return true;
    });
    if (pageNums) { notes.push('Removed ' + pageNums + ' bare page-number line(s).'); }

    text = lines.join('\n')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    return { text: text, notes: notes };
  }

  /* ------------------------------------------------------------------ *
   * Tokenization substitution file (spec §4.2)
   * ------------------------------------------------------------------ */

  /** Parse a simple CSV (2 columns, optional quotes). Returns [[find, replace], ...] */
  function parseCsvPairs(csvText) {
    var pairs = [];
    String(csvText).replace(/\r\n?/g, '\n').split('\n').forEach(function (line) {
      if (!line.trim()) { return; }
      var cells = [];
      var re = /("([^"]*)"|[^,]*)(,|$)/g, m;
      while (cells.length < 2 && (m = re.exec(line)) !== null) {
        cells.push((m[2] !== undefined ? m[2] : m[1]).trim());
        if (m[3] === '') { break; }
      }
      if (cells.length >= 2 && cells[0]) { pairs.push([cells[0], cells[1]]); }
    });
    return pairs;
  }

  /** Parse .xlsx via SheetJS (vendor/xlsx.full.min.js), first sheet, cols A/B. */
  function parseXlsxPairs(arrayBuffer) {
    if (!root.XLSX) { throw new Error('SheetJS not loaded (vendor/xlsx.full.min.js missing).'); }
    var wb = root.XLSX.read(arrayBuffer, { type: 'array' });
    var ws = wb.Sheets[wb.SheetNames[0]];
    var rows = root.XLSX.utils.sheet_to_json(ws, { header: 1, raw: false });
    var pairs = [];
    rows.forEach(function (r) {
      if (r && r[0] !== undefined && r[1] !== undefined && String(r[0]).trim()) {
        pairs.push([String(r[0]).trim(), String(r[1]).trim()]);
      }
    });
    return pairs;
  }

  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  /**
   * Apply substitutions: case-insensitive, longest-find-first, whole-word
   * boundaries (spec §4.2). Returns { text, counts: {find: n} }.
   */
  function applySubstitutions(text, pairs) {
    var counts = {};
    var sorted = pairs.slice().sort(function (a, b) { return b[0].length - a[0].length; });
    sorted.forEach(function (p) {
      var re = new RegExp('\\b' + escapeRe(p[0]) + '\\b', 'gi');
      var n = 0;
      text = text.replace(re, function () { n++; return p[1]; });
      if (n) { counts[p[0]] = n; }
    });
    return { text: text, counts: counts };
  }

  var api = {
    cleanText: cleanText,
    parseCsvPairs: parseCsvPairs,
    parseXlsxPairs: parseXlsxPairs,
    applySubstitutions: applySubstitutions
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadTextClean = api; }
})(typeof self !== 'undefined' ? self : this);
