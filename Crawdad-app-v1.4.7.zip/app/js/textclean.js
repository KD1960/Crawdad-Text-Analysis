/*
 * Crawdad 2026 — deterministic text cleaning + tokenization substitutions
 * (spec §6 step 2-3, §4.2). LLM-assisted cleaning is a separate optional
 * feature (§10 L-1); everything here is rule-based and reproducible.
 */
(function (root) {
  'use strict';

  /**
   * Rule-based cleaning:
   *  - strip markdown/HTML artifacts (headings, emphasis, links, code, tables, images)
   *  - repair words hyphenated across line breaks ("organiza-\ntion")
   *  - drop lines that are page numbers or repeated running headers/footers
   *  - normalize whitespace
   * Returns { text, notes: string[] } — notes describe what was removed.
   */
  function cleanText(raw) {
    var notes = [];
    var text = String(raw);

    // Normalize line endings
    text = text.replace(/\r\n?/g, '\n');

    // Trailing bibliography (fix 2026-08-09): a heading-like line reading
    // "References" / "Bibliography" / "Works Cited" / "Literature Cited" in
    // the last 60% of the document drops everything from that line to the
    // end (resuming at an "Appendix" heading if one follows). Reference
    // lists otherwise flood the network with author-name nodes.
    var refLines = text.split('\n');
    var refStart = Math.floor(refLines.length * 0.4);
    var refRe = /^\s*(?:#{1,6}\s*)?(?:[*_]{1,2})?\s*(?:\d{1,2}\.?\s+)?(references|bibliography|works\s+cited|literature\s+cited|references\s+cited)\s*(?:[*_]{1,2})?\s*:?\s*$/i;
    var refIdx = -1;
    for (var rl = refLines.length - 1; rl >= refStart; rl--) {
      if (refRe.test(refLines[rl])) { refIdx = rl; } // earliest match wins
    }
    if (refIdx !== -1) {
      var appRe = /^\s*(?:#{1,6}\s*)?(?:[*_]{1,2})?\s*appendix\b/i;
      var appIdx = -1;
      for (var al = refIdx + 1; al < refLines.length; al++) {
        if (appRe.test(refLines[al])) { appIdx = al; break; }
      }
      var kept = refLines.slice(0, refIdx);
      var dropped = (appIdx === -1 ? refLines.length : appIdx) - refIdx;
      if (appIdx !== -1) { kept = kept.concat(refLines.slice(appIdx)); }
      text = kept.join('\n');
      notes.push('Removed reference list: ' + dropped + ' line(s) from "' +
        refLines[refIdx].trim().slice(0, 40) + '"' +
        (appIdx !== -1 ? ' (kept appendix that follows)' : ' to end of text') + '.');
    }

    // Numbered bracket citations, e.g. [12] or [3, 7] or [1-4]
    var brackets = (text.match(/\[\s*\d{1,3}(?:\s*[-–—,;]\s*\d{1,3})*\s*\]/g) || []).length;
    if (brackets) {
      text = text.replace(/\[\s*\d{1,3}(?:\s*[-–—,;]\s*\d{1,3})*\s*\]/g, ' ');
      notes.push('Removed ' + brackets + ' numbered bracket citation(s).');
    }
    // DOIs, e.g. "doi:10.1093/..." or bare "10.1177/0001839212437859"
    var dois = (text.match(/\bdoi:\s*\S+|\b10\.\d{4,9}\/[^\s,;)\]]+/gi) || []).length;
    if (dois) {
      text = text.replace(/\bdoi:\s*\S+|\b10\.\d{4,9}\/[^\s,;)\]]+/gi, ' ');
      notes.push('Removed ' + dois + ' DOI(s).');
    }

    // Academic citation artifacts (would otherwise become spurious nodes,
    // e.g. "al" from "et al."):
    var etal = (text.match(/\bet\s+al\.?/gi) || []).length;
    if (etal) {
      text = text.replace(/\bet\s+al\.?/gi, '');
      notes.push('Removed ' + etal + ' "et al." citation fragment(s).');
    }
    // Bare URLs and web addresses (validation study V1 finding: URL fragments
    // otherwise become spurious network nodes)
    var urls = (text.match(/\b(?:https?:\/\/|www\.)\S+|\b[\w-]+(?:\.[\w-]+)*\.(?:com|org|edu|gov|net|io)(?:\/\S*)?/gi) || []).length;
    if (urls) {
      text = text.replace(/\b(?:https?:\/\/|www\.)\S+|\b[\w-]+(?:\.[\w-]+)*\.(?:com|org|edu|gov|net|io)(?:\/\S*)?/gi, ' ');
      notes.push('Removed ' + urls + ' bare URL(s)/web address(es).');
    }

    // Parenthetical citations containing a year, e.g. "(Grosz, Weinstein, & Joshi, 1995)"
    var cites = (text.match(/\([^()]*\b(1[5-9]\d{2}|20\d{2})[a-z]?\b[^()]*\)/g) || []).length;
    if (cites) {
      text = text.replace(/\([^()]*\b(1[5-9]\d{2}|20\d{2})[a-z]?\b[^()]*\)/g, ' ');
      notes.push('Removed ' + cites + ' parenthetical citation(s) containing a year.');
    }

    // Repair hyphenation across line breaks BEFORE other line surgery
    var hyphens = (text.match(/([a-z])-\n\s*([a-z])/g) || []).length;
    if (hyphens) {
      text = text.replace(/([a-z])-\n\s*([a-z])/g, '$1$2');
      notes.push('Rejoined ' + hyphens + ' line-break hyphenation(s).');
    }

    // Markdown/HTML artifacts
    text = text
      .replace(/```[\s\S]*?```/g, ' ')            // fenced code blocks
      .replace(/^\s{0,3}#{1,6}\s+/gm, '')         // heading markers (keep heading text)
      .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')      // images
      .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')    // links -> link text
      .replace(/^[|].*[|]\s*$/gm, ' ')            // markdown table rows
      .replace(/^[-=*_]{3,}\s*$/gm, ' ')          // horizontal rules
      .replace(/[*_]{1,3}([^*_]+)[*_]{1,3}/g, '$1') // emphasis
      .replace(/<[^>\n]{1,80}>/g, ' ');           // inline HTML tags

    var lines = text.split('\n');

    // Detect repeated running headers/footers: identical non-trivial lines
    // appearing 4+ times (e.g., journal headers on every PDF page).
    var freq = {};
    lines.forEach(function (ln) {
      var key = ln.trim();
      if (key.length >= 8) { freq[key] = (freq[key] || 0) + 1; }
    });
    var headerKeys = Object.keys(freq).filter(function (k) { return freq[k] >= 4; });
    if (headerKeys.length) {
      notes.push('Removed repeated running header/footer line(s): ' +
        headerKeys.map(function (k) { return '"' + k.slice(0, 60) + '" x' + freq[k]; }).join('; '));
    }
    var headerSet = {};
    headerKeys.forEach(function (k) { headerSet[k] = true; });

    var pageNums = 0;
    lines = lines.filter(function (ln) {
      var s = ln.trim();
      if (headerSet[s]) { return false; }
      if (/^\d{1,4}$/.test(s)) { pageNums++; return false; }  // bare page numbers
      return true;
    });
    if (pageNums) { notes.push('Removed ' + pageNums + ' bare page-number line(s).'); }

    text = lines.join('\n')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    return { text: text, notes: notes };
  }

  /* ------------------------------------------------------------------ *
   * Tokenization substitution file (spec §4.2)
   * ------------------------------------------------------------------ */

  /** Parse a simple CSV (2 columns, optional quotes). Returns [[find, replace], ...] */
  function parseCsvPairs(csvText) {
    var pairs = [];
    String(csvText).replace(/\r\n?/g, '\n').split('\n').forEach(function (line) {
      if (!line.trim()) { return; }
      var cells = [];
      var re = /("([^"]*)"|[^,]*)(,|$)/g, m;
      while (cells.length < 2 && (m = re.exec(line)) !== null) {
        cells.push((m[2] !== undefined ? m[2] : m[1]).trim());
        if (m[3] === '') { break; }
      }
      if (cells.length >= 2 && cells[0]) { pairs.push([cells[0], cells[1]]); }
    });
    return pairs;
  }

  /** Parse .xlsx via SheetJS (vendor/xlsx.full.min.js), first sheet, cols A/B. */
  function parseXlsxPairs(arrayBuffer) {
    if (!root.XLSX) { throw new Error('SheetJS not loaded (vendor/xlsx.full.min.js missing).'); }
    var wb = root.XLSX.read(arrayBuffer, { type: 'array' });
    var ws = wb.Sheets[wb.SheetNames[0]];
    var rows = root.XLSX.utils.sheet_to_json(ws, { header: 1, raw: false });
    var pairs = [];
    rows.forEach(function (r) {
      if (r && r[0] !== undefined && r[1] !== undefined && String(r[0]).trim()) {
        pairs.push([String(r[0]).trim(), String(r[1]).trim()]);
      }
    });
    return pairs;
  }

  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  /**
   * Apply substitutions: case-insensitive, longest-find-first, whole-word
   * boundaries (spec §4.2). Returns { text, counts: {find: n} }.
   */
  function applySubstitutions(text, pairs) {
    var counts = {};
    var sorted = pairs.slice().sort(function (a, b) { return b[0].length - a[0].length; });
    sorted.forEach(function (p) {
      var re = new RegExp('\\b' + escapeRe(p[0]) + '\\b', 'gi');
      var n = 0;
      text = text.replace(re, function () { n++; return p[1]; });
      if (n) { counts[p[0]] = n; }
    });
    return { text: text, counts: counts };
  }

  /* ------------------------------------------------------------------ *
   * Tokenization suggestions (2026-08-09)
   * ------------------------------------------------------------------ */

  /**
   * Suggest multi-word tokenization candidates from adjacent co-occurrence
   * of center words WITHIN noun phrases (parser output, surface forms —
   * substitutions apply to raw text, so suggestions must be surface forms).
   * A pair/triple of words that repeatedly appears adjacent in the same
   * noun phrase is a candidate single concept ("supply chain").
   *
   * parsedSentences: parser.parse().sentences
   * opts: { minCount (default 3), maxSuggestions (default 20),
   *         isStopWord (fn), existingPairs ([[find, replace], ...]) }
   * Returns [{ phrase, replacement, count, words }] sorted by count desc.
   * Frequency-based candidates only — whether a phrase denotes one concept
   * is the analyst's judgment.
   */
  function suggestTokenizations(parsedSentences, opts) {
    opts = opts || {};
    var minCount = opts.minCount || 3;
    var maxSuggestions = opts.maxSuggestions || 20;
    var isStop = opts.isStopWord || function () { return false; };
    var already = {};
    (opts.existingPairs || []).forEach(function (p) {
      already[String(p[0]).toLowerCase().replace(/\s+/g, ' ').trim()] = true;
    });

    var counts = {}; // "w1 w2" or "w1 w2 w3" -> n
    function bump(words) {
      for (var i = 0; i < words.length; i++) {
        if (words[i].length < 2 || isStop(words[i]) ||
            words[i].indexOf('_') !== -1) { return; } // already a compound
      }
      var key = words.join(' ');
      if (already[key]) { return; }
      counts[key] = (counts[key] || 0) + 1;
    }
    (parsedSentences || []).forEach(function (s) {
      (s.phrases || []).forEach(function (p) {
        for (var i = 0; i + 1 < p.length; i++) {
          bump([p[i], p[i + 1]]);
          if (i + 2 < p.length) { bump([p[i], p[i + 1], p[i + 2]]); }
        }
      });
    });

    var out = Object.keys(counts)
      .filter(function (k) { return counts[k] >= minCount; })
      .map(function (k) {
        return {
          phrase: k,
          replacement: k.replace(/\s+/g, '_'),
          count: counts[k],
          words: k.split(' ').length
        };
      })
      .sort(function (a, b) {
        return b.count - a.count || b.words - a.words ||
          (a.phrase < b.phrase ? -1 : 1);
      });
    return out.slice(0, maxSuggestions);
  }

  var api = {
    cleanText: cleanText,
    parseCsvPairs: parseCsvPairs,
    parseXlsxPairs: parseXlsxPairs,
    applySubstitutions: applySubstitutions,
    suggestTokenizations: suggestTokenizations
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadTextClean = api; }
})(typeof self !== 'undefined' ? self : this);
