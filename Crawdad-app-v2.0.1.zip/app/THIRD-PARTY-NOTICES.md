# Third-party notices

Crawdad Text Analysis Software (Copyright 2026 Kevin J. Dooley) is licensed
under the Apache License, Version 2.0 (see LICENSE). This distribution
bundles the third-party components below, vendored into `vendor/` so the
application runs entirely offline. Each component remains under its own
license, reproduced or referenced here as its license requires. Versions
were recorded from the files themselves where the build embeds a version
string, and from the vendoring record (SECURITY-AND-PROVENANCE.md) where
minification strips it; the recording basis is stated per entry.

Minified builds strip original header comments; the copyright and license
statements below are reproduced from each project's source repository.

---

## wink-nlp, wink-eng-lite-web-model, wink-porter2-stemmer, wink-sentiment

- Files: `vendor/wink-bundle.js` (single bundle, built 2026-08 for this
  distribution)
- Versions: wink-nlp 2.x, wink-eng-lite-web-model 1.x,
  wink-porter2-stemmer 2.0.x, wink-sentiment 5.0.x (vendoring record; the
  minified bundle does not embed version strings)
- Role: sentence segmentation, POS tagging, Porter2 stemming, AFINN-based
  sentiment
- License: MIT. Copyright (c) Graype Systems Private Limited.
- wink-sentiment incorporates scores derived from the AFINN-165 word list
  (Nielsen, F. A. (2011). A new ANEW: evaluation of a word list for
  sentiment analysis in microblogs. Proc. ESWC2011 Workshop) and an emoji
  list; both are distributed by wink-sentiment under its MIT license.

MIT License text: see "MIT License" at the end of this file.

## compromise

- File: `vendor/compromise.js`
- Version: 14.16.0 (embedded)
- Role: second-opinion POS checks (D-14 tagger arbitration)
- License: MIT. Copyright (c) 2022 Spencer Kelly.

## D3

- File: `vendor/d3.min.js`
- Version: 7.9.0 (embedded banner)
- Role: network visualization
- License: ISC. Copyright 2010-2023 Mike Bostock.

ISC License text: see "ISC License" at the end of this file.

## pdf.js (Mozilla)

- Files: `vendor/pdf.min.js`, `vendor/pdf.worker.min.js`
- Version: 3.11.174 (embedded)
- Role: PDF text extraction (run with `isEvalSupported: false`)
- License: Apache License 2.0. Copyright 2023 Mozilla Foundation.
  License text: see the LICENSE file in this distribution.

## mammoth.js

- File: `vendor/mammoth.browser.min.js`
- Version: 1.6.0 (vendoring record; the browser build embeds its
  dependency Underscore.js 1.13.1 — MIT, Copyright (c) 2009-2022 Jeremy
  Ashkenas, DocumentCloud and Investigative Reporters & Editors)
- Role: DOCX text extraction
- License: BSD-2-Clause. Copyright (c) 2013, Michael Williamson.

BSD-2-Clause text: see "BSD 2-Clause License" at the end of this file.

## SheetJS Community Edition

- File: `vendor/xlsx.full.min.js`
- Version: 0.18.5 (embedded)
- Role: spreadsheet (.xlsx/.csv) reading and writing
- License: Apache License 2.0. Copyright (C) 2012-present SheetJS LLC.
  License text: see the LICENSE file in this distribution.

## JSZip

- File: `vendor/jszip.min.js`
- Version: 3.10.1 (embedded banner)
- Role: session bundles (zip reading/writing)
- License: dual MIT or GPLv3; this distribution uses it under the MIT
  license. Copyright (c) 2009-2016 Stuart Knightley, David Duponchel,
  Franz Buchinger, António Afonso.

## jsPDF

- File: `vendor/jspdf.umd.min.js`
- Version: 4.2.1 (embedded banner; built 2026-03-17)
- Role: PDF report generation
- License: MIT. Copyright (c) 2010-2025 James Hall and contributors;
  (c) 2015-2025 yWorks GmbH. The jsPDF build itself bundles several MIT-
  licensed components listed in its upstream header (e.g., FileSaver.js,
  cf-blob.js).

## jspdf-autotable

- File: `vendor/jspdf.plugin.autotable.min.js`
- Version: 5.0.8 (embedded banner)
- Role: tables in PDF reports
- License: MIT. Copyright (c) 2026 Simon Bengtsson.

## pako

- File: `vendor/pako-deflate.min.js`
- Version: 3.0.1, deflate-only build (vendoring record; labeled in output
  files as "pako 3.0.1 deflate (vendored)")
- Role: compression-ratio text metric; deterministic deflate
- License: (MIT AND Zlib). Copyright (C) 2014-2017 Vitaly Puzrin and
  Andrei Tupitcyn.

Zlib license text: see "zlib License" at the end of this file.

## VADER sentiment lexicon

- File: `vendor/vader-lexicon.js` (lexicon data, vendored verbatim;
  the VADER scoring algorithm itself is implemented first-party in
  `js/vader.js`, validated output-identical to Python vaderSentiment 3.3.2)
- Source: Hutto, C. J., & Gilbert, E. E. (2014). VADER: A parsimonious
  rule-based model for sentiment analysis of social media text. ICWSM-14.
- License: MIT. Copyright (c) 2016 C.J. Hutto.
- The emoji sub-lexicon is deliberately omitted (documented deviation).

---

## License texts

### MIT License

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

### ISC License

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

### BSD 2-Clause License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### zlib License

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.

2. Altered source versions must be plainly marked as such, and must not
   be misrepresented as being the original software.

3. This notice may not be removed or altered from any source
   distribution.

### Apache License 2.0

Applies to pdf.js and SheetJS Community Edition; the full text is the
LICENSE file at the root of this distribution.
