/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad 2026 — application shell (M0, spec §5)
 * Screen routing, file selection, _cra.md validation, module menu gating.
 * Analysis modules themselves arrive in M3–M7.
 */
(function () {
  'use strict';

  var S = window.CrawdadSchema;
  var IO = window.CrawdadFileIO;

  /* ---------------- Session state ---------------- */
  var state = {
    genFiles: [],        // { file, status, text, converted, warnings }  (.txt/.md/.pdf/.docx)
    tokFile: null,       // tokenization spreadsheet
    dictFile: null,      // custom dictionary spreadsheet (V2-M1)
    dict: null,          // parsed dictionary + sha256
    craFiles: []         // { name, text, ok, data, errors }
  };

  /* ---------------- Module registry (spec §5.3) ---------------- */
  var MODULES = [
    { id: 'visualizer',  name: 'Visualizer',            min: 1, max: Infinity,
      desc: 'Draw the CRA network of a text.',          milestone: 'M3' },
    { id: 'comparator',  name: 'Comparator',            min: 2, max: Infinity,
      desc: 'Measure resonance between two texts (pick A and B).', milestone: 'M4' },
    { id: 'classifier',  name: 'Classifier',            min: 5, max: Infinity,
      desc: 'Cluster texts by mutual resonance.',       milestone: 'M5' },
    { id: 'themes',      name: 'Theme Identifier',      min: 5, max: Infinity,
      desc: 'Find manifest themes across texts (PCA).', milestone: 'M6' },
    { id: 'latent',      name: 'Latent Theme Identifier', min: 1, max: Infinity,
      desc: 'Score texts against your own theme dictionary.', milestone: 'M6' },
    { id: 'summarizer',  name: 'Summarizer',            min: 2, max: Infinity,
      desc: 'Rank the most influential words across texts.', milestone: 'M7' },
    { id: 'keyness',     name: 'Keyness',               min: 2, max: Infinity,
      desc: 'Compare the vocabulary of two groups of texts (G², Log Ratio, DP, Zeta).',
      milestone: 'V2-M3' },
    { id: 'topics',      name: 'Topic Modeler',         min: 8, max: Infinity,
      desc: 'Deterministic NMF topics with UMass coherence and the √n topic-count rule.',
      milestone: 'V2-M4' },
    { id: 'stylometry',  name: 'Stylometry',            min: 3, max: Infinity,
      desc: 'Burrows/Cosine Delta style distances with clustering; optional NCD.',
      milestone: 'V2-M5' },
    { id: 'dynamics',    name: 'Dynamics',              min: 1, max: Infinity,
      desc: 'Windowed-CRA themes over time: change points, turnover, novelty (Dooley & Corman, 2004).',
      milestone: 'V2-M6' }
  ];

  /* ---------------- Screen routing ---------------- */
  var screens = ['landing', 'generate', 'analyze', 'visualize', 'compare', 'classify',
                 'themes', 'latent', 'summarize', 'keyness', 'topics', 'stylometry',
                 'dynamics'];
  function show(name) {
    screens.forEach(function (s) {
      document.getElementById('screen-' + s).hidden = (s !== name);
    });
    document.getElementById('btn-home').hidden = (name === 'landing');
  }

  document.getElementById('choose-generate').addEventListener('click', function () { show('generate'); });
  document.getElementById('choose-analyze').addEventListener('click', function () { show('analyze'); });
  document.getElementById('btn-home').addEventListener('click', function () { show('landing'); });

  /* ---------------- Generate screen ---------------- */
  IO.wireFilePicker({
    zoneEl: document.getElementById('gen-drop'),
    inputEl: document.getElementById('gen-input'),
    accept: IO.isTextSource,
    onFiles: function (files) {
      files.forEach(function (f) {
        var dup = state.genFiles.some(function (g) { return g.file.name === f.name; });
        if (dup) { return; }
        var entry = { file: f, status: 'extracting…', text: null, converted: false, warnings: [] };
        state.genFiles.push(entry);
        window.CrawdadExtract.extractText(f).then(function (r) {
          entry.text = r.text;
          entry.converted = r.converted;
          entry.warnings = r.warnings;
          var chars = r.text.replace(/\s+/g, ' ').trim().length;
          entry.status = (r.converted ? 'converted, ' : 'ready, ') +
            chars.toLocaleString() + ' chars' +
            (r.warnings.length ? ' — ' + r.warnings.join(' ') : '');
          entry.bad = chars === 0 || r.warnings.length > 0;
          renderGenList();
        }).catch(function (err) {
          entry.status = 'error: ' + err.message;
          entry.bad = true;
          renderGenList();
        });
      });
      renderGenList();
    },
    onRejected: function (names) {
      alert('Not accepted (need .txt, .md, .pdf, or .docx source text, not a _cra.md file):\n' + names.join('\n'));
    }
  });

  function renderGenList() {
    var wrap = document.getElementById('gen-filelist-wrap');
    var tbody = document.querySelector('#gen-filelist tbody');
    tbody.innerHTML = '';
    state.genFiles.forEach(function (g, i) {
      var tr = document.createElement('tr');
      var kb = (g.file.size / 1024).toFixed(1) + ' KB';
      tr.innerHTML = '<td>' + esc(g.file.name) + '</td><td>' + kb + '</td>' +
        '<td class="' + (g.bad ? 'bad' : (g.text !== null ? 'ok' : '')) + '">' + esc(g.status) + '</td>';
      var td = document.createElement('td');
      if (g.converted && g.text) {
        var dl = document.createElement('button');
        dl.className = 'linklike'; dl.textContent = 'download .md';
        dl.title = 'Download the extracted text as a Markdown file';
        dl.addEventListener('click', function () {
          var base = g.file.name.replace(/\.(pdf|docx)$/i, '');
          IO.downloadFile(base + '.md', g.text);
        });
        td.appendChild(dl);
      }
      var rm = document.createElement('button');
      rm.className = 'linklike'; rm.textContent = 'remove';
      rm.addEventListener('click', function () {
        state.genFiles.splice(i, 1); renderGenList();
      });
      td.appendChild(rm); tr.appendChild(td);
      tbody.appendChild(tr);
    });
    wrap.hidden = state.genFiles.length === 0;
    updateRunButton();
  }

  function readyFiles() {
    return state.genFiles.filter(function (g) { return g.text && !g.bad; });
  }

  function updateRunButton() {
    var n = readyFiles().length;
    var btn = document.getElementById('gen-run');
    btn.disabled = n === 0;
    document.getElementById('gen-run-hint').textContent =
      n === 0 ? 'Add at least one readable file to enable.'
              : n + ' file' + (n === 1 ? '' : 's') + ' ready.';
  }

  /* ---------------- Generator run (M2) ---------------- */
  var parserInstance = null;

  document.getElementById('gen-run').addEventListener('click', function () {
    var btn = this;
    btn.disabled = true;
    btn.textContent = 'Processing…';

    var opts = {
      stemming: document.getElementById('set-stemming').value,
      keepPronouns: document.getElementById('set-pronouns').checked,
      interSentenceLinking: document.getElementById('set-intersentence').checked,
      excludeWords: document.getElementById('set-exclude').value
        .split(',').map(function (w) { return w.trim().toLowerCase(); })
        .filter(Boolean),
      tokPairs: state.tokPairs || null,
      tokFileName: state.tokFile ? state.tokFile.name : null,
      surfaceFrequencies: document.getElementById('set-surfacefreq').checked,
      bootstrapCI: document.getElementById('set-bootstrap').checked, // V2-M7
      dictionaries: state.dict ? [{
        name: state.dictFile.name,
        sha256: state.dict.sha256,
        dict: state.dict.parsed,
        mode: document.getElementById('gen-dict-mode').value
      }] : null
    };

    // Rebuild parser if pronoun setting changed
    if (!parserInstance || parserInstance._keepPronouns !== opts.keepPronouns) {
      parserInstance = window.CrawdadParser.createParser({ keepPronouns: opts.keepPronouns });
      parserInstance._keepPronouns = opts.keepPronouns;
    }

    var deps = {
      parser: parserInstance,
      porter2: window.CrawdadWink.porter2,
      sentiment: window.CrawdadWink.sentiment,
      isStopWord: window.CrawdadStopWords.isStopWord,
      schema: window.CrawdadSchema,
      network: window.CrawdadNetwork,
      textclean: window.CrawdadTextClean,
      textmetrics: window.CrawdadTextMetrics,
      vader: window.CrawdadVader,
      lexicons: window.CrawdadLexicons,
      keyphrases: window.CrawdadKeyphrases, // V2-M2
      communities: window.CrawdadCommunities, // V2-M4
      inference: window.CrawdadInference, // V2-M7

      deflate: (typeof pako !== 'undefined') ? function (u8) { return pako.deflate(u8); } : null,
      deflateLabel: 'pako 3.0.1 deflate (vendored)'
    };

    var tbody = document.querySelector('#gen-results tbody');
    tbody.innerHTML = '';
    var logs = [];
    var files = readyFiles();
    state.genResults = []; // { outName, craMd } for bulk actions
    document.getElementById('gen-selall').checked = true;

    // Process sequentially with UI breathing room (no Workers on file://)
    var i = 0;
    function next() {
      if (i >= files.length) {
        document.getElementById('gen-results-wrap').hidden = false;
        document.getElementById('gen-log').textContent = logs.join(' | ');
        btn.disabled = false;
        btn.textContent = 'Run Generator';
        if (document.getElementById('gen-batch').checked && state.genResults.length) {
          runBatchPipeline(); // D-11
        }
        return;
      }
      var g = files[i++];
      var tr = document.createElement('tr');
      try {
        var res = window.CrawdadGenerator.generate(g.file.name, g.text, opts, deps);
        var outName = window.CrawdadGenerator.craFileName(g.file.name);
        state.generated = state.generated || {};
        state.generated[outName] = res.craMd;
        state.sourceTexts = state.sourceTexts || {};
        state.sourceTexts[outName] = g.text; // enables WF 6e cluster aggregation
        state.genResults.push({ outName: outName, craMd: res.craMd, craData: res.craData });
        logs.push(g.file.name + ': ' + res.log.join('; '));
        var top = res.craData.network.nodes.slice()
          .sort(function (a, b) { return b.influence - a.influence; })
          .slice(0, 5)
          .map(function (n) { return n.display + ' (' + n.influence.toFixed(3) + ')'; })
          .join(', ');
        tr.innerHTML = '<td><input type="checkbox" class="gen-sel" checked data-name="' +
          esc(outName) + '"></td>' +
          '<td>' + esc(outName) + '</td>' +
          '<td>' + res.craData.network.nodes.length + '</td>' +
          '<td>' + res.craData.network.edges.length + '</td>' +
          '<td>' + esc(top) + '</td>';
        var td = document.createElement('td');
        var dl = document.createElement('button');
        dl.className = 'linklike'; dl.textContent = 'download';
        dl.addEventListener('click', function () { IO.downloadFile(outName, res.craMd); });
        // V2-M1.1 (D-V2-15): readable PDF companion — human sections only,
        // machine JSON stripped by construction (built from craData)
        var pd = document.createElement('button');
        pd.className = 'linklike'; pd.textContent = 'pdf';
        pd.title = 'Readable PDF (machine data stripped)';
        pd.addEventListener('click', function () {
          var doc = window.CrawdadPdfReport.reportPdf(res.craData);
          doc.save(window.CrawdadPdfReport.pdfFileName(outName));
        });
        var an = document.createElement('button');
        an.className = 'linklike'; an.textContent = 'send to Analyze';
        an.addEventListener('click', function () {
          sendToAnalyze([{ outName: outName, craMd: res.craMd }]);
          show('analyze');
        });
        td.appendChild(dl); td.appendChild(pd); td.appendChild(an); tr.appendChild(td);
      } catch (err) {
        tr.innerHTML = '<td></td><td>' + esc(g.file.name) + '</td>' +
          '<td colspan="4" class="bad">' + esc(err.message) + '</td>';
      }
      tbody.appendChild(tr);
      document.getElementById('gen-results-wrap').hidden = false;
      setTimeout(next, 30); // yield to UI between files
    }
    next();
  });

  // V2-M1: custom dictionary loader (spec V2 §3.1)
  document.getElementById('gen-dict-input').addEventListener('change', function (e) {
    var f = e.target.files[0];
    if (!f) { return; }
    if (!IO.isSpreadsheet(f.name)) {
      alert('Dictionary must be .xlsx or .csv'); e.target.value = ''; return;
    }
    var label = document.getElementById('gen-dict-name');
    function finish(rows, rawTextForHash) {
      var parsed = window.CrawdadLexicons.parseDictionary(rows);
      if (!parsed.type) {
        alert('Could not read dictionary: ' + parsed.errors.join(' '));
        state.dictFile = null; state.dict = null; label.textContent = ''; return;
      }
      state.dictFile = f;
      state.dict = { parsed: parsed, sha256: window.CrawdadLexicons.sha256Hex(rawTextForHash) };
      label.textContent = ' Loaded: ' + f.name + ' (' + parsed.type + ', ' +
        parsed.entries.length + ' entries' +
        (parsed.errors.length ? ', ' + parsed.errors.length + ' row(s) skipped' : '') +
        ', sha256 ' + state.dict.sha256.slice(0, 12) + '…)';
    }
    if (/\.csv$/i.test(f.name)) {
      IO.readFileAsText(f).then(function (t) {
        var rows = String(t).replace(/\r\n?/g, '\n').split('\n')
          .filter(function (ln) { return ln.trim(); })
          .map(function (ln) { return ln.split(','); });
        finish(rows, String(t));
      });
    } else {
      var r = new FileReader();
      r.onload = function () {
        try {
          var wb = window.XLSX.read(r.result, { type: 'array' });
          var ws = wb.Sheets[wb.SheetNames[0]];
          var rows = window.XLSX.utils.sheet_to_json(ws, { header: 1, raw: false });
          // hash the canonical CSV of the parsed rows (stable across xlsx re-saves
          // of identical content; recorded basis documented in the manual)
          var canon = rows.map(function (rr) { return (rr || []).join(','); }).join('\n');
          finish(rows, canon);
        } catch (err) {
          alert('Could not read spreadsheet: ' + err.message);
          state.dictFile = null; state.dict = null;
        }
      };
      r.readAsArrayBuffer(f);
    }
  });

  document.getElementById('gen-tok-input').addEventListener('change', function (e) {
    var f = e.target.files[0];
    if (!f) { return; }
    if (!IO.isSpreadsheet(f.name)) {
      alert('Tokenization file must be .xlsx or .csv'); e.target.value = ''; return;
    }
    state.tokFile = f;
    var label = document.getElementById('gen-tok-name');
    if (/\.csv$/i.test(f.name)) {
      IO.readFileAsText(f).then(function (t) {
        state.tokPairs = window.CrawdadTextClean.parseCsvPairs(t);
        label.textContent = ' Loaded: ' + f.name + ' (' + state.tokPairs.length + ' substitutions)';
      });
    } else {
      var r = new FileReader();
      r.onload = function () {
        try {
          state.tokPairs = window.CrawdadTextClean.parseXlsxPairs(r.result);
          label.textContent = ' Loaded: ' + f.name + ' (' + state.tokPairs.length + ' substitutions)';
        } catch (err) {
          alert('Could not read spreadsheet: ' + err.message);
          state.tokFile = null; state.tokPairs = null;
        }
      };
      r.readAsArrayBuffer(f);
    }
  });

  /* ---------------- Analyze screen ---------------- */
  IO.wireFilePicker({
    zoneEl: document.getElementById('ana-drop'),
    inputEl: document.getElementById('ana-input'),
    accept: IO.isCraFile,
    onFiles: function (files) {
      files.forEach(function (f) {
        IO.readFileAsText(f).then(function (text) {
          var res = S.parseCra(text);
          // replace if same name reloaded
          state.craFiles = state.craFiles.filter(function (c) { return c.name !== f.name; });
          state.craFiles.push({
            name: f.name, text: text, ok: res.ok, data: res.data, errors: res.errors
          });
          renderAnaList();
        }).catch(function (err) {
          alert(err.message);
        });
      });
    },
    onRejected: function (names) {
      alert('Not accepted (need files ending in _cra.md):\n' + names.join('\n'));
    }
  });

  function renderAnaList() {
    var wrap = document.getElementById('ana-filelist-wrap');
    var tbody = document.querySelector('#ana-filelist tbody');
    tbody.innerHTML = '';
    state.craFiles.forEach(function (c, i) {
      var tr = document.createElement('tr');
      var status = c.ok
        ? '<td class="ok">valid</td>'
        : '<td class="bad">invalid</td>';
      var nodes = c.ok ? c.data.network.nodes.length : '—';
      var edges = c.ok ? c.data.network.edges.length : '—';
      tr.innerHTML = '<td>' + esc(c.name) +
        (c.ok ? '' : '<div class="errdetail">' + esc(c.errors.slice(0, 4).join('\n')) + '</div>') +
        '</td>' + status + '<td>' + nodes + '</td><td>' + edges + '</td>';
      var td = document.createElement('td');
      var rm = document.createElement('button');
      rm.className = 'linklike'; rm.textContent = 'remove';
      rm.addEventListener('click', function () {
        state.craFiles.splice(i, 1); renderAnaList();
      });
      td.appendChild(rm); tr.appendChild(td);
      tbody.appendChild(tr);
    });
    wrap.hidden = state.craFiles.length === 0;
    renderModuleMenu();
  }

  function renderModuleMenu() {
    var grid = document.getElementById('module-menu');
    var n = state.craFiles.filter(function (c) { return c.ok; }).length;
    grid.innerHTML = '';
    MODULES.forEach(function (m) {
      var eligible = n >= m.min && n <= m.max;
      var card = document.createElement('div');
      card.className = 'module-card' + (eligible ? '' : ' disabled');
      var req = m.max === m.min ? ('exactly ' + m.min) :
        (m.max === Infinity ? (m.min + ' or more') : (m.min + '–' + m.max));
      card.innerHTML =
        '<h4>' + m.name + '</h4>' +
        '<p>' + m.desc + '</p>' +
        '<span class="req">Requires ' + req + ' valid file' + (m.min === 1 && m.max === Infinity ? '(s)' : 's') +
        ' · have ' + n + '</span>';
      var btn = document.createElement('button');
      var openers = { visualizer: openVisualizer, comparator: openComparator,
                      classifier: openClassifier, themes: openThemes, latent: openLatent,
                      summarizer: openSummarizer, keyness: openKeyness,
                      topics: openTopics, stylometry: openStylometry,
                      dynamics: openDynamics };
      var live = openers.hasOwnProperty(m.id); // modules go live as milestones ship
      if (live) {
        btn.disabled = !eligible;
        btn.textContent = 'Run';
        btn.title = eligible ? '' : ('Needs ' + req + ' valid _cra.md file(s).');
        btn.addEventListener('click', openers[m.id]);
      } else {
        btn.disabled = true;
        btn.textContent = eligible ? ('Run (arrives in ' + m.milestone + ')') : 'Run';
        btn.title = eligible
          ? (m.name + ' is delivered in milestone ' + m.milestone + '.')
          : ('Needs ' + req + ' valid _cra.md file(s).');
      }
      card.appendChild(btn);
      grid.appendChild(card);
    });
    document.getElementById('ana-count-hint').textContent =
      n === 0
        ? 'Load valid files to enable analyses. Analysis modules are delivered in milestones M3–M7; this screen enforces each module’s file-count requirements.'
        : n + ' valid file' + (n === 1 ? '' : 's') + ' loaded. Module buttons activate as each module ships (M3–M7).';
  }

  /* ---------------- Generator bulk actions ---------------- */

  function sendToAnalyze(items) {
    items.forEach(function (it) {
      state.craFiles = state.craFiles.filter(function (c) { return c.name !== it.outName; });
      var parsedBack = S.parseCra(it.craMd);
      state.craFiles.push({ name: it.outName, text: it.craMd, ok: parsedBack.ok,
        data: parsedBack.data, errors: parsedBack.errors });
    });
    renderAnaList();
  }

  function selectedGenResults() {
    var picked = {};
    document.querySelectorAll('#gen-results .gen-sel:checked').forEach(function (cb) {
      picked[cb.getAttribute('data-name')] = true;
    });
    return (state.genResults || []).filter(function (r) { return picked[r.outName]; });
  }

  document.getElementById('gen-selall').addEventListener('change', function () {
    var on = this.checked;
    document.querySelectorAll('#gen-results .gen-sel').forEach(function (cb) { cb.checked = on; });
  });

  document.getElementById('gen-send-selected').addEventListener('click', function () {
    var items = selectedGenResults();
    if (!items.length) { alert('No files selected.'); return; }
    sendToAnalyze(items);
    show('analyze');
  });

  document.getElementById('gen-download-selected').addEventListener('click', function () {
    var items = selectedGenResults();
    if (!items.length) { alert('No files selected.'); return; }
    // stagger downloads so the browser doesn't swallow them
    items.forEach(function (it, i) {
      setTimeout(function () { IO.downloadFile(it.outName, it.craMd); }, i * 350);
    });
  });

  // V2-M1.1 (D-V2-15): bulk readable-PDF download of selected results
  document.getElementById('gen-download-selected-pdf').addEventListener('click', function () {
    var items = selectedGenResults();
    if (!items.length) { alert('No files selected.'); return; }
    items.forEach(function (it, i) {
      setTimeout(function () {
        var doc = window.CrawdadPdfReport.reportPdf(it.craData);
        doc.save(window.CrawdadPdfReport.pdfFileName(it.outName));
      }, i * 450);
    });
  });

  /* ---------------- Visualizer screen (M3) ---------------- */
  var vizHandle = null;

  function openVisualizer() {
    var sel = document.getElementById('viz-file');
    sel.innerHTML = '';
    state.craFiles.filter(function (c) { return c.ok; }).forEach(function (c) {
      var o = document.createElement('option');
      o.value = c.name; o.textContent = c.name;
      sel.appendChild(o);
    });
    document.getElementById('viz-canvas').innerHTML = '';
    document.getElementById('viz-download').disabled = true;
    vizHandle = null;
    show('visualize');
  }

  function drawViz() {
    var name = document.getElementById('viz-file').value;
    var entry = state.craFiles.filter(function (c) { return c.name === name && c.ok; })[0];
    if (!entry) { alert('Select a valid file.'); return; }
    var topK = parseInt(document.getElementById('viz-topk').value, 10) || 30;
    var highlight = parseFloat(document.getElementById('viz-highlight').value);
    if (isNaN(highlight)) { highlight = 0.05; }
    try {
      vizHandle = window.CrawdadVisualizer.render(
        document.getElementById('viz-canvas'), entry.data,
        { topK: topK, highlight: highlight,
          reduction: document.getElementById('viz-reduction').value,        // V2-M4
          communities: document.getElementById('viz-communities').checked }); // V2-M4
      document.getElementById('viz-download').disabled = false;
    } catch (err) {
      alert('Could not draw: ' + err.message);
    }
  }

  document.getElementById('viz-render').addEventListener('click', drawViz);
  document.getElementById('viz-file').addEventListener('change', drawViz);
  document.getElementById('viz-back').addEventListener('click', function () { show('analyze'); });
  document.getElementById('viz-download').addEventListener('click', function () {
    if (!vizHandle) { return; }
    var name = document.getElementById('viz-file').value.replace(/_cra\.md$/i, '');
    vizHandle.exportPng(function (err, blob) {
      if (err) { alert(err.message); return; }
      IO.downloadFile('crawdad-network-' + name + '.png', blob, 'image/png');
    });
  });

  /* ---------------- Comparator screen (M4) ---------------- */
  var cmpReport = null;

  function openComparator() {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    ['cmp-a', 'cmp-b'].forEach(function (id, which) {
      var sel = document.getElementById(id);
      sel.innerHTML = '';
      valid.forEach(function (c, i) {
        var o = document.createElement('option');
        o.value = c.name; o.textContent = c.name;
        if (i === which) { o.selected = true; }
        sel.appendChild(o);
      });
    });
    document.getElementById('cmp-results').innerHTML = '';
    document.getElementById('cmp-download').disabled = true;
    cmpReport = null;
    show('compare');
  }

  document.getElementById('cmp-run').addEventListener('click', function () {
    var nameA = document.getElementById('cmp-a').value;
    var nameB = document.getElementById('cmp-b').value;
    if (nameA === nameB) { alert('Choose two different files.'); return; }
    var A = state.craFiles.filter(function (c) { return c.name === nameA && c.ok; })[0];
    var B = state.craFiles.filter(function (c) { return c.name === nameB && c.ok; })[0];
    if (!A || !B) { alert('Both files must be valid.'); return; }

    // V2-M7 (spec §7.2): optional seeded permutation null for WR′
    var perm = null;
    if (document.getElementById('cmp-perm').checked) {
      perm = window.CrawdadInference.wrPermutation(A.data, B.data,
        { B: 999, seed: 42 }, { resonance: window.CrawdadResonance });
    }
    var rep = window.CrawdadResonance.buildReport(A.data, B.data, (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER), perm);
    cmpReport = { name: 'comparison_' + nameA.replace(/_cra\.md$/i, '') + '_vs_' +
      nameB.replace(/_cra\.md$/i, '') + '.md', markdown: rep.markdown };

    var c = rep.result;
    var html = '';
    if (perm) {
      html += '<p class="hint">Permutation test (' + perm.B + ' permutations, seed ' +
        perm.seed + '): observed WR′ ' + perm.observed + ' vs. permuted mean ' +
        perm.permMean + ', empirical p = ' + perm.permP +
        (perm.permP <= 0.05 ? ' — resonance above chance.' : ' — within chance range.') + '</p>';
    }
    html += '<h3>Resonance</h3><table><thead><tr><th>Measure</th><th>Value</th></tr></thead><tbody>' +
      '<tr><td>Word resonance WR (Eq. 2)</td><td>' + c.WR.toExponential(4) + '</td></tr>' +
      "<tr><td>Word resonance WR&prime; (Eq. 3, 0&ndash;1)</td><td><strong>" + c.WRs.toFixed(5) + '</strong></td></tr>' +
      '<tr><td>Pair resonance PR (Eq. 5)</td><td>' + c.PR.toExponential(4) + '</td></tr>' +
      "<tr><td>Pair resonance PR&prime; (Eq. 6, 0&ndash;1)</td><td><strong>" + c.PRs.toFixed(5) + '</strong></td></tr>' +
      '</tbody></table>';

    function wordTable(title, rows, cols) {
      var h = '<h3>' + esc(title) + '</h3><table><thead><tr>' +
        cols.map(function (x) { return '<th>' + x + '</th>'; }).join('') +
        '</tr></thead><tbody>';
      if (!rows.length) { h += '<tr><td colspan="' + cols.length + '">(none)</td></tr>'; }
      rows.forEach(function (r) {
        h += '<tr><td>' + esc(r.display) + '</td>' +
          (r.iA !== undefined
            ? '<td>' + r.iA.toFixed(5) + '</td><td>' + r.iB.toFixed(5) + '</td>'
            : '<td>' + r.i.toFixed(5) + '</td>') + '</tr>';
      });
      return h + '</tbody></table>';
    }
    html += wordTable('Common words (ranked by min(I_A, I_B))', c.common,
      ['Word', 'Influence in A', 'Influence in B']);
    html += wordTable('Unique to ' + c.fileA, c.uniqueA, ['Word', 'Influence']);
    html += wordTable('Unique to ' + c.fileB, c.uniqueB, ['Word', 'Influence']);
    document.getElementById('cmp-results').innerHTML = html;
    document.getElementById('cmp-download').disabled = false;
  });

  document.getElementById('cmp-download').addEventListener('click', function () {
    if (cmpReport) { IO.downloadFile(cmpReport.name, cmpReport.markdown); }
  });
  document.getElementById('cmp-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Classifier screen (M5) ---------------- */
  var clsReport = null;
  var clsCtx = null; // cached run: { names, mats, cls, mds } — enables instant K switching

  function openClassifier() {
    document.getElementById('cls-results').innerHTML = '';
    document.getElementById('cls-mdsplot').innerHTML = '';
    document.getElementById('cls-aggregate').innerHTML = '';
    document.getElementById('cls-download').disabled = true;
    clsReport = null;
    clsCtx = null;
    show('classify');
  }

  document.getElementById('cls-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (valid.length < 5) { alert('Classifier needs 5 or more valid files.'); return; }
    var names = valid.map(function (c) { return c.name; });
    var datas = valid.map(function (c) { return c.data; });
    var C = window.CrawdadClassifier, R = window.CrawdadResonance;

    var mats = C.resonanceMatrices(datas, R);
    var kSel = document.getElementById('cls-k').value;
    var cls = C.classify(mats.wrs, undefined,
      kSel === 'auto' ? {} : { forceK: parseInt(kSel, 10) });

    var mds = null;
    if (document.getElementById('cls-mds').checked) {
      var D = mats.wrs.map(function (row) { return row.map(function (v) { return 1 - v; }); });
      mds = C.classicalMDS(D);
    }

    clsCtx = { names: names, mats: mats, cls: cls, mds: mds };
    // V2-M7 (spec §7.3): Hennig cluster-wise Jaccard bootstrap on the
    // accepted solution (recomputed on live K switch below)
    clsCtx.wantStability = document.getElementById('cls-stability').checked;
    renderClassification(cls.best, cls.rule);
  });

  // Live K switching: solutions for every K are already computed, so changing
  // K after a run re-renders instantly from cache (no recomputation).
  document.getElementById('cls-k').addEventListener('change', function () {
    if (!clsCtx) { return; } // nothing run yet
    var v = this.value;
    var cls = clsCtx.cls;
    if (v === 'auto') {
      // restore the rule-selected solution from the original (auto) run
      var auto = window.CrawdadClassifier.classify(clsCtx.mats.wrs);
      clsCtx.cls = auto;
      renderClassification(auto.best, auto.rule);
      return;
    }
    var k = parseInt(v, 10);
    var t = cls.tried.filter(function (x) { return x.k === k; })[0];
    if (!t) { alert('K = ' + k + ' not available (max is ' +
      cls.tried[cls.tried.length - 1].k + ' for this file count).'); return; }
    renderClassification(t, 'K = ' + k + ' selected manually by user (viewing alternative solution).');
  });

  function renderClassification(best, rule) {
    var names = clsCtx.names, mats = clsCtx.mats, cls = clsCtx.cls, mds = clsCtx.mds;
    var C = window.CrawdadClassifier;

    // remember what is being viewed; the report is built fresh at download
    // time so it always captures the current K view AND the current HAC cut
    clsCtx.current = { best: best, rule: rule };
    clsCtx.stability = clsCtx.wantStability
      ? window.CrawdadInference.clusterStability(mats.wrs, best.labels,
          { B: 100, seed: 42 }, { classifier: C })
      : null;
    document.getElementById('cls-download').disabled = false;

    // ---- results HTML ----
    var html = '<h3>Cluster membership (K = ' + best.k +
      ', mean silhouette ' + best.silhouette.toFixed(3) +
      ', sizes ' + best.sizes.join('/') + ')</h3>' +
      '<p class="hint">' + esc(rule) +
      ' — change K in the selector above to view alternative solutions instantly.</p>' +
      (best.hasSingleton
        ? '<p class="hint" style="color:#b03a2e">Note: this solution contains a singleton ' +
          'cluster — one text stands alone. Check whether it is a true outlier.</p>' : '') +
      '<table><thead><tr><th>Text</th><th>Cluster</th></tr></thead><tbody>' +
      names.map(function (nm, i) {
        return '<tr><td>' + esc(nm) + '</td><td>' + (best.labels[i] + 1) + '</td></tr>';
      }).join('') + '</tbody></table>';
    if (clsCtx.stability) {
      html += '<h3>Cluster stability (Jaccard bootstrap, B = ' + clsCtx.stability.B +
        ', seed ' + clsCtx.stability.seed + ')</h3>' +
        '<table><thead><tr><th>Cluster</th><th>Mean Jaccard</th><th>Reading (Hennig, 2007)</th></tr></thead><tbody>' +
        clsCtx.stability.clusters.map(function (sc) {
          return '<tr><td>S' + sc.cluster + '</td><td>' + sc.meanJaccard + '</td><td>' +
            esc(sc.verdict) + '</td></tr>';
        }).join('') + '</tbody></table>' +
        '<p class="hint">Clusters below 0.5 dissolve under resampling and should not be interpreted as real structure.</p>';
    }
    html += '<h3>Silhouette by K</h3><table><thead><tr><th>K</th><th>Mean silhouette</th>' +
      '<th>Cluster sizes</th><th>Singleton?</th><th></th></tr></thead><tbody>' +
      cls.tried.map(function (t) {
        return '<tr><td>' + t.k + (t.k === best.k ? ' <strong>(viewing)</strong>' : '') +
          '</td><td>' + t.silhouette.toFixed(4) + '</td><td>' + t.sizes.join(', ') +
          '</td><td>' + (t.hasSingleton ? 'yes' : 'no') + '</td><td>' +
          (t.k === best.k ? '' :
            '<button class="linklike cls-view" data-k="' + t.k + '">view</button>') +
          '</td></tr>';
      }).join('') + '</tbody></table>';
    html += "<h3>Word resonance matrix (WR&prime;)</h3>" + C.matrixHtml(names.map(esc), mats.wrs, "WR'");
    document.getElementById('cls-results').innerHTML = html;

    // per-row "view" links switch solutions too
    document.querySelectorAll('#cls-results .cls-view').forEach(function (b) {
      b.addEventListener('click', function () {
        var k = parseInt(this.getAttribute('data-k'), 10);
        document.getElementById('cls-k').value = String(k);
        var t = cls.tried.filter(function (x) { return x.k === k; })[0];
        renderClassification(t, 'K = ' + k + ' selected manually by user (viewing alternative solution).');
      });
    });

    // ---- interactive HAC dendrogram (D-13) ----
    renderDendrogram();

    // ---- MDS plot (positions fixed; only colors change with K) ----
    if (mds) { drawMdsPlot(names, mds.points, best.labels); }
    else { document.getElementById('cls-mdsplot').innerHTML = ''; }

    // ---- WF 6e post-analysis options (rebuilt for the viewed K) ----
    var agg = document.getElementById('cls-aggregate');
    agg.innerHTML = '<h3>Cluster aggregation (optional)</h3>';
    for (var k = 0; k < best.k; k++) {
      (function (k) {
        var members = names.filter(function (_, i) { return best.labels[i] === k; });
        var haveSources = members.every(function (nm) {
          return state.sourceTexts && state.sourceTexts[nm];
        });
        var div = document.createElement('div');
        div.style.margin = '6px 0';
        var btn = document.createElement('button');
        btn.className = 'linklike';
        btn.textContent = 'Aggregate cluster ' + (k + 1) + ' (' + members.length +
          ' texts) → generate cluster' + (k + 1) + '_cra.md';
        btn.disabled = !haveSources;
        btn.title = haveSources ? ''
          : 'Available only when the source texts were generated in this session ' +
            '(loading _cra.md files alone does not include the original text).';
        btn.addEventListener('click', function () { aggregateCluster(k, members); });
        div.appendChild(btn);
        if (!haveSources) {
          var sp = document.createElement('span');
          sp.className = 'hint';
          sp.textContent = ' (needs in-session source texts)';
          div.appendChild(sp);
        }
        agg.appendChild(div);
      })(k);
    }
  }

  /* ---------------- interactive HAC dendrogram (D-13) ---------------- */

  function renderDendrogram() {
    var wrap = document.getElementById('cls-dendro-wrap');
    if (!clsCtx) { wrap.hidden = true; return; }
    var names = clsCtx.names, mats = clsCtx.mats;
    var C = window.CrawdadClassifier;
    var n = names.length;

    var D = mats.wrs.map(function (row) { return row.map(function (v) { return 1 - v; }); });
    var tree;
    try { tree = C.hac(D); } catch (e) { wrap.hidden = true; return; }
    clsCtx.hacTree = tree;

    var W = 900, H = 420, padL = 56, padR = 16, padT = 14, padB = 96;
    var plotW = W - padL - padR, plotH = H - padT - padB;
    var hMax = Math.max(tree.maxHeight * 1.08, 1e-6);
    function sy(h) { return padT + plotH - (h / hMax) * plotH; } // height -> y
    function yToH(y) { return Math.max(0, Math.min(hMax, (padT + plotH - y) / plotH * hMax)); }

    // leaf x positions in leafOrder
    var leafX = {};
    tree.leafOrder.forEach(function (leaf, i) {
      leafX[leaf] = padL + (n === 1 ? plotW / 2 : (i / (n - 1)) * plotW);
    });
    // internal node positions bottom-up
    var nodeX = {}, nodeY = {};
    tree.leafOrder.forEach(function (leaf) { nodeX[leaf] = leafX[leaf]; nodeY[leaf] = padT + plotH; });
    var links = [];
    tree.merges.forEach(function (m) {
      var xa = nodeX[m.a], xb = nodeX[m.b];
      var ya = nodeY[m.a], yb = nodeY[m.b];
      var y = sy(m.height);
      nodeX[m.id] = (xa + xb) / 2;
      nodeY[m.id] = y;
      links.push({ xa: xa, xb: xb, ya: ya, yb: yb, y: y });
    });

    // initial cut: midpoint between the last two merge heights (gives K=2),
    // or just below max for small trees
    var initH = tree.merges.length >= 2
      ? (tree.merges[tree.merges.length - 2].height + tree.maxHeight) / 2
      : tree.maxHeight * 0.9;

    var svgParts = ['<svg id="dendro-svg" viewBox="0 0 ' + W + ' ' + H +
      '" style="background:#fff;border:1px solid #d7dde2;max-width:100%;touch-action:none">'];
    // y-axis ticks
    for (var tI = 0; tI <= 4; tI++) {
      var hVal = hMax * tI / 4, yv = sy(hVal);
      svgParts.push('<line x1="' + (padL - 4) + '" y1="' + yv + '" x2="' + (W - padR) +
        '" y2="' + yv + '" stroke="#eef1f3"/>');
      svgParts.push('<text x="' + (padL - 8) + '" y="' + (yv + 4) +
        '" text-anchor="end" font-size="10" fill="#5c6b78">' + hVal.toFixed(2) + '</text>');
    }
    svgParts.push('<text x="12" y="' + (padT + plotH / 2) +
      '" font-size="10" fill="#5c6b78" transform="rotate(-90 12 ' + (padT + plotH / 2) +
      ')" text-anchor="middle">distance (1 − WR′)</text>');
    // elbow links
    links.forEach(function (l) {
      svgParts.push('<path d="M' + l.xa + ',' + l.ya + ' V' + l.y + ' H' + l.xb +
        ' V' + l.yb + '" fill="none" stroke="#8a97a1" stroke-width="1.4"/>');
    });
    // leaf labels (rotated)
    tree.leafOrder.forEach(function (leaf) {
      var x = leafX[leaf], y = padT + plotH + 10;
      svgParts.push('<g class="dendro-leaf" data-leaf="' + leaf + '">' +
        '<circle cx="' + x + '" cy="' + (padT + plotH) + '" r="4" fill="#8a97a1"/>' +
        '<text x="' + x + '" y="' + y + '" font-size="11" fill="#1f2a33" ' +
        'transform="rotate(35 ' + x + ' ' + y + ')" text-anchor="start">' +
        esc(names[leaf].replace(/_cra\.md$/i, '')) + '</text></g>');
    });
    // draggable cut bar
    svgParts.push('<g id="cutbar" style="cursor:ns-resize">' +
      '<line id="cutline" x1="' + padL + '" x2="' + (W - padR) +
      '" y1="0" y2="0" stroke="#cc2200" stroke-width="2" stroke-dasharray="7,4"/>' +
      '<rect id="cutgrab" x="' + padL + '" width="' + plotW +
      '" y="0" height="16" fill="transparent"/>' +
      '<text id="cutlabel" x="' + (W - padR - 4) + '" y="0" text-anchor="end" ' +
      'font-size="11" fill="#cc2200" font-weight="bold"></text></g>');
    svgParts.push('</svg>');
    document.getElementById('cls-dendro').innerHTML = svgParts.join('');
    wrap.hidden = false;

    var svg = document.getElementById('dendro-svg');
    var colors = clusterColors(8);

    function applyCut(h) {
      var labels = tree.cutAt(h);
      var k = Math.max.apply(null, labels) + 1;
      clsCtx.hacCut = { height: h, k: k, labels: labels };
      // color leaves
      tree.leafOrder.forEach(function (leaf) {
        var g = svg.querySelector('.dendro-leaf[data-leaf="' + leaf + '"]');
        var col = colors[labels[leaf] % colors.length];
        g.querySelector('circle').setAttribute('fill', col);
        g.querySelector('text').setAttribute('fill', col);
      });
      // move bar
      var y = sy(h);
      svg.querySelector('#cutline').setAttribute('y1', y);
      svg.querySelector('#cutline').setAttribute('y2', y);
      svg.querySelector('#cutgrab').setAttribute('y', y - 8);
      var lbl = svg.querySelector('#cutlabel');
      lbl.setAttribute('y', y - 5);
      lbl.textContent = 'cut ' + h.toFixed(3) + ' → K=' + k;
      // quality metrics
      var sil = null;
      if (k >= 2 && k < names.length) {
        sil = C.silhouette(mats.wrs, labels).mean;
      }
      var sizes = new Array(k).fill(0);
      labels.forEach(function (l) { sizes[l]++; });
      clsCtx.hacCut.silhouette = sil;
      clsCtx.hacCut.sizes = sizes;
      document.getElementById('cls-dendro-stats').innerHTML =
        'K = <strong>' + k + '</strong> · sizes ' + sizes.join('/') +
        ' · mean silhouette ' + (sil === null ? '—' : '<strong>' + sil.toFixed(4) + '</strong>') +
        (sizes.indexOf(1) !== -1 ? ' · <span style="color:#b03a2e">contains singleton</span>' : '') +
        ' — the downloaded report includes this cut.';
      // membership listing grouped by cluster
      var groups = [];
      for (var c = 0; c < k; c++) {
        groups.push(names.filter(function (_, i2) { return labels[i2] === c; })
          .map(function (nm) { return esc(nm.replace(/_cra\.md$/i, '')); }).join(', '));
      }
      document.getElementById('cls-dendro-members').innerHTML =
        '<table><thead><tr><th>Cluster</th><th>Members</th></tr></thead><tbody>' +
        groups.map(function (g2, ci) {
          return '<tr><td style="color:' + colors[ci % colors.length] + ';font-weight:bold">' +
            (ci + 1) + '</td><td>' + g2 + '</td></tr>';
        }).join('') + '</tbody></table>';
    }

    // drag handling (pointer events on the whole svg for easy grabbing)
    var dragging = false;
    function svgY(evt) {
      var r = svg.getBoundingClientRect();
      return (evt.clientY - r.top) * (H / r.height);
    }
    svg.querySelector('#cutbar').addEventListener('pointerdown', function (e) {
      dragging = true; e.preventDefault();
      svg.setPointerCapture && svg.setPointerCapture(e.pointerId);
    });
    svg.addEventListener('pointermove', function (e) {
      if (!dragging) { return; }
      applyCut(yToH(svgY(e)));
    });
    svg.addEventListener('pointerup', function () { dragging = false; });
    svg.addEventListener('pointerleave', function () { dragging = false; });
    // click anywhere on plot also sets the cut
    svg.addEventListener('click', function (e) {
      var y = svgY(e);
      if (y > padT - 6 && y < padT + plotH + 6) { applyCut(yToH(y)); }
    });

    applyCut(initH);
  }

  function aggregateCluster(k, members) {
    // (a) aggregate texts, (b) re-run Generator, (c) new _cra.md, (d) offer Visualizer
    var text = members.map(function (nm) { return state.sourceTexts[nm]; }).join('\n\n');
    var opts = {
      stemming: document.getElementById('set-stemming').value,
      keepPronouns: document.getElementById('set-pronouns').checked,
      interSentenceLinking: document.getElementById('set-intersentence').checked,
      excludeWords: document.getElementById('set-exclude').value
        .split(',').map(function (w) { return w.trim().toLowerCase(); })
        .filter(Boolean)
    };
    if (!parserInstance || parserInstance._keepPronouns !== opts.keepPronouns) {
      parserInstance = window.CrawdadParser.createParser({ keepPronouns: opts.keepPronouns });
      parserInstance._keepPronouns = opts.keepPronouns;
    }
    var deps = {
      parser: parserInstance, porter2: window.CrawdadWink.porter2,
      sentiment: window.CrawdadWink.sentiment,
      isStopWord: window.CrawdadStopWords.isStopWord, schema: S,
      network: window.CrawdadNetwork, textclean: window.CrawdadTextClean,
      textmetrics: window.CrawdadTextMetrics
    };
    try {
      var res = window.CrawdadGenerator.generate('cluster' + (k + 1) + '.txt', text, opts, deps);
      var outName = 'cluster' + (k + 1) + '_cra.md';
      var parsedBack = S.parseCra(res.craMd);
      state.craFiles = state.craFiles.filter(function (c) { return c.name !== outName; });
      state.craFiles.push({ name: outName, text: res.craMd, ok: parsedBack.ok,
        data: parsedBack.data, errors: parsedBack.errors });
      IO.downloadFile(outName, res.craMd);
      renderAnaList();
      if (confirm(outName + ' generated (' + res.craData.network.nodes.length +
          ' nodes). Open it in the Visualizer now?')) {
        openVisualizer();
        document.getElementById('viz-file').value = outName;
        document.getElementById('viz-render').click();
      }
    } catch (err) { alert('Aggregation failed: ' + err.message); }
  }

  function clusterColors(k) {
    var palette = ['#b03a2e', '#1f618d', '#1e7d46', '#8a6d00', '#6c3483', '#0e6655', '#a04000', '#4d5656'];
    return palette.slice(0, k);
  }

  function drawMdsPlot(names, points, labels) {
    var W = 860, H = 480, pad = 60;
    var xs = points.map(function (p) { return p[0]; });
    var ys = points.map(function (p) { return p[1]; });
    var xmin = Math.min.apply(null, xs), xmax = Math.max.apply(null, xs);
    var ymin = Math.min.apply(null, ys), ymax = Math.max.apply(null, ys);
    function sx(x) { return pad + (xmax === xmin ? 0.5 : (x - xmin) / (xmax - xmin)) * (W - 2 * pad); }
    function sy(y) { return H - pad - (ymax === ymin ? 0.5 : (y - ymin) / (ymax - ymin)) * (H - 2 * pad); }
    var colors = clusterColors(Math.max.apply(null, labels) + 1);
    var svg = ['<h3>MDS plot (classical MDS on 1 − WR&prime;)</h3>',
      '<svg viewBox="0 0 ' + W + ' ' + H + '" style="background:#fff;border:1px solid #d7dde2;max-width:100%">'];
    points.forEach(function (p, i) {
      var x = sx(p[0]), y = sy(p[1]);
      svg.push('<circle cx="' + x + '" cy="' + y + '" r="7" fill="' + colors[labels[i]] + '"/>');
      svg.push('<text x="' + (x + 10) + '" y="' + (y + 4) +
        '" font-size="12" font-family="Georgia,serif" fill="#1f2a33">' +
        esc(names[i].replace(/_cra\.md$/i, '')) + ' (' + (labels[i] + 1) + ')</text>');
    });
    svg.push('</svg>');
    document.getElementById('cls-mdsplot').innerHTML = svg.join('');
  }

  document.getElementById('cls-download').addEventListener('click', function () {
    if (!clsCtx || !clsCtx.current) { return; }
    var C = window.CrawdadClassifier;
    var md = C.buildReport(clsCtx.names, clsCtx.mats,
      { tried: clsCtx.cls.tried, best: clsCtx.current.best, rule: clsCtx.current.rule },
      clsCtx.mds, (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER), clsCtx.hacCut || null, clsCtx.stability || null);
    IO.downloadFile('classification_' +
      new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md', md);
  });
  document.getElementById('cls-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Theme Identifier screen (M6) ---------------- */
  var thmReport = null;

  function openThemes() {
    document.getElementById('thm-results').innerHTML = '';
    document.getElementById('thm-download').disabled = true;
    thmReport = null;
    show('themes');
  }

  document.getElementById('thm-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (valid.length < 5) { alert('Theme Identifier needs 5 or more valid files.'); return; }
    var names = valid.map(function (c) { return c.name.replace(/_cra\.md$/i, ''); });
    var datas = valid.map(function (c) { return c.data; });
    var rep = window.CrawdadThemes.themeReport(datas, names, (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER));
    thmReport = {
      name: 'themes_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: rep.markdown
    };
    document.getElementById('thm-download').disabled = false;

    // reuse the report's HTML tables; convert md bullet section to simple HTML
    var md = rep.markdown.split('## Data (machine-readable')[0];
    var html = md
      .replace(/^# .*$/m, '')
      .replace(/^## (.*)$/gm, '<h3>$1</h3>')
      .replace(/^- \*\*(Theme \d+)\*\*(.*)$/gm, '<p><strong>$1</strong>$2</p>')
      .replace(/^- (.*)$/gm, '<p class="hint">$1</p>')
      .replace(/^\|(.*)\|$/gm, function (line) { return mdRow(line); })
      .replace(/\n{2,}/g, '\n');
    document.getElementById('thm-results').innerHTML =
      html + '<p class="hint">Full detail is in the downloadable report.</p>';
  });

  // minimal md-table row -> HTML (for the top-words table in the results pane)
  var mdRowState = { open: false };
  function mdRow(line) {
    if (/^\|[\s-|]+\|$/.test(line)) { return ''; } // separator row
    var cells = line.slice(1, -1).split('|').map(function (c) { return c.trim(); });
    var isHeader = !mdRowState.open;
    var tag = isHeader ? 'th' : 'td';
    var row = '<tr>' + cells.map(function (c) { return '<' + tag + '>' + c + '</' + tag + '>'; }).join('') + '</tr>';
    if (isHeader) { mdRowState.open = true; return '<table>' + row; }
    return row;
  }

  document.getElementById('thm-download').addEventListener('click', function () {
    if (thmReport) { IO.downloadFile(thmReport.name, thmReport.markdown); }
  });
  document.getElementById('thm-back').addEventListener('click', function () {
    mdRowState.open = false; show('analyze');
  });

  /* ---------------- Latent Theme Identifier screen (M6) ---------------- */
  var latReport = null;
  var latCodeRows = null;

  function openLatent() {
    document.getElementById('lat-results').innerHTML = '';
    document.getElementById('lat-download').disabled = true;
    document.getElementById('lat-run').disabled = !latCodeRows;
    latReport = null;
    show('latent');
  }

  document.getElementById('lat-codes').addEventListener('change', function (e) {
    var f = e.target.files[0];
    if (!f) { return; }
    var label = document.getElementById('lat-codes-name');
    function done(rows) {
      latCodeRows = rows;
      label.textContent = ' Loaded: ' + f.name + ' (' + rows.length + ' rows)';
      document.getElementById('lat-run').disabled = false;
    }
    if (/\.csv$/i.test(f.name)) {
      IO.readFileAsText(f).then(function (t) {
        done(window.CrawdadTextClean.parseCsvPairs(t));
      });
    } else {
      var r = new FileReader();
      r.onload = function () {
        try { done(window.CrawdadTextClean.parseXlsxPairs(r.result)); }
        catch (err) { alert('Could not read spreadsheet: ' + err.message); }
      };
      r.readAsArrayBuffer(f);
    }
  });

  document.getElementById('lat-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (!valid.length) { alert('Load at least one valid _cra.md file first.'); return; }
    if (!latCodeRows || !latCodeRows.length) { alert('Load a latent codes file first.'); return; }

    // stem code words to match the files' stemming setting (warn if mixed)
    var modes = {};
    valid.forEach(function (c) {
      modes[(c.data.parameters && c.data.parameters.stemming) || 'porter'] = true;
    });
    var modeList = Object.keys(modes);
    var mode = modeList[0];
    var stemFn = mode === 'porter' ? window.CrawdadWink.porter2
      : mode === 'minimal' ? window.CrawdadNetwork.minimalStem
      : function (w) { return w; };
    var note = 'Code words stemmed with "' + mode + '" to match the files.' +
      (modeList.length > 1
        ? ' **Warning: loaded files use mixed stemming settings (' + modeList.join(', ') +
          ') — matching may be inconsistent.**' : '');

    var names = valid.map(function (c) { return c.name.replace(/_cra\.md$/i, ''); });
    var datas = valid.map(function (c) { return c.data; });
    var themes = window.CrawdadThemes.parseLatentCodes(latCodeRows, stemFn);
    if (!Object.keys(themes).length) { alert('No themes found in the codes file.'); return; }
    var rep = window.CrawdadThemes.latentReport(datas, names, themes, (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER), note);
    latReport = {
      name: 'latent_themes_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: rep.markdown
    };
    document.getElementById('lat-download').disabled = false;

    var html = '<h3>Theme scores (summed total influence)</h3>' +
      '<table><thead><tr><th>Theme</th>' +
      names.map(function (nm) { return '<th>' + esc(nm) + '</th>'; }).join('') +
      '</tr></thead><tbody>' +
      Object.keys(themes).map(function (t) {
        return '<tr><td>' + esc(t) + '</td>' + rep.result.table[t].map(function (v) {
          return '<td>' + v.toFixed(5) + '</td>'; }).join('') + '</tr>';
      }).join('') + '</tbody></table>' +
      '<p class="hint">' + esc(note.replace(/\*\*/g, '')) + '</p>' +
      '<p class="hint">Coverage: ' + rep.result.coverage.found.length +
      ' code word(s) matched; ' + rep.result.coverage.missing.length + ' unmatched' +
      (rep.result.coverage.missing.length
        ? ' — <span style="color:#b03a2e">' + esc(rep.result.coverage.missing.join(', ')) + '</span>'
        : '') + '.</p>';
    document.getElementById('lat-results').innerHTML = html;
  });

  document.getElementById('lat-download').addEventListener('click', function () {
    if (latReport) { IO.downloadFile(latReport.name, latReport.markdown); }
  });
  document.getElementById('lat-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Summarizer screen (M7, spec §7.6) ---------------- */
  /* (LLM features unwired 2026-07-09 per Kevin; module retained in js/llm.js) */
  var sumReport = null;

  function openSummarizer() {
    document.getElementById('sum-results').innerHTML = '';
    document.getElementById('sum-download').disabled = true;
    sumReport = null;
    show('summarize');
  }

  document.getElementById('sum-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (valid.length < 2) { alert('Summarizer needs 2 or more valid files.'); return; }
    var names = valid.map(function (c) { return c.name.replace(/_cra\.md$/i, ''); });
    var datas = valid.map(function (c) { return c.data; });
    var rep = window.CrawdadThemes.summarizerReport(datas, names, (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER));
    sumReport = {
      name: 'summary_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: rep.markdown
    };
    document.getElementById('sum-download').disabled = false;

    var html = '<h3>Text profiles (network + text-level metrics)</h3>' +
      '<div style="overflow-x:auto"><table><thead><tr><th>Text</th>' +
      rep.profile.columns.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') +
      '</tr></thead><tbody>' +
      rep.profile.rows.map(function (r) {
        return '<tr><td>' + esc(r.name) + '</td>' + r.values.map(function (v) {
          return '<td>' + (v === null ? '—' : v) + '</td>';
        }).join('') + '</tr>';
      }).join('') + '</tbody></table></div>' +
      '<p class="hint">— = file generated before metrics were added; regenerate to fill in.</p>';

    html += '<h3>Most influential words (top ' + rep.wtm.words.length + ')</h3>' +
      '<table><thead><tr><th>#</th><th>Word</th><th>Summed</th>' +
      names.map(function (nm) { return '<th>' + esc(nm) + '</th>'; }).join('') +
      '</tr></thead><tbody>' +
      rep.wtm.words.map(function (wr, wi) {
        return '<tr><td>' + (wi + 1) + '</td><td>' + esc(wr.display) + '</td><td>' +
          wr.sum.toFixed(4) + '</td>' +
          rep.wtm.matrix[wi].map(function (v) { return '<td>' + v.toFixed(4) + '</td>'; }).join('') +
          '</tr>';
      }).join('') + '</tbody></table>';
    document.getElementById('sum-results').innerHTML = html;
  });

  document.getElementById('sum-download').addEventListener('click', function () {
    if (sumReport) { IO.downloadFile(sumReport.name, sumReport.markdown); }
  });
  document.getElementById('sum-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Dynamics screen (V2-M6, Build Spec V2 §6.2) ------ */

  var dynReport = null, dynText = null;

  function openDynamics() {
    document.getElementById('dyn-results').innerHTML = '';
    document.getElementById('dyn-download').disabled = true;
    document.getElementById('dyn-text-name').textContent = '';
    dynReport = null; dynText = null;
    show('dynamics');
  }

  document.getElementById('dyn-mode').addEventListener('change', function () {
    var m = this.value;
    document.getElementById('dyn-bucket-opts').hidden = m !== 'bucket';
    document.getElementById('dyn-within-opts').hidden = m !== 'within';
  });

  document.getElementById('dyn-text').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0];
    if (!f) { return; }
    var rd = new FileReader();
    rd.onload = function () {
      dynText = { name: f.name, text: String(rd.result) };
      document.getElementById('dyn-text-name').textContent = f.name + ' loaded';
    };
    rd.readAsText(f);
  });

  /** Within-text mode: sentence-aligned windows, per-window CRA (V2-M6). */
  function withinTextWindows(rawText, rule, size) {
    if (!parserInstance || parserInstance._keepPronouns !== false) {
      parserInstance = window.CrawdadParser.createParser({ keepPronouns: false });
      parserInstance._keepPronouns = false;
    }
    var cleaned = window.CrawdadTextClean.cleanText(rawText);
    var parsed = parserInstance.parse(cleaned.text, {});
    var sents = parsed.sentences;
    var counts = sents.map(function (s) { return (s.tokens || []).length; });
    var cuts = []; // sentence index where each new window starts
    if (rule === 'tiling') {
      var tokens = [];
      var sentStart = [];
      sents.forEach(function (s, si) {
        sentStart.push(tokens.length);
        (s.tokens || []).forEach(function (t) { tokens.push(t.w); });
      });
      var tt = window.CrawdadDynamics.textTiling(tokens, {});
      tt.boundaries.forEach(function (b) {
        // map token boundary to the first sentence starting at/after it
        for (var si = 1; si < sents.length; si++) {
          if (sentStart[si] >= b) { cuts.push(si); break; }
        }
      });
      cuts = cuts.filter(function (c, i) { return cuts.indexOf(c) === i; });
    } else {
      var acc = 0;
      for (var si = 0; si < sents.length; si++) {
        acc += counts[si];
        if (acc >= size && si + 1 < sents.length) { cuts.push(si + 1); acc = 0; }
      }
    }
    var starts = [0].concat(cuts);
    var windows = [], texts = [];
    for (var w = 0; w < starts.length; w++) {
      var from = starts[w], to = w + 1 < starts.length ? starts[w + 1] : sents.length;
      var chunk = sents.slice(from, to);
      if (!chunk.length) { continue; }
      var cra = window.CrawdadNetwork.buildCra(chunk, { stemming: 'porter' },
        { porter2: window.CrawdadWink.porter2,
          isStopWord: window.CrawdadStopWords.isStopWord });
      var sfCounts = Object.create(null), sfTot = 0;
      chunk.forEach(function (sn) {
        (sn.tokens || []).forEach(function (t) {
          sfCounts[t.w] = (sfCounts[t.w] || 0) + 1; sfTot++;
        });
      });
      var sfTokens = Object.keys(sfCounts).map(function (wd) { return [wd, sfCounts[wd]]; });
      windows.push({ name: 'W' + (windows.length + 1),
        data: { network: { nodes: cra.nodes, edges: cra.edges },
          surfaceFrequencies: { totalTokens: sfTot, tokens: sfTokens } } });
      texts.push(chunk); // sentence objects — CrawdadVader.documentSentiment
                         // takes a sentences array, not a string (gate fix)
    }
    return { windows: windows, texts: texts,
      note: rule === 'tiling'
        ? 'within-text, TextTiling boundaries (Hearst, 1997 — pre-2002 gap-fill), sentence-aligned'
        : 'within-text, fixed ~' + size + '-token windows, sentence-aligned' };
  }

  document.getElementById('dyn-run').addEventListener('click', function () {
    var D = window.CrawdadDynamics;
    var mode = document.getElementById('dyn-mode').value;
    var windows, windowNote, arcTexts = null;
    try {
      if (mode === 'within') {
        if (!dynText) { alert('Load a text file for within-text mode.'); return; }
        var rule = document.getElementById('dyn-within-rule').value;
        var size = parseInt(document.getElementById('dyn-within-size').value, 10) || 1000;
        var wt = withinTextWindows(dynText.text, rule, size);
        windows = wt.windows; windowNote = wt.note; arcTexts = wt.texts;
      } else {
        var valid = state.craFiles.filter(function (c) { return c.ok; });
        var files = valid.map(function (c) {
          return { name: c.name.replace(/_cra\.md$/i, ''), data: c.data };
        }).sort(function (a, b) { return a.name < b.name ? -1 : 1; });
        if (mode === 'bucket') {
          var bk = D.bucketize(files, {
            bucketRule: document.getElementById('dyn-bucket-rule').value,
            emptyBucket: document.getElementById('dyn-empty').value
          });
          windows = bk.windows;
          windowNote = 'per-article buckets by ' + bk.rule + ', documents weighted ' +
            'equally; empty buckets: ' + bk.emptyBucket + ' (D-V2-14)';
        } else {
          windows = files;
          windowNote = 'each loaded file = one window, filename order';
        }
      }
      var res = D.runDynamics(windows, {
        mode: mode === 'within' ? 'within-text' : mode,
        windowNote: windowNote,
        evCut: parseFloat(document.getElementById('dyn-evcut').value),
        peltPenaltyMult: parseFloat(document.getElementById('dyn-pelt').value) || 1,
        kCoincide: parseInt(document.getElementById('dyn-k').value, 10) || 2,
        ntrW: parseInt(document.getElementById('dyn-ntrw').value, 10) || 2
      }, { themes: window.CrawdadThemes, resonance: window.CrawdadResonance });

      // within-text valence arc (windowed VADER + DCT low-pass)
      if (arcTexts && window.CrawdadVader) {
        var raw = arcTexts.map(function (chunk) {
          var v = window.CrawdadVader.documentSentiment(chunk);
          return v ? Math.round(v.meanCompound * 1e4) / 1e4 : 0;
        });
        var sm = D.dctLowPass(raw, 5);
        res.arc = { raw: raw, smoothed: sm.smoothed, kept: sm.kept };
      }
      renderDynamics(res);
      dynReport = {
        name: 'dynamics_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
        markdown: D.serializeReport(res,
          (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER))
      };
      document.getElementById('dyn-download').disabled = false;
    } catch (err) { alert('Dynamics: ' + err.message); return; }
  });

  function renderDynamics(res) {
    var pal = window.CrawdadVisualizer.OKABE_ITO;
    var html = '<p class="hint">' + esc(res.caution) + '</p>';
    html += '<h3>Dynamic themes (' + res.kRetain + ')</h3><ul>' +
      res.themes.map(function (t, ti) {
        return '<li><strong style="color:' + pal[ti % pal.length] + '">T' + (ti + 1) +
          '</strong> (' + t.length + '): ' + t.slice(0, 10).map(function (w) {
            return esc(w.display);
          }).join(', ') + (t.length > 10 ? ', …' : '') + '</li>';
      }).join('') + '</ul>';
    html += '<h3>Theme series</h3><canvas id="dyn-series" width="860" height="330" ' +
      'style="border:1px solid #E7E2DA;background:#fff;max-width:100%"></canvas>';
    html += '<h3>Diagnostics + change points</h3>' +
      '<div style="overflow-x:auto"><table><thead><tr><th>Theme</th><th>Model (AICc)</th>' +
      '<th>Reading</th><th>Change points</th></tr></thead><tbody>' +
      res.diagnostics.map(function (d, ti) {
        return '<tr><td>T' + (ti + 1) + '</td><td>' + d.model.best.model + ' ' +
          esc(d.model.best.detail || '') + '</td><td>' + esc(d.model.reading) +
          '</td><td>' + (d.changePointLabels.join(', ') || '—') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
    html += '<p><strong>Stage transitions (≥' + res.parameters.kCoincide +
      ' themes):</strong> ' + (res.stageTransitions.length
        ? res.stageTransitions.map(function (tr) {
            return esc(tr.label) + ' (' + tr.themes.map(function (t) {
              return 'T' + (t + 1);
            }).join(',') + ')';
          }).join(' · ')
        : 'none under current penalty/k') + '</p>';
    if (res.xcorr.links.length) {
      html += '<h3>Temporal relationships (lagged cross-correlations)</h3>' +
        '<div id="dyn-lagdiagram"></div>';
    }
    if (res.seqWR) {
      html += '<h3>Turnover (sequential WR′) ' +
        (res.ntr ? '+ Barron novelty' : '') + '</h3>' +
        '<canvas id="dyn-turnover" width="860" height="240" ' +
        'style="border:1px solid #E7E2DA;background:#fff;max-width:100%"></canvas>';
    }
    if (res.arc) {
      html += '<h3>Valence arc (windowed VADER, DCT-smoothed)</h3>' +
        '<canvas id="dyn-arc" width="860" height="200" ' +
        'style="border:1px solid #E7E2DA;background:#fff;max-width:100%"></canvas>';
    }
    document.getElementById('dyn-results').innerHTML = html;

    // theme series chart
    var cv = document.getElementById('dyn-series');
    var ctx = cv.getContext('2d');
    var n = res.windowNames.length;
    var allV = [];
    res.series.forEach(function (s) { s.forEach(function (v) { allV.push(v); }); });
    var vMax = Math.max.apply(null, allV.concat([1e-9]));
    function sx(i) { return 50 + i / Math.max(1, n - 1) * 770; }
    function sy(v) { return 290 - v / vMax * 260; }
    ctx.font = '10px "IBM Plex Sans", sans-serif';
    ctx.strokeStyle = '#E7E2DA';
    ctx.beginPath(); ctx.moveTo(50, 290); ctx.lineTo(820, 290); ctx.stroke();
    res.windowNames.forEach(function (nm, i) {
      ctx.fillStyle = '#6E6862';
      ctx.save();
      ctx.translate(sx(i), 305); ctx.rotate(-0.6);
      ctx.fillText(String(nm).slice(0, 10), -18, 0);
      ctx.restore();
    });
    res.series.forEach(function (s, ti) {
      ctx.strokeStyle = pal[ti % pal.length];
      ctx.lineWidth = 2;
      ctx.beginPath();
      s.forEach(function (v, i) {
        if (i === 0) { ctx.moveTo(sx(i), sy(v)); } else { ctx.lineTo(sx(i), sy(v)); }
      });
      ctx.stroke();
      // change-point markers
      res.diagnostics[ti].changePoints.forEach(function (cp) {
        ctx.fillStyle = pal[ti % pal.length];
        ctx.beginPath();
        ctx.arc(sx(cp), sy(s[cp]), 4, 0, 2 * Math.PI);
        ctx.fill();
      });
      ctx.fillStyle = pal[ti % pal.length];
      ctx.fillText('T' + (ti + 1), 824, sy(s[n - 1]) + 3);
    });

    // lag diagram (Fig.-5 form): theme boxes on a circle, arrows with lags
    if (res.xcorr.links.length) {
      var K = res.kRetain, R = 100, CX = 200, CY = 130;
      var pos = [];
      for (var t2 = 0; t2 < K; t2++) {
        var ang = -Math.PI / 2 + 2 * Math.PI * t2 / K;
        pos.push([CX + R * Math.cos(ang), CY + R * Math.sin(ang)]);
      }
      var svg = ['<svg viewBox="0 0 720 270" style="max-width:100%;background:#fff;border:1px solid #E7E2DA">'];
      svg.push('<defs><marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0L10,5L0,10z" fill="#3D3833"/></marker></defs>');
      res.xcorr.links.forEach(function (l) {
        var a = pos[l.from], b = pos[l.to];
        var dx = b[0] - a[0], dy = b[1] - a[1];
        var len = Math.sqrt(dx * dx + dy * dy);
        var ux = dx / len, uy = dy / len;
        var x1 = a[0] + ux * 26, y1 = a[1] + uy * 26;
        var x2 = b[0] - ux * 26, y2 = b[1] - uy * 26;
        svg.push('<line x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 +
          '" stroke="#3D3833" stroke-width="1.3"' +
          (l.lag > 0 ? ' marker-end="url(#arr)"' : ' stroke-dasharray="4 3"') + '/>');
        svg.push('<text x="' + ((x1 + x2) / 2 + 5) + '" y="' + ((y1 + y2) / 2 - 4) +
          '" font-size="10" fill="#6E6862">' +
          (l.lag > 0 ? 'lag ' + l.lag : 'r=' + l.r) + '</text>');
      });
      pos.forEach(function (p, ti) {
        svg.push('<circle cx="' + p[0] + '" cy="' + p[1] + '" r="22" fill="#F4F1EC" stroke="' +
          pal[ti % pal.length] + '" stroke-width="2.5"/>');
        svg.push('<text x="' + p[0] + '" y="' + (p[1] + 4) +
          '" text-anchor="middle" font-size="12" fill="#16130F">T' + (ti + 1) + '</text>');
      });
      svg.push('<text x="380" y="30" font-size="11" fill="#6E6862">Solid arrow = lagged ' +
        '(direction of lead), dashed = lag-0; |r| ≥ ' + res.xcorr.sig +
        (res.xcorr.cycles.length ? ' · CYCLES: ' + res.xcorr.cycles.map(function (c) {
          return 'T' + (c.a + 1) + '⇄T' + (c.b + 1);
        }).join(' ') : '') + '</text>');
      svg.push('</svg>');
      document.getElementById('dyn-lagdiagram').innerHTML = svg.join('');
    }

    // turnover + novelty chart
    if (res.seqWR) {
      var cv2 = document.getElementById('dyn-turnover');
      var c2 = cv2.getContext('2d');
      c2.font = '10px "IBM Plex Sans", sans-serif';
      function tx(i) { return 50 + i / Math.max(1, n - 1) * 770; }
      c2.strokeStyle = '#16130F'; c2.lineWidth = 2;
      c2.beginPath();
      res.seqWR.forEach(function (s2, i) {
        var x = (tx(i) + tx(i + 1)) / 2, y = 200 - s2.wrp * 170;
        if (i === 0) { c2.moveTo(x, y); } else { c2.lineTo(x, y); }
      });
      c2.stroke();
      c2.fillStyle = '#16130F'; c2.fillText('WR′ (0–1)', 55, 20);
      if (res.ntr) {
        var novMax = Math.max.apply(null, res.ntr.rows.map(function (r) {
          return r.novelty || 0;
        }).concat([1e-9]));
        c2.strokeStyle = '#C63C15'; c2.lineWidth = 1.6;
        c2.beginPath();
        var started = false;
        res.ntr.rows.forEach(function (r, i) {
          if (r.novelty === null) { return; }
          var x = tx(i), y = 200 - r.novelty / novMax * 170;
          if (!started) { c2.moveTo(x, y); started = true; } else { c2.lineTo(x, y); }
        });
        c2.stroke();
        c2.fillStyle = '#C63C15'; c2.fillText('Barron novelty (scaled)', 140, 20);
      }
      res.windowNames.forEach(function (nm, i) {
        c2.fillStyle = '#6E6862';
        c2.save(); c2.translate(tx(i), 232); c2.rotate(-0.6);
        c2.fillText(String(nm).slice(0, 10), -18, 0); c2.restore();
      });
    }

    // arc chart
    if (res.arc) {
      var cv3 = document.getElementById('dyn-arc');
      var c3 = cv3.getContext('2d');
      c3.font = '10px "IBM Plex Sans", sans-serif';
      function ax(i) { return 50 + i / Math.max(1, n - 1) * 770; }
      function ay(v) { return 100 - v * 80; }
      c3.strokeStyle = '#E7E2DA';
      c3.beginPath(); c3.moveTo(50, 100); c3.lineTo(820, 100); c3.stroke();
      c3.strokeStyle = '#6E6862'; c3.lineWidth = 1;
      c3.beginPath();
      res.arc.raw.forEach(function (v, i) {
        if (i === 0) { c3.moveTo(ax(i), ay(v)); } else { c3.lineTo(ax(i), ay(v)); }
      });
      c3.stroke();
      c3.strokeStyle = '#F04E23'; c3.lineWidth = 2.5;
      c3.beginPath();
      res.arc.smoothed.forEach(function (v, i) {
        if (i === 0) { c3.moveTo(ax(i), ay(v)); } else { c3.lineTo(ax(i), ay(v)); }
      });
      c3.stroke();
      c3.fillStyle = '#6E6862';
      c3.fillText('gray = raw VADER; orange = DCT low-pass (' + res.arc.kept + ' components)', 55, 16);
    }
  }

  document.getElementById('dyn-download').addEventListener('click', function () {
    if (dynReport) { IO.downloadFile(dynReport.name, dynReport.markdown); }
  });
  document.getElementById('dyn-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Stylometry screen (V2-M5, Build Spec V2 §6.1) ---- */

  var styReport = null, stySources = {};

  function openStylometry() {
    document.getElementById('sty-results').innerHTML = '';
    document.getElementById('sty-download').disabled = true;
    document.getElementById('sty-src-note').textContent = '';
    styReport = null; stySources = {};
    show('stylometry');
  }

  document.getElementById('sty-src').addEventListener('change', function (ev) {
    var files = Array.prototype.slice.call(ev.target.files || []);
    var pending = files.length;
    if (!pending) { return; }
    files.forEach(function (f) {
      var rd = new FileReader();
      rd.onload = function () {
        stySources[f.name.replace(/\.(txt|md)$/i, '')] = String(rd.result);
        if (--pending === 0) {
          document.getElementById('sty-src-note').textContent =
            Object.keys(stySources).length + ' source text(s) loaded for NCD';
        }
      };
      rd.readAsText(f);
    });
  });

  document.getElementById('sty-run').addEventListener('click', function () {
    var ST2 = window.CrawdadStylometry, C = window.CrawdadClassifier;
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (valid.length < 3) { alert('Stylometry needs 3 or more valid files.'); return; }
    var names = valid.map(function (c) { return c.name.replace(/_cra\.md$/i, ''); });
    var datas = valid.map(function (c) { return c.data; });
    var res;
    try {
      res = ST2.stylometry(datas, names, {
        mfw: parseInt(document.getElementById('sty-mfw').value, 10) || 200,
        culling: parseInt(document.getElementById('sty-culling').value, 10),
        sourceTexts: Object.keys(stySources).length ? stySources : null
      }, { deflateFn: (typeof pako !== 'undefined')
            ? function (u8) { return pako.deflate(u8); } : null,
          deflateLabel: 'pako 3.0.1 deflate (vendored)' });
    } catch (err) { alert('Stylometry: ' + err.message); return; }

    styReport = {
      name: 'stylometry_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: ST2.serializeReport(res,
        (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER))
    };
    document.getElementById('sty-download').disabled = false;

    function matTable(title, nms, D) {
      return '<h3>' + title + '</h3><div style="overflow-x:auto"><table><thead><tr><th></th>' +
        nms.map(function (nm) { return '<th>' + esc(nm) + '</th>'; }).join('') +
        '</tr></thead><tbody>' +
        nms.map(function (nm, i) {
          return '<tr><td><strong>' + esc(nm) + '</strong></td>' +
            D[i].map(function (v, j) {
              return '<td>' + (i === j ? '—' : v) + '</td>';
            }).join('') + '</tr>';
        }).join('') + '</tbody></table></div>';
    }

    var html = '<p class="hint">MFW ' + res.parameters.mfw + ', culling ' +
      res.parameters.culling + '%. Delta attributes among the candidates given; ' +
      'it does not verify authorship absolutely.</p>';
    if (res.warnings.length) {
      html += '<p class="hint">' + res.warnings.map(function (w) {
        return '⚠ ' + esc(w);
      }).join('<br>') + '</p>';
    }
    html += matTable('Burrows Delta', res.names, res.delta);
    html += matTable('Cosine Delta (Evert et al., 2017)', res.names, res.cosine);
    if (res.ncd) {
      html += matTable('NCD (' + esc(res.ncd.compressor) + ')', res.ncd.names, res.ncd.D);
    } else {
      html += '<p class="hint">NCD not computed — load matching source .txt files above to add it.</p>';
    }

    // ---- style clustering for free: K-means (√n rule) + HAC + MDS ----
    var cls = C.classify(res.z);
    var best = cls.best;
    html += '<h3>Style clusters (K-means on z-profiles, √n rule + silhouette)</h3><p>' +
      'K = ' + best.k + ' (silhouette ' + (Math.round(best.silhouette * 1000) / 1000) + '): ' +
      res.names.map(function (nm, i) {
        return esc(nm) + ' → S' + (best.labels[i] + 1);
      }).join(' · ') + '</p>';

    // static dendrogram on the Burrows Delta matrix
    var tree = C.hac(res.delta);
    var W2 = 880, H2 = 360, padL2 = 50, padT2 = 12, padB2 = 110;
    var plotW2 = W2 - padL2 - 14, plotH2 = H2 - padT2 - padB2;
    var hMax2 = Math.max(tree.maxHeight * 1.08, 1e-6);
    function sy2(h) { return padT2 + plotH2 - (h / hMax2) * plotH2; }
    var leafX2 = {}, nodeX2 = {}, nodeY2 = {};
    tree.leafOrder.forEach(function (leaf, i) {
      leafX2[leaf] = padL2 + (res.names.length === 1 ? plotW2 / 2
        : (i / (res.names.length - 1)) * plotW2);
      nodeX2[leaf] = leafX2[leaf]; nodeY2[leaf] = padT2 + plotH2;
    });
    var parts = ['<svg viewBox="0 0 ' + W2 + ' ' + H2 +
      '" style="background:#fff;border:1px solid #E7E2DA;max-width:100%">'];
    tree.merges.forEach(function (m) {
      var y = sy2(m.height);
      parts.push('<path d="M' + nodeX2[m.a] + ',' + nodeY2[m.a] + ' V' + y +
        ' H' + nodeX2[m.b] + ' V' + nodeY2[m.b] +
        '" fill="none" stroke="#8a97a1" stroke-width="1.4"/>');
      nodeX2[m.id] = (nodeX2[m.a] + nodeX2[m.b]) / 2;
      nodeY2[m.id] = y;
    });
    tree.leafOrder.forEach(function (leaf) {
      parts.push('<text x="' + leafX2[leaf] + '" y="' + (padT2 + plotH2 + 12) +
        '" font-size="10" fill="#3D3833" transform="rotate(55 ' + leafX2[leaf] + ' ' +
        (padT2 + plotH2 + 12) + ')">' + esc(res.names[leaf]) + '</text>');
    });
    parts.push('<text x="12" y="' + (padT2 + plotH2 / 2) +
      '" font-size="10" fill="#6E6862" transform="rotate(-90 12 ' +
      (padT2 + plotH2 / 2) + ')" text-anchor="middle">Burrows Delta</text>');
    parts.push('</svg>');
    html += '<h3>HAC dendrogram (Burrows Delta)</h3>' + parts.join('');
    html += '<h3>MDS map (Burrows Delta)</h3><canvas id="sty-mds" width="760" height="400" ' +
      'style="border:1px solid #E7E2DA;background:#fff;max-width:100%"></canvas>';
    document.getElementById('sty-results').innerHTML = html;

    var mds = C.classicalMDS(res.delta);
    var cv = document.getElementById('sty-mds');
    var ctx = cv.getContext('2d');
    var pal = window.CrawdadVisualizer.OKABE_ITO;
    var xs = mds.points.map(function (p) { return p[0]; });
    var ys = mds.points.map(function (p) { return p[1]; });
    var xMin = Math.min.apply(null, xs), xMax = Math.max.apply(null, xs);
    var yMin = Math.min.apply(null, ys), yMax = Math.max.apply(null, ys);
    function px2(x) { return 50 + (xMax === xMin ? 0.5 : (x - xMin) / (xMax - xMin)) * 660; }
    function py2(y) { return 25 + (yMax === yMin ? 0.5 : (y - yMin) / (yMax - yMin)) * 330; }
    ctx.font = '11px "IBM Plex Sans", sans-serif';
    res.names.forEach(function (nm, i) {
      ctx.fillStyle = pal[best.labels[i] % pal.length];
      ctx.beginPath();
      ctx.arc(px2(mds.points[i][0]), py2(mds.points[i][1]), 5, 0, 2 * Math.PI);
      ctx.fill();
      ctx.fillStyle = '#3D3833';
      ctx.fillText(nm.slice(0, 20), px2(mds.points[i][0]) + 8, py2(mds.points[i][1]) + 4);
    });
    ctx.fillStyle = '#6E6862';
    ctx.fillText('Classical MDS of Burrows Delta; color = K-means style cluster', 50, 390);
  });

  document.getElementById('sty-download').addEventListener('click', function () {
    if (styReport) { IO.downloadFile(styReport.name, styReport.markdown); }
  });
  document.getElementById('sty-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Topic Modeler screen (V2-M4, Build Spec V2 §5.1) - */

  var topReport = null;

  function openTopics() {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    var kSel = document.getElementById('top-k');
    kSel.innerHTML = '<option value="">auto (√n rule)</option>';
    var kMax = Math.min(12, valid.length - 1);
    for (var k = 2; k <= kMax; k++) {
      var o = document.createElement('option');
      o.value = k; o.textContent = 'K = ' + k;
      kSel.appendChild(o);
    }
    document.getElementById('top-results').innerHTML = '';
    document.getElementById('top-download').disabled = true;
    topReport = null;
    show('topics');
  }

  document.getElementById('top-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (valid.length < 8) { alert('Topic Modeler needs 8 or more valid files.'); return; }
    var names = valid.map(function (c) { return c.name.replace(/_cra\.md$/i, ''); });
    var datas = valid.map(function (c) { return c.data; });
    var mode = document.getElementById('top-mode').value;
    var kOverride = document.getElementById('top-k').value;
    var res;
    try {
      res = window.CrawdadTopics.topicModel(datas, names,
        { mode: mode, k: kOverride ? parseInt(kOverride, 10) : undefined },
        { isStopWord: window.CrawdadKeyphrases.isKpStopWord,
          jacobiEig: window.CrawdadThemes.jacobiEig });
    } catch (err) { alert('Topic Modeler: ' + err.message); return; }

    topReport = {
      name: 'topics_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: window.CrawdadTopics.serializeReport(res,
        (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER))
    };
    document.getElementById('top-download').disabled = false;

    var html = '<h3>K = ' + res.k + ' (' + esc(res.parameters.kRule) + ')</h3>';
    if (res.excluded.length) {
      html += '<p class="hint">Excluded (no surface frequencies): ' +
        esc(res.excluded.join(', ')) + '</p>';
    }
    html += '<table><thead><tr><th>K</th><th>UMass coherence</th><th>Iterations</th>' +
      '<th>Error</th></tr></thead><tbody>' +
      res.coherenceByK.map(function (r) {
        return '<tr' + (r.k === res.k ? ' style="font-weight:600"' : '') + '><td>' +
          r.k + (r.k === res.k ? ' ←' : '') + '</td><td>' + r.coherence + '</td><td>' +
          r.nIter + '</td><td>' + r.error + '</td></tr>';
      }).join('') + '</tbody></table>';
    html += res.topics.map(function (t, ti) {
      return '<h3>Topic ' + t.topic + ' <span class="hint">(coherence ' +
        res.coherencePerTopic[ti] + ')</span></h3><p>' +
        t.words.map(function (w) {
          return esc(w.word) + ' <span class="hint">(' + w.weight + ')</span>';
        }).join(', ') + '</p>';
    }).join('');
    html += '<h3>Document–topic loadings (share)</h3>' +
      '<div style="overflow-x:auto"><table><thead><tr><th>Text</th><th>Dominant</th>' +
      res.topics.map(function (t) { return '<th>T' + t.topic + '</th>'; }).join('') +
      '</tr></thead><tbody>' +
      res.loadings.map(function (d) {
        return '<tr><td>' + esc(d.name) + '</td><td>T' + d.dominant + '</td>' +
          d.share.map(function (v) { return '<td>' + v + '</td>'; }).join('') + '</tr>';
      }).join('') + '</tbody></table></div>';
    html += '<h3>Topic-labeled MDS overlay</h3><canvas id="top-mds" width="760" height="440" ' +
      'style="border:1px solid #E7E2DA;background:#fff;max-width:100%"></canvas>';
    document.getElementById('top-results').innerHTML = html;

    // MDS of documents on topic-share space, colored by dominant topic
    // (Okabe–Ito, hue sanctioned: computed grouping)
    var n = res.loadings.length;
    var D = [];
    for (var i2 = 0; i2 < n; i2++) {
      D.push(new Array(n).fill(0));
      for (var j2 = 0; j2 < n; j2++) {
        var s2 = 0;
        for (var t2 = 0; t2 < res.k; t2++) {
          var dd = res.loadings[i2].share[t2] - res.loadings[j2].share[t2];
          s2 += dd * dd;
        }
        D[i2][j2] = Math.sqrt(s2);
      }
    }
    var mds = window.CrawdadClassifier.classicalMDS(D);
    var cv = document.getElementById('top-mds');
    var ctx = cv.getContext('2d');
    var pal = window.CrawdadVisualizer.OKABE_ITO;
    var xs = mds.points.map(function (p) { return p[0]; });
    var ys = mds.points.map(function (p) { return p[1]; });
    var xMin = Math.min.apply(null, xs), xMax = Math.max.apply(null, xs);
    var yMin = Math.min.apply(null, ys), yMax = Math.max.apply(null, ys);
    function px(x) { return 50 + (xMax === xMin ? 0.5 : (x - xMin) / (xMax - xMin)) * 660; }
    function py(y) { return 30 + (yMax === yMin ? 0.5 : (y - yMin) / (yMax - yMin)) * 360; }
    ctx.font = '11px "IBM Plex Sans", sans-serif';
    res.loadings.forEach(function (d, i3) {
      var c = pal[(d.dominant - 1) % pal.length];
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.arc(px(mds.points[i3][0]), py(mds.points[i3][1]), 5, 0, 2 * Math.PI);
      ctx.fill();
      ctx.fillStyle = '#3D3833';
      ctx.fillText(d.name.slice(0, 18), px(mds.points[i3][0]) + 8, py(mds.points[i3][1]) + 4);
    });
    ctx.fillStyle = '#6E6862';
    ctx.fillText('Classical MDS of document topic shares; color = dominant topic (Okabe–Ito)', 50, 430);
  });

  document.getElementById('top-download').addEventListener('click', function () {
    if (topReport) { IO.downloadFile(topReport.name, topReport.markdown); }
  });
  document.getElementById('top-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Keyness screen (V2-M3, Build Spec V2 §4) --------- */

  var keyReport = null;

  function openKeyness() {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    var host = document.getElementById('key-groups');
    var rows = valid.map(function (c, i) {
      var hasSf = !!(c.data && c.data.surfaceFrequencies &&
        c.data.surfaceFrequencies.totalTokens);
      var def = i < Math.ceil(valid.length / 2) ? 'A' : 'B';
      if (!hasSf) {
        return '<tr><td>' + esc(c.name) + '</td><td colspan="3" class="hint">' +
          'no surface frequencies — regenerate with v2.0.0-M1 or later</td></tr>';
      }
      return '<tr><td>' + esc(c.name) + '</td>' +
        ['A', 'B', 'skip'].map(function (g) {
          return '<td><label><input type="radio" name="keyg-' + i + '" value="' + g +
            '"' + (g === def ? ' checked' : '') + '> ' + g + '</label></td>';
        }).join('') + '</tr>';
    }).join('');
    host.innerHTML = '<h3>Assign files to groups</h3>' +
      '<table><thead><tr><th>File</th><th>Group A</th><th>Group B</th><th>Skip</th></tr></thead>' +
      '<tbody>' + rows + '</tbody></table>';
    document.getElementById('key-results').innerHTML = '';
    document.getElementById('key-download').disabled = true;
    keyReport = null;
    show('keyness');
  }

  document.getElementById('key-run').addEventListener('click', function () {
    var K = window.CrawdadKeyness;
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    var docsA = [], docsB = [], namesA = [], namesB = [];
    valid.forEach(function (c, i) {
      var sel = document.querySelector('input[name="keyg-' + i + '"]:checked');
      if (!sel || sel.value === 'skip') { return; }
      var d = K.docFromCra(c.name, c.data);
      if (!d) { return; }
      if (sel.value === 'A') { docsA.push(d); namesA.push(c.name); }
      else { docsB.push(d); namesB.push(c.name); }
    });
    if (docsA.length < 1 || docsB.length < 1) {
      alert('Keyness needs at least one file with surface frequencies in each group.');
      return;
    }
    var usePerm = document.getElementById('key-perm').checked;
    var res = K.computeKeyness(docsA, docsB, {
      minFreq: parseInt(document.getElementById('key-minfreq').value, 10) || 3,
      permutations: usePerm
        ? (parseInt(document.getElementById('key-permn').value, 10) || 999) : 0,
      seed: parseInt(document.getElementById('key-seed').value, 10) || 42
    });
    keyReport = {
      name: 'keyness_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: K.serializeReport(res, namesA, namesB,
        (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER))
    };
    document.getElementById('key-download').disabled = false;

    var permCol = res.parameters.permutations > 0;
    var html = '<h3>Key words (by G²) — A: ' + res.totals.docsA + ' file(s), ' +
      res.totals.NA + ' tokens · B: ' + res.totals.docsB + ' file(s), ' +
      res.totals.NB + ' tokens</h3>' +
      '<p class="hint">G² is evidence; Log Ratio is effect size (each doubling of the ' +
      'relative rate adds 1). ⚠ = found in fewer than half the overusing group\'s ' +
      'documents (keyness driven by one document).</p>' +
      '<div style="overflow-x:auto"><table><thead><tr><th>Word</th><th>Dir</th>' +
      '<th>Freq A</th><th>/1k A</th><th>Freq B</th><th>/1k B</th><th>G²</th><th>p</th>' +
      (permCol ? '<th>perm p</th>' : '') +
      '<th>Log Ratio</th><th>%DIFF</th><th>DP</th><th>Docs</th><th></th></tr></thead><tbody>' +
      res.keywords.map(function (r) {
        return '<tr><td>' + esc(r.word) + '</td><td>' + r.direction + '</td><td>' +
          r.freqA + '</td><td>' + r.per1kA + '</td><td>' + r.freqB + '</td><td>' +
          r.per1kB + '</td><td>' + r.g2 + '</td><td>' +
          (r.p < 0.0001 ? '&lt;0.0001' : Math.round(r.p * 1e4) / 1e4) + '</td>' +
          (permCol ? '<td>' + r.permP + '</td>' : '') +
          '<td>' + r.logRatio + '</td><td>' + (r.pctDiff === null ? 'A-only' : r.pctDiff) +
          '</td><td>' + (r.dp === null ? '—' : r.dp) + '</td><td>' + r.docShare +
          '</td><td>' + (r.warn ? '⚠' : '') + '</td></tr>';
      }).join('') + '</tbody></table></div>';

    function zetaTable(title, list, key, dCol, oCol, dTot, oTot) {
      if (!list.length) { return '<h3>' + title + '</h3><p class="hint">none above 1</p>'; }
      return '<h3>' + title + '</h3><table><thead><tr><th>Word</th><th>Zeta</th>' +
        '<th>In own docs</th><th>In other docs</th></tr></thead><tbody>' +
        list.map(function (r) {
          return '<tr><td>' + esc(r.word) + '</td><td>' + r[key] + '</td><td>' +
            r[dCol] + '/' + dTot + '</td><td>' + r[oCol] + '/' + oTot + '</td></tr>';
        }).join('') + '</tbody></table>';
    }
    html += zetaTable('Zeta marker words for A', res.zetaA, 'zetaA', 'docsA', 'docsB',
      res.totals.docsA, res.totals.docsB);
    html += zetaTable('Zeta marker words for B', res.zetaB, 'zetaB', 'docsB', 'docsA',
      res.totals.docsB, res.totals.docsA);
    document.getElementById('key-results').innerHTML = html;
  });

  document.getElementById('key-download').addEventListener('click', function () {
    if (keyReport) { IO.downloadFile(keyReport.name, keyReport.markdown); }
  });
  document.getElementById('key-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- E-2: session bundle save/load ---------------- */

  document.getElementById('ana-save-bundle').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (!valid.length) { alert('No valid files loaded.'); return; }
    var zip = new window.JSZip();
    valid.forEach(function (c) { zip.file(c.name, c.text); });
    zip.file('session-info.json', JSON.stringify({
      schema: 'crawdad-session', schemaVersion: '1.0',
      saved: new Date().toISOString(), files: valid.map(function (c) { return c.name; })
    }, null, 1));
    zip.generateAsync({ type: 'blob' }).then(function (blob) {
      IO.downloadFile('crawdad-session-' +
        new Date().toISOString().slice(0, 10) + '.zip', blob, 'application/zip');
    });
  });

  document.getElementById('ana-load-bundle').addEventListener('change', function (e) {
    var f = e.target.files[0];
    if (!f) { return; }
    window.JSZip.loadAsync(f).then(function (zip) {
      var loads = [];
      zip.forEach(function (path, entry) {
        if (/_cra\.md$/i.test(path) && !entry.dir) {
          loads.push(entry.async('string').then(function (text) {
            var res = S.parseCra(text);
            state.craFiles = state.craFiles.filter(function (c) { return c.name !== path; });
            state.craFiles.push({ name: path, text: text, ok: res.ok,
              data: res.data, errors: res.errors });
          }));
        }
      });
      return Promise.all(loads);
    }).then(function () {
      renderAnaList();
      e.target.value = '';
    }).catch(function (err) { alert('Could not read bundle: ' + err.message); });
  });

  /* ---------------- E-3: batch PNG export ---------------- */

  function exportAllPngs(done) {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (!valid.length) { if (done) { done(0); } return; }
    var topK = parseInt(document.getElementById('viz-topk').value, 10) || 30;
    var highlight = parseFloat(document.getElementById('viz-highlight').value);
    if (isNaN(highlight)) { highlight = 0.05; }
    var i = 0, made = 0;
    function next() {
      if (i >= valid.length) { if (done) { done(made); } return; }
      var c = valid[i++];
      try {
        var h = window.CrawdadVisualizer.render(
          document.getElementById('viz-canvas'), c.data, { topK: topK, highlight: highlight });
        h.exportPng(function (err, blob) {
          if (!err) {
            IO.downloadFile('crawdad-network-' + c.name.replace(/_cra\.md$/i, '') + '.png',
              blob, 'image/png');
            made++;
          }
          setTimeout(next, 500); // stagger downloads
        });
      } catch (e) { setTimeout(next, 50); }
    }
    next();
  }

  document.getElementById('viz-export-all').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (!valid.length) { alert('No valid files loaded.'); return; }
    exportAllPngs(null);
  });

  /* ---------------- D-11: batch pipeline ---------------- */

  function runBatchPipeline() {
    var prog = document.getElementById('batch-progress');
    function step(msg) { prog.textContent = 'Batch: ' + msg; }

    // 1. load all generated files into the analysis session
    sendToAnalyze(state.genResults);
    var n = state.craFiles.filter(function (c) { return c.ok; }).length;

    // 2. download all _cra.md files
    step('downloading ' + state.genResults.length + ' _cra.md file(s)…');
    state.genResults.forEach(function (r, i) {
      setTimeout(function () { IO.downloadFile(r.outName, r.craMd); }, i * 350);
    });
    var delay = state.genResults.length * 350 + 400;

    // 3. visualizer PNGs for every file
    setTimeout(function () {
      step('rendering network PNGs…');
      exportAllPngs(function () {
        // 4-6: analyses, staggered so the browser accepts each download
        var stages = [];
        if (n >= 5) {
          stages.push({ msg: 'classifying…', run: 'cls-run', dl: 'cls-download' });
          stages.push({ msg: 'identifying themes…', run: 'thm-run', dl: 'thm-download' });
        }
        if (n >= 2) {
          stages.push({ msg: 'summarizing…', run: 'sum-run', dl: 'sum-download' });
        }
        var si = 0;
        function nextStage() {
          if (si >= stages.length) {
            var skipped = [];
            if (n < 5) { skipped.push('Classifier and Theme Identifier (need 5+ files, have ' + n + ')'); }
            if (n < 2) { skipped.push('Summarizer (needs 2+ files)'); }
            step('done — all outputs downloaded.' +
              (skipped.length ? ' Skipped: ' + skipped.join('; ') + '.' : ''));
            return;
          }
          var st = stages[si++];
          step(st.msg);
          try {
            document.getElementById(st.run).dispatchEvent(new Event('click'));
            document.getElementById(st.dl).dispatchEvent(new Event('click'));
          } catch (e) { /* stage failure shouldn't halt the batch */ }
          setTimeout(nextStage, 600);
        }
        nextStage();
      });
    }, delay);
  }

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch];
    });
  }

  /* ---------------- Universal PDF report downloads (V2-M7) ------------
   * Kevin 2026-08-11: every report download in every tool offers .md or
   * .pdf. The PDF is the readable companion — machine block stripped by
   * CrawdadPdfReport.reportFromMarkdown, Design Guide styling. */

  function savePdfReport(md, mdName) {
    var doc = window.CrawdadPdfReport.reportFromMarkdown(md);
    doc.save(mdName.replace(/\.md$/i, '') + '.pdf');
  }
  function addPdfButton(afterId, onClick) {
    var mdBtn = document.getElementById(afterId);
    if (!mdBtn) { return; }
    var b = document.createElement('button');
    b.className = 'secondary';
    b.id = afterId + '-pdf';
    b.textContent = 'PDF';
    b.title = 'Readable PDF of this report (machine data stripped)';
    b.style.marginLeft = '6px';
    mdBtn.parentNode.insertBefore(b, mdBtn.nextSibling);
    b.addEventListener('click', onClick);
  }
  [['cmp-download', function () { return cmpReport; }],
   ['thm-download', function () { return thmReport; }],
   ['lat-download', function () { return latReport; }],
   ['sum-download', function () { return sumReport; }],
   ['key-download', function () { return keyReport; }],
   ['top-download', function () { return topReport; }],
   ['sty-download', function () { return styReport; }],
   ['dyn-download', function () { return dynReport; }]
  ].forEach(function (w) {
    addPdfButton(w[0], function () {
      var rep = w[1]();
      if (!rep) { alert('Run the analysis first.'); return; }
      savePdfReport(rep.markdown, rep.name);
    });
  });
  // Classifier builds its markdown on demand rather than caching it
  addPdfButton('cls-download', function () {
    if (!clsCtx || !clsCtx.current) { alert('Run the classifier first.'); return; }
    var C = window.CrawdadClassifier;
    var md = C.buildReport(clsCtx.names, clsCtx.mats,
      { tried: clsCtx.cls.tried, best: clsCtx.current.best, rule: clsCtx.current.rule },
      clsCtx.mds, (S.CITATION + "\n\n" + S.softwareCitation(window.CrawdadGenerator.APP_VERSION) + "\n\n" + S.DISCLAIMER), clsCtx.hacCut || null, clsCtx.stability || null);
    savePdfReport(md, 'classification_' +
      new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md');
  });

  renderModuleMenu();
  show('landing');

  // test hook (harmless in production; used by tests)
  window.__crawdadDebug = { state: state, renderModuleMenu: renderModuleMenu,
    renderAnaList: renderAnaList, runBatchPipeline: runBatchPipeline };
})();
