/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M2 — keyphrase extraction (Build Spec V2 §3.3)
 *
 * Two deterministic, single-document methods, reported side by side:
 *
 *  TextRank (Mihalcea & Tarau, 2004): PageRank on a POS-filtered word
 *  co-occurrence graph (nouns + adjectives; window 2 = adjacency in the
 *  token stream), top-third vertices (capped at 20) merged into phrases
 *  where selected words are adjacent in the text. PageRank uses the
 *  networkx convention (damping 0.85, scores sum to 1) via the same
 *  routine as the CRA node statistics — oracle-validated against
 *  networkx.pagerank. Phrase score = sum of member word scores (a
 *  documented reporting choice; the paper ranks single words only).
 *
 *  YAKE (Campos et al., 2020): purely statistical, no POS. In-house port
 *  of the reference implementation (LIAAD yake, algorithm as published):
 *  term features TCase/TPos/TFNorm/TRel/TSpread combined into S(t), n-gram
 *  score S(kw) = prod(S)/(TF*(1+sum S)) with the reference's "bi"
 *  stopword weighting, Levenshtein deduplication at 0.9. LOWER scores are
 *  better. Deliberate deviations, documented: (1) sentence segmentation
 *  comes from the app's parser (wink-nlp) and tokenization from a simpler
 *  case-preserving tokenizer rather than segtok — the scoring core is
 *  validated exactly (1e-9) against the reference on identical token
 *  streams, and end-to-end agreement is tested on real fixtures; (2) the
 *  deduplication metric is normalized Levenshtein similarity (the
 *  reference default is a SequenceMatcher-style heuristic); (3) stopwords
 *  are an in-house enumeration of English closed-class function words
 *  (below) — the reference ships its own list, provenance unstated, which
 *  licensing ruling 2 forbids bundling.
 */
(function (root) {
  'use strict';

  /* ------------------------------------------------------------------ *
   * Shared small utilities
   * ------------------------------------------------------------------ */

  function round5(x) { return Math.round(x * 1e5) / 1e5; }

  function median(xs) {
    var a = xs.slice().sort(function (x, y) { return x - y; });
    var n = a.length;
    if (n === 0) { return 0; }
    return n % 2 ? a[(n - 1) / 2] : (a[n / 2 - 1] + a[n / 2]) / 2;
  }

  function levenshtein(a, b) {
    var m = a.length, n = b.length, i, j;
    if (m === 0) { return n; }
    if (n === 0) { return m; }
    var prev = new Array(n + 1), cur = new Array(n + 1);
    for (j = 0; j <= n; j++) { prev[j] = j; }
    for (i = 1; i <= m; i++) {
      cur[0] = i;
      for (j = 1; j <= n; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1,
          prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
      }
      var t = prev; prev = cur; cur = t;
    }
    return prev[n];
  }

  function levSimilarity(a, b) {
    var mx = Math.max(a.length, b.length);
    return mx === 0 ? 1 : 1 - levenshtein(a, b) / mx;
  }

  /* ------------------------------------------------------------------ *
   * YAKE tokenizer (case-preserving; approximates the reference's
   * segtok tokenizer on ordinary prose — deviation documented above)
   * ------------------------------------------------------------------ */

  /* ------------------------------------------------------------------ *
   * Keyphrase stopword list — in-house enumeration of English CLOSED-CLASS
   * function words (articles, pronouns, prepositions, conjunctions,
   * auxiliaries/modals, degree/frequency adverbs, quantifiers). YAKE
   * requires a full function-word list (Crawdad's CRA stop list is only a
   * POS-filter safety net); the reference implementation's own list cannot
   * be bundled under licensing ruling 2 (provenance unstated), so this list
   * is authored for Crawdad. Closed-class membership is a grammatical fact,
   * not a licensable resource.
   * ------------------------------------------------------------------ */
  var KP_STOPWORDS = [
    // articles & demonstratives
    'a', 'an', 'the', 'this', 'that', 'these', 'those',
    // pronouns & possessives
    'i', 'me', 'my', 'mine', 'myself', 'we', 'us', 'our', 'ours', 'ourselves',
    'you', 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his',
    'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they',
    'them', 'their', 'theirs', 'themselves', 'one', 'ones', 'oneself',
    'who', 'whom', 'whose', 'which', 'what', 'whatever', 'whoever',
    'whichever', 'something', 'anything', 'nothing', 'everything', 'someone',
    'anyone', 'everyone', 'somebody', 'anybody', 'nobody', 'everybody', 'none',
    // prepositions & particles
    'of', 'in', 'on', 'at', 'to', 'from', 'by', 'with', 'without', 'within',
    'about', 'above', 'below', 'under', 'over', 'between', 'among', 'through',
    'throughout', 'during', 'before', 'after', 'since', 'until', 'till',
    'toward', 'towards', 'against', 'across', 'along', 'around', 'behind',
    'beside', 'besides', 'beyond', 'despite', 'except', 'inside', 'outside',
    'into', 'onto', 'off', 'out', 'up', 'down', 'near', 'per', 'via', 'upon',
    'amid', 'amidst', 'amongst', 'unto', 'atop', 'unlike', 'like', 'versus',
    // conjunctions & complementizers
    'and', 'or', 'but', 'nor', 'so', 'yet', 'for', 'as', 'if', 'then',
    'because', 'although', 'though', 'while', 'whereas', 'unless', 'whether',
    'once', 'when', 'whenever', 'where', 'wherever', 'why', 'how', 'than',
    'that', 'lest', 'albeit',
    // auxiliaries, modals, copulas
    'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'do', 'does',
    'did', 'doing', 'done', 'have', 'has', 'had', 'having', 'can', 'could',
    'will', 'would', 'shall', 'should', 'may', 'might', 'must', 'ought',
    'cannot', 'dare', 'need',
    // negation, degree & frequency adverbs, discourse connectives
    'not', 'no', 'yes', 'nor', 'never', 'always', 'often', 'sometimes',
    'seldom', 'rarely', 'ever', 'again', 'too', 'very', 'quite', 'rather',
    'almost', 'nearly', 'just', 'only', 'even', 'still', 'already', 'also',
    'else', 'perhaps', 'maybe', 'however', 'therefore', 'thus', 'hence',
    'moreover', 'furthermore', 'nevertheless', 'nonetheless', 'meanwhile',
    'otherwise', 'instead', 'anyway', 'indeed', 'accordingly', 'consequently',
    'here', 'there', 'now', 'then', 'soon', 'later', 'ago', 'away', 'back',
    'well', 'much', 'more', 'most', 'less', 'least', 'quite', 'enough',
    // quantifiers & numerals-as-determiners
    'all', 'any', 'some', 'each', 'every', 'either', 'neither', 'both',
    'few', 'fewer', 'many', 'several', 'such', 'same', 'other', 'others',
    'another', 'own', 'certain', 'various',
    // contractions surviving tokenization
    'nt', 's', 't', 'd', 'll', 'm', 're', 've', 'etc',
    // citation fragments (fix 2026-10-28, parser diagnostics: the "et. al."
    // typo defeats the cleaning rules and wink tags et/al as NOUN; the app
    // stop list blocks them from the network, but keyphrases need their own
    // entries since KP_STOPWORDS is an independent closed-class list)
    'et', 'al', 'ibid', 'viz', 'cf', 'eg', 'ie'
  ];
  var KP_STOPSET = Object.create(null);
  KP_STOPWORDS.forEach(function (w) { KP_STOPSET[w] = true; });
  function isKpStopWord(w) { return KP_STOPSET[w] === true; }

  var TOKEN_RE = /(?:[A-Za-z]\.){2,}|[A-Za-z]+(?:-[A-Za-z]+)*|\d+(?:[.,]\d+)*|\S/g;

  /** Tokenize one sentence string into case-preserved tokens. */
  function yakeTokenize(sentence) {
    var out = [], m;
    TOKEN_RE.lastIndex = 0;
    while ((m = TOKEN_RE.exec(String(sentence))) !== null) {
      var w = m[0];
      // reference filter: drop apostrophe-led fragments ("'s", "'t")
      if (w.charAt(0) === "'" && w.length > 1) { continue; }
      if (w.length > 0) { out.push(w); }
    }
    return out;
  }

  var PUNCT = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"; // string.punctuation
  function isPunctChar(c) { return PUNCT.indexOf(c) !== -1; }
  function allPunct(w) {
    for (var i = 0; i < w.length; i++) { if (!isPunctChar(w.charAt(i))) { return false; } }
    return w.length > 0;
  }

  /** Reference get_tag: d digit / u unusual / a acronym / n proper noun / p plain. */
  function yakeTag(word, posInSentence) {
    var noComma = word.replace(/,/g, '');
    if (/^\d+$/.test(noComma) || /^\d*\.?\d+$/.test(noComma.replace('.', ''))) {
      // mirrors: word.replace(',','').isdigit() or ...replace('.','',1).isdigit()
      if (/^\d+$/.test(noComma) || /^\d+\.\d+$/.test(noComma) ||
          /^\.\d+$/.test(noComma) || /^\d+\.$/.test(noComma)) { return 'd'; }
    }
    var cdigit = 0, calpha = 0, cexclude = 0, i, c;
    for (i = 0; i < word.length; i++) {
      c = word.charAt(i);
      if (/\d/.test(c)) { cdigit++; }
      if (/[A-Za-z]/.test(c)) { calpha++; }
      if (isPunctChar(c)) { cexclude++; }
    }
    if ((cdigit > 0 && calpha > 0) || (cdigit === 0 && calpha === 0) || cexclude > 1) {
      return 'u';
    }
    if (word === word.toUpperCase() && /[A-Z]/.test(word)) { return 'a'; }
    if (word.length > 1 && /^[A-Z]/.test(word) && posInSentence > 0) {
      var nUpper = 0;
      for (i = 0; i < word.length; i++) { if (/[A-Z]/.test(word.charAt(i))) { nUpper++; } }
      if (nUpper === 1) { return 'n'; }
    }
    return 'p';
  }

  /* ------------------------------------------------------------------ *
   * YAKE core (reference-faithful; operates on tokenized sentences)
   * ------------------------------------------------------------------ */

  /**
   * Run YAKE on pre-tokenized sentences (case-preserved tokens).
   * opts: { isStopWord: fn(lowercaseWord)->bool, n (3), windowSize (1),
   *         top (20), dedupLim (0.9) }
   * Returns [{ phrase, score }] — LOWER score = more important.
   */
  function yake(tokenizedSentences, opts) {
    opts = opts || {};
    var nMax = opts.n || 3;
    var windowSize = opts.windowSize || 1;
    var top = opts.top || 20;
    var dedupLim = opts.dedupLim === undefined ? 0.9 : opts.dedupLim;
    var isStop = opts.isStopWord || function () { return false; };

    // ---- term store ----
    var terms = Object.create(null); // uniqueTerm -> term object
    var termList = [];
    var edges = Object.create(null); // "leftId|rightId" -> tf (directed)
    var nSentences = tokenizedSentences.length;

    function getTerm(strWord) {
      var uniq = strWord.toLowerCase();
      var simplesSto = isStop(uniq);
      if (/s$/.test(uniq) && uniq.length > 3) { uniq = uniq.slice(0, -1); }
      if (terms[uniq] !== undefined) { return terms[uniq]; }
      var stripped = '';
      for (var i = 0; i < uniq.length; i++) {
        if (!isPunctChar(uniq.charAt(i))) { stripped += uniq.charAt(i); }
      }
      var t = {
        id: termList.length, term: uniq,
        stopword: simplesSto || isStop(uniq) || stripped.length < 3,
        tf: 0, tfA: 0, tfN: 0, occurs: Object.create(null),
        h: 0
      };
      terms[uniq] = t; termList.push(t);
      return t;
    }
    function addEdge(l, r) {
      var k = l.id + '|' + r.id;
      edges[k] = (edges[k] || 0) + 1;
    }

    // ---- candidate store ----
    var candidates = Object.create(null); // uniqueKw -> candidate
    var candList = [];
    function addCandidate(entries) { // entries: [{tag, word, term}]
      var kw = entries.map(function (e) { return e.word; }).join(' ');
      var uniq = kw.toLowerCase();
      var tagStr = entries.map(function (e) { return e.tag; }).join('');
      var c = candidates[uniq];
      if (c === undefined) {
        c = {
          kw: kw, uniqueKw: uniq, size: entries.length,
          terms: entries.map(function (e) { return e.term; }),
          tags: Object.create(null), tf: 0, h: 1,
          startOrEndStopword: entries[0].term.stopword ||
            entries[entries.length - 1].term.stopword
        };
        candidates[uniq] = c; candList.push(c);
      }
      c.tags[tagStr] = true;
      c.tf += 1;
    }

    // ---- pass over the text ----
    tokenizedSentences.forEach(function (sentence, sentId) {
      var block = []; // current block: [{tag, word, term}]
      sentence.forEach(function (word, posSent) {
        if (allPunct(word)) { block = []; return; }
        var tag = yakeTag(word, posSent);
        var term = getTerm(word);
        // occurrence
        if (term.occurs[sentId] === undefined) { term.occurs[sentId] = 0; }
        term.occurs[sentId] += 1;
        term.tf += 1;
        if (tag === 'a') { term.tfA += 1; }
        if (tag === 'n') { term.tfN += 1; }
        // co-occurrence (window over current block; u/d tags excluded)
        if (tag !== 'u' && tag !== 'd') {
          var from = Math.max(0, block.length - windowSize);
          for (var w = from; w < block.length; w++) {
            if (block[w].tag !== 'u' && block[w].tag !== 'd') {
              addEdge(block[w].term, term);
            }
          }
        }
        // candidates ending at this word (1..nMax)
        var entry = { tag: tag, word: word, term: term };
        var cand = [entry];
        addCandidate(cand);
        for (var b = block.length - 1; b >= Math.max(0, block.length - (nMax - 1)); b--) {
          cand.push(block[b]);
          addCandidate(cand.slice().reverse());
        }
        block.push(entry);
      });
    });

    if (termList.length === 0) { return []; }

    // ---- graph metrics ----
    var outDeg = new Array(termList.length).fill(0);
    var outW = new Array(termList.length).fill(0);
    var inDeg = new Array(termList.length).fill(0);
    var inW = new Array(termList.length).fill(0);
    Object.keys(edges).forEach(function (k) {
      var p = k.split('|');
      outDeg[+p[0]] += 1; outW[+p[0]] += edges[k];
      inDeg[+p[1]] += 1; inW[+p[1]] += edges[k];
    });

    // ---- single-term features (reference update_h) ----
    var valid = termList.filter(function (t) { return !t.stopword; });
    if (valid.length === 0) { return []; }
    var maxTf = 0, sumTf = 0;
    termList.forEach(function (t) { if (t.tf > maxTf) { maxTf = t.tf; } });
    valid.forEach(function (t) { sumTf += t.tf; });
    var avgTf = sumTf / valid.length;
    var varTf = 0;
    valid.forEach(function (t) { varTf += (t.tf - avgTf) * (t.tf - avgTf); });
    var stdTf = Math.sqrt(varTf / valid.length); // population std (np.std)

    termList.forEach(function (t) {
      var pwr = outW[t.id] === 0 ? 0 : outDeg[t.id] / outW[t.id];
      var pwl = inW[t.id] === 0 ? 0 : inDeg[t.id] / inW[t.id];
      var rel = (0.5 + (pwl * (t.tf / maxTf))) + (0.5 + (pwr * (t.tf / maxTf)));
      var freq = t.tf / (avgTf + stdTf);
      var spread = Object.keys(t.occurs).length / nSentences;
      var wcase = Math.max(t.tfA, t.tfN) / (1 + Math.log(t.tf));
      var sentIds = Object.keys(t.occurs).map(Number);
      var wpos = Math.log(Math.log(3 + median(sentIds)));
      t.h = (wpos * rel) / (wcase + (freq / rel) + (spread / rel));
    });

    // ---- multi-term scores (reference "bi" stopword weighting) ----
    candList.forEach(function (c) {
      var sumH = 0, prodH = 1;
      for (var t = 0; t < c.terms.length; t++) {
        var term = c.terms[t];
        if (!term.stopword) {
          sumH += term.h; prodH *= term.h;
        } else {
          var probT1 = 0, probT2 = 0, k;
          if (t > 0) {
            k = c.terms[t - 1].id + '|' + term.id;
            if (edges[k] !== undefined) { probT1 = edges[k] / c.terms[t - 1].tf; }
          }
          if (t < c.terms.length - 1) {
            k = term.id + '|' + c.terms[t + 1].id;
            // reference quirk kept verbatim: divides by the NEXT term's tf
            if (edges[k] !== undefined) { probT2 = edges[k] / c.terms[t + 1].tf; }
          }
          var prob = probT1 * probT2;
          prodH *= 1 + (1 - prob);
          sumH -= 1 - prob;
        }
      }
      c.h = prodH / ((sumH + 1) * c.tf);
    });

    // ---- validity, sort, dedup ----
    var validCands = candList.filter(function (c) {
      var ok = false;
      Object.keys(c.tags).forEach(function (tg) {
        if (tg.indexOf('u') === -1 && tg.indexOf('d') === -1) { ok = true; }
      });
      return ok && !c.startOrEndStopword;
    });
    // stable sort by h ascending (ties keep first-occurrence order)
    validCands = validCands
      .map(function (c, i) { return [c, i]; })
      .sort(function (a, b) { return a[0].h - b[0].h || a[1] - b[1]; })
      .map(function (p) { return p[0]; });

    var picked = [];
    for (var ci = 0; ci < validCands.length && picked.length < top; ci++) {
      var cnd = validCands[ci], dup = false;
      for (var pi = 0; pi < picked.length; pi++) {
        if (levSimilarity(cnd.uniqueKw, picked[pi].uniqueKw) > dedupLim) {
          dup = true; break;
        }
      }
      if (!dup) { picked.push(cnd); }
    }
    return picked.map(function (c) { return { phrase: c.kw, score: c.h }; });
  }

  /* ------------------------------------------------------------------ *
   * TextRank (Mihalcea & Tarau, 2004)
   * ------------------------------------------------------------------ */

  /**
   * TextRank keywords/keyphrases from parser output.
   * parsedSentences: [{ tokens: [{w, pos}], ... }]
   * deps: { pageRank: CrawdadNetwork.pageRank }
   * opts: { windowSize (2), damping (0.85), maxPhrases (20) }
   * Returns { phrases: [{phrase, score, count}], vertexCount, selectedCount }
   */
  function textRank(parsedSentences, deps, opts) {
    opts = opts || {};
    var windowSize = opts.windowSize || 2;
    var damping = opts.damping === undefined ? 0.85 : opts.damping;
    var maxPhrases = opts.maxPhrases || 20;

    var CAND = { NOUN: 1, PROPN: 1, ADJ: 1 };
    // flatten token stream; mark candidates. A break pseudo-token between
    // sentences stops both co-occurrence windows and phrase merging from
    // crossing sentence boundaries — a merged phrase must be a sequence
    // that actually occurs in the text (caught by test fixture 2026-08-11:
    // "fragile" + sentence break + "supply chain" must not merge).
    var stream = [];
    (parsedSentences || []).forEach(function (s) {
      (s.tokens || []).forEach(function (t) {
        // closed-class/citation-fragment tokens are never candidates even
        // when the tagger calls them NOUN (fix 2026-10-28: a mis-tagged
        // "et"/"al" from the "et. al." typo surfaced in TextRank phrases)
        stream.push({ w: t.w,
          cand: CAND[t.pos] === 1 && t.w.length >= 2 && !isKpStopWord(t.w) });
      });
      stream.push({ w: '', cand: false }); // sentence break
    });

    var idOf = Object.create(null), words = [];
    stream.forEach(function (t) {
      if (t.cand && idOf[t.w] === undefined) {
        idOf[t.w] = words.length; words.push(t.w);
      }
    });
    if (words.length === 0) {
      return { phrases: [], vertexCount: 0, selectedCount: 0 };
    }

    // co-occurrence within windowSize tokens of the ORIGINAL stream
    // (window 2 = adjacent tokens); unweighted, undirected, deduplicated
    var seen = Object.create(null), edges = [];
    for (var i = 0; i < stream.length; i++) {
      if (!stream[i].cand) { continue; }
      for (var j = i + 1; j < stream.length && j - i <= windowSize - 1; j++) {
        if (!stream[j].cand || stream[i].w === stream[j].w) { continue; }
        var a = idOf[stream[i].w], b = idOf[stream[j].w];
        var k = Math.min(a, b) + '|' + Math.max(a, b);
        if (seen[k] === undefined) {
          seen[k] = 1;
          edges.push({ source: Math.min(a, b), target: Math.max(a, b), weight: 1 });
        }
      }
    }

    var pr = deps.pageRank(words.length, edges, damping);

    // top third of vertices (min 3, cap 20), paper §3.1
    var T = Math.max(3, Math.min(20, Math.ceil(words.length / 3)));
    var ranked = words
      .map(function (w, ix) { return [w, pr[ix]]; })
      .sort(function (x, y) { return y[1] - x[1] || (x[0] < y[0] ? -1 : 1); });
    var selected = Object.create(null);
    ranked.slice(0, T).forEach(function (p) { selected[p[0]] = p[1]; });

    // merge adjacent selected words in the stream into phrases
    var phrases = Object.create(null), order = [];
    var run = [];
    function flushRun() {
      if (run.length === 0) { return; }
      var key = run.join(' ');
      if (phrases[key] === undefined) {
        var score = 0;
        run.forEach(function (w) { score += selected[w]; });
        phrases[key] = { phrase: key, score: round5(score), count: 0 };
        order.push(key);
      }
      phrases[key].count += 1;
      run = [];
    }
    stream.forEach(function (t) {
      if (t.cand && selected[t.w] !== undefined) { run.push(t.w); }
      else { flushRun(); }
    });
    flushRun();

    var out = order.map(function (k) { return phrases[k]; })
      .sort(function (x, y) {
        return y.score - x.score || (x.phrase < y.phrase ? -1 : 1);
      })
      .slice(0, maxPhrases);
    return { phrases: out, vertexCount: words.length, selectedCount: T };
  }

  /* ------------------------------------------------------------------ *
   * Top-level: both methods for the Generator
   * ------------------------------------------------------------------ */

  /**
   * Extract keyphrases for a _cra.md file.
   * parsedSentences: parser output (needs .text and .tokens per sentence)
   * deps: { isStopWord, pageRank }
   * Returns the schema `keyphrases` block.
   */
  function extract(parsedSentences, deps, opts) {
    opts = opts || {};
    var tr = textRank(parsedSentences, { pageRank: deps.pageRank }, opts.textRank);
    var tokenized = (parsedSentences || []).map(function (s) {
      return yakeTokenize(s.text || '');
    }).filter(function (s) { return s.length > 0; });
    var yk = yake(tokenized, {
      isStopWord: isKpStopWord, // closed-class function-word list (in-house)
      n: 3, windowSize: 1, top: 20, dedupLim: 0.9
    });
    return {
      textRank: {
        parameters: { windowSize: 2, damping: 0.85,
          selection: 'top third of vertices (min 3, max 20)',
          phraseScore: 'sum of member word scores' },
        vertexCount: tr.vertexCount,
        phrases: tr.phrases
      },
      yake: {
        parameters: { n: 3, windowSize: 1, top: 20, dedupLim: 0.9,
          dedup: 'normalized Levenshtein',
          stopwords: 'crawdad closed-class function words (in-house)',
          note: 'lower score = more important' },
        phrases: yk.map(function (p) {
          return { phrase: p.phrase, score: round5(p.score) };
        })
      }
    };
  }

  var api = {
    yakeTokenize: yakeTokenize,
    yakeTag: yakeTag,
    yake: yake,
    textRank: textRank,
    extract: extract,
    levSimilarity: levSimilarity,
    stopwords: KP_STOPWORDS,
    isKpStopWord: isKpStopWord
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadKeyphrases = api; }
})(typeof self !== 'undefined' ? self : this);
