/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M7 tests — inference layer + universal PDF reports
 * (Build Spec V2 §7, §11; Kevin 2026-08-11: every report offers .md/.pdf).
 * Node:    NODE_PATH=... node tests/test-inference.js
 * Browser: open tests/test-inference.html
 * Oracles per spec §11 M7: determinism (same seed → identical) and
 * statistical sanity on synthetic nulls; markdown→PDF model checks.
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var INF = isNode ? require('../js/inference.js') : root.CrawdadInference;
  var NET = isNode ? require('../js/network.js') : root.CrawdadNetwork;
  var RES = isNode ? require('../js/resonance.js') : root.CrawdadResonance;
  var CLS = isNode ? require('../js/classifier.js') : root.CrawdadClassifier;
  var S = isNode ? require('../js/craschema.js') : root.CrawdadSchema;
  var PDF = isNode ? require('../js/pdfreport.js') : root.CrawdadPdfReport;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }

  /* ---------------- shared synthetic material ---------------- */

  function sentence(words) { // parser-shaped sentence with one noun phrase
    return { text: words.join(' ') + '.', phrases: [words],
      tokens: words.map(function (w) { return { w: w, pos: 'NOUN' }; }) };
  }
  function porterish(w) { return w; } // identity stem for synthetic material

  function synthSentences() {
    // "king castle" backbone; heterogeneous satellites so resampling varies
    var s = [];
    for (var i = 0; i < 14; i++) {
      s.push(sentence(['king', 'castle', 'court' + i, 'tower' + (i % 5)]));
    }
    s.push(sentence(['moat', 'king']));
    return s;
  }

  /* ---------------- 1. influence bootstrap ---------------- */

  t('bootstrap CIs: deterministic for a seed, different for another seed', function () {
    var deps = { network: NET, porter2: porterish, isStopWord: function () { return false; } };
    var a = INF.bootstrapInfluence(synthSentences(), { B: 50, seed: 42, stemming: 'none' }, deps);
    var b = INF.bootstrapInfluence(synthSentences(), { B: 50, seed: 42, stemming: 'none' }, deps);
    var c = INF.bootstrapInfluence(synthSentences(), { B: 50, seed: 7, stemming: 'none' }, deps);
    assert(JSON.stringify(a.ci) === JSON.stringify(b.ci), 'same seed identical');
    assert(JSON.stringify(a.ci) !== JSON.stringify(c.ci), 'different seed differs');
    assert(a.B === 50 && a.seed === 42 && /bootstrap/.test(a.method), 'method/count/seed stated');
  });

  t('bootstrap CIs: backbone word CI excludes 0; rare word CI reaches 0', function () {
    var deps = { network: NET, porter2: porterish, isStopWord: function () { return false; } };
    var r = INF.bootstrapInfluence(synthSentences(), { B: 100, seed: 42, stemming: 'none' }, deps);
    assert(r.ci.king && r.ci.king[0] > 0, 'king lower bound > 0 (in every sentence): ' +
      JSON.stringify(r.ci.king));
    assert(r.ci.moat && r.ci.moat[0] === 0, 'moat lower bound 0 (one sentence): ' +
      JSON.stringify(r.ci.moat));
    assert(r.ci.king[0] <= r.ci.king[1], 'ordered bounds');
  });

  /* ---------------- 2. WR' permutation ---------------- */

  function craOf(sentences, name) {
    var cra = NET.buildCra(sentences, { stemming: 'none' },
      { porter2: porterish, isStopWord: function () { return false; } });
    return { source: { filename: name || 'synth.txt' },
      network: { nodes: cra.nodes, edges: cra.edges } };
  }

  t('WR′ permutation: identical texts are significant; unrelated texts are not', function () {
    var A = craOf(synthSentences());
    var same = INF.wrPermutation(A, A, { B: 199, seed: 42 }, { resonance: RES });
    assert(same.permP <= 0.05, 'self-resonance above chance: p=' + same.permP);
    // unrelated: disjoint vocabulary -> WR' = 0 -> never above chance
    var other = [];
    for (var i = 0; i < 12; i++) { other.push(sentence(['ship', 'sea', 'sail' + (i % 3)])); }
    var Bdat = craOf(other);
    var diff = INF.wrPermutation(A, Bdat, { B: 199, seed: 42 }, { resonance: RES });
    assert(diff.permP > 0.5, 'disjoint texts unremarkable: p=' + diff.permP);
    assert(same.B === 199 && same.seed === 42 && /permuted/.test(same.method),
      'method/count/seed stated');
  });

  t('WR′ permutation is deterministic for a seed', function () {
    var A = craOf(synthSentences());
    var r1 = INF.wrPermutation(A, A, { B: 99, seed: 5 }, { resonance: RES });
    var r2 = INF.wrPermutation(A, A, { B: 99, seed: 5 }, { resonance: RES });
    assert(r1.permP === r2.permP && r1.permMean === r2.permMean, 'identical');
  });

  /* ---------------- 3. cluster stability ---------------- */

  function blockRows(n1, n2, tight) {
    // similarity matrix with two blocks; tight=true -> crisp, else noisy
    var n = n1 + n2, rows = [];
    for (var i = 0; i < n; i++) {
      rows.push([]);
      for (var j = 0; j < n; j++) {
        var sameBlock = (i < n1) === (j < n1);
        var base = i === j ? 1 : (sameBlock ? (tight ? 0.9 : 0.55) : (tight ? 0.1 : 0.45));
        // deterministic jitter
        var f = Math.sin((i * 31 + j * 17)) * 10000;
        rows[i].push(base + (f - Math.floor(f) - 0.5) * (tight ? 0.02 : 0.12));
      }
    }
    return rows;
  }

  t('cluster stability: crisp two-block structure scores highly stable', function () {
    var rows = blockRows(6, 6, true);
    var labels = [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1];
    var st = INF.clusterStability(rows, labels, { B: 60, seed: 42 }, { classifier: CLS });
    st.clusters.forEach(function (c) {
      assert(c.meanJaccard >= 0.85, 'S' + c.cluster + ' Jaccard ' + c.meanJaccard);
      assert(/highly stable/.test(c.verdict), 'verdict');
    });
    assert(/Hennig/.test(st.method) && st.B === 60 && st.seed === 42,
      'method/count/seed stated');
  });

  t('cluster stability: arbitrary split of noise scores below the crisp case', function () {
    var rows = blockRows(6, 6, false);
    // deliberately WRONG split (interleaved) — should be less stable
    var badLabels = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1];
    var stBad = INF.clusterStability(rows, badLabels, { B: 60, seed: 42 }, { classifier: CLS });
    var crisp = INF.clusterStability(blockRows(6, 6, true),
      [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1], { B: 60, seed: 42 }, { classifier: CLS });
    var meanBad = (stBad.clusters[0].meanJaccard + stBad.clusters[1].meanJaccard) / 2;
    var meanCrisp = (crisp.clusters[0].meanJaccard + crisp.clusters[1].meanJaccard) / 2;
    assert(meanBad < meanCrisp - 0.15, 'bad ' + meanBad + ' vs crisp ' + meanCrisp);
  });

  t('cluster stability is deterministic for a seed', function () {
    var rows = blockRows(5, 5, true);
    var labels = [0, 0, 0, 0, 0, 1, 1, 1, 1, 1];
    var a = INF.clusterStability(rows, labels, { B: 40, seed: 9 }, { classifier: CLS });
    var b = INF.clusterStability(rows, labels, { B: 40, seed: 9 }, { classifier: CLS });
    assert(JSON.stringify(a) === JSON.stringify(b), 'identical');
  });

  /* ---------------- report integrations ---------------- */

  t('comparator report carries the permutation section + JSON when supplied', function () {
    var A = craOf(synthSentences());
    var perm = INF.wrPermutation(A, A, { B: 99, seed: 42 }, { resonance: RES });
    var rep = RES.buildReport(A, A, 'CITE', perm);
    assert(/## Resonance significance \(permutation test\)/.test(rep.markdown), 'section');
    assert(/99 permutations, seed 42/.test(rep.markdown), 'count/seed');
    assert(/"inference"/.test(rep.markdown), 'machine block carries inference');
    var plain = RES.buildReport(A, A, 'CITE');
    assert(!/Resonance significance/.test(plain.markdown), 'absent when not requested');
  });

  t('node table gains the 95% CI column when inference is present', function () {
    var d = S.newCraData('ci.txt', null, '2.0.0-M7 (built 2026-08-11)');
    d.network.nodes = [
      { id: 0, word: 'king', display: 'king', degree: 1, strength: 2,
        influence: 0.5, pageRank: 0.5 },
      { id: 1, word: 'castle', display: 'castle', degree: 1, strength: 2,
        influence: 0.3, pageRank: 0.5 }
    ];
    d.network.edges = [{ source: 0, target: 1, weight: 2 }];
    d.summary = { nodeCount: 2, edgeCount: 1 };
    d.inference = { influenceCI: { method: 'sentence bootstrap, percentile CI (nearest rank)',
      B: 200, seed: 42, ciLevel: 0.95,
      ci: { king: [0.4, 0.6], castle: [0.1, 0.5] } } };
    var md = S.serializeCra(d);
    assert(/95% CI/.test(md), 'CI column');
    assert(/\[0\.400, 0\.600\]/.test(md), 'king range');
    assert(/B = 200, seed 42/.test(md), 'method line');
    var back = S.parseCra(md);
    assert(back.ok && back.data.inference.influenceCI.B === 200, 'round-trip');
    // malformed inference rejected
    var bad = JSON.parse(JSON.stringify(d));
    bad.inference = { influenceCI: { B: 'x' } };
    assert(!S.validateCra(bad).ok, 'validator rejects malformed CI block');
  });

  /* ---------------- universal PDF (markdown -> model) ---------------- */

  t('markdownToModel strips the machine block, keeps tables and citations', function () {
    var md = ['# Title X', '', '- Generated: now', '- Params: a=1', '',
      '## Section A', '', 'Prose line.', '', '| H1 | H2 |', '|---|---|',
      '| a | 1 |', '| b | 2 |', '',
      '## Data (machine-readable — do not edit)', '', '```json',
      '{"schemaVersion":"9.9","secret":[1,2,3]}', '```', '', '---',
      '*Cite one.*', '', '*Disclaimer here.*', ''].join('\n');
    var m = PDF.markdownToModel(md);
    assert(m.title === 'Title X', 'title');
    assert(m.settingsLines.length === 2, 'metadata bullets -> settings');
    var js = JSON.stringify(m);
    assert(js.indexOf('schemaVersion') === -1 && js.indexOf('secret') === -1,
      'machine block stripped');
    assert(m.footerCitations.length === 2 && /Disclaimer/.test(m.footerCitations[1]),
      'citations preserved');
    var tbl = null;
    m.sections.forEach(function (s) { if (s.tables.length) { tbl = s.tables[0]; } });
    assert(tbl && tbl.head[0] === 'H1' && tbl.rows.length === 2, 'table parsed');
  });

  t('markdownToModel strips inline markdown and separator rows', function () {
    var md = '# T\n\n## S\n\n| **A** | `B` |\n|---|---|\n| *x* | y |\n';
    var m = PDF.markdownToModel(md);
    var tbl = m.sections[0].tables[0];
    assert(tbl.head[0] === 'A' && tbl.head[1] === 'B', 'bold/code stripped in head');
    assert(tbl.rows.length === 1 && tbl.rows[0][0] === 'x', 'em stripped, separator dropped');
  });

  t('reportFromMarkdown renders a %PDF for a real-shaped report', function () {
    var deps = null;
    if (isNode) {
      var jspdf = require('jspdf');
      var at = require('jspdf-autotable');
      deps = { jsPDF: jspdf.jsPDF, autoTable: at.default || at };
    }
    var md = '# Crawdad Keyness: demo\n\n- Generated: t\n\n## Key words (by G²)\n\n' +
      '| Word | G² |\n|---|---|\n| union | 12.3 |\n\n' +
      '## Data (machine-readable — do not edit)\n\n```json\n{"x":1}\n```\n\n---\n*C1.*\n\n*C2.*\n';
    var doc = PDF.reportFromMarkdown(md, deps);
    var head = String.fromCharCode.apply(null,
      new Uint8Array(doc.output('arraybuffer').slice(0, 4)));
    assert(head === '%PDF', 'renders');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M7 inference/universal-PDF tests: ' + passed + '/' + results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadInferenceTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
