/*
 * Crawdad 2026 — E-1: PDF/DOCX -> text extraction (spec §9 E-1, pulled into v1)
 * Uses locally vendored libraries so the app runs offline from file://:
 *   vendor/pdf.min.js + vendor/pdf.worker.min.js  (pdf.js, Apache-2.0)
 *   vendor/mammoth.browser.min.js                 (mammoth, BSD-2-Clause)
 *
 * Note: pdf.js extracts the text layer only. Scanned/image PDFs yield little
 * or no text; we detect that and warn (OCR is out of scope for v1).
 */
(function (root) {
  'use strict';

  var PDF_MIN_CHARS_PER_PAGE = 20; // below this average, likely a scanned PDF

  function configurePdfJs() {
    if (!root.pdfjsLib) {
      throw new Error('pdf.js not loaded (vendor/pdf.min.js missing).');
    }
    // On file:// real Workers are blocked; pdf.js falls back to its "fake
    // worker" on the main thread, loading this script via a <script> tag.
    root.pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdf.worker.min.js';
  }

  function readAsArrayBuffer(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(r.result); };
      r.onerror = function () { reject(new Error('Could not read ' + file.name)); };
      r.readAsArrayBuffer(file);
    });
  }

  /** Extract text from a PDF File. Resolves { text, warnings: string[] }. */
  function extractPdf(file) {
    configurePdfJs();
    return readAsArrayBuffer(file).then(function (buf) {
      return root.pdfjsLib.getDocument({ data: buf, isEvalSupported: false }).promise;
    }).then(function (doc) {
      var pages = [];
      var chain = Promise.resolve();
      var i;
      var getPage = function (n) {
        return function () {
          return doc.getPage(n).then(function (page) {
            return page.getTextContent();
          }).then(function (tc) {
            // Join items; insert newlines where pdf.js marks end-of-line.
            var out = '';
            tc.items.forEach(function (it) {
              out += it.str;
              out += it.hasEOL ? '\n' : ' ';
            });
            pages.push(out.trim());
          });
        };
      };
      for (i = 1; i <= doc.numPages; i++) { chain = chain.then(getPage(i)); }
      return chain.then(function () {
        var text = pages.join('\n\n');
        var warnings = [];
        var avg = text.replace(/\s/g, '').length / Math.max(doc.numPages, 1);
        if (avg < PDF_MIN_CHARS_PER_PAGE) {
          warnings.push(file.name + ': almost no extractable text — this looks like a ' +
            'scanned (image-only) PDF. Crawdad v1 does not do OCR; please supply a text PDF or .txt/.md.');
        }
        return { text: text, warnings: warnings };
      });
    });
  }

  /** Extract text from a DOCX File. Resolves { text, warnings: string[] }. */
  function extractDocx(file) {
    if (!root.mammoth) {
      return Promise.reject(new Error('mammoth not loaded (vendor/mammoth.browser.min.js missing).'));
    }
    return readAsArrayBuffer(file).then(function (buf) {
      return root.mammoth.extractRawText({ arrayBuffer: buf });
    }).then(function (res) {
      var warnings = (res.messages || [])
        .filter(function (m) { return m.type === 'warning' || m.type === 'error'; })
        .map(function (m) { return file.name + ': ' + m.message; });
      return { text: res.value || '', warnings: warnings };
    });
  }

  /**
   * Route any accepted source file to plain text.
   * Resolves { text, converted: boolean, warnings: string[] }.
   */
  function extractText(file) {
    var name = file.name.toLowerCase();
    if (/\.pdf$/.test(name)) {
      return extractPdf(file).then(function (r) {
        return { text: r.text, converted: true, warnings: r.warnings };
      });
    }
    if (/\.docx$/.test(name)) {
      return extractDocx(file).then(function (r) {
        return { text: r.text, converted: true, warnings: r.warnings };
      });
    }
    // .txt / .md pass through unchanged
    return root.CrawdadFileIO.readFileAsText(file).then(function (t) {
      return { text: t, converted: false, warnings: [] };
    });
  }

  root.CrawdadExtract = {
    extractText: extractText,
    extractPdf: extractPdf,
    extractDocx: extractDocx
  };
})(typeof self !== 'undefined' ? self : this);
