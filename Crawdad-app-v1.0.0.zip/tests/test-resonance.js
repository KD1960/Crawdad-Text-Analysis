/*
 * Crawdad 2026 — M4 validation: resonance math vs hand calculations.
 * Node:    node tests/test-resonance.js
 * Browser: open tests/test-resonance.html
 *
 * Hand-computed reference (toy networks):
 *   A: nodes x(I=.5) y(.2) z(.1); edges x-y F=2, y-z F=1
 *   B: nodes x(I=.4) w(.3) y(.1); edges x-y F=3, x-w F=1
 *
 *   WR   = .5*.4 + .2*.1                        = 0.22
 *   WR'  = .22 / sqrt((.25+.04+.01)(.16+.09+.01))
 *        = .22 / sqrt(.30*.26)                  = 0.7877263...
 *   P^A  : x-y = .5*.2*2 = .2 ; y-z = .2*.1*1 = .02
 *   P^B  : x-y = .4*.1*3 = .12; x-w = .4*.3*1 = .12
 *   PR   = .2*.12 (only {x,y} common)           = 0.024
 *   PR'  = .024 / sqrt((.04+.0004)(.0144+.0144))
 *        = .024 / sqrt(.00116352)               = 0.7036066...
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var R = isNode ? require('../js/resonance.js') : root.CrawdadResonance;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function approx(a, b, eps) { return Math.abs(a - b) <= (eps || 1e-9); }

  function mk(words, edges) {
    // words: {word: influence}; edges: [[wordA, wordB, F], ...]
    var nodes = [], id = {}, i = 0;
    Object.keys(words).forEach(function (w) {
      id[w] = i;
      nodes.push({ id: i, word: w, display: w, degree: 0, influence: words[w] });
      i++;
    });
    var es = edges.map(function (e) {
      return { source: id[e[0]], target: id[e[1]], weight: e[2] };
    });
    return { schema: 'crawdad-cra', schemaVersion: '1.0',
      source: { filename: 'toy.txt' }, parameters: { stemming: 'porter', interSentenceLinking: true },
      network: { nodes: nodes, edges: es }, summary: {} };
  }

  var A = mk({ x: 0.5, y: 0.2, z: 0.1 }, [['x', 'y', 2], ['y', 'z', 1]]);
  var B = mk({ x: 0.4, w: 0.3, y: 0.1 }, [['x', 'y', 3], ['x', 'w', 1]]);

  t('WR matches hand calculation (0.22)', function () {
    assert(approx(R.wordResonance(A, B).WR, 0.22), 'got ' + R.wordResonance(A, B).WR);
  });

  t("WR' matches hand calculation (0.7877263)", function () {
    var v = R.wordResonance(A, B).WRs;
    assert(approx(v, 0.22 / Math.sqrt(0.30 * 0.26), 1e-12), 'got ' + v);
  });

  t('pair influence maps match Eq. 4 (frequency-weighted)', function () {
    var PA = R.pairInfluenceMap(A);
    assert(approx(PA['x|y'], 0.2), 'P_xy^A: ' + PA['x|y']);
    assert(approx(PA['y|z'], 0.02), 'P_yz^A: ' + PA['y|z']);
    var PB = R.pairInfluenceMap(B);
    assert(approx(PB['x|y'], 0.12), 'P_xy^B: ' + PB['x|y']);
    assert(approx(PB['w|x'], 0.12), 'P_xw^B: ' + PB['w|x']);
  });

  t('PR matches hand calculation (0.024)', function () {
    assert(approx(R.pairResonance(A, B).PR, 0.024), 'got ' + R.pairResonance(A, B).PR);
  });

  t("PR' matches hand calculation (0.7036066)", function () {
    var v = R.pairResonance(A, B).PRs;
    assert(approx(v, 0.024 / Math.sqrt(0.0404 * 0.0288), 1e-12), 'got ' + v);
  });

  t("identity: WR'_AA = 1 and PR'_AA = 1", function () {
    assert(approx(R.wordResonance(A, A).WRs, 1, 1e-12), 'WR self');
    assert(approx(R.pairResonance(A, A).PRs, 1, 1e-12), 'PR self');
  });

  t('symmetry: WR_AB = WR_BA, PR_AB = PR_BA', function () {
    assert(approx(R.wordResonance(A, B).WR, R.wordResonance(B, A).WR), 'WR asym');
    assert(approx(R.pairResonance(A, B).PR, R.pairResonance(B, A).PR), 'PR asym');
  });

  t('disjoint texts: all resonance zero', function () {
    var C = mk({ p: 0.5, q: 0.2 }, [['p', 'q', 1]]);
    assert(R.wordResonance(A, C).WR === 0 && R.pairResonance(A, C).PR === 0);
    assert(R.wordResonance(A, C).WRs === 0 && R.pairResonance(A, C).PRs === 0);
  });

  t('pair matching is order-free (β set equality)', function () {
    // B2 has edge y-x (reversed ids relative to A's x-y) — must still match
    var B2 = mk({ y: 0.1, x: 0.4 }, [['y', 'x', 3]]);
    assert(approx(R.pairResonance(A, B2).PR, 0.2 * 0.12), 'got ' + R.pairResonance(A, B2).PR);
  });

  t('common words ranked by min(I_A, I_B); x before y', function () {
    var c = R.commonWords(A, B, 10);
    assert(c.length === 2, 'expected x and y');
    assert(c[0].word === 'x' && approx(c[0].rank, 0.4), 'x first (min .4)');
    assert(c[1].word === 'y' && approx(c[1].rank, 0.1), 'y second (min .1)');
  });

  t('unique word lists are per-text (D-5)', function () {
    var uA = R.uniqueWords(A, B, 10), uB = R.uniqueWords(B, A, 10);
    assert(uA.length === 1 && uA[0].word === 'z', 'unique to A');
    assert(uB.length === 1 && uB[0].word === 'w', 'unique to B');
  });

  t('word lists cap at 10', function () {
    var big = {}, i;
    for (i = 0; i < 25; i++) { big['w' + i] = (25 - i) / 100; }
    var C1 = mk(big, []), C2 = mk(big, []);
    assert(R.commonWords(C1, C2).length === 10, 'cap failed');
  });

  t('report: contains all four resonance values, word lists, citation, JSON block', function () {
    var rep = R.buildReport(A, B,
      'Please cite: Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002). Studying complex ' +
      'discursive systems: Centering Resonance Analysis of organizational communication. ' +
      'Human Communication Research, 28(2), 157-206.');
    var md = rep.markdown;
    assert(md.indexOf('Word resonance WR') !== -1 && md.indexOf("WR'") !== -1, 'WR rows');
    assert(md.indexOf('Pair resonance PR') !== -1 && md.indexOf("PR'") !== -1, 'PR rows');
    assert(md.indexOf('unique to toy.txt') !== -1, 'unique sections');
    assert(md.indexOf('Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002)') !== -1, 'citation');
    assert(/```json/.test(md), 'JSON block');
    var parsed = JSON.parse(md.match(/```json\s*\n([\s\S]*?)\n```/)[1]);
    assert(parsed.schema === 'crawdad-comparison', 'schema tag');
    assert(approx(parsed.result.WR, 0.22), 'JSON WR');
  });

  t('report warns when files were generated with different parameters', function () {
    var B3 = JSON.parse(JSON.stringify(B));
    B3.parameters.stemming = 'minimal';
    var md = R.buildReport(A, B3, 'cite').markdown;
    assert(md.indexOf('different parameters') !== -1, 'no warning');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'M4 resonance tests: ' + passed + '/' + results.length + ' passed';

  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadResonanceTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
