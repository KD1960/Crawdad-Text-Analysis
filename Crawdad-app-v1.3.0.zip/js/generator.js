/*
 * Crawdad 2026 — M2: Generator pipeline orchestration (spec §6)
 * clean -> substitutions -> parse -> normalize/link/index -> _cra.md
 */
(function (root) {
  'use strict';

  var APP_VERSION = '1.3.0';

  /**
   * Run the full Generator pipeline on one text.
   * deps: { parser, porter2, isStopWord, schema, textclean }
   * options: { stemming, keepPronouns, interSentenceLinking, tokPairs, tokFileName }
   * Returns { craData, craMd, log: string[] }
   */
  function generate(filename, rawText, options, deps) {
    var log = [];
    options = options || {};

    // 1-2. clean
    var cleaned = deps.textclean.cleanText(rawText);
    cleaned.notes.forEach(function (n) { log.push('[clean] ' + n); });

    // 3. tokenization substitutions
    var text = cleaned.text;
    if (options.tokPairs && options.tokPairs.length) {
      var sub = deps.textclean.applySubstitutions(text, options.tokPairs);
      text = sub.text;
      Object.keys(sub.counts).forEach(function (k) {
        log.push('[tokenize] "' + k + '" -> replaced ' + sub.counts[k] + 'x');
      });
    }

    // 4. parse (sentence segmentation, POS, NP extraction)
    var parsed = deps.parser.parse(text);
    log.push('[parse] ' + parsed.sentences.length + ' sentences');

    // 4b. text-level metrics (D-12) — computed on the full token stream
    var textMetrics = null;
    if (deps.textmetrics) {
      var stemMode = options.stemming || 'porter';
      var stemFn = stemMode === 'porter' ? deps.porter2
        : stemMode === 'minimal' ? deps.network.minimalStem
        : function (w) { return w; };
      textMetrics = deps.textmetrics.computeAll(parsed.sentences,
        { sentimentFn: deps.sentiment || null, stemFn: stemFn });
      log.push('[metrics] text-level metrics computed');
    }

    // 5-7. normalize, link, index
    var cra = deps.network.buildCra(parsed.sentences, {
      stemming: options.stemming || 'porter',
      interSentenceLinking: options.interSentenceLinking !== false
    }, { porter2: deps.porter2, isStopWord: deps.isStopWord });
    log.push('[network] ' + cra.nodes.length + ' nodes, ' + cra.edges.length + ' edges');

    if (cra.nodes.length === 0) {
      throw new Error('No noun phrases found in "' + filename + '" — is this prose?');
    }

    // 8. emit
    var data = deps.schema.newCraData(filename, {
      stemming: options.stemming || 'porter',
      pronouns: !!options.keepPronouns,
      interSentenceLinking: options.interSentenceLinking !== false,
      tokenizationFile: options.tokFileName || null,
      stopWordList: 'default'
    }, APP_VERSION);
    data.network.nodes = cra.nodes;
    data.network.edges = cra.edges;
    data.summary = cra.summary;
    if (textMetrics) { data.textMetrics = textMetrics; }

    var md = deps.schema.serializeCra(data);
    return { craData: data, craMd: md, log: log };
  }

  function craFileName(sourceName) {
    return sourceName.replace(/\.(txt|md|pdf|docx)$/i, '') + '_cra.md';
  }

  var api = { generate: generate, craFileName: craFileName, APP_VERSION: APP_VERSION };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadGenerator = api; }
})(typeof self !== 'undefined' ? self : this);
