# Crawdad 2026 — Security & Provenance (v1.0.0)

This document states, verifiably, what this software can and cannot do on your
computer. It is written for recipients who want to check the app before running it.

## Security properties

1. **No network access.** The application makes no network requests of any
   kind. All libraries are bundled locally in `vendor/`; every `<script>` tag
   in `index.html` points to a local file. Your texts never leave your machine.
   - Verify yourself: open the browser's developer tools → Network tab while
     using the app; after the initial local file loads, no requests appear.
   - One source file, `js/llm.js`, contains dormant code for an optional
     LLM feature that was **deliberately not enabled**: it is not referenced by
     `index.html` and is never loaded or executed. It is retained for possible
     future use and does nothing in this release.
2. **No installation, no executables.** This is plain HTML/CSS/JavaScript run
   by your own browser inside its standard sandbox — the same security model as
   any web page. There is no installer, no binary, no browser extension, and
   nothing placed outside this folder. (This is also why your OS shows no
   "unidentified developer" warning: nothing executable is being installed.)
3. **No persistent storage.** The app does not use cookies, localStorage, or
   any browser storage. Closing the tab erases the session. The only files
   written to disk are the ones you explicitly download.
4. **No eval / dynamic code in application code.** The app's own JavaScript
   (`js/*.js`) contains no `eval` or `new Function`. PDF text extraction runs
   with pdf.js's `isEvalSupported: false`.
5. **No telemetry, analytics, or auto-update.** The app has no knowledge of
   who runs it.

## Integrity

`CHECKSUMS.txt` contains a SHA-256 hash for every file in this distribution.
Verify from inside this folder:

- macOS: `shasum -a 256 -c CHECKSUMS.txt`
- Linux: `sha256sum -c CHECKSUMS.txt`
- Windows (PowerShell): compare `Get-FileHash <file> -Algorithm SHA256` values.

If any file has been modified in transit, verification will fail. Obtain the
expected hash of the distribution zip from the sender through a separate
channel (e.g., the email that carried the link).

## Bundled third-party libraries (all open source, vendored offline)

| File | Library | Version | License | Role |
|---|---|---|---|---|
| vendor/wink-bundle.js | wink-nlp + wink-eng-lite-web-model + wink-porter2-stemmer | 2.x / 1.x | MIT | POS tagging, noun phrases, stemming |
| vendor/d3.min.js | D3 | 7.x | ISC | network visualization |
| vendor/pdf.min.js, vendor/pdf.worker.min.js | pdf.js (Mozilla) | 3.11.174 | Apache-2.0 | PDF text extraction |
| vendor/mammoth.browser.min.js | mammoth | 1.6.0 | BSD-2-Clause | DOCX text extraction |
| vendor/xlsx.full.min.js | SheetJS | 0.18.x | Apache-2.0 | spreadsheet reading |
| vendor/jszip.min.js | JSZip | 3.x | MIT/GPLv3 dual | session bundles |

Minified vendor files contain URL strings internally (license headers,
source-map references); none are fetched at runtime — see property 1.

## Method validation

The analysis code is validated by 111 automated tests (`tests/`), including:
betweenness against published reference values, resonance formulas against
hand calculations, PCA and varimax against independent numpy implementations
(agreement ≤ 1e-6), and the JHC 2002 linking example reproduced exactly.
Run them yourself: open `tests/index.html`.

## Citation

Please cite: Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002). Studying
complex discursive systems: Centering Resonance Analysis of organizational
communication. *Human Communication Research, 28*(2), 157–206.
