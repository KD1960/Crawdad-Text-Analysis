/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M1 — custom dictionary loader (Build Spec V2 §3.1, D-V2 rulings).
 * User-authored dictionaries only; the product ships no third-party lexical
 * data beyond the MIT-licensed VADER lexicon (licensing ruling 2, 2026-08-09).
 *
 * Two shapes, auto-detected:
 *   Scored:      word, value [, value2 ...] with a header row naming columns
 *                -> per-column metric: mean value over matched tokens.
 *   Categorical: word, category (no numeric second column)
 *                -> per-category rate per 1,000 tokens.
 * Matching: exact | stemmed (same stemmer as the run). Trailing "*" = prefix
 * match. Coverage (share of running tokens matched) always reported; < 60%
 * triggers a warning flag (the Latent-Themes lesson: silent low coverage is
 * a validity trap). The dictionary's SHA-256 is recorded in every output so
 * the dictionary is citable and the analysis reproducible.
 */
(function (root) {
  'use strict';

  /* ---------------- SHA-256 (synchronous, self-contained) ---------------- *
   * crypto.subtle is async and unavailable in some file:// contexts; this  *
   * is the standard public-domain-style implementation, hex output.        */
  function sha256Hex(str) {
    var K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
      0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
      0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
      0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
      0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
      0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
      0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
      0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
      0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
      0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
    var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
             0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
    // UTF-8 encode
    var bytes = [];
    for (var ci = 0; ci < str.length; ci++) {
      var code = str.charCodeAt(ci);
      if (code < 0x80) { bytes.push(code); }
      else if (code < 0x800) {
        bytes.push(0xc0 | (code >> 6), 0x80 | (code & 63));
      } else if (code < 0xd800 || code >= 0xe000) {
        bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63));
      } else { // surrogate pair
        var hi = code, lo = str.charCodeAt(++ci);
        var cp = 0x10000 + ((hi & 0x3ff) << 10) + (lo & 0x3ff);
        bytes.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 63),
                   0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63));
      }
    }
    var l = bytes.length;
    bytes.push(0x80);
    while (bytes.length % 64 !== 56) { bytes.push(0); }
    var bitLenHi = Math.floor(l / 0x20000000), bitLenLo = (l << 3) >>> 0;
    for (var b = 3; b >= 0; b--) { bytes.push((bitLenHi >>> (b * 8)) & 255); }
    for (b = 3; b >= 0; b--) { bytes.push((bitLenLo >>> (b * 8)) & 255); }
    function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }
    var w = new Array(64);
    for (var off = 0; off < bytes.length; off += 64) {
      for (var t = 0; t < 16; t++) {
        w[t] = (bytes[off + t * 4] << 24) | (bytes[off + t * 4 + 1] << 16) |
               (bytes[off + t * 4 + 2] << 8) | bytes[off + t * 4 + 3];
      }
      for (t = 16; t < 64; t++) {
        var s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ (w[t - 15] >>> 3);
        var s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ (w[t - 2] >>> 10);
        w[t] = (w[t - 16] + s0 + w[t - 7] + s1) >>> 0;
      }
      var a = H[0], bb = H[1], c = H[2], d = H[3],
          e = H[4], f = H[5], g = H[6], h = H[7];
      for (t = 0; t < 64; t++) {
        var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        var ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + K[t] + w[t]) >>> 0;
        var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        var maj = (a & bb) ^ (a & c) ^ (bb & c);
        var t2 = (S0 + maj) >>> 0;
        h = g; g = f; f = e; e = (d + t1) >>> 0;
        d = c; c = bb; bb = a; a = (t1 + t2) >>> 0;
      }
      H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + bb) >>> 0;
      H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
      H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0;
      H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
    }
    var hex = '';
    for (var i = 0; i < 8; i++) { hex += ('00000000' + H[i].toString(16)).slice(-8); }
    return hex;
  }

  /* ---------------- parsing ---------------- */

  function isNumeric(s) {
    return s !== '' && s !== null && s !== undefined && !isNaN(Number(s));
  }

  /**
   * Parse dictionary rows ([[col1, col2, ...], ...] from CSV or SheetJS).
   * Shape detection (deterministic, documented):
   *   scored     — every data row's columns 2..n are numeric; row 1 is the
   *                header naming the value columns (its columns 2..n are
   *                NOT numeric). At least one value column required.
   *   categorical— otherwise; column 2 is the category label; no header row.
   * Returns { type, columns (scored only), entries: [{word, values|category}],
   *           errors: [] }
   */
  function parseDictionary(rows) {
    var clean = (rows || []).filter(function (r) {
      return r && String(r[0] || '').trim() !== '';
    }).map(function (r) {
      return r.map(function (c) { return String(c === undefined || c === null ? '' : c).trim(); });
    });
    if (clean.length === 0) {
      return { type: null, entries: [], errors: ['Dictionary has no usable rows.'] };
    }
    var first = clean[0], rest = clean.slice(1);
    // Scored shape requires a header row + >= 1 data row; a single-row file
    // is always read as categorical.
    var restNumeric = clean.length >= 2 && rest.every(function (r) {
      return r.length >= 2 && r.slice(1).some(function (c) { return c !== ''; }) &&
        r.slice(1).every(function (c) { return c === '' || isNumeric(c); });
    });
    var headerNumeric = first.length >= 2 && first.slice(1).every(function (c) { return c === '' || isNumeric(c); });
    var errors = [];
    if (restNumeric && !headerNumeric) {
      // scored with header
      var nCols = first.length - 1;
      var columns = first.slice(1).map(function (c, j) { return c || ('value' + (j + 1)); });
      var entries = rest.map(function (r) {
        var values = [];
        for (var j = 1; j <= nCols; j++) {
          values.push(r[j] === '' || r[j] === undefined ? null : Number(r[j]));
        }
        return { word: r[0].toLowerCase(), values: values };
      });
      return { type: 'scored', columns: columns, entries: entries, errors: errors };
    }
    // categorical: every row word,category (header row not expected; a row
    // whose 2nd column is empty is an error)
    var entriesC = [];
    clean.forEach(function (r, idx) {
      if (!r[1]) { errors.push('Row ' + (idx + 1) + ' has no category/value; skipped.'); return; }
      entriesC.push({ word: r[0].toLowerCase(), category: r[1] });
    });
    return { type: 'categorical', entries: entriesC, errors: errors };
  }

  /* ---------------- application ---------------- */

  function buildMatcher(entries, mode, stemFn) {
    // exact map + prefix list (trailing *). Stemmed mode stems dictionary
    // words and matches against token stems.
    var exact = Object.create(null);
    var prefixes = [];
    entries.forEach(function (e, idx) {
      var w = e.word;
      if (w.slice(-1) === '*') {
        prefixes.push({ p: w.slice(0, -1), idx: idx });
      } else {
        exact[mode === 'stem' ? stemFn(w) : w] = idx;
      }
    });
    prefixes.sort(function (a, b) { return b.p.length - a.p.length; }); // longest first
    return function (token) {
      var t = mode === 'stem' ? stemFn(token) : token;
      if (t in exact) { return exact[t]; }
      for (var i = 0; i < prefixes.length; i++) {
        if (token.indexOf(prefixes[i].p) === 0) { return prefixes[i].idx; }
      }
      return -1;
    };
  }

  /**
   * Apply a parsed dictionary to the token stream (parser tokens: [{w, pos}]).
   * opts: { mode: 'exact'|'stem', stemFn }
   * Returns { type, coverage, matchedTokens, totalTokens, lowCoverage,
   *           metrics: scored -> {column: {mean, n}} | categorical -> {cat: per1000} }
   */
  function applyDictionary(tokens, dict, opts) {
    var mode = (opts && opts.mode) === 'stem' ? 'stem' : 'exact';
    var stemFn = (opts && opts.stemFn) || function (w) { return w; };
    var match = buildMatcher(dict.entries, mode, stemFn);
    var total = 0, matched = 0;
    var r4 = function (x) { return Math.round(x * 1e4) / 1e4; };

    if (dict.type === 'scored') {
      var sums = dict.columns.map(function () { return 0; });
      var ns = dict.columns.map(function () { return 0; });
      tokens.forEach(function (t) {
        total++;
        var idx = match(t.w);
        if (idx === -1) { return; }
        matched++;
        dict.entries[idx].values.forEach(function (v, j) {
          if (v !== null) { sums[j] += v; ns[j]++; }
        });
      });
      var metrics = {};
      dict.columns.forEach(function (c, j) {
        metrics[c] = { mean: ns[j] ? r4(sums[j] / ns[j]) : null, n: ns[j] };
      });
      var cov = total ? matched / total : 0;
      return { type: 'scored', metrics: metrics, matchedTokens: matched,
        totalTokens: total, coverage: r4(cov), lowCoverage: cov < 0.6 };
    }
    // categorical
    var counts = Object.create(null);
    tokens.forEach(function (t) {
      total++;
      var idx = match(t.w);
      if (idx === -1) { return; }
      matched++;
      var cat = dict.entries[idx].category;
      counts[cat] = (counts[cat] || 0) + 1;
    });
    var metricsC = {};
    Object.keys(counts).sort().forEach(function (cat) {
      metricsC[cat] = { per1000: total ? r4(1000 * counts[cat] / total) : 0, n: counts[cat] };
    });
    var covC = total ? matched / total : 0;
    return { type: 'categorical', metrics: metricsC, matchedTokens: matched,
      totalTokens: total, coverage: r4(covC), lowCoverage: covC < 0.6 };
  }

  var api = {
    sha256Hex: sha256Hex,
    parseDictionary: parseDictionary,
    applyDictionary: applyDictionary
  };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadLexicons = api; }
})(typeof self !== 'undefined' ? self : this);
