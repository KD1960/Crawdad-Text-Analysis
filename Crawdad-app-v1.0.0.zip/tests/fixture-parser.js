/*
 * Crawdad 2026 — M1 gold-standard parser fixture (spec §11, M1)
 *
 * 20 hand-annotated sentences. For each: the sentence and its noun phrases
 * per CRA selection rules (spec §3.1 / JHC pp. 174-175):
 *   - noun phrase = noun + zero or more nouns/adjectives (subject or object)
 *   - determiners dropped; verb phrases excluded; pronouns dropped
 *   - numerals excluded (neither noun nor adjective)
 *   - surface forms, lowercased; stemming happens LATER in the pipeline
 *
 * Annotation judgment calls (for Kevin's review):
 *   A1. S5 "Tuesday": proper noun functioning as object of preposition — included.
 *   A2. S8 "swimming": gerund as subject — included as noun.
 *   A3. S13 "five": numeral — excluded; "manufacturing": noun adjunct — included.
 *   A4. S16 "overlooking": verb (participle) — excluded; its object "valley" included.
 *   A5. S19 "daily": adverb here — excluded.
 *   A6. Prepositional-phrase nouns are included throughout (they are centers
 *       available for reference; consistent with original Crawdad behavior).
 */
(function (root) {
  'use strict';

  var FIXTURE = [
    { s: 'The quick brown fox jumps over the lazy dog.',
      gold: [['quick', 'brown', 'fox'], ['lazy', 'dog']] },
    { s: 'Supply chain management improves organizational performance.',
      gold: [['supply', 'chain', 'management'], ['organizational', 'performance']] },
    { s: 'She quickly sold the old house near the river.',
      gold: [['old', 'house'], ['river']] },
    { s: 'Complex discursive systems require new analytical methods.',
      gold: [['complex', 'discursive', 'systems'], ['new', 'analytical', 'methods']] },
    { s: 'Professor Corman presented the quarterly report on Tuesday.',
      gold: [['professor', 'corman'], ['quarterly', 'report'], ['tuesday']] },
    { s: 'The committee approved the new policy without debate.',
      gold: [['committee'], ['new', 'policy'], ['debate']] },
    { s: 'Effective leaders communicate a clear vision to employees.',
      gold: [['effective', 'leaders'], ['clear', 'vision'], ['employees']] },
    { s: 'Swimming improves cardiovascular health.',
      gold: [['swimming'], ['cardiovascular', 'health']] },
    { s: 'The negotiators connected on the issues.',
      gold: [['negotiators'], ['issues']] },
    { s: 'There was a disconnect between the negotiators on the issues.',
      gold: [['disconnect'], ['negotiators'], ['issues']] },
    { s: 'Macbeth murdered the king in his sleep.',
      gold: [['macbeth'], ['king'], ['sleep']] },
    { s: 'Sustainable packaging reduces environmental impact and consumer waste.',
      gold: [['sustainable', 'packaging'], ['environmental', 'impact'], ['consumer', 'waste']] },
    { s: 'The research team collected data from five manufacturing plants.',
      gold: [['research', 'team'], ['data'], ['manufacturing', 'plants']] },
    { s: 'Organizational communication creates coherent structures of meaning.',
      gold: [['organizational', 'communication'], ['coherent', 'structures'], ['meaning']] },
    { s: 'Good managers listen carefully to customer complaints.',
      gold: [['good', 'managers'], ['customer', 'complaints']] },
    { s: 'The ancient castle stood on a high hill overlooking the valley.',
      gold: [['ancient', 'castle'], ['high', 'hill'], ['valley']] },
    { s: 'Innovation requires both creativity and disciplined execution.',
      gold: [['innovation'], ['creativity'], ['disciplined', 'execution']] },
    { s: 'The supply network experienced significant disruption during the pandemic.',
      gold: [['supply', 'network'], ['significant', 'disruption'], ['pandemic']] },
    { s: 'Students who study daily achieve better grades.',
      gold: [['students'], ['better', 'grades']] },
    { s: 'Corporate sustainability reports often exaggerate actual progress.',
      gold: [['corporate', 'sustainability', 'reports'], ['actual', 'progress']] }
  ];

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = FIXTURE;
  } else {
    root.CrawdadParserFixture = FIXTURE;
  }
})(typeof self !== 'undefined' ? self : this);
