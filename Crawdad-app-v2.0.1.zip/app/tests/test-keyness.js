/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M3 tests — Keyness module (Build Spec V2 §4, §11).
 * Node:    NODE_PATH=... node tests/test-keyness.js
 * Browser: open tests/test-keyness.html
 * Oracles: scipy.stats.chi2.sf + hand-worked G² contingency examples
 *          (fixture-keyness.json); closed-form Log Ratio / %DIFF / DP /
 *          Zeta hand examples; permutation determinism.
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var K = isNode ? require('../js/keyness.js') : root.CrawdadKeyness;
  var FIX = isNode ? require('./fixture-keyness.json') : root.CrawdadFixture_keyness;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function close(a, b, tol, m) {
    if (Math.abs(a - b) > tol) { throw new Error((m || '') + ' |' + a + ' - ' + b + '| > ' + tol); }
  }

  function doc(name, n, counts) {
    var c = Object.create(null);
    Object.keys(counts).forEach(function (w) { c[w] = counts[w]; });
    return { name: name, n: n, counts: c };
  }

  /* ---------------- G² + p vs. scipy ---------------- */

  t('G² matches scipy on 10 contingency cases (1e-9), incl. zero cells', function () {
    FIX.forEach(function (c) {
      close(K.g2Of(c.a, c.b, c.NA, c.NB), c.g2, 1e-9,
        'G² for a=' + c.a + ',b=' + c.b);
    });
  });

  t('chi-square p matches scipy.stats.chi2.sf (1e-12 abs, 1e-9 rel)', function () {
    FIX.forEach(function (c) {
      var p = K.chi2P(c.g2);
      var tol = Math.max(1e-12, c.p * 1e-9);
      close(p, c.p, tol, 'p for G²=' + c.g2);
    });
  });

  t('G² hand-worked (Rayson & Garside layout): a=10/1000 vs b=2/2000', function () {
    // E1 = 1000*12/3000 = 4, E2 = 2000*12/3000 = 8
    // G² = 2*(10*ln(10/4) + 2*ln(2/8)) = 2*(10*ln2.5 + 2*ln0.25)
    var hand = 2 * (10 * Math.log(2.5) + 2 * Math.log(0.25));
    close(K.g2Of(10, 2, 1000, 2000), hand, 1e-12, 'hand G²');
  });

  t('G² is symmetric in direction and zero when rates are equal', function () {
    close(K.g2Of(40, 40, 2500, 2500), 0, 1e-12, 'equal rates');
    close(K.g2Of(10, 2, 1000, 2000), K.g2Of(2, 10, 2000, 1000), 1e-12, 'swap');
  });

  /* ---------------- effect sizes ---------------- */

  t('Log Ratio hand-worked: rate ratio 4 -> LR = 2; zero uses 0.5 adjust', function () {
    var A = [doc('a1', 1000, { x: 8, filler: 992 })];
    var B = [doc('b1', 1000, { x: 2, filler: 998 })];
    var res = K.computeKeyness(A, B, { minFreq: 3 });
    var x = res.keywords.filter(function (r) { return r.word === 'x'; })[0];
    close(x.logRatio, 2, 1e-9, 'LR'); // log2((8/1000)/(2/1000)) = 2
    // A-only word: b -> 0.5 (Hardie), LR = log2((6/1000)/(0.5/1000))
    var A2 = [doc('a1', 1000, { only: 6, filler: 994 })];
    var B2 = [doc('b1', 1000, { filler: 1000 })];
    var r2 = K.computeKeyness(A2, B2, { minFreq: 3 });
    var o = r2.keywords.filter(function (r) { return r.word === 'only'; })[0];
    close(o.logRatio, Math.round(Math.log(12) / Math.LN2 * 1000) / 1000, 1e-9,
      'zero-adjust LR (module reports 3 dp)');
    assert(o.pctDiff === null, '%DIFF must be null (A-only), not an imputed number');
  });

  t('%DIFF hand-worked: (8-2)/2 * 100 = 300', function () {
    var A = [doc('a1', 1000, { x: 8, filler: 992 })];
    var B = [doc('b1', 1000, { x: 2, filler: 998 })];
    var res = K.computeKeyness(A, B, { minFreq: 3 });
    var x = res.keywords.filter(function (r) { return r.word === 'x'; })[0];
    close(x.pctDiff, 300, 1e-9, '%DIFF');
  });

  /* ---------------- DP + doc-share warning ---------------- */

  t('DP hand-worked: all occurrences in one of two equal docs -> DP = 0.5, warn on', function () {
    // Overusing group A: two docs of 500 tokens each; "burst" only in a1 (6x)
    var A = [doc('a1', 500, { burst: 6, filler: 494 }),
             doc('a2', 500, { filler: 500 })];
    var B = [doc('b1', 1000, { filler: 1000 })];
    var res = K.computeKeyness(A, B, { minFreq: 3 });
    var r = res.keywords.filter(function (k) { return k.word === 'burst'; })[0];
    // s = (.5,.5), v = (1,0) -> DP = (|.5-1| + |.5-0|)/2 = 0.5
    close(r.dp, 0.5, 1e-9, 'DP');
    close(r.docShare, 0.5, 1e-9, 'doc share');
    assert(r.warn === false, 'exactly half the docs is not warned');
    // in only 1 of 3 docs -> share 1/3 -> warn
    var A3 = A.concat([doc('a3', 500, { filler: 500 })]);
    var r3 = K.computeKeyness(A3, B, { minFreq: 3 })
      .keywords.filter(function (k) { return k.word === 'burst'; })[0];
    assert(r3.warn === true, 'one-of-three doc concentration must warn');
  });

  t('DP is 0 when occurrences track document sizes exactly', function () {
    var A = [doc('a1', 600, { even: 6, filler: 594 }),
             doc('a2', 400, { even: 4, filler: 396 })];
    var B = [doc('b1', 1000, { filler: 1000 })];
    var r = K.computeKeyness(A, B, { minFreq: 3 })
      .keywords.filter(function (k) { return k.word === 'even'; })[0];
    close(r.dp, 0, 1e-9, 'proportional spread');
  });

  /* ---------------- Zeta ---------------- */

  t('Zeta hand-worked: in every A doc, no B doc -> zeta = 2', function () {
    var A = [doc('a1', 100, { marker: 1, shared: 1 }),
             doc('a2', 100, { marker: 2, shared: 1 })];
    var B = [doc('b1', 100, { shared: 3 }), doc('b2', 100, { shared: 1 })];
    var res = K.computeKeyness(A, B, { minFreq: 3 });
    var m = res.zetaA.filter(function (r) { return r.word === 'marker'; })[0];
    assert(m, 'marker present in zetaA');
    close(m.zetaA, 2, 1e-9, 'perfect marker');
    // shared word: pA=1, pB=1 -> zetaA = 1 -> excluded (must exceed 1)
    assert(!res.zetaA.some(function (r) { return r.word === 'shared'; }),
      'ubiquitous word is not a marker');
  });

  t('Zeta surfaces a presence-consistent word that G² ranks low', function () {
    // "steady": once in every A doc (consistent), rate diff tiny -> low G²,
    // but zetaA = 1 + 1 - 0 = 2
    var A = [doc('a1', 1000, { steady: 1, filler: 999 }),
             doc('a2', 1000, { steady: 1, filler: 999 }),
             doc('a3', 1000, { steady: 1, filler: 999 })];
    var B = [doc('b1', 1000, { filler: 1000 }), doc('b2', 1000, { filler: 1000 })];
    var res = K.computeKeyness(A, B, { minFreq: 3 });
    var z = res.zetaA.filter(function (r) { return r.word === 'steady'; })[0];
    assert(z && z.zetaA === 2, 'steady is a perfect A marker');
  });

  /* ---------------- permutation ---------------- */

  t('permutation p is deterministic for a fixed seed and changes with the seed', function () {
    function mk() {
      return {
        A: [doc('a1', 500, { key: 9, filler: 491 }), doc('a2', 500, { key: 7, filler: 493 })],
        B: [doc('b1', 500, { key: 1, filler: 499 }), doc('b2', 500, { filler: 500 })]
      };
    }
    var g = mk();
    var r1 = K.computeKeyness(g.A, g.B, { minFreq: 3, permutations: 199, seed: 42 });
    var r2 = K.computeKeyness(g.A, g.B, { minFreq: 3, permutations: 199, seed: 42 });
    assert(JSON.stringify(r1.keywords) === JSON.stringify(r2.keywords),
      'same seed must reproduce exactly');
    var k1 = r1.keywords.filter(function (r) { return r.word === 'key'; })[0];
    assert(typeof k1.permP === 'number' && k1.permP > 0 && k1.permP <= 1, 'permP in (0,1]');
    assert(r1.parameters.seed === 42 && r1.parameters.permutations === 199,
      'seed + count recorded');
  });

  t('permutation p uses the add-one rule: minimum is 1/(B+1)', function () {
    var A = [doc('a1', 100, { xx: 50, filler: 50 }), doc('a2', 100, { xx: 50, filler: 50 })];
    var B = [doc('b1', 100, { filler: 100 }), doc('b2', 100, { filler: 100 })];
    var r = K.computeKeyness(A, B, { minFreq: 3, permutations: 99, seed: 7 });
    var k = r.keywords.filter(function (x) { return x.word === 'xx'; })[0];
    assert(k.permP >= 1 / 100 - 1e-12, 'permP >= 1/(B+1)');
  });

  /* ---------------- plumbing ---------------- */

  t('docFromCra reads surfaceFrequencies; returns null without the block', function () {
    var d = K.docFromCra('f1', { surfaceFrequencies: {
      totalTokens: 10, tokens: [['the', 4], ['union', 2]] } });
    assert(d && d.n === 10 && d.counts.union === 2, 'parsed');
    assert(K.docFromCra('f2', {}) === null, 'V1-era file -> null');
  });

  t('keywords sorted by G² desc; capped at maxRows; minFreq applies', function () {
    var A = [doc('a1', 1000, { big: 30, mid: 8, rare: 2, filler: 960 })];
    var B = [doc('b1', 1000, { big: 2, mid: 2, rare: 0, filler: 996 })];
    var res = K.computeKeyness(A, B, { minFreq: 3, maxRows: 2 });
    assert(res.keywords.length === 2, 'maxRows cap');
    assert(res.keywords[0].g2 >= res.keywords[1].g2, 'sorted');
    assert(!res.keywords.some(function (r) { return r.word === 'rare'; }),
      'below minFreq excluded');
  });

  t('report carries tables, parameters, limitation note, citations, JSON block', function () {
    var A = [doc('a1', 1000, { union: 12, filler: 988 })];
    var B = [doc('b1', 1000, { union: 2, slavery: 5, filler: 993 })];
    var res = K.computeKeyness(A, B, { minFreq: 3, permutations: 99, seed: 42 });
    var md = K.serializeReport(res, ['a1'], ['b1'], 'CITE-1\n\nCITE-2\n\nDISCLAIMER');
    assert(/## Key words \(by G²\)/.test(md), 'key word table');
    assert(/perm p/.test(md), 'permutation column when enabled');
    assert(/## Zeta marker words/.test(md), 'zeta tables');
    assert(/top 2,000 surface/.test(md), 'truncation limitation stated');
    assert(/seed=42/.test(md), 'seed recorded');
    assert(/Dunning, 1993/.test(md) && /Hardie, 2014/.test(md) &&
      /Gries, 2008/.test(md) && /Burrows,/.test(md), 'method citations');
    assert(/```json/.test(md) && /"crawdad-keyness"/.test(md), 'machine block');
    assert(/CITE-1/.test(md) && /DISCLAIMER/.test(md), 'citation footer');
  });

  t('gammq sanity: Q(0.5, 0)=1, monotone decreasing, Q(0.5, large) ~ 0', function () {
    close(K.gammq(0.5, 0), 1, 1e-15, 'x=0');
    var prev = 1;
    for (var x = 0.5; x <= 20; x += 0.5) {
      var q = K.gammq(0.5, x);
      assert(q < prev, 'monotone at ' + x);
      prev = q;
    }
    assert(K.gammq(0.5, 100) < 1e-40, 'tail');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M3 keyness tests: ' + passed + '/' + results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadKeynessTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
