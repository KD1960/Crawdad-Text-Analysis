/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad 2026 — M2: Generator pipeline orchestration (spec §6)
 * clean -> substitutions -> parse -> normalize/link/index -> _cra.md
 */
(function (root) {
  'use strict';

  var APP_VERSION = '2.0.1';
  var BUILD_DATE = '2026-10-28';

  /**
   * Run the full Generator pipeline on one text.
   * deps: { parser, porter2, isStopWord, schema, textclean }
   * options: { stemming, keepPronouns, interSentenceLinking, tokPairs, tokFileName }
   * Returns { craData, craMd, log: string[] }
   */
  function generate(filename, rawText, options, deps) {
    var log = [];
    options = options || {};

    // 1-2. clean
    var cleaned = deps.textclean.cleanText(rawText);
    cleaned.notes.forEach(function (n) { log.push('[clean] ' + n); });

    // 3. tokenization substitutions
    var text = cleaned.text;
    if (options.tokPairs && options.tokPairs.length) {
      var sub = deps.textclean.applySubstitutions(text, options.tokPairs);
      text = sub.text;
      Object.keys(sub.counts).forEach(function (k) {
        log.push('[tokenize] "' + k + '" -> replaced ' + sub.counts[k] + 'x');
      });
    }

    // 4. parse (sentence segmentation, POS, NP extraction); excluded words
    // break center runs at the parser level (D-14)
    var exclParse = null;
    if (options.excludeWords && options.excludeWords.length) {
      exclParse = Object.create(null);
      options.excludeWords.forEach(function (w) { exclParse[w] = true; });
      log.push('[exclude] ' + options.excludeWords.join(', '));
    }
    var parsed = deps.parser.parse(text, { exclude: exclParse });
    log.push('[parse] ' + parsed.sentences.length + ' sentences');

    // 4a. tokenization suggestions (2026-08-09; V2-M2: ranked by NPMI with
    // log-Dice alongside, raw count still shown — spec §3.3): adjacent
    // co-occurrence of center words within noun phrases → candidate
    // multi-word tokens. Advisory only; never applied automatically.
    var tokenSuggestions = null, collocationTokens = null;
    if (deps.textclean.suggestTokenizations) {
      var sug = deps.textclean.suggestTokenizations(parsed.sentences, {
        isStopWord: deps.isStopWord,
        existingPairs: options.tokPairs || []
      });
      tokenSuggestions = sug.suggestions;
      collocationTokens = sug.nTokens;
    }
    if (tokenSuggestions && tokenSuggestions.length) {
      log.push('[tokenize] ' + tokenSuggestions.length + ' candidate multi-word token(s) suggested (NPMI-ranked)');
    }

    // 4a-ii. keyphrases (V2-M2, spec §3.3): TextRank + YAKE, reported side
    // by side; complements (not rivals) CRA influence — different graphs,
    // different centralities.
    var keyphrases = null;
    if (deps.keyphrases) {
      keyphrases = deps.keyphrases.extract(parsed.sentences, {
        isStopWord: deps.isStopWord, pageRank: deps.network.pageRank
      });
      log.push('[keyphrases] TextRank ' + keyphrases.textRank.phrases.length +
        ' phrase(s), YAKE ' + keyphrases.yake.phrases.length + ' phrase(s)');
    }

    // 4b. text-level metrics (D-12; extended V2-M1) — full token stream
    var textMetrics = null;
    var stemMode = options.stemming || 'porter';
    var sing = deps.network.singularizeIrregular ||
      function (w) { return w; };  // irregular plural -> singular (2026-10-28)
    var stemFn = stemMode === 'porter'
      ? function (w) { return deps.porter2(sing(w)); }
      : stemMode === 'minimal'
      ? function (w) { return deps.network.minimalStem(sing(w)); }
      : function (w) { return w; };
    if (deps.textmetrics) {
      textMetrics = deps.textmetrics.computeAll(parsed.sentences,
        { sentimentFn: deps.sentiment || null, stemFn: stemFn,
          vaderFn: deps.vader ? deps.vader.documentSentiment : null,
          rawText: text, deflateFn: deps.deflate || null,
          deflateLabel: deps.deflateLabel || null,
          mattrWindow: options.mattrWindow || 500 });
      log.push('[metrics] text-level metrics computed');
    }

    // 4c. surface token frequencies (schema 2.0, D-V2-2: on by default) —
    // top 2,000 surface tokens INCLUDING function words, counted before
    // stop-word removal and stemming; enables Keyness/Stylometry/Dynamics
    // from _cra.md files alone. Opt-out via options.surfaceFrequencies=false.
    var surfaceFrequencies = null;
    if (options.surfaceFrequencies !== false) {
      var sfCounts = Object.create(null), sfTotal = 0;
      parsed.sentences.forEach(function (sn) {
        (sn.tokens || []).forEach(function (t) {
          sfCounts[t.w] = (sfCounts[t.w] || 0) + 1; sfTotal++;
        });
      });
      var sfTokens = Object.keys(sfCounts)
        .sort(function (a, b) { return sfCounts[b] - sfCounts[a] || (a < b ? -1 : 1); })
        .slice(0, 2000)
        .map(function (w) { return [w, sfCounts[w]]; });
      surfaceFrequencies = { totalTokens: sfTotal, tokens: sfTokens };
      log.push('[schema] surface frequencies: ' + sfTokens.length + ' of ' +
        Object.keys(sfCounts).length + ' types recorded');
    }

    // 4d. custom dictionaries (V2-M1, spec §3.1) — user-authored only;
    // options.dictionaries: [{ name, sha256, dict, mode }]
    var lexiconsUsed = null;
    if (deps.lexicons && options.dictionaries && options.dictionaries.length) {
      var allTokensStream = [];
      parsed.sentences.forEach(function (sn) {
        (sn.tokens || []).forEach(function (t) { allTokensStream.push(t); });
      });
      lexiconsUsed = options.dictionaries.map(function (spec) {
        var res = deps.lexicons.applyDictionary(allTokensStream, spec.dict,
          { mode: spec.mode || 'exact', stemFn: stemFn });
        log.push('[dictionary] "' + spec.name + '" (' + res.type + '): coverage ' +
          Math.round(res.coverage * 1000) / 10 + '%' +
          (res.lowCoverage ? ' — LOW COVERAGE WARNING' : ''));
        return { name: spec.name, sha256: spec.sha256, type: res.type,
          mode: spec.mode || 'exact', entryCount: spec.dict.entries.length,
          coverage: res.coverage, lowCoverage: res.lowCoverage,
          matchedTokens: res.matchedTokens, totalTokens: res.totalTokens,
          metrics: res.metrics };
      });
    }

    // 5-7. normalize, link, index
    var excludeSet = Object.create(null);
    (options.excludeWords || []).forEach(function (w) { excludeSet[w] = true; });
    var isStopOrExcluded = function (w) {
      return deps.isStopWord(w) || excludeSet[w] === true;
    };
    var cra = deps.network.buildCra(parsed.sentences, {
      stemming: options.stemming || 'porter',
      interSentenceLinking: options.interSentenceLinking === true // default off (D-17)
    }, { porter2: deps.porter2, isStopWord: isStopOrExcluded });
    log.push('[network] ' + cra.nodes.length + ' nodes, ' + cra.edges.length + ' edges');

    if (cra.nodes.length === 0) {
      throw new Error('No noun phrases found in "' + filename + '" — is this prose?');
    }

    // 7b. concept communities (V2-M4, spec §5.2, D-V2-4): deterministic
    // Leiden on this text's CRA network; a within-text theme view (the PCA
    // themes are corpus-level).
    var communities = null;
    if (deps.communities) {
      communities = deps.communities.communitiesBlock(cra.nodes, cra.edges,
        { resolution: 1 });
      log.push('[communities] ' + communities.count + ' concept communities, ' +
        'modularity ' + communities.modularity);
    }

    // 7c. influence bootstrap CIs (V2-M7, spec §7.1) — optional, seeded
    var inference = null;
    if (deps.inference && options.bootstrapCI) {
      var bs = deps.inference.bootstrapInfluence(parsed.sentences, {
        B: options.bootstrapB || 200,
        seed: options.bootstrapSeed === undefined ? 42 : options.bootstrapSeed,
        stemming: options.stemming || 'porter',
        interSentenceLinking: options.interSentenceLinking === true
      }, { network: deps.network, porter2: deps.porter2,
        isStopWord: isStopOrExcluded });
      inference = { influenceCI: bs };
      log.push('[inference] influence 95% CIs: sentence bootstrap, B=' + bs.B +
        ', seed=' + bs.seed);
    }

    // 8. emit
    var data = deps.schema.newCraData(filename, {
      stemming: options.stemming || 'porter',
      pronouns: !!options.keepPronouns,
      interSentenceLinking: options.interSentenceLinking === true, // D-17
      excludeWords: options.excludeWords || [],
      tokenizationFile: options.tokFileName || null,
      stopWordList: 'default'
    }, APP_VERSION + ' (built ' + BUILD_DATE + ')');
    data.network.nodes = cra.nodes;
    data.network.edges = cra.edges;
    data.summary = cra.summary;
    if (textMetrics) { data.textMetrics = textMetrics; }
    if (tokenSuggestions && tokenSuggestions.length) {
      data.tokenSuggestions = tokenSuggestions;
      data.collocationTokens = collocationTokens; // N for corpus-level NPMI (Summarizer)
    }
    if (keyphrases) { data.keyphrases = keyphrases; }
    if (communities) { data.communities = communities; }
    if (inference) { data.inference = inference; }
    if (cleaned.notes.length) { data.cleaningNotes = cleaned.notes; }
    if (surfaceFrequencies) { data.surfaceFrequencies = surfaceFrequencies; }
    if (lexiconsUsed) { data.lexiconsUsed = lexiconsUsed; }

    var md = deps.schema.serializeCra(data);
    return { craData: data, craMd: md, log: log };
  }

  function craFileName(sourceName) {
    return sourceName.replace(/\.(txt|md|pdf|docx)$/i, '') + '_cra.md';
  }

  var api = { generate: generate, craFileName: craFileName,
    APP_VERSION: APP_VERSION, BUILD_DATE: BUILD_DATE };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadGenerator = api; }
})(typeof self !== 'undefined' ? self : this);
