/*
 * Crawdad 2026 — M6 validation.
 * Node:    node tests/test-themes.js
 * Browser: open tests/test-themes.html
 *
 * PCA reference values computed independently with numpy (np.corrcoef +
 * np.linalg.eigh) on the fixture matrix below; agreement required to 1e-6
 * (spec §11 M6). Sign convention both sides: largest-|.| eigenvector
 * element positive.
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var T = isNode ? require('../js/themes.js') : root.CrawdadThemes;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function approx(a, b, eps) { return Math.abs(a - b) <= (eps || 1e-9); }

  /* ---------- PCA vs numpy reference ---------- */

  var FIXTURE_MATRIX = [
    [0.30, 0.28, 0.02, 0.01],
    [0.25, 0.22, 0.00, 0.03],
    [0.18, 0.20, 0.05, 0.00],
    [0.02, 0.01, 0.30, 0.28],
    [0.00, 0.04, 0.26, 0.22],
    [0.05, 0.00, 0.19, 0.21],
    [0.10, 0.12, 0.11, 0.09],
    [0.08, 0.07, 0.09, 0.10]
  ];
  var NUMPY_EIGENVALUES = [3.7405682931, 0.1897748425, 0.0653629009, 0.0042939635];
  var NUMPY_LOADINGS = [
    [-0.9640653219, 0.2270677930, 0.1347227581, -0.0294627060],
    [-0.9686877184, 0.2080948303, -0.1312858605, 0.0332365558],
    [0.9644640473, 0.2324411118, -0.1214299894, -0.0321712387],
    [0.9708756635, 0.2021947848, 0.1234158007, 0.0358644002]
  ];

  t('PCA eigenvalues match numpy to 1e-6', function () {
    var res = T.pca(FIXTURE_MATRIX);
    NUMPY_EIGENVALUES.forEach(function (ev, j) {
      assert(approx(res.eigenvalues[j], ev, 1e-6),
        'eig[' + j + ']: ' + res.eigenvalues[j] + ' vs ' + ev);
    });
  });

  t('PCA loadings match numpy to 1e-6 (sign convention aligned)', function () {
    var res = T.pca(FIXTURE_MATRIX);
    for (var i = 0; i < 4; i++) {
      for (var j = 0; j < 4; j++) {
        assert(approx(res.loadings[i][j], NUMPY_LOADINGS[i][j], 1e-6),
          'loading[' + i + '][' + j + ']: ' + res.loadings[i][j] +
          ' vs ' + NUMPY_LOADINGS[i][j]);
      }
    }
  });

  t('PCA eigenvalues sum to number of variables (correlation matrix trace)', function () {
    var res = T.pca(FIXTURE_MATRIX);
    var sum = res.eigenvalues.reduce(function (a, b) { return a + b; }, 0);
    assert(approx(sum, 4, 1e-9), 'sum: ' + sum);
  });

  t('loadings are bounded: |loading| <= 1 and squared loadings sum to 1 per text', function () {
    var res = T.pca(FIXTURE_MATRIX);
    res.loadings.forEach(function (row, i) {
      var ss = 0;
      row.forEach(function (v) {
        assert(Math.abs(v) <= 1 + 1e-9, 'loading[' + i + '] = ' + v + ' exceeds 1');
        ss += v * v;
      });
      assert(approx(ss, 1, 1e-9), 'communality of text ' + i + ': ' + ss);
    });
  });

  t('word scores are standardized: unit variance across words per component', function () {
    var res = T.pca(FIXTURE_MATRIX);
    var m = FIXTURE_MATRIX.length;
    for (var j = 0; j < 4; j++) {
      if (res.eigenvalues[j] <= 1e-12) { continue; }
      var ss = 0;
      for (var w = 0; w < m; w++) { ss += res.wordScores[w][j] * res.wordScores[w][j]; }
      assert(approx(ss / (m - 1), 1, 1e-9), 'variance comp ' + j + ': ' + (ss / (m - 1)));
    }
  });

  /* ---------- varimax rotation (D-9) ---------- */

  // 15 words × 6 texts, three topical blocks; two eigenvalues > 1.
  // Reference rotated loadings computed with an INDEPENDENT numpy varimax
  // (SVD-based algorithm, Kaiser-normalized) — this JS uses the classic
  // pairwise-rotation algorithm, so agreement is a genuine cross-check.
  var VMX_MATRIX = [
    [0.2801,0.2774,0.0215,0.0181,0.0166,0.0285],[0.3259,0.3326,0.0072,0.0239,0.0019,0.0109],
    [0.2941,0.3081,0.0021,0.0087,0.0237,0.0272],[0.2751,0.3156,0.0185,0.0108,0.0051,0.0131],
    [0.3662,0.337,0.0006,0.0231,0.009,0.021],[0.022,0.028,0.335,0.2716,0.0242,0.0229],
    [0.0196,0.0243,0.3587,0.3644,0.01,0.0221],[0.0285,0.01,0.2849,0.3242,0.0138,0.0023],
    [0.0006,0.0228,0.2656,0.2804,0.0222,0.0126],[0.011,0.0051,0.3055,0.2908,0.022,0.0263],
    [0.0194,0.0209,0.0058,0.023,0.3359,0.345],[0.0096,0.017,0.0198,0.0173,0.294,0.2884],
    [0.0253,0.0091,0.0131,0.0027,0.2702,0.261],[0.0103,0.0213,0.0292,0.0188,0.3294,0.3297],
    [0.0188,0.0248,0.016,0.0273,0.268,0.3066]
  ];
  var NUMPY_ROTATED = [
    [-0.726470398853,-0.680009570025],[-0.729374921004,-0.679096743923],
    [0.957825169645,-0.269719965103],[0.951055045391,-0.288507482466],
    [-0.204190854388,0.976690291765],[-0.231352792857,0.968405341167]
  ];
  var NUMPY_SS = [2.976899790546, 2.971303660776];

  t('varimax: k=2 retained (eigenvalues > 1) on 3-block fixture', function () {
    var res = T.pca(VMX_MATRIX);
    assert(res.rotated && res.rotated.k === 2,
      'k: ' + (res.rotated && res.rotated.k) + ' | eigs: ' + res.eigenvalues.map(function (e) {
        return e.toFixed(3); }).join(','));
  });

  t('varimax rotated loadings match independent numpy implementation to 1e-6', function () {
    var res = T.pca(VMX_MATRIX);
    for (var i = 0; i < 6; i++) {
      for (var j = 0; j < 2; j++) {
        assert(approx(res.rotated.loadings[i][j], NUMPY_ROTATED[i][j], 1e-6),
          '[' + i + '][' + j + ']: ' + res.rotated.loadings[i][j] + ' vs ' + NUMPY_ROTATED[i][j]);
      }
    }
    for (j = 0; j < 2; j++) {
      assert(approx(res.rotated.ssLoadings[j], NUMPY_SS[j], 1e-6), 'SS ' + j);
    }
  });

  t('varimax preserves communalities (orthogonal rotation)', function () {
    var res = T.pca(VMX_MATRIX);
    for (var i = 0; i < 6; i++) {
      var before = 0, after = 0;
      for (var j = 0; j < 2; j++) {
        before += res.loadings[i][j] * res.loadings[i][j];
        after += res.rotated.loadings[i][j] * res.rotated.loadings[i][j];
      }
      assert(approx(before, after, 1e-9), 'text ' + i + ': ' + before + ' vs ' + after);
    }
  });

  t('varimax improves simple structure (higher variance of squared loadings)', function () {
    var res = T.pca(VMX_MATRIX);
    function vmxCriterion(L, k) {
      var crit = 0;
      for (var j = 0; j < k; j++) {
        var s = 0, s2 = 0;
        for (var i = 0; i < L.length; i++) {
          var q = L[i][j] * L[i][j];
          s += q; s2 += q * q;
        }
        crit += s2 / L.length - Math.pow(s / L.length, 2);
      }
      return crit;
    }
    var before = vmxCriterion(res.loadings.map(function (r) { return r.slice(0, 2); }), 2);
    var after = vmxCriterion(res.rotated.loadings, 2);
    assert(after >= before - 1e-12, 'criterion: ' + before + ' -> ' + after);
  });

  t('varimax not applied when only one eigenvalue > 1', function () {
    var res = T.pca(FIXTURE_MATRIX); // eigenvalues [3.74, 0.19, ...] — k=1
    assert(res.rotated === null, 'rotation should be null');
  });

  t('rotated word scores remain unit variance', function () {
    var res = T.pca(VMX_MATRIX);
    var m = VMX_MATRIX.length;
    for (var j = 0; j < res.rotated.k; j++) {
      var ss = 0;
      for (var w = 0; w < m; w++) {
        ss += res.rotated.wordScores[w][j] * res.rotated.wordScores[w][j];
      }
      assert(approx(ss / (m - 1), 1, 1e-9), 'variance rotated comp ' + j + ': ' + (ss / (m - 1)));
    }
  });

  /* ---------- summed influence (WF 7b hand example) ---------- */

  function mkData(words, fname) {
    var nodes = [], i = 0;
    Object.keys(words).forEach(function (w) {
      nodes.push({ id: i++, word: w, display: w.toUpperCase(), degree: 0, influence: words[w] });
    });
    return { schema: 'crawdad-cra', schemaVersion: '1.0',
      source: { filename: fname }, parameters: { stemming: 'porter' }, summary: {},
      network: { nodes: nodes, edges: [] } };
  }

  t('WF 7b example: influences .1,.1,0,.2,0 sum to 0.4 (zeros count, no averaging)', function () {
    var datas = [
      mkData({ scm: 0.1 }, 'a'), mkData({ scm: 0.1 }, 'b'), mkData({ other: 0.5 }, 'c'),
      mkData({ scm: 0.2 }, 'd'), mkData({ another: 0.3 }, 'e')
    ];
    var wtm = T.wordTextMatrix(datas, ['a', 'b', 'c', 'd', 'e']);
    var scm = wtm.words.filter(function (w) { return w.word === 'scm'; })[0];
    assert(scm && approx(scm.sum, 0.4), 'sum: ' + (scm && scm.sum));
    var row = wtm.matrix[wtm.words.indexOf(scm)];
    assert(JSON.stringify(row) === JSON.stringify([0.1, 0.1, 0, 0.2, 0]), 'row: ' + row);
  });

  t('top-50 cap and ordering by summed influence', function () {
    var big = {};
    for (var i = 0; i < 70; i++) { big['w' + i] = (70 - i) / 1000; }
    var datas = [mkData(big, 'a'), mkData(big, 'b'), mkData(big, 'c'),
                 mkData(big, 'd'), mkData(big, 'e')];
    var wtm = T.wordTextMatrix(datas, ['a', 'b', 'c', 'd', 'e']);
    assert(wtm.words.length === 50, 'got ' + wtm.words.length);
    assert(wtm.words[0].word === 'w0', 'highest first');
  });

  /* ---------- latent themes ---------- */

  t('latent codes: comma lists split, words stemmed, themes grouped', function () {
    var themes = T.parseLatentCodes(
      [['Sustainability', 'recycling, emissions'], ['Sustainability', 'waste'],
       ['Quality', 'defects']],
      function (w) { return w.toUpperCase(); }); // fake stemmer to prove application
    assert(themes.Sustainability.length === 3, 'sustainability words');
    assert(themes.Sustainability[0] === 'RECYCLING', 'stemmer not applied');
    assert(themes.Quality.length === 1, 'quality words');
  });

  t('latent scores: summed influence per theme per text; absent = 0', function () {
    var datas = [
      mkData({ recycl: 0.2, wast: 0.1 }, 'a'),
      mkData({ recycl: 0.05 }, 'b'),
      mkData({ defect: 0.3 }, 'c')
    ];
    var themes = { Sust: ['recycl', 'wast'], Qual: ['defect'], Empty: ['unicorn'] };
    var res = T.latentScores(datas, themes);
    assert(approx(res.table.Sust[0], 0.3), 'Sust a: ' + res.table.Sust[0]);
    assert(approx(res.table.Sust[1], 0.05), 'Sust b');
    assert(res.table.Sust[2] === 0, 'Sust c');
    assert(approx(res.table.Qual[2], 0.3), 'Qual c');
    assert(res.table.Empty.every(function (v) { return v === 0; }), 'Empty theme');
  });

  t('latent coverage: unmatched code words reported', function () {
    var datas = [mkData({ recycl: 0.2 }, 'a')];
    var res = T.latentScores(datas, { S: ['recycl', 'unicorn', 'gryphon'] });
    assert(res.coverage.found.length === 1 && res.coverage.found[0] === 'recycl', 'found');
    assert(res.coverage.missing.length === 2 &&
      res.coverage.missing.indexOf('unicorn') !== -1, 'missing: ' + res.coverage.missing);
  });

  /* ---------- reports ---------- */

  t('theme report: eigenvalue >1 and |loading| >0.4 color-coded; citation; JSON', function () {
    var datas = [];
    for (var i = 0; i < 5; i++) {
      var words = {};
      // two blocks of words: first 3 texts share group A, last 2 share group B
      if (i < 3) { words.alpha = 0.3 - i * 0.02; words.beta = 0.2; }
      else { words.gamma = 0.3; words.delta = 0.25 - (i - 3) * 0.02; }
      words.common = 0.1;
      datas.push(mkData(words, 't' + i));
    }
    var rep = T.themeReport(datas, ['t0', 't1', 't2', 't3', 't4'], 'CITE-SENTINEL');
    var md = rep.markdown;
    assert(md.indexOf('background-color:#ffe08a') !== -1, 'eigenvalue >1 highlight missing');
    assert(md.indexOf('background-color:#f6c3bc') !== -1, '|loading|>0.4 highlight missing');
    assert(md.indexOf('CITE-SENTINEL') !== -1, 'citation');
    assert(md.indexOf('Defining words per component') !== -1, 'word scores section');
    var parsed = JSON.parse(md.match(/```json\s*\n([\s\S]*?)\n```/)[1]);
    assert(parsed.schema === 'crawdad-themes' && parsed.eigenvalues.length === 5, 'JSON');
  });

  t('latent report: table, coverage warning, citation', function () {
    var datas = [mkData({ recycl: 0.2 }, 'a'), mkData({ defect: 0.1 }, 'b')];
    var rep = T.latentReport(datas, ['a', 'b'],
      { S: ['recycl', 'unicorn'] }, 'CITE-SENTINEL', 'stem note');
    var md = rep.markdown;
    assert(md.indexOf('| S |') !== -1, 'theme row');
    assert(md.indexOf('unicorn') !== -1 && md.indexOf('validity trap') !== -1, 'coverage warning');
    assert(md.indexOf('CITE-SENTINEL') !== -1, 'citation');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'M6 theme tests: ' + passed + '/' + results.length + ' passed';

  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadThemesTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
