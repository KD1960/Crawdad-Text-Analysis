/*
 * Crawdad 2026 — file I/O helpers (spec §5)
 * Plain script, browser-only. No data leaves the machine.
 */
(function (root) {
  'use strict';

  /** Read a File object as UTF-8 text. Returns a Promise<string>. */
  function readFileAsText(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(r.result); };
      r.onerror = function () { reject(new Error('Could not read ' + file.name)); };
      r.readAsText(file, 'utf-8');
    });
  }

  /** Trigger a download of `content` as a file named `name`. */
  function downloadFile(name, content, mime) {
    var blob = content instanceof Blob
      ? content
      : new Blob([content], { type: mime || 'text/markdown;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 5000);
  }

  /**
   * Wire a drop zone + hidden <input type=file>.
   * opts: { zoneEl, inputEl, accept: fn(name)->bool, onFiles: fn(File[]) }
   */
  function wireFilePicker(opts) {
    var zone = opts.zoneEl, input = opts.inputEl;

    function accepted(files) {
      var ok = [], bad = [];
      Array.prototype.forEach.call(files, function (f) {
        (opts.accept(f.name) ? ok : bad).push(f);
      });
      if (bad.length) {
        opts.onRejected && opts.onRejected(bad.map(function (f) { return f.name; }));
      }
      if (ok.length) { opts.onFiles(ok); }
    }

    zone.addEventListener('click', function () { input.click(); });
    zone.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); }
    });
    input.addEventListener('change', function () {
      accepted(input.files);
      input.value = ''; // allow re-selecting same file
    });
    ['dragover', 'dragenter'].forEach(function (evt) {
      zone.addEventListener(evt, function (e) {
        e.preventDefault();
        zone.classList.add('dragover');
      });
    });
    ['dragleave', 'drop'].forEach(function (evt) {
      zone.addEventListener(evt, function (e) {
        e.preventDefault();
        zone.classList.remove('dragover');
      });
    });
    zone.addEventListener('drop', function (e) {
      if (e.dataTransfer && e.dataTransfer.files) { accepted(e.dataTransfer.files); }
    });
  }

  /** Extension checks (spec §5.2; .pdf/.docx via E-1 conversion). */
  function isTextSource(name) { return /\.(txt|md|pdf|docx)$/i.test(name) && !/_cra\.md$/i.test(name); }
  function isCraFile(name) { return /_cra\.md$/i.test(name); }
  function isSpreadsheet(name) { return /\.(xlsx|csv)$/i.test(name); }

  root.CrawdadFileIO = {
    readFileAsText: readFileAsText,
    downloadFile: downloadFile,
    wireFilePicker: wireFilePicker,
    isTextSource: isTextSource,
    isCraFile: isCraFile,
    isSpreadsheet: isSpreadsheet
  };
})(typeof self !== 'undefined' ? self : this);
