/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad 2026 — M1 parser module (spec §3.1)
 * Sentence segmentation, POS tagging, and CRA noun-phrase extraction.
 *
 * Engine: wink-nlp + wink-eng-lite-web-model (chosen in the M1 benchmark:
 * F1 = 0.970 on the 20-sentence gold fixture; errors are modifier misses,
 * never head-noun losses — see tests/benchmark-parsers.js).
 *
 * Chunking rule (CRA; WF 2h.i "each unique noun and adjective becomes a
 * node"): center runs are maximal contiguous runs of {ADJ, NOUN, PROPN}.
 * Adjective-only runs (predicate adjectives: "the cat was OLD and WISE") ARE
 * centers per the workflow spec — fixed 2026-07-28 (D-14); previously they
 * were wrongly dropped. DET, PRON (default), NUM, VERB, ADV, etc. break runs
 * and are excluded.
 *
 * Browser: requires vendor/wink-bundle.js loaded first (window.CrawdadWink).
 * Node (tests): pass winkNLP + model to createParser().
 */
(function (root) {
  'use strict';

  function createParser(winkNLP, model, options) {
    var nlp = winkNLP(model);
    var its = nlp.its;
    var keepPronouns = !!(options && options.keepPronouns); // spec §3.1 toggle

    // D-14b dual-tagger verb arbitration: wink's known weakness is tagging
    // past-tense verbs ("chased") as nouns; compromise's known weakness is
    // the reverse (calling real nouns verbs), but NOT for -ed forms (M1
    // benchmark). So: when wink says NOUN/PROPN for a word ending in -ed,
    // ask compromise; if compromise says unambiguously Verb, treat as verb.
    // Scope deliberately narrow: -ed only (not -eed, not -ing: "swimming"
    // is a legitimate gerund center), length >= 5.
    var compromise = (options && options.compromise) ||
                     (typeof root.nlp === 'function' ? root.nlp : null);

    function makeTagChecks(sentText) {
      var map = null; // lazy: only built if a candidate appears
      function tagsFor(w) {
        if (!compromise) { return null; }
        if (map === null) {
          map = Object.create(null);
          try {
            compromise(sentText).json().forEach(function (s) {
              (s.terms || []).forEach(function (t) {
                var key = (t.text || '').toLowerCase().replace(/[^a-z0-9'-]/g, '');
                if (!key) { return; }
                var set = map[key] = map[key] || Object.create(null);
                (t.tags || []).forEach(function (g) { set[g] = true; });
              });
            });
          } catch (e) { map = Object.create(null); }
        }
        return map[w] || null;
      }
      return {
        // D-14b: wink NOUN, compromise unambiguous Verb -> verb
        saysVerb: function (w) {
          var tags = tagsFor(w);
          return !!(tags && tags.Verb && !tags.Noun);
        },
        // D-14c: wink VERB after a preposition (a position that takes
        // nominals), compromise unambiguous Noun -> noun center
        // ("structures of MEANING"; validation study V1 finding)
        saysNoun: function (w) {
          var tags = tagsFor(w);
          return !!(tags && tags.Noun && !tags.Verb);
        },
        saysAdj: function (w) {
          var tags = tagsFor(w);
          return !!(tags && tags.Adjective && !tags.Adverb && !tags.Verb);
        }
      };
    }

    function isNounPos(pos) { return pos === 'NOUN' || pos === 'PROPN'; }
    function isAdjPos(pos) { return pos === 'ADJ'; }
    function isPronoun(pos) { return pos === 'PRON'; }

    // Surname particles (Kevin's report 2026-08-11: "Van" in "Van Wyck"
    // survived as a node). A capitalized particle tagged PROPN whose NEXT
    // token is also PROPN is part of a name, not a concept — dropped from
    // center runs (the following name words stay, and stay linked). The
    // list is deliberately conservative: English homographs with real noun
    // senses ("den", "ten") are excluded, and lowercase/common-noun uses
    // ("the van") are untouched because those are not PROPN+capitalized.
    var NAME_PARTICLES = Object.create(null);
    ['van', 'von', 'vander', 'vanden', 'de', 'del', 'della', 'di', 'da',
     'du', 'der', 'la', 'le'].forEach(function (w) { NAME_PARTICLES[w] = true; });

    /**
     * Parse text into sentences of CRA noun phrases.
     * Returns { sentences: [ { text, phrases: [ [word, ...], ... ] } ] }
     * Words are lowercased surface forms; stemming happens downstream (§3.5).
     */
    function parse(text, perCall) {
      // perCall.exclude: {word: true} — excluded words BREAK center runs
      // exactly as a verb would (D-14 escape hatch for tagger errors), so the
      // surrounding noun phrases keep their true structure
      var excl = (perCall && perCall.exclude) || null;
      var doc = nlp.readDoc(text);
      var sentences = [];
      doc.sentences().each(function (sent) {
        var phrases = [];
        var tokens = []; // full token/POS stream (for text-level metrics, D-12)
        var cur = [];
        var checks = makeTagChecks(sent.out());
        var prevPos = null;
        function flush() {
          if (cur.length) { phrases.push(cur); } // ADJ-only runs kept (WF 2h.i, D-14)
          cur = [];
        }
        // Collect the raw token stream first so underscore compounds created
        // by tokenization substitutions (spec §4.2) can be re-joined: wink
        // tokenizes "supply_chain" as supply / _ / chain, which silently
        // undid the user's substitution (fix 2026-08-09). Joined compounds
        // are treated as NOUN centers and are exempt from the D-14 dual-
        // tagger checks (they are user-defined tokens, not tagger output).
        var raw = [];
        sent.tokens().each(function (t) {
          raw.push({ text: t.out(), pos: t.out(its.pos) });
        });
        var merged = [];
        for (var ri = 0; ri < raw.length; ri++) {
          var tk = raw[ri];
          if (tk.text === '_' && merged.length &&
              /[a-z0-9]$/i.test(merged[merged.length - 1].text) &&
              ri + 1 < raw.length && /^[a-z0-9]/i.test(raw[ri + 1].text)) {
            merged[merged.length - 1] = {
              text: merged[merged.length - 1].text + '_' + raw[ri + 1].text,
              pos: 'NOUN', compound: true
            };
            ri++; // consume the following word token as well
            continue;
          }
          merged.push(tk);
        }
        merged.forEach(function (t, mi) {
          var pos = t.pos;
          var w = t.text.toLowerCase();
          // Transliterate Latin diacritics before any filtering (fix
          // 2026-10-28, parser diagnostics: "Müller" survived citation
          // cleaning as a token and the character filter below mangled it to
          // "mller"). NFD splits base letters from combining marks; the marks
          // are dropped. Letters with no decomposition (ø, ß) still fall to
          // the character filter.
          if (/[^\x00-\x7f]/.test(w)) {
            w = w.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
          }
          // surname-particle drop (2026-08-11): "Van Wyck" -> center "wyck";
          // token still enters the metrics stream below, never a center
          if ((pos === 'PROPN' || pos === 'NOUN') && NAME_PARTICLES[w] &&
              /^[A-Z]/.test(t.text) && mi + 1 < merged.length &&
              merged[mi + 1].pos === 'PROPN' && /^[A-Z]/.test(merged[mi + 1].text)) {
            var wp = w.replace(/[^a-z0-9'_-]/g, '');
            if (wp && /[a-z0-9]/.test(wp)) { tokens.push({ w: wp, pos: pos }); }
            prevPos = pos;
            return; // no flush: the surrounding name run stays intact
          }
          // keep letters/digits/internal hyphens, apostrophes & underscores only
          w = w.replace(/[^a-z0-9'_-]/g, '');
          // punctuation-only residue (bare "_", "-", "'") is not a word
          if (!/[a-z0-9]/.test(w)) { w = ''; }
          // a token still carrying an underscore is a user-defined compound
          if (w.indexOf('_') !== -1) { pos = 'NOUN'; }
          if (w && pos !== 'PUNCT' && pos !== 'SYM') { tokens.push({ w: w, pos: pos }); }
          // drop single-character tokens (citation initials "j", "r", etc.)
          // and possessive clitics: "'s" is 2 characters, passes the length
          // guard, and sat one POS mis-tag away from becoming a node
          // (2026-10-28). It stays in the metrics token stream above; here it
          // only breaks the center run, exactly as a correctly tagged PART
          // would.
          if (!w || w.length < 2 || w === "'s" || w === "s'") {
            flush(); prevPos = pos; return;
          }
          if (excl && excl[w]) { flush(); prevPos = pos; return; }
          // D-14b: second-opinion check for -ed words wink tagged as nouns.
          // NOTE (2026-10-28): an extension to ADJ-tagged -ed words was
          // built and REVERTED — on the golden corpus it dropped legitimate
          // attributive/postposed participles ("a house divided",
          // "civilized world", "unfettered", "unquestioned") because
          // compromise reads them as past-tense verbs in context. Verbal
          // participles that wink tags ADJ ("used surveys") therefore remain
          // a documented tagger limitation; the per-run exclude-words option
          // is the escape hatch.
          if (!t.compound && (pos === 'NOUN' || pos === 'PROPN') && w.length >= 5 &&
              /[a-z]ed$/.test(w) && !/eed$/.test(w) && checks.saysVerb(w)) {
            flush(); prevPos = pos; return; // arbitrated as verb: no node
          }
          // D-14c: wink VERB right after a preposition — that position takes
          // nominals; if compromise says unambiguous Noun, rescue as center
          if (pos === 'VERB' && prevPos === 'ADP' && checks.saysNoun(w)) {
            pos = 'NOUN';
          }
          // D-14d: sentence-initial "Prior studies…" pattern — wink tags
          // ADV then VERB; if compromise reads Adjective/Noun unambiguously,
          // rescue (validation study V1: A6, F7)
          if (pos === 'ADV' && prevPos === null && checks.saysAdj(w)) {
            pos = 'ADJ';
          } else if (pos === 'VERB' && prevPos === 'ADJ→' && checks.saysNoun(w)) {
            pos = 'NOUN';
          }
          prevPos = (pos === 'ADJ' && prevPos === null) ? 'ADJ→' : pos;
          if (isNounPos(pos) || isAdjPos(pos) || (keepPronouns && isPronoun(pos))) {
            cur.push(w);
          } else {
            flush();
          }
        });
        flush();
        sentences.push({ text: sent.out(), phrases: phrases, tokens: tokens });
      });
      return { sentences: sentences };
    }

    /** Debug helper: token/POS listing for a sentence (M1 acceptance review). */
    function tagView(text) {
      var doc = nlp.readDoc(text);
      var out = [];
      doc.tokens().each(function (t) {
        out.push({ token: t.out(), pos: t.out(its.pos) });
      });
      return out;
    }

    return { parse: parse, tagView: tagView, engine: 'wink-nlp' };
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { createParser: createParser };   // Node (tests)
  } else {
    if (!root.CrawdadWink) {
      throw new Error('vendor/wink-bundle.js must be loaded before js/parser.js');
    }
    root.CrawdadParser = {
      createParser: function (options) {
        return createParser(root.CrawdadWink.winkNLP, root.CrawdadWink.model, options);
      }
    };
  }
})(typeof self !== 'undefined' ? self : this);
