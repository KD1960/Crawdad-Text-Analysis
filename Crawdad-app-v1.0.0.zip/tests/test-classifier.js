/*
 * Crawdad 2026 — M5 validation.
 * Node:    node tests/test-classifier.js
 * Browser: open tests/test-classifier.html
 *
 * Hand-computed silhouette reference (1-D rows, 2 clusters):
 *   points: p0=0, p1=1, p2=10, p3=11; clusters {p0,p1} {p2,p3}
 *   s(p0): a=1, b=(10+11)/2=10.5, s=(10.5-1)/10.5 = 0.904762
 *   s(p1): a=1, b=(9+10)/2=9.5,  s=(9.5-1)/9.5   = 0.894737
 *   s(p2): a=1, b=(10+9)/2=9.5,  s=0.894737
 *   s(p3): a=1, b=(11+10)/2=10.5, s=0.904762
 *   mean = 0.899749...
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var C = isNode ? require('../js/classifier.js') : root.CrawdadClassifier;
  var R = isNode ? require('../js/resonance.js') : root.CrawdadResonance;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function approx(a, b, eps) { return Math.abs(a - b) <= (eps || 1e-9); }

  /* ---------- silhouette ---------- */

  t('silhouette matches hand calculation (mean 0.899749)', function () {
    var rows = [[0], [1], [10], [11]];
    var sil = C.silhouette(rows, [0, 0, 1, 1]);
    assert(approx(sil.values[0], 9.5 / 10.5, 1e-12), 's(p0): ' + sil.values[0]);
    assert(approx(sil.values[1], 8.5 / 9.5, 1e-12), 's(p1): ' + sil.values[1]);
    var mean = (9.5 / 10.5 + 8.5 / 9.5 + 8.5 / 9.5 + 9.5 / 10.5) / 4;
    assert(approx(sil.mean, mean, 1e-12), 'mean: ' + sil.mean);
  });

  t('silhouette: singleton cluster convention s=0', function () {
    var sil = C.silhouette([[0], [10], [11]], [0, 1, 1]);
    assert(sil.values[0] === 0, 'singleton not 0: ' + sil.values[0]);
  });

  /* ---------- k-means ---------- */

  function synthRows(groups, perGroup, spread, dims) {
    // deterministic synthetic data: groups centered far apart
    var rows = [], truth = [];
    var rand = C.rng(42);
    for (var g = 0; g < groups; g++) {
      for (var i = 0; i < perGroup; i++) {
        var row = [];
        for (var d = 0; d < dims; d++) {
          row.push(g * 100 + (rand() - 0.5) * spread);
        }
        rows.push(row); truth.push(g);
      }
    }
    return { rows: rows, truth: truth };
  }

  function sameGrouping(a, b) {
    // label-permutation-invariant equality
    var map = {};
    for (var i = 0; i < a.length; i++) {
      if (map[a[i]] === undefined) { map[a[i]] = b[i]; }
      if (map[a[i]] !== b[i]) { return false; }
    }
    return true;
  }

  t('k-means recovers 2 well-separated synthetic clusters', function () {
    var s = synthRows(2, 4, 5, 3);
    var km = C.kmeans(s.rows, 2);
    assert(sameGrouping(km.labels, s.truth), 'labels: ' + km.labels.join(','));
  });

  t('k-means recovers 3 well-separated synthetic clusters', function () {
    var s = synthRows(3, 3, 5, 3);
    var km = C.kmeans(s.rows, 3);
    assert(sameGrouping(km.labels, s.truth), 'labels: ' + km.labels.join(','));
  });

  t('k-means determinism: identical labels across 5 repeated runs (fixed seed)', function () {
    var s = synthRows(3, 4, 20, 4);
    var first = C.kmeans(s.rows, 3).labels.join(',');
    for (var r = 0; r < 5; r++) {
      assert(C.kmeans(s.rows, 3).labels.join(',') === first, 'run ' + r + ' differs');
    }
  });

  t('classify: 3-group data (n=9) — sqrt(n) rule accepts K=3', function () {
    var s3 = synthRows(3, 3, 5, 3);
    var r = C.classify(s3.rows);
    assert(r.best.k === 3, 'K: ' + r.best.k);
    assert(r.rule.indexOf('sqrt') === 0, 'rule: ' + r.rule);
  });

  t('classify: 2 tight far groups (n=8, sqrt target 3) — falls back to K=2', function () {
    var s2 = synthRows(2, 4, 2, 3); // very tight, very separated
    var r = C.classify(s2.rows);
    assert(r.best.k === 2, 'K: ' + r.best.k);
    assert(r.rule.indexOf('rejected') !== -1, 'rule should explain fallback: ' + r.rule);
  });

  t('classify: sqrt rule keeps K=3 over a degenerate 8-vs-1 K=2 split (D-8 motivation)', function () {
    // 3 real groups of 3, one group pulled far away: silhouette at K=2 is high
    // (far group vs the rest) but the K=3 structure is the informative one.
    var rows = [];
    var rand = C.rng(7);
    function grp(cx, m) { for (var i = 0; i < m; i++) {
      rows.push([cx + (rand() - 0.5) * 4, cx * 0.5 + (rand() - 0.5) * 4]); } }
    grp(0, 3); grp(30, 3); grp(300, 3); // n=9, K0=3
    var r = C.classify(rows);
    assert(r.best.k === 3, 'K: ' + r.best.k + ' | ' + r.rule);
    assert(!r.best.hasSingleton, 'sizes: ' + r.best.sizes.join(','));
  });

  t('classify: forceK override respected and labeled in rule', function () {
    var s = synthRows(2, 4, 5, 3);
    var r = C.classify(s.rows, undefined, { forceK: 4 });
    assert(r.best.k === 4, 'K: ' + r.best.k);
    assert(r.rule.indexOf('manually') !== -1, 'rule: ' + r.rule);
  });

  t('classify: sizes and singleton flags reported for every K tried', function () {
    var s = synthRows(3, 3, 5, 3);
    var r = C.classify(s.rows);
    r.tried.forEach(function (t2) {
      assert(Array.isArray(t2.sizes) && t2.sizes.length === t2.k, 'sizes for K=' + t2.k);
      assert(t2.sizes.reduce(function (a, b) { return a + b; }, 0) === 9, 'sizes sum');
      assert(typeof t2.hasSingleton === 'boolean', 'flag for K=' + t2.k);
    });
  });

  t('classify caps K at min(8, n-1)', function () {
    var s = synthRows(2, 3, 5, 2); // n=6 -> K up to 5
    var tried = C.classify(s.rows).tried.map(function (x) { return x.k; });
    assert(tried[0] === 2 && tried[tried.length - 1] === 5, 'K range: ' + tried.join(','));
  });

  /* ---------- resonance matrices ---------- */

  function mk(words, edges) {
    var nodes = [], id = {}, i = 0;
    Object.keys(words).forEach(function (w) {
      id[w] = i; nodes.push({ id: i, word: w, display: w, degree: 0, influence: words[w] }); i++;
    });
    return { schema: 'crawdad-cra', schemaVersion: '1.0', source: { filename: 't' },
      parameters: {}, summary: {},
      network: { nodes: nodes, edges: edges.map(function (e) {
        return { source: id[e[0]], target: id[e[1]], weight: e[2] }; }) } };
  }

  t('resonance matrix: symmetric, unit diagonal', function () {
    var datas = [
      mk({ x: 0.5, y: 0.2 }, [['x', 'y', 1]]),
      mk({ x: 0.4, z: 0.3 }, [['x', 'z', 2]]),
      mk({ p: 0.6, q: 0.1 }, [['p', 'q', 1]])
    ];
    var m = C.resonanceMatrices(datas, R);
    for (var i = 0; i < 3; i++) {
      assert(m.wrs[i][i] === 1 && m.prs[i][i] === 1, 'diagonal');
      for (var j = 0; j < 3; j++) {
        assert(approx(m.wrs[i][j], m.wrs[j][i]), 'wr symmetry');
        assert(approx(m.prs[i][j], m.prs[j][i]), 'pr symmetry');
      }
    }
    assert(m.wrs[0][2] === 0, 'disjoint texts should be 0');
    assert(m.wrs[0][1] > 0, 'overlapping texts should be > 0');
  });

  /* ---------- classical MDS ---------- */

  t('MDS recovers a unit square (pairwise distances preserved)', function () {
    // square: (0,0),(1,0),(1,1),(0,1)
    var pts = [[0, 0], [1, 0], [1, 1], [0, 1]];
    var D = pts.map(function (a) {
      return pts.map(function (b) {
        return Math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]));
      });
    });
    var mds = C.classicalMDS(D);
    // embedded pairwise distances must match D (up to rotation/reflection)
    for (var i = 0; i < 4; i++) {
      for (var j = 0; j < 4; j++) {
        var p = mds.points[i], q = mds.points[j];
        var d = Math.sqrt((p[0] - q[0]) * (p[0] - q[0]) + (p[1] - q[1]) * (p[1] - q[1]));
        assert(approx(d, D[i][j], 1e-6), 'd(' + i + ',' + j + ')=' + d + ' vs ' + D[i][j]);
      }
    }
  });

  t('MDS eigenvalues non-negative and ordered', function () {
    var D = [[0, 1, 2], [1, 0, 1], [2, 1, 0]];
    var mds = C.classicalMDS(D);
    assert(mds.eigenvalues[0] >= mds.eigenvalues[1] && mds.eigenvalues[1] >= 0,
      'eigs: ' + mds.eigenvalues.join(','));
  });

  /* ---------- report ---------- */

  t('report: membership, silhouettes, both matrices, MDS coords, citation, JSON', function () {
    var datas = [
      mk({ x: 0.5, y: 0.2 }, [['x', 'y', 1]]),
      mk({ x: 0.4, y: 0.3 }, [['x', 'y', 2]]),
      mk({ x: 0.45, y: 0.25 }, [['x', 'y', 1]]),
      mk({ p: 0.6, q: 0.1 }, [['p', 'q', 1]]),
      mk({ p: 0.5, q: 0.2 }, [['p', 'q', 3]])
    ];
    var names = ['a', 'b', 'c', 'd', 'e'];
    var mats = C.resonanceMatrices(datas, R);
    var cls = C.classify(mats.wrs);
    var D = mats.wrs.map(function (r) { return r.map(function (v) { return 1 - v; }); });
    var md = C.buildReport(names, mats, cls, C.classicalMDS(D), 'CITE-SENTINEL');
    ['Cluster membership', 'Silhouette by K', "Word resonance matrix (WR'",
     "Pair resonance matrix (PR'", 'MDS coordinates', 'CITE-SENTINEL', '```json']
      .forEach(function (sec) {
        assert(md.indexOf(sec) !== -1, 'missing: ' + sec);
      });
    var parsed = JSON.parse(md.match(/```json\s*\n([\s\S]*?)\n```/)[1]);
    assert(parsed.schema === 'crawdad-classification', 'schema tag');
    assert(parsed.labels.length === 5, 'labels in JSON');
    // face validity: xy-texts {a,b,c} together, pq-texts {d,e} together
    var L = parsed.labels;
    assert(L[0] === L[1] && L[1] === L[2] && L[3] === L[4] && L[0] !== L[3],
      'clusters wrong: ' + L.join(','));
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'M5 classifier tests: ' + passed + '/' + results.length + ' passed';

  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadClassifierTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
