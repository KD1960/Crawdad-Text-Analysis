/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M1 — VADER sentiment (Hutto & Gilbert, 2014, ICWSM-14).
 * In-house port of the reference implementation (vaderSentiment 3.3.2,
 * MIT license), validated against it output-for-output on the bundled
 * fixture (tests/test-vader.js): rounded compound (4 dp) and pos/neu/neg
 * (3 dp) must match the Python reference exactly.
 *
 * Deliberate deviation, documented per Build Spec V2 §2.6: the reference's
 * emoji-to-description translation step is omitted (its emoji lexicon adds
 * ~100 KB for content absent from research prose). Inputs containing emoji
 * are scored with the emoji characters treated as ordinary tokens. The
 * oracle fixture is emoji-free.
 *
 * Quirk-faithful notes: the reference's "but"-clause reweighting locates
 * each sentiment by VALUE (Python list.index), not position — duplicate
 * values resolve to the first occurrence. That behavior is reproduced
 * exactly, since fidelity to the published implementation outranks tidiness.
 */
(function (root) {
  'use strict';

  var LEXICON = (typeof module !== 'undefined' && module.exports)
    ? require('../vendor/vader-lexicon.js')
    : root.VADER_LEXICON;
  if (!LEXICON) { throw new Error('vendor/vader-lexicon.js must be loaded before js/vader.js'); }

  var B_INCR = 0.293, B_DECR = -0.293, C_INCR = 0.733, N_SCALAR = -0.74;

  var NEGATE = ["aint", "arent", "cannot", "cant", "couldnt", "darent", "didnt", "doesnt",
    "ain't", "aren't", "can't", "couldn't", "daren't", "didn't", "doesn't",
    "dont", "hadnt", "hasnt", "havent", "isnt", "mightnt", "mustnt", "neither",
    "don't", "hadn't", "hasn't", "haven't", "isn't", "mightn't", "mustn't",
    "neednt", "needn't", "never", "none", "nope", "nor", "not", "nothing", "nowhere",
    "oughtnt", "shant", "shouldnt", "uhuh", "wasnt", "werent",
    "oughtn't", "shan't", "shouldn't", "uh-uh", "wasn't", "weren't",
    "without", "wont", "wouldnt", "won't", "wouldn't", "rarely", "seldom", "despite"];
  var NEGATE_SET = Object.create(null);
  NEGATE.forEach(function (w) { NEGATE_SET[w] = true; });

  var BOOSTER_DICT = Object.create(null);
  (function () {
    var incr = ["absolutely", "amazingly", "awfully", "completely", "considerable",
      "considerably", "decidedly", "deeply", "effing", "enormous", "enormously",
      "entirely", "especially", "exceptional", "exceptionally", "extreme", "extremely",
      "fabulously", "flipping", "flippin", "frackin", "fracking", "fricking", "frickin",
      "frigging", "friggin", "fully", "fuckin", "fucking", "fuggin", "fugging",
      "greatly", "hella", "highly", "hugely", "incredible", "incredibly", "intensely",
      "major", "majorly", "more", "most", "particularly", "purely", "quite", "really",
      "remarkably", "so", "substantially", "thoroughly", "total", "totally",
      "tremendous", "tremendously", "uber", "unbelievably", "unusually", "utter",
      "utterly", "very"];
    var decr = ["almost", "barely", "hardly", "just enough", "kind of", "kinda",
      "kindof", "kind-of", "less", "little", "marginal", "marginally", "occasional",
      "occasionally", "partly", "scarce", "scarcely", "slight", "slightly", "somewhat",
      "sort of", "sorta", "sortof", "sort-of"];
    incr.forEach(function (w) { BOOSTER_DICT[w] = B_INCR; });
    decr.forEach(function (w) { BOOSTER_DICT[w] = B_DECR; });
  })();

  var SPECIAL_CASES = Object.create(null);
  SPECIAL_CASES["the shit"] = 3; SPECIAL_CASES["the bomb"] = 3;
  SPECIAL_CASES["bad ass"] = 1.5; SPECIAL_CASES["badass"] = 1.5;
  SPECIAL_CASES["bus stop"] = 0.0; SPECIAL_CASES["yeah right"] = -2;
  SPECIAL_CASES["kiss of death"] = -1.5; SPECIAL_CASES["to die for"] = 3;
  SPECIAL_CASES["beating heart"] = 3.5;

  var PUNCT = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";

  function stripPunc(token) {
    var start = 0, end = token.length;
    while (start < end && PUNCT.indexOf(token[start]) !== -1) { start++; }
    while (end > start && PUNCT.indexOf(token[end - 1]) !== -1) { end--; }
    var stripped = token.slice(start, end);
    if (stripped.length <= 2) { return token; } // likely an emoticon
    return stripped;
  }

  function wordsAndEmoticons(text) {
    return text.split(/\s+/).filter(function (t) { return t.length > 0; }).map(stripPunc);
  }

  /** Python str.isupper: >=1 cased char, all cased chars uppercase. */
  function isUpper(s) {
    var hasCased = false;
    for (var i = 0; i < s.length; i++) {
      var c = s[i], lo = c.toLowerCase(), up = c.toUpperCase();
      if (lo !== up) { // cased character
        hasCased = true;
        if (c !== up) { return false; }
      }
    }
    return hasCased;
  }

  function allcapDifferential(words) {
    var allcap = 0;
    for (var i = 0; i < words.length; i++) { if (isUpper(words[i])) { allcap++; } }
    var diff = words.length - allcap;
    return diff > 0 && diff < words.length;
  }

  function negated(wordsLower) {
    for (var i = 0; i < wordsLower.length; i++) {
      if (NEGATE_SET[wordsLower[i]]) { return true; }
      if (wordsLower[i].indexOf("n't") !== -1) { return true; }
    }
    return false;
  }

  function normalizeScore(score) {
    var norm = score / Math.sqrt(score * score + 15);
    if (norm < -1) { return -1; }
    if (norm > 1) { return 1; }
    return norm;
  }

  function scalarIncDec(word, valence, isCapDiff) {
    var scalar = 0.0;
    var wl = word.toLowerCase();
    if (wl in BOOSTER_DICT) {
      scalar = BOOSTER_DICT[wl];
      if (valence < 0) { scalar *= -1; }
      if (isUpper(word) && isCapDiff) {
        scalar += (valence > 0) ? C_INCR : -C_INCR;
      }
    }
    return scalar;
  }

  function negationCheck(valence, wae, startI, i) {
    var lower = wae.map(function (w) { return w.toLowerCase(); });
    if (startI === 0) {
      if (negated([lower[i - 1]])) { valence *= N_SCALAR; }
    }
    if (startI === 1) {
      if (lower[i - 2] === "never" && (lower[i - 1] === "so" || lower[i - 1] === "this")) {
        valence *= 1.25;
      } else if (lower[i - 2] === "without" && lower[i - 1] === "doubt") {
        // no change
      } else if (negated([lower[i - 2]])) {
        valence *= N_SCALAR;
      }
    }
    if (startI === 2) {
      if ((lower[i - 3] === "never" &&
           (lower[i - 2] === "so" || lower[i - 2] === "this")) ||
          (lower[i - 1] === "so" || lower[i - 1] === "this")) {
        valence *= 1.25;
      } else if (lower[i - 3] === "without" &&
                 (lower[i - 2] === "doubt" || lower[i - 1] === "doubt")) {
        // no change
      } else if (negated([lower[i - 3]])) {
        valence *= N_SCALAR;
      }
    }
    return valence;
  }

  function specialIdiomsCheck(valence, wae, i) {
    var lower = wae.map(function (w) { return w.toLowerCase(); });
    var onezero = lower[i - 1] + " " + lower[i];
    var twoonezero = lower[i - 2] + " " + lower[i - 1] + " " + lower[i];
    var twoone = lower[i - 2] + " " + lower[i - 1];
    var threetwoone = lower[i - 3] + " " + lower[i - 2] + " " + lower[i - 1];
    var threetwo = lower[i - 3] + " " + lower[i - 2];
    var sequences = [onezero, twoonezero, twoone, threetwoone, threetwo];
    for (var s = 0; s < sequences.length; s++) {
      if (sequences[s] in SPECIAL_CASES) { valence = SPECIAL_CASES[sequences[s]]; break; }
    }
    if (lower.length - 1 > i) {
      var zeroone = lower[i] + " " + lower[i + 1];
      if (zeroone in SPECIAL_CASES) { valence = SPECIAL_CASES[zeroone]; }
    }
    if (lower.length - 1 > i + 1) {
      var zeroonetwo = lower[i] + " " + lower[i + 1] + " " + lower[i + 2];
      if (zeroonetwo in SPECIAL_CASES) { valence = SPECIAL_CASES[zeroonetwo]; }
    }
    var nGrams = [threetwoone, threetwo, twoone];
    for (var g = 0; g < nGrams.length; g++) {
      if (nGrams[g] in BOOSTER_DICT) { valence += BOOSTER_DICT[nGrams[g]]; }
    }
    return valence;
  }

  function leastCheck(valence, wae, i) {
    if (i > 1 && !(wae[i - 1].toLowerCase() in LEXICON) &&
        wae[i - 1].toLowerCase() === "least") {
      if (wae[i - 2].toLowerCase() !== "at" && wae[i - 2].toLowerCase() !== "very") {
        valence *= N_SCALAR;
      }
    } else if (i > 0 && !(wae[i - 1].toLowerCase() in LEXICON) &&
               wae[i - 1].toLowerCase() === "least") {
      valence *= N_SCALAR;
    }
    return valence;
  }

  function sentimentValence(valence, wae, isCapDiff, item, i, sentiments) {
    var itemLower = item.toLowerCase();
    if (itemLower in LEXICON) {
      valence = LEXICON[itemLower];
      // "no" as negation for an adjacent lexicon item vs. stand-alone "no"
      if (itemLower === "no" && i !== wae.length - 1 &&
          (wae[i + 1].toLowerCase() in LEXICON)) {
        valence = 0.0;
      }
      if ((i > 0 && wae[i - 1].toLowerCase() === "no") ||
          (i > 1 && wae[i - 2].toLowerCase() === "no") ||
          (i > 2 && wae[i - 3].toLowerCase() === "no" &&
           (wae[i - 1].toLowerCase() === "or" || wae[i - 1].toLowerCase() === "nor"))) {
        valence = LEXICON[itemLower] * N_SCALAR;
      }
      if (isUpper(item) && isCapDiff) {
        valence += (valence > 0) ? C_INCR : -C_INCR;
      }
      for (var startI = 0; startI < 3; startI++) {
        if (i > startI && !(wae[i - (startI + 1)].toLowerCase() in LEXICON)) {
          var s = scalarIncDec(wae[i - (startI + 1)], valence, isCapDiff);
          if (startI === 1 && s !== 0) { s = s * 0.95; }
          if (startI === 2 && s !== 0) { s = s * 0.9; }
          valence = valence + s;
          valence = negationCheck(valence, wae, startI, i);
          if (startI === 2) { valence = specialIdiomsCheck(valence, wae, i); }
        }
      }
      valence = leastCheck(valence, wae, i);
    }
    sentiments.push(valence);
    return sentiments;
  }

  /** Quirk-faithful port of the reference _but_check (value-based index). */
  function butCheck(wae, sentiments) {
    var lower = wae.map(function (w) { return w.toLowerCase(); });
    var bi = lower.indexOf('but');
    if (bi !== -1) {
      for (var it = 0; it < sentiments.length; it++) {
        var sentiment = sentiments[it];
        var si = sentiments.indexOf(sentiment); // first occurrence, as in Python
        if (si < bi) {
          sentiments.splice(si, 1);
          sentiments.splice(si, 0, sentiment * 0.5);
        } else if (si > bi) {
          sentiments.splice(si, 1);
          sentiments.splice(si, 0, sentiment * 1.5);
        }
      }
    }
    return sentiments;
  }

  function amplifyEp(text) {
    var count = (text.match(/!/g) || []).length;
    if (count > 4) { count = 4; }
    return count * 0.292;
  }

  function amplifyQm(text) {
    var count = (text.match(/\?/g) || []).length;
    if (count > 1) { return count <= 3 ? count * 0.18 : 0.96; }
    return 0;
  }

  /** Python round(): banker's rounding (round-half-to-even). */
  function pyRound(x, nd) {
    var m = Math.pow(10, nd);
    var v = x * m;
    var f = Math.floor(v), diff = v - f;
    var r;
    if (Math.abs(diff - 0.5) < 1e-9) { r = (f % 2 === 0) ? f : f + 1; }
    else { r = Math.round(v); }
    return r / m;
  }

  function scoreValence(sentiments, text) {
    var compound = 0, pos = 0, neg = 0, neu = 0;
    if (sentiments.length) {
      var sumS = sentiments.reduce(function (a, b) { return a + b; }, 0);
      var punct = amplifyEp(text) + amplifyQm(text);
      if (sumS > 0) { sumS += punct; }
      else if (sumS < 0) { sumS -= punct; }
      compound = normalizeScore(sumS);
      var posSum = 0, negSum = 0, neuCount = 0;
      sentiments.forEach(function (s) {
        if (s > 0) { posSum += s + 1; }
        if (s < 0) { negSum += s - 1; }
        if (s === 0) { neuCount += 1; }
      });
      if (posSum > Math.abs(negSum)) { posSum += punct; }
      else if (posSum < Math.abs(negSum)) { negSum -= punct; }
      var total = posSum + Math.abs(negSum) + neuCount;
      pos = Math.abs(posSum / total);
      neg = Math.abs(negSum / total);
      neu = Math.abs(neuCount / total);
    }
    return {
      neg: pyRound(neg, 3), neu: pyRound(neu, 3),
      pos: pyRound(pos, 3), compound: pyRound(compound, 4)
    };
  }

  /** polarity scores for one text (sentence). Reference semantics, no emoji step. */
  function polarityScores(text) {
    text = String(text).trim();
    var wae = wordsAndEmoticons(text);
    var isCapDiff = allcapDifferential(wae);
    var sentiments = [];
    for (var i = 0; i < wae.length; i++) {
      var item = wae[i];
      if (item.toLowerCase() in BOOSTER_DICT) { sentiments.push(0); continue; }
      if (i < wae.length - 1 && item.toLowerCase() === "kind" &&
          wae[i + 1].toLowerCase() === "of") { sentiments.push(0); continue; }
      sentiments = sentimentValence(0, wae, isCapDiff, item, i, sentiments);
    }
    sentiments = butCheck(wae, sentiments);
    return scoreValence(sentiments, text);
  }

  /**
   * Document-level metric for textmetrics (D-12 pattern): mean per-sentence
   * compound, plus shares of sentences at the conventional ±0.05 cut
   * (Hutto & Gilbert, 2014).
   */
  function documentSentiment(sentences) {
    var comps = [];
    sentences.forEach(function (s) {
      if (s.text && s.text.trim()) { comps.push(polarityScores(s.text).compound); }
    });
    if (!comps.length) { return null; }
    var mean = comps.reduce(function (a, b) { return a + b; }, 0) / comps.length;
    var posN = comps.filter(function (c) { return c >= 0.05; }).length;
    var negN = comps.filter(function (c) { return c <= -0.05; }).length;
    var r4 = function (x) { return Math.round(x * 1e4) / 1e4; };
    return {
      meanCompound: r4(mean),
      posShare: r4(posN / comps.length),
      negShare: r4(negN / comps.length)
    };
  }

  var api = { polarityScores: polarityScores, documentSentiment: documentSentiment };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadVader = api; }
})(typeof self !== 'undefined' ? self : this);
