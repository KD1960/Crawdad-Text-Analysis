/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M4 tests — Topic Modeler + concept communities + backbone
 * (Build Spec V2 §5, §11).
 * Node:    NODE_PATH=... node tests/test-topics.js
 * Browser: open tests/test-topics.html
 * Oracles: sklearn NMF (init nndsvd via exact SVD, solver mu, tol 1e-6,
 *          max_iter 500) + gensim u_mass — fixture-nmf.json;
 *          leidenalg + igraph weighted modularity — fixture-leiden.json;
 *          hand-worked disparity-filter α (Serrano et al., 2009).
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var T = isNode ? require('../js/topics.js') : root.CrawdadTopics;
  var CM = isNode ? require('../js/communities.js') : root.CrawdadCommunities;
  var TH = isNode ? require('../js/themes.js') : root.CrawdadThemes;
  var VZ = isNode ? require('../js/visualizer.js') : root.CrawdadVisualizer;
  var FIX_NMF = isNode ? require('./fixture-nmf.json') : root.CrawdadFixture_nmf;
  var FIX_LEI = isNode ? require('./fixture-leiden.json') : root.CrawdadFixture_leiden;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function close(a, b, tol, m) {
    if (Math.abs(a - b) > tol) { throw new Error((m || '') + ' |' + a + ' - ' + b + '| > ' + tol); }
  }
  function maxAbsDiff(A, B) {
    var m = 0;
    for (var i = 0; i < A.length; i++) {
      for (var j = 0; j < A[i].length; j++) {
        m = Math.max(m, Math.abs(A[i][j] - B[i][j]));
      }
    }
    return m;
  }

  /* ---------------- NMF vs sklearn ---------------- */

  t('NNDSVD matches the exact-SVD reference (sklearn port) at 1e-9', function () {
    var init = T.nndsvd(FIX_NMF.X, FIX_NMF.k, { jacobiEig: TH.jacobiEig });
    assert(maxAbsDiff(init.W, FIX_NMF.refW0) < 1e-9, 'W0 diff ' + maxAbsDiff(init.W, FIX_NMF.refW0));
    assert(maxAbsDiff(init.H, FIX_NMF.refH0) < 1e-9, 'H0 diff ' + maxAbsDiff(init.H, FIX_NMF.refH0));
  });

  t('MU-NMF matches sklearn (solver=mu, tol=1e-6, max_iter=500) at 1e-6', function () {
    var fit = T.nmfMu(FIX_NMF.X, FIX_NMF.refW0, FIX_NMF.refH0, { maxIter: 500, tol: 1e-6 });
    assert(fit.nIter === FIX_NMF.refNIter,
      'iteration count ' + fit.nIter + ' vs sklearn ' + FIX_NMF.refNIter);
    assert(maxAbsDiff(fit.W, FIX_NMF.refW) < 1e-6, 'W diff ' + maxAbsDiff(fit.W, FIX_NMF.refW));
    assert(maxAbsDiff(fit.H, FIX_NMF.refH) < 1e-6, 'H diff ' + maxAbsDiff(fit.H, FIX_NMF.refH));
  });

  t('UMass coherence matches gensim (topn=10) at 1e-9', function () {
    var bags = FIX_NMF.X.map(function (row) {
      var b = Object.create(null);
      row.forEach(function (v, j) { if (v > 0) { b[j] = 1; } });
      return b;
    });
    var coh = T.umass(FIX_NMF.tops, bags);
    FIX_NMF.refUmassPerTopic.forEach(function (ref, i) {
      close(coh.perTopic[i], ref, 1e-9, 'topic ' + i);
    });
    close(coh.mean, FIX_NMF.refUmassMean, 1e-9, 'mean');
  });

  t('NMF pipeline is deterministic', function () {
    var a = T.nmfMu(FIX_NMF.X, FIX_NMF.refW0, FIX_NMF.refH0, { maxIter: 100, tol: 1e-6 });
    var b = T.nmfMu(FIX_NMF.X, FIX_NMF.refW0, FIX_NMF.refH0, { maxIter: 100, tol: 1e-6 });
    assert(JSON.stringify(a.W) === JSON.stringify(b.W), 'nondeterminism');
  });

  t('topicModel: √n K rule + coherence table + parameters recorded', function () {
    // synthetic 9 docs, two clean topics via surfaceFrequencies
    var datas = [], names = [];
    for (var i = 0; i < 9; i++) {
      var words = i < 5
        ? [['satellite', 6], ['orbit', 5], ['launch', 4], ['rocket', 3], ['space', 2 + i]]
        : [['bankruptcy', 6], ['creditor', 5], ['debt', 4], ['court', 3], ['filing', 2 + i]];
      words.push(['company', 3]); // shared
      var total = 0;
      words.forEach(function (w) { total += w[1]; });
      datas.push({ surfaceFrequencies: { totalTokens: total, tokens: words } });
      names.push('doc' + i);
    }
    var res = T.topicModel(datas, names, { mode: 'tfidf' },
      { isStopWord: function () { return false; }, jacobiEig: TH.jacobiEig });
    assert(res.k0 === 3, 'K0 = round(sqrt(9)) = 3, got ' + res.k0);
    assert(res.coherenceByK.length >= 2, 'coherence table');
    assert(res.parameters.init === 'nndsvd' && res.parameters.maxIter === 500, 'params');
    assert(res.topics.length === res.k, 'topics count');
    assert(res.loadings.length === 9, 'loadings');
    // at K=2 the two planted vocabularies must separate cleanly, and every
    // document must load dominantly on its own side's topic
    var r2 = T.topicModel(datas, names, { mode: 'tfidf', k: 2 },
      { isStopWord: function () { return false; }, jacobiEig: TH.jacobiEig });
    var joined = r2.topics.map(function (tp) {
      return tp.words.map(function (w) { return w.word; }).join(' ');
    });
    var pureBank = joined.findIndex(function (s) {
      return /bankruptcy/.test(s) && !/satellite/.test(s);
    });
    assert(pureBank !== -1, 'bankruptcy topic separated: ' + joined.join(' || '));
    var bankTopic = pureBank + 1;
    for (var di = 5; di < 9; di++) {
      assert(r2.loadings[di].dominant === bankTopic,
        'doc' + di + ' should load on the bankruptcy topic');
    }
  });

  t('manual K override recorded; influence mode labeled NOVEL', function () {
    var datas = [], names = [];
    for (var i = 0; i < 8; i++) {
      var nodes = [];
      for (var j = 0; j < 6; j++) {
        nodes.push({ id: j, word: 'w' + ((i % 2) * 6 + j), influence: 0.1 + 0.01 * j });
      }
      // overlap across docs of same parity
      datas.push({ network: { nodes: nodes, edges: [] } });
      names.push('d' + i);
    }
    var res = T.topicModel(datas, names, { mode: 'influence', k: 2 },
      { isStopWord: function () { return false; }, jacobiEig: TH.jacobiEig });
    assert(res.k === 2, 'override respected');
    assert(/MANUAL OVERRIDE/.test(res.parameters.kRule), 'override recorded');
    assert(/NOVEL/.test(res.parameters.variant), 'novel label');
  });

  t('report carries coherence table, topics, loadings, JSON block, citations', function () {
    var datas = [], names = [];
    for (var i = 0; i < 9; i++) {
      datas.push({ surfaceFrequencies: { totalTokens: 20, tokens: [
        ['alpha' + (i % 3), 5], ['beta' + (i % 3), 5], ['gamma', 5], ['delta', 5]] } });
      names.push('doc' + i);
    }
    var res = T.topicModel(datas, names, {},
      { isStopWord: function () { return false; }, jacobiEig: TH.jacobiEig });
    var md = T.serializeReport(res, 'CITE-A\n\nCITE-B\n\nDISC');
    assert(/## Coherence by K/.test(md), 'coherence table');
    assert(/## Topic 1/.test(md), 'topic sections');
    assert(/## Document–topic loadings/.test(md), 'loadings');
    assert(/"crawdad-topics"/.test(md), 'machine block');
    assert(/Lee & Seung, 1999/.test(md) && /Boutsidis/.test(md) &&
      /Mimno/.test(md), 'method citations');
    assert(/CITE-A/.test(md) && /DISC/.test(md), 'citation footer');
  });

  /* ---------------- Leiden communities ---------------- */

  t('Leiden: identical partition to leidenalg on the unambiguous two-triangles graph', function () {
    var f = FIX_LEI.filter(function (c) { return c.name === 'twotri'; })[0];
    var edges = f.edges.map(function (e) { return { source: e[0], target: e[1], weight: e[2] }; });
    var r = CM.leiden(f.n, edges, {});
    assert(JSON.stringify(r.membership) === JSON.stringify(f.leidenalgCanon),
      'membership ' + JSON.stringify(r.membership) + ' vs ' + JSON.stringify(f.leidenalgCanon));
  });

  t('Leiden: deterministic regression + modularity matches igraph recompute (1e-9)', function () {
    FIX_LEI.forEach(function (f) {
      var edges = f.edges.map(function (e) { return { source: e[0], target: e[1], weight: e[2] }; });
      var r = CM.leiden(f.n, edges, {});
      assert(JSON.stringify(r.membership) === JSON.stringify(f.expectedMembership),
        f.name + ': partition regression');
      close(CM.modularity(f.n, edges, r.membership), f.igraphQofOurs, 1e-9,
        f.name + ': modularity vs igraph');
    });
  });

  t('Leiden: modularity within 0.015 of leidenalg on real CRA networks', function () {
    FIX_LEI.forEach(function (f) {
      var edges = f.edges.map(function (e) { return { source: e[0], target: e[1], weight: e[2] }; });
      var r = CM.leiden(f.n, edges, {});
      var q = CM.modularity(f.n, edges, r.membership);
      assert(q >= f.leidenalgQ - 0.015,
        f.name + ': Q ' + q + ' vs leidenalg ' + f.leidenalgQ);
    });
  });

  t('communitiesBlock: labels, sizes, membership length, influence ordering', function () {
    var nodes = [
      { id: 0, word: 'king', display: 'king', influence: 0.5 },
      { id: 1, word: 'castl', display: 'castle', influence: 0.3 },
      { id: 2, word: 'moat', display: 'moat', influence: 0.1 },
      { id: 3, word: 'ship', display: 'ship', influence: 0.4 },
      { id: 4, word: 'sea', display: 'sea', influence: 0.2 },
      { id: 5, word: 'sail', display: 'sail', influence: 0.1 }
    ];
    var edges = [[0, 1], [1, 2], [0, 2], [3, 4], [4, 5], [3, 5], [2, 3]]
      .map(function (p) { return { source: p[0], target: p[1], weight: 1 }; });
    var blk = CM.communitiesBlock(nodes, edges, {});
    assert(blk.count === 2, '2 communities');
    assert(blk.membership.length === 6, 'membership length');
    assert(blk.communities[0].label === 'king', 'top community labeled by top word');
    assert(blk.communities[0].members[0].influence >= blk.communities[0].members[1].influence,
      'members by influence');
    assert(typeof blk.modularity === 'number' && blk.modularity > 0, 'modularity');
    assert(blk.parameters.order === 'ascending node id', 'order recorded');
  });

  /* ---------------- disparity filter ---------------- */

  t('disparity α hand-worked (Serrano et al., 2009)', function () {
    // node with k=3, s=10; edge w=8: α = (1 - 0.8)^2 = 0.04 (significant at .05)
    close(CM.disparityAlpha(8, 10, 3), 0.04, 1e-12, 'alpha');
    // edge w=1: α = (1 - 0.1)^2 = 0.81 (not significant)
    close(CM.disparityAlpha(1, 10, 3), 0.81, 1e-12, 'weak alpha');
    assert(CM.disparityAlpha(5, 5, 1) === 0, 'k=1 edges kept by convention');
  });

  t('disparityFilter keeps an edge significant for EITHER endpoint', function () {
    // hub 0 with one dominant edge (0-1 w=8) and two weak (w=1);
    // node 1 has k=1 -> α=0 -> everything at node 1 kept anyway;
    // check a weak edge dies: 0-2 w=1 with node 2 also weak multi-edge
    var edges = [
      { source: 0, target: 1, weight: 8 },
      { source: 0, target: 2, weight: 1 },
      { source: 0, target: 3, weight: 1 },
      { source: 2, target: 3, weight: 1 }
    ];
    var kept = CM.disparityFilter(4, edges, 0.05);
    assert(kept.some(function (e) { return e.source === 0 && e.target === 1; }),
      'dominant edge kept');
    assert(!kept.some(function (e) { return e.source === 2 && e.target === 3; }),
      'weak-weak edge dropped');
  });

  /* ---------------- visualizer helpers ---------------- */

  t('communityStyles: Okabe–Ito + shape redundancy, size-ranked, >8 grayed', function () {
    var membership = [];
    var shownIds = [];
    for (var c = 0; c < 10; c++) {
      for (var i = 0; i < 10 - c; i++) { membership.push(c); shownIds.push(membership.length - 1); }
    }
    var st = VZ.communityStyles(membership, shownIds, null);
    assert(st.legend.length === 8, 'legend capped at 8');
    assert(st.byCommunity[0].color === VZ.OKABE_ITO[0] &&
      st.byCommunity[0].glyph === VZ.SHAPES[0], 'largest gets first color+shape');
    assert(st.byCommunity[9].glyph === '·', 'ninth+ grayed');
    // color and glyph always paired (redundant encoding)
    st.legend.forEach(function (lg, r) {
      assert(lg.color === VZ.OKABE_ITO[r] && lg.glyph === VZ.SHAPES[r], 'pairing');
    });
  });

  /* ---------------- schema integration ---------------- */

  var S = isNode ? require('../js/craschema.js') : root.CrawdadSchema;

  t('communities block serializes, round-trips, and is validated', function () {
    var d = S.newCraData('cm.txt', null, '2.0.0-M4 (built 2026-08-11)');
    d.network.nodes = [
      { id: 0, word: 'king', display: 'king', degree: 1, influence: 0.5 },
      { id: 1, word: 'castl', display: 'castle', degree: 1, influence: 0.2 }
    ];
    d.network.edges = [{ source: 0, target: 1, weight: 2 }];
    d.summary = { nodeCount: 2, edgeCount: 1 };
    d.communities = CM.communitiesBlock(d.network.nodes, d.network.edges, {});
    var md = S.serializeCra(d);
    assert(/## Concept communities/.test(md), 'section present');
    assert(/Traag, Waltman/.test(md), 'method citation');
    var back = S.parseCra(md);
    assert(back.ok, 'round-trip: ' + back.errors.join('; '));
    assert(back.data.communities.membership.length === 2, 'membership survives');
    // malformed: membership length mismatch must fail validation
    var bad = JSON.parse(JSON.stringify(d));
    bad.communities.membership = [0];
    assert(!S.validateCra(bad).ok, 'length mismatch rejected');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M4 topics/communities/backbone tests: ' + passed + '/' +
    results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadTopicsTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
