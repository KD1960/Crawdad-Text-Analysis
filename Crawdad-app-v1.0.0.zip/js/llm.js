/*
 * Crawdad 2026 — M7: optional LLM features (spec §10; decided 2026-07-09)
 *
 * Principles:
 *  - The CRA pipeline NEVER depends on an LLM. Everything here is opt-in.
 *  - API key lives in memory for the session only: never persisted, never
 *    sent anywhere except the model provider.
 *  - Every output is labeled LLM-generated and non-deterministic.
 *  - L-4 prompts include ONLY Crawdad's computed tables — no raw text —
 *    so summaries stay grounded in the CRA results.
 *
 * Transport is injectable (configure({ fetchFn })) so tests run without
 * a key or network.
 */
(function (root) {
  'use strict';

  var cfg = {
    apiKey: null,
    model: 'claude-sonnet-5',
    fetchFn: null // defaults to global fetch at call time
  };

  function configure(opts) {
    if (!opts) { return; }
    if (opts.apiKey !== undefined) { cfg.apiKey = opts.apiKey || null; }
    if (opts.model) { cfg.model = opts.model; }
    if (opts.fetchFn !== undefined) { cfg.fetchFn = opts.fetchFn; }
  }

  function isEnabled() { return !!cfg.apiKey; }

  /** Core call. Resolves the model's text. Rejects with a clear error if no key. */
  function callModel(system, user, maxTokens) {
    if (!cfg.apiKey) {
      return Promise.reject(new Error(
        'No API key set. LLM features are optional — add a key under LLM settings to enable them.'));
    }
    var f = cfg.fetchFn || (typeof fetch !== 'undefined' ? fetch : null);
    if (!f) { return Promise.reject(new Error('fetch unavailable.')); }
    return f('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': cfg.apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: cfg.model,
        max_tokens: maxTokens || 1024,
        system: system,
        messages: [{ role: 'user', content: user }]
      })
    }).then(function (r) {
      if (!r.ok) {
        return r.text().then(function (t) {
          throw new Error('API error ' + r.status + ': ' + t.slice(0, 300));
        });
      }
      return r.json();
    }).then(function (j) {
      if (!j.content || !j.content[0] || typeof j.content[0].text !== 'string') {
        throw new Error('Unexpected API response shape.');
      }
      return j.content[0].text;
    });
  }

  var DISCLAIMER = '[LLM-generated; non-deterministic — verify before use]';

  /* ---------- L-3: theme / cluster labeling ---------- */

  /** items: [{ name: 'Theme 1', words: ['a','b',...] }, ...] -> Promise<[{name,label}]> */
  function suggestLabels(items) {
    var lines = items.map(function (it) {
      return it.name + ': ' + it.words.join(', ');
    }).join('\n');
    var system = 'You label themes from a Centering Resonance Analysis. ' +
      'Given defining words for each theme, return STRICT JSON only: an array of objects ' +
      '{"name": "<theme name as given>", "label": "<2-4 word label>"}. No other text.';
    return callModel(system, lines, 500).then(function (text) {
      var m = text.match(/\[[\s\S]*\]/);
      if (!m) { throw new Error('Model did not return JSON.'); }
      return JSON.parse(m[0]);
    });
  }

  /* ---------- L-4: narrative summary of computed tables ---------- */

  /**
   * reportMarkdown: a Crawdad report. The JSON data block and everything
   * after it are STRIPPED so the prompt contains only the computed tables.
   */
  function tablesOnly(reportMarkdown) {
    return reportMarkdown.split('## Data (machine-readable')[0];
  }

  function narrativeSummary(reportMarkdown) {
    var tables = tablesOnly(reportMarkdown);
    var system = 'You summarize results of a Centering Resonance Analysis (Corman, Kuhn, ' +
      'McPhee, & Dooley, 2002) for a researcher. Use ONLY the numbers and words in the ' +
      'provided tables; do not speculate beyond them. Two short paragraphs, plain prose, ' +
      'no bullet points.';
    return callModel(system, tables, 800).then(function (text) {
      return DISCLAIMER + '\n\n' + text;
    });
  }

  /* ---------- L-1 / L-2: text preparation ---------- */

  var PREP_CHAR_LIMIT = 60000;

  function prepText(rawText, doClean, doPronouns) {
    if (!doClean && !doPronouns) {
      return Promise.reject(new Error('Select at least one preparation step.'));
    }
    if (rawText.length > PREP_CHAR_LIMIT) {
      return Promise.reject(new Error('Text too long for LLM preparation (' +
        rawText.length + ' chars; limit ' + PREP_CHAR_LIMIT + '). ' +
        'Deterministic cleaning still applies at Generate time.'));
    }
    var tasks = [];
    if (doClean) {
      tasks.push('remove running headers/footers, page numbers, citation fragments, ' +
        'table/figure captions, and other non-prose boilerplate');
    }
    if (doPronouns) {
      tasks.push('replace pronouns with their referent nouns where the referent is ' +
        'unambiguous (JHC 2002, p. 175); leave ambiguous pronouns unchanged');
    }
    var system = 'You prepare text for Centering Resonance Analysis. Apply exactly these ' +
      'operations: ' + tasks.join('; ') + '. Preserve all prose sentences and their ' +
      'wording otherwise. Return ONLY the prepared text, no commentary.';
    return callModel(system, rawText, 8000);
  }

  var api = {
    configure: configure,
    isEnabled: isEnabled,
    callModel: callModel,
    suggestLabels: suggestLabels,
    narrativeSummary: narrativeSummary,
    tablesOnly: tablesOnly,
    prepText: prepText,
    DISCLAIMER: DISCLAIMER,
    PREP_CHAR_LIMIT: PREP_CHAR_LIMIT
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadLLM = api; }
})(typeof self !== 'undefined' ? self : this);
