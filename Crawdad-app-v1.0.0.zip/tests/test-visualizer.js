/*
 * Crawdad 2026 — M3 validation.
 * Node:    node tests/test-visualizer.js     (pure logic: top-K, threshold, styles)
 * Browser: open tests/test-visualizer.html   (adds render + 1920x1080 export check)
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var V = isNode ? require('../js/visualizer.js') : root.CrawdadVisualizer;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }

  function mkNodes(n) {
    var out = [];
    for (var i = 0; i < n; i++) {
      out.push({ id: i, word: 'w' + i, display: 'w' + i, degree: i,
                 influence: (n - i) / (n * 10) }); // descending influence
    }
    return out;
  }

  t('selectTopK returns exactly K nodes, highest influence first', function () {
    var nodes = mkNodes(50);
    var top = V.selectTopK(nodes, 30);
    assert(top.length === 30, 'got ' + top.length);
    assert(top[0].influence >= top[29].influence, 'not sorted');
    assert(top[0].id === 0, 'wrong top node');
  });

  t('selectTopK with K larger than node count returns all', function () {
    assert(V.selectTopK(mkNodes(10), 30).length === 10);
  });

  t('selectTopK tie-break is deterministic (degree, then word)', function () {
    var nodes = [
      { id: 0, word: 'b', degree: 1, influence: 0.5 },
      { id: 1, word: 'a', degree: 1, influence: 0.5 },
      { id: 2, word: 'c', degree: 9, influence: 0.5 }
    ];
    var top = V.selectTopK(nodes, 2);
    assert(top[0].id === 2, 'highest degree first among ties');
    assert(top[1].word === 'a', 'alphabetical second');
  });

  t('edgesAmong keeps only edges with BOTH endpoints displayed', function () {
    var edges = [
      { source: 0, target: 1, weight: 1 },
      { source: 1, target: 5, weight: 2 },
      { source: 5, target: 6, weight: 3 }
    ];
    var kept = V.edgesAmong([0, 1, 2], edges);
    assert(kept.length === 1 && kept[0].source === 0, 'wrong edges kept');
  });

  t('boxClass: top word red, > threshold yellow, others plain (WF 4e)', function () {
    assert(V.boxClass(0.30, 0.30, 0.05) === 'top');
    assert(V.boxClass(0.10, 0.30, 0.05) === 'high');
    assert(V.boxClass(0.05, 0.30, 0.05) === 'plain', 'threshold is strict >');
    assert(V.boxClass(0.01, 0.30, 0.05) === 'plain');
  });

  t('boxClass: no red/yellow when nothing exceeds threshold', function () {
    assert(V.boxClass(0.03, 0.03, 0.05) === 'plain');
  });

  t('fontScale monotone and bounded', function () {
    var lo = V.fontScale(0, 0.3), mid = V.fontScale(0.1, 0.3), hi = V.fontScale(0.3, 0.3);
    assert(lo >= 12 && hi <= 26 && lo < mid && mid < hi, lo + '/' + mid + '/' + hi);
  });

  t('edgeStyle: weight 1 light/thin, max weight dark/thick', function () {
    var lo = V.edgeStyle(1, 10), hi = V.edgeStyle(10, 10);
    assert(hi.width > lo.width, 'width not increasing');
    assert(lo.color === 'rgb(200,200,200)', 'min color: ' + lo.color);
    assert(hi.color === 'rgb(30,30,30)', 'max color: ' + hi.color);
  });

  t('default configuration matches spec (K=30, highlight 0.05, 16:9)', function () {
    assert(V.DEFAULTS.topK === 30 && V.DEFAULTS.highlight === 0.05);
    assert(Math.abs(V.DEFAULTS.width / V.DEFAULTS.height - 16 / 9) < 1e-9, 'not 16:9');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'M3 visualizer logic tests: ' + passed + '/' + results.length + ' passed';

  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadVizTestResults = { results: results, summary: summary, t: t, finish: function () {
      var p = results.filter(function (r) { return r.pass; }).length;
      root.CrawdadVizTestResults.summary =
        'M3 visualizer tests (incl. render/export): ' + p + '/' + results.length + ' passed';
    } };
  }
})(typeof self !== 'undefined' ? self : this);
