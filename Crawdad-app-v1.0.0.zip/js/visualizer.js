/*
 * Crawdad 2026 — M3: Visualizer (spec §7.1)
 * Draws the CRA network in the style of the original Crawdad renderings
 * (see "Visualizer examples/"): plain text labels, yellow boxes around
 * words with influence > threshold, red box on the single most influential
 * word, curved gray edges darkened/thickened by F_ij.
 *
 * Layout: d3-force ("spring", WF 4c), pre-run to equilibrium for a stable
 * image, then interactive (drag nodes; hover for exact influence).
 * Export: 1920x1080 PNG (16:9, WF 4f-g) with filename, logo, citation.
 *
 * Pure logic helpers (selectTopK, edgesAmong, boxClass, scales) are
 * exported for Node unit tests; render/export need a browser DOM.
 */
(function (root) {
  'use strict';

  var DEFAULTS = { topK: 30, highlight: 0.05, width: 1600, height: 900 };

  /* ---------------- pure logic (Node-testable) ---------------- */

  /** Top-K nodes by influence, ties broken by degree then word. */
  function selectTopK(nodes, k) {
    return nodes.slice().sort(function (a, b) {
      return (b.influence - a.influence) || (b.degree - a.degree) ||
        (a.word < b.word ? -1 : 1);
    }).slice(0, Math.max(0, k));
  }

  /** Edges whose both endpoints are in the displayed node set. */
  function edgesAmong(nodeIds, edges) {
    var set = {};
    nodeIds.forEach(function (id) { set[id] = true; });
    return edges.filter(function (e) { return set[e.source] && set[e.target]; });
  }

  /** 'top' (red box) | 'high' (yellow box) | 'plain'. */
  function boxClass(influence, maxInfluence, highlightThreshold) {
    if (influence === maxInfluence && influence > highlightThreshold) { return 'top'; }
    return influence > highlightThreshold ? 'high' : 'plain';
  }

  /** Font px from influence (sqrt scale between bounds). */
  function fontScale(influence, maxInfluence) {
    var lo = 12, hi = 26;
    if (maxInfluence <= 0) { return lo; }
    return lo + (hi - lo) * Math.sqrt(influence / maxInfluence);
  }

  /** Edge stroke width and darkness from weight. */
  function edgeStyle(weight, maxWeight) {
    var w = maxWeight > 1 ? (weight - 1) / (maxWeight - 1) : 0; // 0..1
    return {
      width: 0.6 + 1.8 * w,
      color: 'rgb(' + Math.round(200 - 170 * w) + ',' +
                      Math.round(200 - 170 * w) + ',' +
                      Math.round(200 - 170 * w) + ')'
    };
  }

  /* ---------------- rendering (browser only) ---------------- */

  /**
   * Render into containerEl. Returns a handle { svgNode, exportPng(cb), stop() }.
   * craData: parsed _cra.md data object. opts: { topK, highlight }.
   */
  function render(containerEl, craData, opts) {
    var d3 = root.d3;
    if (!d3) { throw new Error('d3 not loaded (vendor/d3.min.js).'); }
    opts = opts || {};
    var W = DEFAULTS.width, H = DEFAULTS.height;
    var topK = opts.topK || DEFAULTS.topK;
    var highlight = (opts.highlight !== undefined) ? opts.highlight : DEFAULTS.highlight;

    var shown = selectTopK(craData.network.nodes, topK);
    var ids = shown.map(function (n) { return n.id; });
    var links = edgesAmong(ids, craData.network.edges).map(function (e) {
      return { source: e.source, target: e.target, weight: e.weight };
    });
    var maxI = shown.length ? shown[0].influence : 0;
    var maxW = links.reduce(function (m, e) { return Math.max(m, e.weight); }, 1);

    var nodes = shown.map(function (n) {
      return { id: n.id, word: n.display || n.word, influence: n.influence,
               degree: n.degree, cls: boxClass(n.influence, maxI, highlight),
               font: fontScale(n.influence, maxI) };
    });

    containerEl.innerHTML = '';
    var svg = d3.select(containerEl).append('svg')
      .attr('viewBox', '0 0 ' + W + ' ' + H)
      .attr('width', '100%')
      .style('background', '#ffffff')
      .style('border', '1px solid #d7dde2');

    // --- layout: pre-run force simulation to equilibrium ---
    var sim = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(function (d) { return d.id; })
        .distance(function (l) { return 120 - Math.min(l.weight, 6) * 8; })
        .strength(0.4))
      .force('charge', d3.forceManyBody().strength(-320))
      .force('center', d3.forceCenter(W / 2, H / 2 - 20))
      .force('collide', d3.forceCollide().radius(function (d) {
        return d.word.length * d.font * 0.32 + 12;
      }))
      .force('x', d3.forceX(W / 2).strength(0.06))
      .force('y', d3.forceY(H / 2).strength(0.12)) // slight horizontal spread (16:9)
      .stop();
    for (var i = 0; i < 300; i++) { sim.tick(); }
    clamp();

    function clamp() {
      nodes.forEach(function (d) {
        d.x = Math.max(70, Math.min(W - 70, d.x));
        d.y = Math.max(50, Math.min(H - 70, d.y));
      });
    }

    // --- edges: curved paths (reference style) ---
    var edgeG = svg.append('g');
    function edgePath(l) {
      var dx = l.target.x - l.source.x, dy = l.target.y - l.source.y;
      var dr = Math.sqrt(dx * dx + dy * dy) * 2.2;
      return 'M' + l.source.x + ',' + l.source.y +
             'A' + dr + ',' + dr + ' 0 0,1 ' + l.target.x + ',' + l.target.y;
    }
    var paths = edgeG.selectAll('path').data(links).enter().append('path')
      .attr('fill', 'none')
      .attr('stroke', function (l) { return edgeStyle(l.weight, maxW).color; })
      .attr('stroke-width', function (l) { return edgeStyle(l.weight, maxW).width; })
      .attr('d', edgePath);

    // --- nodes: text labels with optional boxes ---
    var nodeG = svg.append('g');
    var gs = nodeG.selectAll('g').data(nodes).enter().append('g')
      .attr('transform', function (d) { return 'translate(' + d.x + ',' + d.y + ')'; })
      .style('cursor', 'grab');

    gs.append('title').text(function (d) {
      return d.word + '\ninfluence: ' + d.influence.toFixed(5) + '\ndegree: ' + d.degree;
    });

    var texts = gs.append('text')
      .text(function (d) { return d.word; })
      .attr('text-anchor', 'middle')
      .attr('dy', '0.34em')
      .attr('font-family', 'Georgia, "Times New Roman", serif')
      .attr('font-size', function (d) { return d.font; })
      .attr('paint-order', 'stroke')
      .attr('stroke', '#ffffff')
      .attr('stroke-width', 4)
      .attr('fill', '#111111');

    // boxes sized to text bbox
    gs.each(function (d) {
      var g = d3.select(this);
      var bb = g.select('text').node().getBBox();
      if (d.cls !== 'plain') {
        g.insert('rect', 'text')
          .attr('x', bb.x - 5).attr('y', bb.y - 3)
          .attr('width', bb.width + 10).attr('height', bb.height + 6)
          .attr('fill', '#ffffff')
          .attr('stroke', d.cls === 'top' ? '#cc2200' : '#e6c400')
          .attr('stroke-width', d.cls === 'top' ? 2.5 : 2);
      } else {
        g.insert('rect', 'text')
          .attr('x', bb.x - 3).attr('y', bb.y - 2)
          .attr('width', bb.width + 6).attr('height', bb.height + 4)
          .attr('fill', '#ffffff').attr('fill-opacity', 0.75).attr('stroke', 'none');
      }
    });

    // --- chrome: title, logo, citation ---
    svg.append('text')
      .attr('x', 24).attr('y', 34)
      .attr('font-family', 'Georgia, serif').attr('font-size', 22).attr('fill', '#1f2a33')
      .text('CRA network — ' + craData.source.filename +
        '   (top ' + nodes.length + ' words; highlight > ' + highlight + ')');
    svg.append('image')
      .attr('href', root.CRAWDAD_LOGO_DATA_URI)
      .attr('x', W - 262).attr('y', 10).attr('width', 238).attr('height', 49);
    svg.append('text')
      .attr('x', W / 2).attr('y', H - 12)
      .attr('text-anchor', 'middle')
      .attr('font-family', 'Georgia, serif').attr('font-size', 11).attr('fill', '#5c6b78')
      .text('Please cite: Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002). Studying complex discursive systems: ' +
            'Centering Resonance Analysis of organizational communication. Human Communication Research, 28(2), 157-206.');

    // --- interactivity: drag ---
    gs.call(d3.drag()
      .on('drag', function (event, d) {
        d.x = Math.max(70, Math.min(W - 70, event.x));
        d.y = Math.max(50, Math.min(H - 70, event.y));
        d3.select(this).attr('transform', 'translate(' + d.x + ',' + d.y + ')');
        paths.attr('d', edgePath);
      }));

    /** Export current view as 1920x1080 PNG (spec WF 4f-g). */
    function exportPng(cb) {
      var xml = new XMLSerializer().serializeToString(svg.node());
      var svgBlob = new Blob([xml], { type: 'image/svg+xml;charset=utf-8' });
      var url = URL.createObjectURL(svgBlob);
      var img = new Image();
      img.onload = function () {
        var canvas = document.createElement('canvas');
        canvas.width = 1920; canvas.height = 1080;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 1920, 1080);
        ctx.drawImage(img, 0, 0, 1920, 1080);
        URL.revokeObjectURL(url);
        canvas.toBlob(function (blob) { cb(null, blob, canvas); }, 'image/png');
      };
      img.onerror = function () { URL.revokeObjectURL(url); cb(new Error('SVG rasterization failed')); };
      img.src = url;
    }

    return { svgNode: svg.node(), exportPng: exportPng, shownCount: nodes.length };
  }

  var api = {
    DEFAULTS: DEFAULTS,
    selectTopK: selectTopK,
    edgesAmong: edgesAmong,
    boxClass: boxClass,
    fontScale: fontScale,
    edgeStyle: edgeStyle,
    render: render
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadVisualizer = api; }
})(typeof self !== 'undefined' ? self : this);
