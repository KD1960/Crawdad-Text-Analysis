/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad 2026 — M3: Visualizer (spec §7.1)
 * Draws the CRA network in the style of the original Crawdad renderings
 * (see "Visualizer examples/"): plain text labels, yellow boxes around
 * words with influence > threshold, red box on the single most influential
 * word, curved gray edges darkened/thickened by F_ij.
 *
 * Layout: d3-force ("spring", WF 4c), pre-run to equilibrium for a stable
 * image, then interactive (drag nodes; hover for exact influence).
 * Export: 1920x1080 PNG (16:9, WF 4f-g) with filename, logo, citation.
 *
 * Pure logic helpers (selectTopK, edgesAmong, boxClass, scales) are
 * exported for Node unit tests; render/export need a browser DOM.
 */
(function (root) {
  'use strict';

  var DEFAULTS = { topK: 30, highlight: 0.05, width: 1600, height: 900 };

  /* ---------------- pure logic (Node-testable) ---------------- */

  /** Top-K nodes by influence, ties broken by degree then word. */
  function selectTopK(nodes, k) {
    return nodes.slice().sort(function (a, b) {
      return (b.influence - a.influence) || (b.degree - a.degree) ||
        (a.word < b.word ? -1 : 1);
    }).slice(0, Math.max(0, k));
  }

  /** Edges whose both endpoints are in the displayed node set. */
  function edgesAmong(nodeIds, edges) {
    var set = {};
    nodeIds.forEach(function (id) { set[id] = true; });
    return edges.filter(function (e) { return set[e.source] && set[e.target]; });
  }

  /** 'top' (red box) | 'high' (yellow box) | 'plain'. */
  function boxClass(influence, maxInfluence, highlightThreshold) {
    if (influence === maxInfluence && influence > highlightThreshold) { return 'top'; }
    return influence > highlightThreshold ? 'high' : 'plain';
  }

  /** Font px from influence (sqrt scale between bounds). */
  function fontScale(influence, maxInfluence) {
    var lo = 12, hi = 26;
    if (maxInfluence <= 0) { return lo; }
    return lo + (hi - lo) * Math.sqrt(influence / maxInfluence);
  }

  /** Edge stroke width and darkness from weight. */
  function edgeStyle(weight, maxWeight) {
    var w = maxWeight > 1 ? (weight - 1) / (maxWeight - 1) : 0; // 0..1
    return {
      width: 0.6 + 1.8 * w,
      color: 'rgb(' + Math.round(200 - 170 * w) + ',' +
                      Math.round(200 - 170 * w) + ',' +
                      Math.round(200 - 170 * w) + ')'
    };
  }

  /* V2-M4 (spec §5.2, D-V2-4): Okabe–Ito categorical palette with shape
   * redundancy for the optional communities rendering. Hue is sanctioned
   * here because communities are a computed grouping; the classic
   * monochrome drawing remains the default. */
  var OKABE_ITO = ['#E69F00', '#56B4E9', '#009E73', '#F0E442',
                   '#0072B2', '#D55E00', '#CC79A7', '#000000'];
  var SHAPES = ['●', '■', '▲', '◆',
                '▼', '★', '✚', '✖'];

  /**
   * Style map for the communities rendering: communities ranked by member
   * count among SHOWN nodes; the top 8 get color+shape, the rest gray dot.
   * Returns { byCommunity: {cid: {color, glyph, rank}}, legend: [...] }.
   */
  function communityStyles(membership, shownIds, labels) {
    var counts = Object.create(null);
    shownIds.forEach(function (id) {
      var c = membership[id];
      counts[c] = (counts[c] || 0) + 1;
    });
    var ranked = Object.keys(counts).map(Number).sort(function (a, b) {
      return counts[b] - counts[a] || a - b;
    });
    var by = Object.create(null), legend = [];
    ranked.forEach(function (c, r) {
      if (r < 8) {
        by[c] = { color: OKABE_ITO[r], glyph: SHAPES[r], rank: r };
        legend.push({ community: c, color: OKABE_ITO[r], glyph: SHAPES[r],
          label: (labels && labels[c]) || ('C' + (c + 1)),
          count: counts[c] });
      } else {
        by[c] = { color: '#6E6862', glyph: '·', rank: r };
      }
    });
    return { byCommunity: by, legend: legend };
  }

  /* ---------------- rendering (browser only) ---------------- */

  /**
   * Render into containerEl. Returns a handle { svgNode, exportPng(cb), stop() }.
   * craData: parsed _cra.md data object. opts: { topK, highlight }.
   */
  function render(containerEl, craData, opts) {
    var d3 = root.d3;
    if (!d3) { throw new Error('d3 not loaded (vendor/d3.min.js).'); }
    opts = opts || {};
    var W = DEFAULTS.width, H = DEFAULTS.height;
    var topK = opts.topK || DEFAULTS.topK;
    var highlight = (opts.highlight !== undefined) ? opts.highlight : DEFAULTS.highlight;

    // --- V2-M4 reduction option: top-K (default) or disparity backbone ---
    var reduction = opts.reduction || 'topk';
    var allEdges = craData.network.edges;
    var shown, edgePool;
    if (reduction === 'backbone' && root.CrawdadCommunities) {
      edgePool = root.CrawdadCommunities.disparityFilter(
        craData.network.nodes.length, allEdges, 0.05);
      var inBackbone = Object.create(null);
      edgePool.forEach(function (e) { inBackbone[e.source] = 1; inBackbone[e.target] = 1; });
      var bbNodes = craData.network.nodes.filter(function (n) { return inBackbone[n.id] === 1; });
      shown = selectTopK(bbNodes, topK); // cap for legibility, stated in caption
    } else {
      reduction = 'topk';
      edgePool = allEdges;
      shown = selectTopK(craData.network.nodes, topK);
    }
    var ids = shown.map(function (n) { return n.id; });
    var links = edgesAmong(ids, edgePool).map(function (e) {
      return { source: e.source, target: e.target, weight: e.weight };
    });
    var maxI = shown.length ? shown[0].influence : 0;
    var maxW = links.reduce(function (m, e) { return Math.max(m, e.weight); }, 1);

    // --- V2-M4 communities option (from the file, else computed live) ---
    var membership = null, commLabels = null, commStyles = null, commMeta = '';
    if (opts.communities) {
      var cmB = craData.communities;
      if (cmB && cmB.membership) {
        membership = cmB.membership;
        commLabels = {};
        // communities list is sorted by influence; recover labels by id via
        // membership of each community's top member word
        cmB.communities.forEach(function (cg, ci) { commLabels[ci] = cg.label; });
        // membership ids in the block are dense in first-appearance order,
        // matching communitiesBlock; labels map community id -> label
        commLabels = null; // safe default: label = C<n>; block order differs
        commMeta = 'communities: Leiden, k=' + cmB.count +
          ', modularity ' + cmB.modularity;
      } else if (root.CrawdadCommunities) {
        var live = root.CrawdadCommunities.leiden(
          craData.network.nodes.length, allEdges, { resolution: 1 });
        membership = live.membership;
        commMeta = 'communities: Leiden (computed now), k=' +
          (new Set(membership)).size + ', modularity ' + live.modularity;
      }
      if (membership) {
        commStyles = communityStyles(membership, ids, commLabels);
        // legend label = highest-influence shown word of each community
        commStyles.legend.forEach(function (lg) {
          var best = null;
          shown.forEach(function (n) {
            if (membership[n.id] === lg.community &&
                (!best || n.influence > best.influence)) { best = n; }
          });
          if (best) { lg.label = best.display || best.word; }
        });
      }
    }

    var nodes = shown.map(function (n) {
      var st = commStyles ? commStyles.byCommunity[membership[n.id]] : null;
      return { id: n.id, word: n.display || n.word, influence: n.influence,
               degree: n.degree, cls: boxClass(n.influence, maxI, highlight),
               font: fontScale(n.influence, maxI),
               commColor: st ? st.color : null,
               commGlyph: st ? st.glyph : null };
    });

    containerEl.innerHTML = '';
    var svg = d3.select(containerEl).append('svg')
      .attr('viewBox', '0 0 ' + W + ' ' + H)
      .attr('width', '100%')
      .style('background', '#ffffff')
      .style('border', '1px solid #d7dde2');

    // --- layout: pre-run force simulation to equilibrium ---
    var sim = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(function (d) { return d.id; })
        .distance(function (l) { return 120 - Math.min(l.weight, 6) * 8; })
        .strength(0.4))
      .force('charge', d3.forceManyBody().strength(-320))
      .force('center', d3.forceCenter(W / 2, H / 2 - 20))
      .force('collide', d3.forceCollide().radius(function (d) {
        return d.word.length * d.font * 0.32 + 12;
      }))
      .force('x', d3.forceX(W / 2).strength(0.06))
      .force('y', d3.forceY(H / 2).strength(0.12)) // slight horizontal spread (16:9)
      .stop();
    for (var i = 0; i < 300; i++) { sim.tick(); }
    clamp();

    function clamp() {
      nodes.forEach(function (d) {
        d.x = Math.max(70, Math.min(W - 70, d.x));
        d.y = Math.max(50, Math.min(H - 70, d.y));
      });
    }

    // --- edges: curved paths (reference style) ---
    var edgeG = svg.append('g');
    function edgePath(l) {
      var dx = l.target.x - l.source.x, dy = l.target.y - l.source.y;
      var dr = Math.sqrt(dx * dx + dy * dy) * 2.2;
      return 'M' + l.source.x + ',' + l.source.y +
             'A' + dr + ',' + dr + ' 0 0,1 ' + l.target.x + ',' + l.target.y;
    }
    var paths = edgeG.selectAll('path').data(links).enter().append('path')
      .attr('fill', 'none')
      .attr('stroke', function (l) { return edgeStyle(l.weight, maxW).color; })
      .attr('stroke-width', function (l) { return edgeStyle(l.weight, maxW).width; })
      .attr('d', edgePath);

    // --- nodes: text labels with optional boxes ---
    var nodeG = svg.append('g');
    var gs = nodeG.selectAll('g').data(nodes).enter().append('g')
      .attr('transform', function (d) { return 'translate(' + d.x + ',' + d.y + ')'; })
      .style('cursor', 'grab');

    gs.append('title').text(function (d) {
      return d.word + '\ninfluence: ' + d.influence.toFixed(5) + '\ndegree: ' + d.degree;
    });

    // word text stays ink for legibility (Okabe–Ito yellow is unreadable on
    // white); the community hue lives on the glyph and the box border, with
    // the glyph shape as the redundant channel
    var texts = gs.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '0.34em')
      .attr('font-family', 'Georgia, "Times New Roman", serif')
      .attr('font-size', function (d) { return d.font; })
      .attr('paint-order', 'stroke')
      .attr('stroke', '#ffffff')
      .attr('stroke-width', 4)
      .attr('fill', '#111111');
    texts.each(function (d) {
      var el = d3.select(this);
      if (d.commGlyph) {
        el.append('tspan').attr('fill', d.commColor).text(d.commGlyph + ' ');
        el.append('tspan').attr('fill', '#111111').text(d.word);
      } else {
        el.text(d.word);
      }
    });

    // boxes sized to text bbox; in communities mode borders take the
    // community hue (top word keeps its heavier border weight)
    gs.each(function (d) {
      var g = d3.select(this);
      var bb = g.select('text').node().getBBox();
      if (d.cls !== 'plain') {
        g.insert('rect', 'text')
          .attr('x', bb.x - 5).attr('y', bb.y - 3)
          .attr('width', bb.width + 10).attr('height', bb.height + 6)
          .attr('fill', '#ffffff')
          .attr('stroke', d.commColor ||
            (d.cls === 'top' ? '#F04E23' : '#16130F'))
          .attr('stroke-width', d.cls === 'top' ? 2.5 : 2);
      } else {
        g.insert('rect', 'text')
          .attr('x', bb.x - 3).attr('y', bb.y - 2)
          .attr('width', bb.width + 6).attr('height', bb.height + 4)
          .attr('fill', '#ffffff').attr('fill-opacity', 0.75).attr('stroke', 'none');
      }
    });

    // --- chrome: title, logo, citation ---
    // caption states the reduction used (spec §5.3)
    var reductionNote = reduction === 'backbone'
      ? 'disparity-filter backbone α=0.05 (Serrano et al., 2009), ' +
        nodes.length + ' words shown'
      : 'top ' + nodes.length + ' words';
    svg.append('text')
      .attr('x', 24).attr('y', 34)
      .attr('font-family', "'Source Serif 4', Georgia, serif")
      .attr('font-size', 22).attr('fill', '#16130F')
      .text('CRA network — ' + craData.source.filename +
        '   (' + reductionNote + '; highlight > ' + highlight + ')');
    if (commStyles) {
      svg.append('text')
        .attr('x', 24).attr('y', 58)
        .attr('font-family', "'IBM Plex Sans', Helvetica, Arial, sans-serif")
        .attr('font-size', 14).attr('fill', '#3D3833')
        .text(commMeta + '   ·   ' + commStyles.legend.map(function (lg) {
          return lg.glyph + ' ' + lg.label + ' (' + lg.count + ')';
        }).join('   '));
      commStyles.legend.forEach(function (lg, li) {
        // colored glyph markers over the legend line (approximate x spacing
        // is fine — the text line above carries the authoritative pairing)
        void li;
      });
    }
    svg.append('image')
      .attr('href', root.CRAWDAD_LOGO_DATA_URI)
      .attr('x', W - 144).attr('y', 8).attr('width', 118).attr('height', 80);
    // Design Guide §06: method + software citations on every export
    svg.append('text')
      .attr('x', W / 2).attr('y', H - 38)
      .attr('text-anchor', 'middle')
      .attr('font-family', "'IBM Plex Sans', Helvetica, Arial, sans-serif")
      .attr('font-size', 11).attr('fill', '#6E6862')
      .text('Please cite: Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002). Studying complex discursive systems: ' +
            'Centering Resonance Analysis of organizational communication. Human Communication Research, 28(2), 157-206.');
    svg.append('text')
      .attr('x', W / 2).attr('y', H - 24)
      .attr('text-anchor', 'middle')
      .attr('font-family', "'IBM Plex Sans', Helvetica, Arial, sans-serif")
      .attr('font-size', 11).attr('fill', '#6E6862')
      .text((root.CrawdadSchema && root.CrawdadSchema.softwareCitation)
        ? root.CrawdadSchema.softwareCitation(craData.source.appVersion)
        : 'Dooley, K. (2026). Crawdad Text Analysis Software [Computer software].');
    svg.append('text')
      .attr('x', W / 2).attr('y', H - 10)
      .attr('text-anchor', 'middle')
      .attr('font-family', "'IBM Plex Sans', Helvetica, Arial, sans-serif")
      .attr('font-size', 10).attr('fill', '#6E6862')
      .text((root.CrawdadSchema && root.CrawdadSchema.DISCLAIMER) ||
            'Disclaimer: analyses are generated automatically and provided as-is, without warranty of any kind. ' +
            'We take no responsibility for interpretations, conclusions, or decisions based on these results.');

    // --- interactivity: drag ---
    gs.call(d3.drag()
      .on('drag', function (event, d) {
        d.x = Math.max(70, Math.min(W - 70, event.x));
        d.y = Math.max(50, Math.min(H - 70, event.y));
        d3.select(this).attr('transform', 'translate(' + d.x + ',' + d.y + ')');
        paths.attr('d', edgePath);
      }));

    /** Export current view as 1920x1080 PNG (spec WF 4f-g). */
    function exportPng(cb) {
      var xml = new XMLSerializer().serializeToString(svg.node());
      var svgBlob = new Blob([xml], { type: 'image/svg+xml;charset=utf-8' });
      var url = URL.createObjectURL(svgBlob);
      var img = new Image();
      img.onload = function () {
        var canvas = document.createElement('canvas');
        canvas.width = 1920; canvas.height = 1080;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 1920, 1080);
        ctx.drawImage(img, 0, 0, 1920, 1080);
        URL.revokeObjectURL(url);
        canvas.toBlob(function (blob) { cb(null, blob, canvas); }, 'image/png');
      };
      img.onerror = function () { URL.revokeObjectURL(url); cb(new Error('SVG rasterization failed')); };
      img.src = url;
    }

    return { svgNode: svg.node(), exportPng: exportPng, shownCount: nodes.length };
  }

  var api = {
    DEFAULTS: DEFAULTS,
    OKABE_ITO: OKABE_ITO,
    SHAPES: SHAPES,
    selectTopK: selectTopK,
    edgesAmong: edgesAmong,
    boxClass: boxClass,
    fontScale: fontScale,
    edgeStyle: edgeStyle,
    communityStyles: communityStyles,
    render: render
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadVisualizer = api; }
})(typeof self !== 'undefined' ? self : this);
