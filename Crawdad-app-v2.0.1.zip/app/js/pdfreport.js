/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M1.1 — readable PDF export of a _cra.md (D-V2-15; Kevin's
 * queue item 1, 2026-08-11): the human sections only, machine JSON block
 * excluded by construction (the PDF is built from craData fields, never
 * from the serialized markdown).
 *
 * Split for testability:
 *   buildModel(craData)  — pure; returns the ordered section model.
 *   render(model, deps)  — jsPDF + autotable rendering, Design Guide v1.0:
 *     Letter, 25 mm margins; title block with the document's ONE heavy ink
 *     rule; settings in a panel-filled, orange-left-bordered mono block;
 *     tables with horizontal rules only, headers on panel fill; both
 *     citations + disclaimer at the end; sans page footer.
 *   Fonts degrade cleanly per the guide (§05): jsPDF core fonts stand in —
 *   times (serif body), helvetica (UI/captions), courier (data/settings).
 *
 * Vendored: vendor/jspdf.umd.min.js (jsPDF 4.2.1, MIT),
 *           vendor/jspdf.plugin.autotable.min.js (5.0.8, MIT).
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var SCHEMA = isNode ? require('./craschema.js') : root.CrawdadSchema;

  /* Design Guide tokens (hex without #) */
  var INK = [22, 19, 15], INK2 = [61, 56, 51], MUTED = [110, 104, 98];
  var PANEL = [244, 241, 236], RULE = [231, 226, 218];
  var ORANGE_DEEP = [198, 60, 21];

  function fmt(x, places) { return Number(x).toFixed(places === undefined ? 5 : places); }

  /* ------------------------------------------------------------------ *
   * Model (pure)
   * ------------------------------------------------------------------ */

  function buildModel(data) {
    var I = SCHEMA.INTERPRET;
    var m = { title: 'CRA Analysis: ' + data.source.filename, sections: [] };
    function sec(s) { m.sections.push(s); }

    m.settingsLines = [
      'processed ' + (data.source.processedAt || 'unknown') +
        ' · app ' + (data.source.appVersion || 'unknown'),
      'stemming=' + data.parameters.stemming +
        ' · pronouns=' + (data.parameters.pronouns ? 'retained' : 'dropped') +
        ' · inter-sentence=' + (data.parameters.interSentenceLinking ? 'on' : 'off (JHC 2002)'),
      'tokenization file=' + (data.parameters.tokenizationFile || 'none') +
        (data.parameters.excludeWords && data.parameters.excludeWords.length
          ? ' · exclude=' + data.parameters.excludeWords.join(',') : ' · exclude=(none)')
    ];

    if (data.cleaningNotes && data.cleaningNotes.length) {
      sec({ kind: 'bullets', heading: 'Text cleaning',
        intro: 'Applied before parsing (deterministic; citations and reference lists are ' +
               'removed so author names and years do not become network nodes):',
        items: data.cleaningNotes.slice() });
    }

    var s = data.summary || {}, c = s.centralization || {};
    var rows = [
      ['Nodes', String(data.network.nodes.length)],
      ['Edges', String(data.network.edges.length)]
    ];
    ['degree', 'betweenness', 'closeness', 'eigenvector'].forEach(function (k) {
      var cap = k.charAt(0).toUpperCase() + k.slice(1);
      var note = (k === 'closeness' && s.closenessNote) ? s.closenessNote : '';
      rows.push([cap + ' centralization',
        (c[k] === undefined || c[k] === null ? 'n/a' : fmt(c[k])) + note]);
    });
    if (s.meanInfluence !== undefined) { rows.push(['Mean influence', fmt(s.meanInfluence)]); }
    if (s.componentCount !== undefined) {
      rows.push(['Network fragmentation', s.componentCount + ' component(s); largest holds ' +
        fmt(s.largestComponentShare, 3) + ' of nodes']);
    }
    sec({ kind: 'table', heading: 'Network summary',
      head: ['Measure', 'Value'], rows: rows,
      after: SCHEMA.interpretSummary(s) });

    var tm = data.textMetrics;
    if (tm) {
      var tr = [];
      function row(label, value, interp, method) { tr.push([label, value, interp, method]); }
      if (tm.sentiment !== null && tm.sentiment !== undefined) {
        row('Sentiment (-1..+1; mean/sentence)', String(tm.sentiment),
          I.sentiment(tm.sentiment), 'AFINN-165 (Nielsen, 2011)');
      }
      if (tm.vader) {
        row('VADER sentiment (mean compound)', tm.vader.meanCompound +
          ' (pos ' + tm.vader.posShare + ' / neg ' + tm.vader.negShare + ')',
          I.vader(tm.vader), 'Hutto & Gilbert (2014)');
      }
      if (tm.genderedLanguage) {
        row('Gendered language index', tm.genderedLanguage.index +
          ' (M ' + tm.genderedLanguage.masculinePer1000 + '/1k, F ' +
          tm.genderedLanguage.femininePer1000 + '/1k)',
          I.gendered(tm.genderedLanguage), 'Gaucher et al. (2011) stems');
      }
      if (tm.abstractness !== null && tm.abstractness !== undefined) {
        row('Abstractness (0..1)', String(tm.abstractness),
          I.abstractness(tm.abstractness), 'HEURISTIC (suffixes)');
      }
      if (tm.agreeableness) {
        row('Agreeableness index', String(tm.agreeableness.index),
          I.agreeableness(tm.agreeableness), 'HEURISTIC markers');
      }
      if (tm.lexicalDiversity) {
        row('Lexical diversity MTLD', tm.lexicalDiversity.mtld +
          ' (TTR ' + tm.lexicalDiversity.ttr + ')',
          I.mtld(tm.lexicalDiversity.mtld), 'McCarthy & Jarvis (2010)');
      }
      if (tm.diversity2) {
        if (tm.diversity2.mattr !== null) {
          row('MATTR (window ' + tm.diversity2.mattrWindow + ')', String(tm.diversity2.mattr),
            I.mattr(tm.diversity2.mattr), 'Covington & McFall (2010)');
        }
        if (tm.diversity2.hdd !== null) {
          row('HD-D (42-token sample)', String(tm.diversity2.hdd),
            I.hdd(tm.diversity2.hdd), 'McCarthy & Jarvis (2010)');
        }
        if (tm.diversity2.mtldMaWrap !== null) {
          row('MTLD-MA (wrap)', String(tm.diversity2.mtldMaWrap),
            I.mtld(tm.diversity2.mtldMaWrap), 'McCarthy & Jarvis (2010)');
        }
      }
      if (tm.lexicalDensity !== null && tm.lexicalDensity !== undefined) {
        row('Lexical density', String(tm.lexicalDensity),
          I.density(tm.lexicalDensity), 'Ure (1971)');
      }
      if (tm.readability) {
        row('Flesch Reading Ease', tm.readability.fleschReadingEase +
          ' (FK grade ' + tm.readability.fleschKincaidGrade + ')',
          I.fre(tm.readability.fleschReadingEase), 'Kincaid et al. (1975)');
      }
      if (tm.cohesion) {
        row('Cohesion: adjacent noun overlap', tm.cohesion.adjacentNounOverlap +
          ' (global ' + tm.cohesion.globalNounOverlap + ')',
          I.cohesion(tm.cohesion.adjacentNounOverlap), 'Coh-Metrix style');
      }
      if (tm.hedging) {
        row('Certainty index', String(tm.hedging.certaintyIndex),
          I.certainty(tm.hedging.certaintyIndex), 'Hyland (2005)');
      }
      if (tm.pronounRates) {
        row('Pronouns /1k (I/we/you/3rd)', tm.pronounRates.firstSingularPer1000 + ' / ' +
          tm.pronounRates.firstPluralPer1000 + ' / ' + tm.pronounRates.secondPer1000 +
          ' / ' + tm.pronounRates.thirdPer1000,
          I.pronouns(tm.pronounRates), 'pre-drop counts');
      }
      if (tm.wordLength) {
        row('Word length (mean; share ≥7)', tm.wordLength.meanChars + '; ' +
          tm.wordLength.longWordShare, I.wordLength(tm.wordLength), 'proxy');
      }
      if (tm.passiveRate !== null && tm.passiveRate !== undefined) {
        row('Passive voice (share)', String(tm.passiveRate),
          I.passive(tm.passiveRate), 'HEURISTIC');
      }
      if (tm.formality !== null && tm.formality !== undefined) {
        row('Formality F-score', String(tm.formality),
          I.formality(tm.formality), 'Heylighen & Dewaele (1999)');
      }
      if (tm.infoTheory) {
        var it = tm.infoTheory;
        row('Unigram entropy (bits/token)', String(it.entropyBitsPerToken),
          'comparative: higher = less predictable', 'Shannon');
        if (it.zipfSlope !== null) {
          row('Zipf slope', String(it.zipfSlope), I.zipf(it.zipfSlope), 'rank-frequency fit');
        }
        if (it.heapsExponent !== null) {
          row('Heaps exponent', String(it.heapsExponent), I.heaps(it.heapsExponent), 'type growth fit');
        }
        if (it.compression) {
          row('Compression ratio', String(it.compression.ratio),
            'comparative: lower = more repetitive', it.compression.method);
        }
        if (it.burstiness) {
          row('Burstiness (mean B, top 20)', String(it.burstiness.meanTop20),
            I.burstiness(it.burstiness.meanTop20), 'Goh & Barabási (2008)');
        }
      }
      sec({ kind: 'table', heading: 'Text metrics',
        head: ['Metric', 'Value', 'Interpretation', 'Method'], rows: tr, small: true,
        after: ['Interpretations are descriptive guides, not validated cutpoints; ' +
          'comparisons across texts processed with identical settings are more ' +
          'defensible than absolute readings. Metrics marked HEURISTIC use ' +
          'unvalidated word lists.'] });
    }

    if (data.lexiconsUsed && data.lexiconsUsed.length) {
      data.lexiconsUsed.forEach(function (lx) {
        var lrows = Object.keys(lx.metrics).map(function (k) {
          var v = lx.metrics[k];
          return [k, lx.type === 'scored'
            ? (v.mean === null ? '—' : 'mean ' + v.mean) : v.per1000 + ' /1k', String(v.n)];
        });
        sec({ kind: 'table',
          heading: 'Custom dictionary: ' + lx.name,
          intro: lx.type + ', ' + lx.entryCount + ' entries, matching=' + lx.mode +
            ', coverage ' + fmt(lx.coverage * 100, 1) + '% of tokens' +
            (lx.lowCoverage ? ' — WARNING: coverage below 60%; treat results as exploratory' : '') +
            ' · sha256 ' + lx.sha256.slice(0, 16) + '…',
          introWarn: !!lx.lowCoverage,
          head: ['Measure', 'Value', 'N matched'], rows: lrows });
      });
    }

    var byId = Object.create(null);
    data.network.nodes.forEach(function (n) { byId[n.id] = n; });
    var nbrs = Object.create(null);
    data.network.nodes.forEach(function (n) { nbrs[n.id] = []; });
    data.network.edges.forEach(function (e) {
      nbrs[e.source].push(byId[e.target].display || byId[e.target].word);
      nbrs[e.target].push(byId[e.source].display || byId[e.source].word);
    });
    // V2-M2: PageRank + strength columns when the data carries them
    var hasNodeStats = data.network.nodes.length > 0 &&
      data.network.nodes[0].pageRank !== undefined &&
      data.network.nodes[0].strength !== undefined;
    var ciMap = data.inference && data.inference.influenceCI
      ? data.inference.influenceCI.ci : null;
    var infRows = data.network.nodes
      .filter(function (n) { return n.influence > SCHEMA.DISPLAY_THRESHOLD; })
      .sort(function (a, b) { return b.influence - a.influence; })
      .map(function (n) {
        var cols = hasNodeStats
          ? [n.display || n.word, String(n.degree), String(n.strength),
             fmt(n.influence), fmt(n.pageRank)]
          : [n.display || n.word, String(n.degree), fmt(n.influence)];
        if (ciMap) {
          var ci = ciMap[n.word];
          cols.push(ci ? '[' + fmt(ci[0], 3) + ', ' + fmt(ci[1], 3) + ']' : '—');
        }
        cols.push(nbrs[n.id].sort().join(', '));
        return cols;
      });
    var infHead = hasNodeStats
      ? ['Word', 'Degree', 'Strength', 'Influence', 'PageRank']
      : ['Word', 'Degree', 'Influence'];
    if (ciMap) { infHead.push('95% CI'); }
    infHead.push('Connected to');
    sec({ kind: 'table',
      heading: 'Influential words (influence > ' + SCHEMA.DISPLAY_THRESHOLD + ')',
      intro: ciMap ? ('Influence 95% CI: ' + data.inference.influenceCI.method +
        ', B = ' + data.inference.influenceCI.B + ', seed ' +
        data.inference.influenceCI.seed) : undefined,
      head: infHead,
      rows: infRows, small: true,
      after: hasNodeStats ? ['Influence is CRA’s normalized betweenness; strength ' +
        '(weighted degree; Opsahl et al., 2010) and PageRank (damping 0.85) are ' +
        'frequency-family scores on the same network. Disagreement between the ' +
        'families is itself diagnostic.'] : undefined });

    if (data.tokenSuggestions && data.tokenSuggestions.length) {
      var hasAssoc = data.tokenSuggestions[0].npmi !== undefined;
      sec({ kind: 'table', heading: 'Tokenization suggestions (word–word adjacency)',
        intro: (hasAssoc
          ? 'Candidate multi-word concepts ranked by NPMI (Bouma, 2009; +1 = words ' +
            'only occur together) with log-Dice (Rychlý, 2008; max 14) alongside. '
          : 'Candidate multi-word concepts (frequency-based). ') +
          'The judgment is the analyst’s. To merge one, add a row to a tokenization ' +
          'file and re-run the Generator; replacements must be single tokens.',
        head: hasAssoc
          ? ['Candidate phrase', 'Count', 'NPMI', 'log-Dice', 'Suggested replacement']
          : ['Candidate phrase', 'Count', 'Suggested replacement'],
        rows: data.tokenSuggestions.map(function (sg) {
          return hasAssoc
            ? [sg.phrase, String(sg.count), String(sg.npmi), String(sg.logDice), sg.replacement]
            : [sg.phrase, String(sg.count), sg.replacement];
        }) });
    }

    // V2-M4: concept communities (Leiden, spec §5.2)
    if (data.communities) {
      var cmB = data.communities;
      sec({ kind: 'bullets', heading: 'Concept communities (within-text themes)',
        intro: 'Leiden (Traag et al., 2019), deterministic variant, modularity ' +
          cmB.modularity + ', ' + cmB.count + ' communities. Words that interlink ' +
          'more among themselves than with the rest of the network.',
        items: cmB.communities.map(function (cGrp, ci) {
          var shown = cGrp.members.slice(0, 8).map(function (mm) {
            return mm.word + ' (' + fmt(mm.influence, 3) + ')';
          }).join(', ');
          return 'C' + (ci + 1) + ' “' + cGrp.label + '” (' + cGrp.size +
            ' words): ' + shown + (cGrp.size > 8 ? ' … +' + (cGrp.size - 8) + ' more' : '');
        }) });
    }

    // V2-M2: keyphrases (TextRank + YAKE, spec §3.3)
    if (data.keyphrases) {
      var kpTR = data.keyphrases.textRank, kpY = data.keyphrases.yake;
      if (kpTR && kpTR.phrases && kpTR.phrases.length) {
        sec({ kind: 'table', heading: 'Keyphrases — TextRank',
          intro: 'PageRank on a word co-occurrence graph (nouns + adjectives, ' +
            'window 2; Mihalcea & Tarau, 2004). Higher scores are better. A ' +
            'complement to CRA influence, not a rival: different graph, ' +
            'different centrality.',
          head: ['Phrase', 'Score', 'Count'],
          rows: kpTR.phrases.map(function (p) {
            return [p.phrase, fmt(p.score), String(p.count)];
          }) });
      }
      if (kpY && kpY.phrases && kpY.phrases.length) {
        sec({ kind: 'table', heading: 'Keyphrases — YAKE',
          intro: 'Statistical single-document extraction (Campos et al., 2020); ' +
            'LOWER scores are better. Agreement across TextRank, YAKE, and CRA ' +
            'influence is strong evidence a concept matters.',
          head: ['Phrase', 'Score (lower = better)'],
          rows: kpY.phrases.map(function (p) {
            return [p.phrase, fmt(p.score)];
          }) });
      }
    }

    m.footerCitations = [
      SCHEMA.CITATION,
      SCHEMA.softwareCitation(data.source.appVersion),
      SCHEMA.DISCLAIMER
    ];
    m.pageFooter = data.source.filename + ' · Crawdad ' +
      (data.source.appVersion || '') + ' · readable companion to the _cra.md file ' +
      '(machine-readable data lives there, not here)';
    return m;
  }

  /* ------------------------------------------------------------------ *
   * Render (jsPDF + autotable)
   * ------------------------------------------------------------------ */

  function render(model, deps) {
    var JsPdf = (deps && deps.jsPDF) ||
      (root.jspdf && root.jspdf.jsPDF);
    if (!JsPdf) { throw new Error('jsPDF not loaded (vendor/jspdf.umd.min.js).'); }
    var doc = new JsPdf({ unit: 'mm', format: 'letter' });
    var autoTable = (deps && deps.autoTable) ||
      (root.jspdf && root.jspdf.autoTable) || doc.autoTable;
    var M = 25;                       // Design Guide §06: 25 mm margins
    var W = doc.internal.pageSize.getWidth();
    var maxW = W - 2 * M;
    var y = M;

    function ensure(space) {
      var H = doc.internal.pageSize.getHeight();
      if (y + space > H - M) { doc.addPage(); y = M; }
    }
    function para(text, font, size, color, lead, maxWidth) {
      doc.setFont(font, 'normal'); doc.setFontSize(size);
      doc.setTextColor(color[0], color[1], color[2]);
      var lines = doc.splitTextToSize(text, maxWidth || maxW);
      lines.forEach(function (ln) {
        ensure(lead);
        doc.text(ln, M, y);
        y += lead;
      });
    }
    function heading(text) {
      ensure(14);
      y += 4;
      doc.setFont('times', 'bold'); doc.setFontSize(13);
      doc.setTextColor(INK[0], INK[1], INK[2]);
      doc.text(text, M, y);
      y += 6;
    }

    // ---- title block: the document's one heavy ink rule (§06) ----
    doc.setFont('times', 'bold'); doc.setFontSize(17);
    doc.setTextColor(INK[0], INK[1], INK[2]);
    doc.splitTextToSize(model.title, maxW).forEach(function (ln) {
      doc.text(ln, M, y); y += 8;
    });
    doc.setDrawColor(INK[0], INK[1], INK[2]);
    doc.setLineWidth(0.7);
    doc.line(M, y, W - M, y);
    y += 6;

    // ---- settings block: panel fill, orange-deep left border, mono ----
    // pre-wrap so the panel height matches the actual line count (long
    // metadata bullets used to overlap — caught in the generic-PDF gate)
    doc.setFont('courier', 'normal'); doc.setFontSize(8);
    var wrapped = [];
    model.settingsLines.forEach(function (ln) {
      doc.splitTextToSize(ln, maxW - 8).forEach(function (seg) { wrapped.push(seg); });
    });
    var setH = wrapped.length * 3.8 + 5;
    ensure(setH + 4);
    doc.setFillColor(PANEL[0], PANEL[1], PANEL[2]);
    doc.rect(M, y - 3, maxW, setH, 'F');
    doc.setFillColor(ORANGE_DEEP[0], ORANGE_DEEP[1], ORANGE_DEEP[2]);
    doc.rect(M, y - 3, 1.2, setH, 'F');
    doc.setTextColor(INK2[0], INK2[1], INK2[2]);
    wrapped.forEach(function (seg) {
      doc.text(seg, M + 4, y + 2);
      y += 3.8;
    });
    y += 6;

    // ---- sections ----
    model.sections.forEach(function (s) {
      if (s.heading) { heading(s.heading); }
      if (s.intro) {
        para(s.intro, 'helvetica', 8.5,
          s.introWarn ? ORANGE_DEEP : MUTED, 4);
        y += 1.5;
      }
      if (s.kind === 'bullets') {
        s.items.forEach(function (it) {
          para('–  ' + it, 'times', 9.5, INK2, 4.6);
        });
      } else if (s.kind === 'table') {
        var opts = {
          startY: y,
          margin: { left: M, right: M },
          head: [s.head],
          body: s.rows,
          theme: 'plain',
          styles: {
            font: 'courier', fontSize: s.small ? 7.2 : 8.5,
            textColor: INK2, cellPadding: 1.4,
            lineWidth: { bottom: 0.15 }, lineColor: RULE
          },
          headStyles: {
            font: 'helvetica', fontStyle: 'bold', fontSize: 8,
            textColor: MUTED, fillColor: PANEL,
            lineWidth: { bottom: 0.4 }, lineColor: INK
          }
        };
        if (autoTable && autoTable !== doc.autoTable) { autoTable(doc, opts); }
        else { doc.autoTable(opts); }
        y = doc.lastAutoTable.finalY + 5;
      }
      (s.after || []).forEach(function (p) {
        para(p, 'times', 9.5, INK2, 4.6);
        y += 1.5;
      });
    });

    // ---- citations + disclaimer (Design Guide §06: both, every time) ----
    ensure(30);
    y += 3;
    doc.setDrawColor(RULE[0], RULE[1], RULE[2]);
    doc.setLineWidth(0.2);
    doc.line(M, y, W - M, y);
    y += 5;
    model.footerCitations.forEach(function (ctext) {
      para(ctext, 'helvetica', 7.6, MUTED, 3.6);
      y += 2;
    });

    // ---- page footer on every page ----
    var pages = doc.getNumberOfPages();
    for (var p = 1; p <= pages; p++) {
      doc.setPage(p);
      doc.setFont('helvetica', 'normal'); doc.setFontSize(7);
      doc.setTextColor(MUTED[0], MUTED[1], MUTED[2]);
      var H = doc.internal.pageSize.getHeight();
      doc.text(model.pageFooter, M, H - 12, { maxWidth: maxW - 20 });
      doc.text(String(p) + ' / ' + pages, W - M, H - 12, { align: 'right' });
    }
    return doc;
  }

  /** One-call helper: craData -> jsPDF doc. */
  function reportPdf(craData, deps) {
    return render(buildModel(craData), deps);
  }

  /* ------------------------------------------------------------------ *
   * Generic report markdown -> PDF (V2-M7, Kevin 2026-08-11: every
   * report download in every tool offers .md or .pdf). The machine-
   * readable JSON block is stripped; trailing italic lines become the
   * citation footer; leading "- " metadata bullets fill the settings
   * panel; sections render as tables / bullets / prose with the same
   * Design Guide styling as the Generator PDF.
   * ------------------------------------------------------------------ */

  function stripInline(s) {
    return String(s)
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/⬆|←|&larr;/g, '');
  }

  function markdownToModel(md) {
    var lines = String(md).replace(/\r\n?/g, '\n').split('\n');
    // 1) strip the machine block: from "## Data (machine-readable" through
    //    the closing ``` fence
    var out = [], skipping = false, fences = 0;
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i];
      if (!skipping && /^## Data \(machine-readable/.test(ln)) {
        skipping = true; fences = 0; continue;
      }
      if (skipping) {
        if (/^```/.test(ln)) {
          fences++;
          if (fences === 2) { skipping = false; }
        }
        continue;
      }
      out.push(ln);
    }
    // 2) trailing citation lines (*...*) after the final --- rule
    var footer = [];
    for (i = out.length - 1; i >= 0; i--) {
      var t = out[i].trim();
      if (t === '') { continue; }
      if (/^\*[^*].*\*$/.test(t)) { footer.unshift(stripInline(t)); out.splice(i, 1); continue; }
      if (t === '---') { out.splice(i, 1); break; }
      break;
    }
    var m = { title: 'Crawdad report', settingsLines: [], sections: [],
      footerCitations: footer, pageFooter: '' };
    var cur = null, texts = [];
    function ensureSection() {
      if (!cur) {
        cur = { kind: 'mixed', heading: '', paras: [], tables: [], bullets: [] };
        m.sections.push(cur);
      }
      return cur;
    }
    function flushTexts() {
      if (!texts.length) { return; }
      ensureSection().paras.push(texts.join(' '));
      texts = [];
    }
    function startSection(head) {
      flushTexts();
      cur = { kind: 'mixed', heading: stripInline(head), paras: [], tables: [], bullets: [] };
      m.sections.push(cur);
      return cur;
    }
    var inPreamble = true;
    for (i = 0; i < out.length; i++) {
      var line = out[i];
      var trimmed = line.trim();
      if (/^# /.test(trimmed)) { m.title = stripInline(trimmed.slice(2)); continue; }
      if (/^## /.test(trimmed)) { inPreamble = false; startSection(trimmed.slice(3)); continue; }
      if (trimmed === '') { flushTexts(); continue; }
      if (/^\|/.test(trimmed)) {
        // table block
        flushTexts();
        var rows = [];
        while (i < out.length && /^\|/.test(out[i].trim())) {
          var cells = out[i].trim().replace(/^\||\|$/g, '').split('|')
            .map(function (c) { return stripInline(c.trim()); });
          rows.push(cells);
          i++;
        }
        i--;
        if (rows.length >= 2) {
          var body = rows.slice(1).filter(function (r) {
            return !r.every(function (c) { return /^:?-{2,}:?$/.test(c) || c === ''; });
          });
          var sec2 = ensureSection();
          sec2.tables.push({ head: rows[0], rows: body });
        }
        continue;
      }
      if (/^[-•] /.test(trimmed)) {
        if (inPreamble) { m.settingsLines.push(stripInline(trimmed.slice(2))); }
        else {
          var sec3 = ensureSection();
          sec3.bullets.push(stripInline(trimmed.replace(/^[-•] /, '')));
        }
        continue;
      }
      if (/^> /.test(trimmed)) { texts.push(stripInline(trimmed.slice(2))); continue; }
      texts.push(stripInline(trimmed));
    }
    flushTexts();
    m.pageFooter = m.title + ' · readable companion to the .md report ' +
      '(machine-readable data lives there, not here)';
    if (!m.settingsLines.length) { m.settingsLines = ['(no run metadata recorded)']; }
    return m;
  }

  /** Render a generic report model (mixed sections). */
  function renderMarkdownModel(model, deps) {
    // adapt mixed sections into the section kinds render() understands
    var flat = { title: model.title, settingsLines: model.settingsLines,
      footerCitations: model.footerCitations, pageFooter: model.pageFooter,
      sections: [] };
    model.sections.forEach(function (s) {
      var first = true;
      function headOnce() { var h = first ? s.heading : ''; first = false; return h; }
      if (s.paras.length || s.bullets.length || s.tables.length === 0) {
        flat.sections.push({ kind: 'bullets', heading: headOnce(),
          intro: s.paras.join(' ') || undefined,
          items: s.bullets.length ? s.bullets : [] });
      }
      s.tables.forEach(function (tb) {
        flat.sections.push({ kind: 'table', heading: headOnce(),
          head: tb.head, rows: tb.rows,
          small: tb.head.length > 4 || tb.rows.length > 15 });
      });
    });
    return render(flat, deps);
  }

  /** One-call helper: report markdown -> jsPDF doc (machine block stripped). */
  function reportFromMarkdown(md, deps) {
    return renderMarkdownModel(markdownToModel(md), deps);
  }

  function pdfFileName(outName) { return outName + '.pdf'; } // name_cra.md.pdf per Kevin

  var api = { buildModel: buildModel, render: render, reportPdf: reportPdf,
    markdownToModel: markdownToModel, reportFromMarkdown: reportFromMarkdown,
    pdfFileName: pdfFileName };
  if (isNode) { module.exports = api; }
  else { root.CrawdadPdfReport = api; }
})(typeof self !== 'undefined' ? self : this);
