/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M3 — Keyness module (Build Spec V2 §4).
 *
 * Subcorpus-vs-subcorpus comparison (A vs. B) on the schema-2.0
 * `surfaceFrequencies` block of loaded _cra.md files:
 *
 *   G²        log-likelihood keyness (Dunning, 1993; Rayson & Garside, 2000)
 *   p         asymptotic chi-square (df = 1) via the regularized incomplete
 *             gamma function Q(1/2, G²/2), double-precision series/continued
 *             fraction (oracle: scipy.stats.chi2.sf, 1e-12)
 *   Log Ratio effect size (Hardie, 2014): log2 of the rate ratio; a zero
 *             frequency is replaced by `zeroAdjust` (default 0.5, recorded) —
 *             statistic and effect size are SEPARATED in the output because a
 *             G² threshold alone confounds sample size with importance
 *   %DIFF     (Gabrielatos, 2018) reported alongside; null when the word is
 *             absent from B (direction A) — no arbitrary constant is imputed
 *   DP        Gries's (2008) deviation of proportions within the overusing
 *             group, plus the share of that group's documents containing the
 *             word; docShare < 0.5 raises the warning glyph (a "key" word
 *             driven by one document is a known failure mode)
 *   Zeta      Craig's variant (Burrows, 2007): document-proportion marker
 *             words per side, zeta = P(docs_A contain w) + (1 − P(docs_B
 *             contain w)) ∈ [0, 2]; presence-based, so it surfaces
 *             mid-frequency markers G² misses
 *   Permutation option: documents shuffled between groups (default 999,
 *             seeded mulberry32 PRNG, seed recorded); empirical
 *             p = (hits + 1)/(B + 1) computed for the reported words
 *
 * Honest limitation (stated in every report): surfaceFrequencies stores the
 * top 2,000 surface types per file; a word outside a file's top 2,000 counts
 * as absent there. Negligible for texts under ~10k tokens; regenerate files
 * with 2.0.0-M1+ to include the block at all.
 */
(function (root) {
  'use strict';

  /* ------------------------------------------------------------------ *
   * Numerics
   * ------------------------------------------------------------------ */

  /** ln Γ(x) (Lanczos, double precision). */
  function gammln(x) {
    var cof = [76.18009172947146, -86.50532032941677, 24.01409824083091,
      -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
    var y = x, tmp = x + 5.5;
    tmp -= (x + 0.5) * Math.log(tmp);
    var ser = 1.000000000190015;
    for (var j = 0; j < 6; j++) { ser += cof[j] / ++y; }
    return -tmp + Math.log(2.5066282746310005 * ser / x);
  }

  /** Regularized upper incomplete gamma Q(a, x), series/continued fraction. */
  function gammq(a, x) {
    if (x < 0 || a <= 0) { return NaN; }
    if (x === 0) { return 1; }
    var EPS = 1e-16, ITMAX = 500, i;
    if (x < a + 1) {
      // series for P(a,x), return 1 - P
      var ap = a, sum = 1 / a, del = sum;
      for (i = 0; i < ITMAX; i++) {
        ap += 1; del *= x / ap; sum += del;
        if (Math.abs(del) < Math.abs(sum) * EPS) { break; }
      }
      return 1 - sum * Math.exp(-x + a * Math.log(x) - gammln(a));
    }
    // Lentz continued fraction for Q(a,x)
    var FPMIN = 1e-300;
    var b = x + 1 - a, c = 1 / FPMIN, d = 1 / b, h = d;
    for (i = 1; i <= ITMAX; i++) {
      var an = -i * (i - a);
      b += 2;
      d = an * d + b; if (Math.abs(d) < FPMIN) { d = FPMIN; }
      c = b + an / c; if (Math.abs(c) < FPMIN) { c = FPMIN; }
      d = 1 / d;
      var delta = d * c;
      h *= delta;
      if (Math.abs(delta - 1) < EPS) { break; }
    }
    return Math.exp(-x + a * Math.log(x) - gammln(a)) * h;
  }

  /** Chi-square (df=1) upper-tail p for the G² statistic. */
  function chi2P(g2) { return g2 <= 0 ? 1 : gammq(0.5, g2 / 2); }

  /** Seeded PRNG (mulberry32) — deterministic permutations. */
  function mulberry32(seed) {
    var s = seed >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      var t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function round(x, p) { var m = Math.pow(10, p); return Math.round(x * m) / m; }

  /* ------------------------------------------------------------------ *
   * Core computation
   * ------------------------------------------------------------------ */

  function docFromCra(name, data) {
    var sf = data && data.surfaceFrequencies;
    if (!sf || !sf.totalTokens || !sf.tokens) { return null; }
    var counts = Object.create(null);
    sf.tokens.forEach(function (t) { counts[t[0]] = t[1]; });
    return { name: name, n: sf.totalTokens, counts: counts };
  }

  function g2Of(a, b, NA, NB) {
    var t = a + b, N = NA + NB;
    if (t === 0) { return 0; }
    var Ea = NA * t / N, Eb = NB * t / N;
    var g = 0;
    if (a > 0) { g += a * Math.log(a / Ea); }
    if (b > 0) { g += b * Math.log(b / Eb); }
    return 2 * g;
  }

  /**
   * Keyness A vs. B.
   * docsA/docsB: [{name, n, counts}] from docFromCra (nulls excluded upstream)
   * opts: { minFreq (3), maxRows (100), zeroAdjust (0.5),
   *         permutations (0 = off; spec default 999), seed (42) }
   */
  function computeKeyness(docsA, docsB, opts) {
    opts = opts || {};
    var minFreq = opts.minFreq === undefined ? 3 : opts.minFreq;
    var maxRows = opts.maxRows === undefined ? 100 : opts.maxRows;
    var zeroAdjust = opts.zeroAdjust === undefined ? 0.5 : opts.zeroAdjust;
    var nPerm = opts.permutations === undefined ? 0 : opts.permutations;
    var seed = opts.seed === undefined ? 42 : opts.seed;

    function groupCounts(docs) {
      var g = Object.create(null), N = 0;
      docs.forEach(function (d) {
        N += d.n;
        Object.keys(d.counts).forEach(function (w) {
          g[w] = (g[w] || 0) + d.counts[w];
        });
      });
      return { counts: g, N: N };
    }
    var A = groupCounts(docsA), B = groupCounts(docsB);
    var NA = A.N, NB = B.N;

    // candidate vocabulary
    var vocab = Object.create(null);
    Object.keys(A.counts).forEach(function (w) { vocab[w] = 1; });
    Object.keys(B.counts).forEach(function (w) { vocab[w] = 1; });

    var rows = [];
    Object.keys(vocab).forEach(function (w) {
      var a = A.counts[w] || 0, b = B.counts[w] || 0;
      if (a + b < minFreq) { return; }
      var rateA = a / NA, rateB = b / NB;
      var dirA = rateA > rateB;
      var g2 = g2Of(a, b, NA, NB);
      var lr = Math.log(((a || zeroAdjust) / NA) / ((b || zeroAdjust) / NB)) / Math.LN2;
      var pd = b > 0 ? 100 * (rateA - rateB) / rateB : null;
      // DP + doc share in the overusing group
      var docs = dirA ? docsA : docsB;
      var gN = dirA ? NA : NB, gC = dirA ? a : b;
      var dp = null, contain = 0;
      if (gC > 0) {
        dp = 0;
        docs.forEach(function (d) {
          var ci = d.counts[w] || 0;
          if (ci > 0) { contain++; }
          dp += Math.abs(d.n / gN - ci / gC);
        });
        dp = dp / 2;
      }
      var docShare = docs.length ? contain / docs.length : 0;
      rows.push({
        word: w, freqA: a, freqB: b,
        per1kA: round(rateA * 1000, 3), per1kB: round(rateB * 1000, 3),
        g2: round(g2, 4), p: chi2P(g2),
        logRatio: round(lr, 3), pctDiff: pd === null ? null : round(pd, 1),
        direction: dirA ? 'A' : 'B',
        dp: dp === null ? null : round(dp, 3),
        docShare: round(docShare, 3),
        warn: docShare < 0.5
      });
    });
    rows.sort(function (x, y) {
      return y.g2 - x.g2 || (x.word < y.word ? -1 : 1);
    });
    rows = rows.slice(0, maxRows);

    // permutation option (documents shuffled between groups)
    if (nPerm > 0 && rows.length) {
      var all = docsA.concat(docsB);
      var kA = docsA.length;
      var rng = mulberry32(seed);
      var hits = rows.map(function () { return 0; });
      var words = rows.map(function (r) { return r.word; });
      for (var it = 0; it < nPerm; it++) {
        // Fisher–Yates, seeded
        var idx = all.map(function (_, i) { return i; });
        for (var i = idx.length - 1; i > 0; i--) {
          var j = Math.floor(rng() * (i + 1));
          var tmp = idx[i]; idx[i] = idx[j]; idx[j] = tmp;
        }
        var pa = 0, pb = 0, ca = Object.create(null), cb = Object.create(null);
        idx.forEach(function (di, pos) {
          var d = all[di];
          var into = pos < kA;
          if (into) { pa += d.n; } else { pb += d.n; }
          words.forEach(function (w) {
            var c = d.counts[w] || 0;
            if (!c) { return; }
            if (into) { ca[w] = (ca[w] || 0) + c; } else { cb[w] = (cb[w] || 0) + c; }
          });
        });
        rows.forEach(function (r, ri) {
          var g2p = g2Of(ca[r.word] || 0, cb[r.word] || 0, pa, pb);
          if (g2p >= r.g2 - 1e-12) { hits[ri]++; }
        });
      }
      rows.forEach(function (r, ri) {
        r.permP = round((hits[ri] + 1) / (nPerm + 1), 4);
      });
    }

    // ---- Zeta (Craig variant): presence proportions over documents ----
    var presA = Object.create(null), presB = Object.create(null);
    docsA.forEach(function (d) {
      Object.keys(d.counts).forEach(function (w) { presA[w] = (presA[w] || 0) + 1; });
    });
    docsB.forEach(function (d) {
      Object.keys(d.counts).forEach(function (w) { presB[w] = (presB[w] || 0) + 1; });
    });
    var zRows = [];
    Object.keys(vocab).forEach(function (w) {
      var da = presA[w] || 0, db = presB[w] || 0;
      if (da + db < 2) { return; } // hapax-document noise
      var pA = docsA.length ? da / docsA.length : 0;
      var pB = docsB.length ? db / docsB.length : 0;
      zRows.push({ word: w, docsA: da, docsB: db,
        pA: round(pA, 3), pB: round(pB, 3),
        zetaA: round(pA + (1 - pB), 3), zetaB: round(pB + (1 - pA), 3) });
    });
    function topZeta(key) {
      return zRows.slice().sort(function (x, y) {
        return y[key] - x[key] || (x.word < y.word ? -1 : 1);
      }).slice(0, 20).filter(function (r) { return r[key] > 1; });
    }

    return {
      parameters: {
        minFreq: minFreq, maxRows: maxRows, zeroAdjust: zeroAdjust,
        permutations: nPerm, seed: nPerm > 0 ? seed : null,
        significance: nPerm > 0 ? 'asymptotic + seeded permutation'
                                : 'asymptotic chi-square (df=1)'
      },
      totals: { NA: NA, NB: NB, docsA: docsA.length, docsB: docsB.length },
      keywords: rows,
      zetaA: topZeta('zetaA'),
      zetaB: topZeta('zetaB')
    };
  }

  /* ------------------------------------------------------------------ *
   * Report serialization
   * ------------------------------------------------------------------ */

  function fmtP(p) {
    if (p === null || p === undefined) { return '—'; }
    if (p < 0.0001) { return '<0.0001'; }
    return String(round(p, 4));
  }

  function serializeReport(res, namesA, namesB, citationBlock) {
    var L = [];
    var par = res.parameters;
    L.push('# Crawdad Keyness: group A vs. group B');
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- Group A (' + res.totals.docsA + ' file(s), ' + res.totals.NA +
      ' tokens): ' + namesA.join(', '));
    L.push('- Group B (' + res.totals.docsB + ' file(s), ' + res.totals.NB +
      ' tokens): ' + namesB.join(', '));
    L.push('- Parameters: min frequency=' + par.minFreq + ', max rows=' + par.maxRows +
      ', Log-Ratio zero adjust=' + par.zeroAdjust + ', significance=' + par.significance +
      (par.permutations ? ' (' + par.permutations + ' permutations, seed=' + par.seed + ')' : ''));
    L.push('');
    L.push('Counts come from each file\'s `surfaceFrequencies` block (top 2,000 surface');
    L.push('types per file, counted before stop-word removal and stemming); a word outside');
    L.push('a file\'s top 2,000 counts as absent there — negligible for texts under ~10k');
    L.push('tokens. G² measures evidence against equal rates; Log Ratio measures the SIZE');
    L.push('of the difference (each doubling of the relative rate adds 1). They answer');
    L.push('different questions and are reported separately: with large corpora, tiny');
    L.push('differences reach significance. ⚠ marks words found in fewer than half the');
    L.push('overusing group\'s documents (DP = Gries\'s deviation of proportions; higher =');
    L.push('more concentrated) — keyness driven by one document is a known failure mode.');
    L.push('');
    L.push('## Key words (by G²)');
    L.push('');
    var permCol = par.permutations > 0;
    L.push('| Word | Dir | Freq A | /1k A | Freq B | /1k B | G² | p' +
      (permCol ? ' | perm p' : '') + ' | Log Ratio | %DIFF | DP | Doc share | |');
    L.push('|---|---|---|---|---|---|---|---|' + (permCol ? '---|' : '') + '---|---|---|---|');
    res.keywords.forEach(function (r) {
      L.push('| ' + r.word + ' | ' + r.direction + ' | ' + r.freqA + ' | ' + r.per1kA +
        ' | ' + r.freqB + ' | ' + r.per1kB + ' | ' + r.g2 + ' | ' + fmtP(r.p) +
        (permCol ? ' | ' + fmtP(r.permP) : '') +
        ' | ' + r.logRatio + ' | ' + (r.pctDiff === null ? 'A-only' : r.pctDiff) +
        ' | ' + (r.dp === null ? '—' : r.dp) + ' | ' + r.docShare +
        ' | ' + (r.warn ? '⚠' : '') + ' |');
    });
    L.push('');
    L.push('## Zeta marker words (Craig variant; document proportions)');
    L.push('');
    L.push('Presence-based (in how many documents does the word appear at all?), so it');
    L.push('surfaces consistent mid-frequency markers that G² can miss. Zeta = P(A docs');
    L.push('contain word) + (1 − P(B docs contain word)); 2 = in every A document and no');
    L.push('B document. Only words above 1 (favoring the side) are listed; with few');
    L.push('documents per group the proportions are coarse — read accordingly.');
    L.push('');
    L.push('| Marker for A | Zeta | In A docs | In B docs |');
    L.push('|---|---|---|---|');
    res.zetaA.forEach(function (r) {
      L.push('| ' + r.word + ' | ' + r.zetaA + ' | ' + r.docsA + '/' + res.totals.docsA +
        ' | ' + r.docsB + '/' + res.totals.docsB + ' |');
    });
    L.push('');
    L.push('| Marker for B | Zeta | In B docs | In A docs |');
    L.push('|---|---|---|---|');
    res.zetaB.forEach(function (r) {
      L.push('| ' + r.word + ' | ' + r.zetaB + ' | ' + r.docsB + '/' + res.totals.docsB +
        ' | ' + r.docsA + '/' + res.totals.docsA + ' |');
    });
    L.push('');
    L.push('Methods: G² log-likelihood (Dunning, 1993; Rayson & Garside, 2000); Log Ratio');
    L.push('(Hardie, 2014); %DIFF (Gabrielatos, 2018); DP (Gries, 2008); Zeta (Burrows,');
    L.push('2007; Craig variant). Permutation test, when enabled: documents shuffled');
    L.push('between groups, empirical p = (hits + 1)/(B + 1), seed recorded above.');
    L.push('');
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-keyness', schemaVersion: '1.0',
      groupA: namesA, groupB: namesB, parameters: res.parameters,
      totals: res.totals, keywords: res.keywords,
      zetaA: res.zetaA, zetaB: res.zetaB }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    String(citationBlock || '').split('\n\n').forEach(function (c) {
      if (c) { L.push('*' + c + '*'); L.push(''); }
    });
    return L.join('\n');
  }

  var api = {
    gammq: gammq,
    chi2P: chi2P,
    g2Of: g2Of,
    mulberry32: mulberry32,
    docFromCra: docFromCra,
    computeKeyness: computeKeyness,
    serializeReport: serializeReport
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadKeyness = api; }
})(typeof self !== 'undefined' ? self : this);
