/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M4 — concept communities + network backbone
 * (Build Spec V2 §5.2, §5.3; D-V2-4).
 *
 * Leiden community detection (Traag, Waltman, & van Eck, 2019) on the
 * valued CRA network, DETERMINISTIC variant: modularity objective
 * (Newman & Girvan, 2004; resolution γ recorded, default 1), nodes
 * processed in ascending id order, best-gain moves with ties broken by
 * lowest community id, refinement by greedy argmax merge (the paper's
 * randomized proportional selection replaced by argmax for determinism —
 * recorded as `variant: 'deterministic-greedy'`). Louvain's known defect —
 * internally disconnected communities — is prevented by the refinement
 * phase, which only merges within connected neighborhoods.
 *
 * Oracle discipline: leidenalg cannot be matched bit-for-bit (its
 * randomness rides on igraph's RNG), so validation is (a) identical
 * partitions on unambiguous test graphs, (b) modularity within tolerance
 * of leidenalg on real CRA networks, (c) determinism (same input → same
 * partition), (d) modularity value cross-checked against igraph's
 * weighted modularity for our own partitions (1e-9).
 *
 * Disparity filter (Serrano, Boguñá, & Vespignani, 2009): for node i of
 * strength s_i and degree k_i, edge weight w: α_ij = (1 − w/s_i)^(k_i−1);
 * the edge is retained when α < level for EITHER endpoint (the paper's
 * rule). k = 1 edges are kept (a single edge is that node's whole
 * neighborhood; the test would always discard it at any level < 1).
 */
(function (root) {
  'use strict';

  function round5(x) { return Math.round(x * 1e5) / 1e5; }

  /* ------------------------------------------------------------------ *
   * Weighted modularity (Newman & Girvan, 2004)
   * ------------------------------------------------------------------ */

  function modularity(nNodes, edges, membership, resolution) {
    var gamma = resolution === undefined ? 1 : resolution;
    var m2 = 0; // 2m = total weight * 2
    var strength = new Array(nNodes).fill(0);
    edges.forEach(function (e) {
      strength[e.source] += e.weight;
      strength[e.target] += e.weight;
      m2 += 2 * e.weight;
    });
    if (m2 === 0) { return 0; }
    var inW = Object.create(null), totW = Object.create(null);
    edges.forEach(function (e) {
      if (membership[e.source] === membership[e.target]) {
        inW[membership[e.source]] = (inW[membership[e.source]] || 0) + e.weight;
      }
    });
    for (var i = 0; i < nNodes; i++) {
      totW[membership[i]] = (totW[membership[i]] || 0) + strength[i];
    }
    var q = 0;
    Object.keys(totW).forEach(function (c) {
      q += (2 * (inW[c] || 0)) / m2 - gamma * Math.pow(totW[c] / m2, 2);
    });
    return q;
  }

  /* ------------------------------------------------------------------ *
   * Deterministic Leiden
   * ------------------------------------------------------------------ */

  function adjOf(nNodes, edges) {
    var adj = [];
    for (var i = 0; i < nNodes; i++) { adj.push([]); }
    edges.forEach(function (e) {
      adj[e.source].push([e.target, e.weight]);
      adj[e.target].push([e.source, e.weight]);
    });
    return adj;
  }

  /**
   * One local-moving pass to convergence over a (possibly aggregated)
   * weighted graph. memb mutated in place. Returns true if anything moved.
   * Constrained mode: node may only join communities whose constraint
   * label matches its own (used by refinement).
   */
  function localMove(nNodes, adj, selfW, nodeW, memb, gamma, m2, constraint) {
    var commTot = Object.create(null);
    for (var i = 0; i < nNodes; i++) {
      commTot[memb[i]] = (commTot[memb[i]] || 0) + nodeW[i];
    }
    var movedAny = false, improved = true;
    while (improved) {
      improved = false;
      for (var v = 0; v < nNodes; v++) { // ascending id order (recorded)
        var cur = memb[v];
        // weights to neighboring communities
        var wTo = Object.create(null);
        adj[v].forEach(function (nb) {
          if (constraint && constraint[nb[0]] !== constraint[v]) { return; }
          wTo[memb[nb[0]]] = (wTo[memb[nb[0]]] || 0) + nb[1];
        });
        commTot[cur] -= nodeW[v];
        var bestC = cur, bestGain = (wTo[cur] || 0) - gamma * commTot[cur] * nodeW[v] / m2;
        Object.keys(wTo).forEach(function (cStr) {
          var c = +cStr;
          if (c === cur) { return; }
          var gain = wTo[c] - gamma * commTot[c] * nodeW[v] / m2;
          if (gain > bestGain + 1e-12 ||
              (Math.abs(gain - bestGain) <= 1e-12 && c < bestC)) {
            bestGain = gain; bestC = c;
          }
        });
        commTot[bestC] = (commTot[bestC] || 0) + nodeW[v];
        if (bestC !== cur) { memb[v] = bestC; improved = true; movedAny = true; }
      }
    }
    return movedAny;
  }

  /**
   * Leiden on a weighted undirected graph.
   * Returns { membership (dense, 0..k-1 by first appearance), modularity,
   *           levels, parameters }.
   */
  function leiden(nNodes, edges, opts) {
    opts = opts || {};
    var gamma = opts.resolution === undefined ? 1 : opts.resolution;
    var maxLevels = opts.maxLevels || 20;

    // current aggregated graph state
    var curN = nNodes;
    var curEdges = edges.map(function (e) {
      return { source: e.source, target: e.target, weight: e.weight };
    });
    var mapping = []; // original node -> current aggregated node
    for (var i = 0; i < nNodes; i++) { mapping.push(i); }
    var m2 = 0;
    edges.forEach(function (e) { m2 += 2 * e.weight; });
    if (m2 === 0) {
      var single = [];
      for (i = 0; i < nNodes; i++) { single.push(i); }
      return { membership: single, modularity: 0, levels: 0,
        parameters: params(gamma) };
    }

    var levels = 0;
    var curSelf = new Array(curN).fill(0); // aggregated self-loop weight
    for (var level = 0; level < maxLevels; level++) {
      var adj = adjOf(curN, curEdges);
      var nodeW = new Array(curN).fill(0);
      curEdges.forEach(function (e) {
        nodeW[e.source] += e.weight; nodeW[e.target] += e.weight;
      });
      // self-loops carry the community-internal weight through aggregation:
      // each contributes 2w to its node's strength (dropping them understated
      // k_v and over-merged everything — caught by the two-triangles test)
      for (var si = 0; si < curN; si++) { nodeW[si] += 2 * curSelf[si]; }
      var selfW = curSelf;
      // 1) local moving
      var memb = [];
      for (i = 0; i < curN; i++) { memb.push(i); }
      var moved = localMove(curN, adj, selfW, nodeW, memb, gamma, m2, null);
      // count communities
      var commSet = Object.create(null), nComm = 0;
      for (i = 0; i < curN; i++) {
        if (commSet[memb[i]] === undefined) { commSet[memb[i]] = nComm++; }
      }
      if (!moved || nComm === curN) { // nothing to aggregate further
        // write back and stop
        for (i = 0; i < nNodes; i++) { mapping[i] = commSet[memb[mapping[i]]]; }
        levels = level + 1;
        break;
      }
      // 2) refinement: within each community, sub-partition by constrained
      // greedy local moving from singletons (keeps communities connected)
      var refMemb = [];
      for (i = 0; i < curN; i++) { refMemb.push(i); }
      localMove(curN, adj, selfW, nodeW, refMemb, gamma, m2, memb);
      var refSet = Object.create(null), nRef = 0;
      for (i = 0; i < curN; i++) {
        if (refSet[refMemb[i]] === undefined) { refSet[refMemb[i]] = nRef++; }
      }
      // 3) aggregate on the REFINED partition (self-loops preserved)
      var aggEdges = Object.create(null);
      var newSelf = new Array(nRef).fill(0);
      for (i = 0; i < curN; i++) { newSelf[refSet[refMemb[i]]] += curSelf[i]; }
      curEdges.forEach(function (e) {
        var a = refSet[refMemb[e.source]], b = refSet[refMemb[e.target]];
        if (a === b) { newSelf[a] += e.weight; return; }
        var k = a < b ? a + '|' + b : b + '|' + a;
        aggEdges[k] = (aggEdges[k] || 0) + e.weight;
      });
      var newEdges = Object.keys(aggEdges).map(function (k) {
        var p = k.split('|');
        return { source: +p[0], target: +p[1], weight: aggEdges[k] };
      });
      // update original-node mapping to refined aggregated nodes
      for (i = 0; i < nNodes; i++) { mapping[i] = refSet[refMemb[mapping[i]]]; }
      curN = nRef;
      curEdges = newEdges;
      curSelf = newSelf;
      levels = level + 1;
      if (nRef === nComm && !moved) { break; }
    }

    // final polish: one node-level local-moving pass on the ORIGINAL graph
    // from the found partition (recovers quality the greedy aggregation
    // leaves behind; still fully deterministic)
    var adj0 = adjOf(nNodes, edges);
    var nodeW0 = new Array(nNodes).fill(0);
    edges.forEach(function (e) {
      nodeW0[e.source] += e.weight; nodeW0[e.target] += e.weight;
    });
    localMove(nNodes, adj0, new Array(nNodes).fill(0), nodeW0, mapping, gamma, m2, null);

    // dense final membership by first appearance over ORIGINAL node order
    var dense = Object.create(null), next = 0, membership = [];
    for (i = 0; i < nNodes; i++) {
      var c = mapping[i];
      if (dense[c] === undefined) { dense[c] = next++; }
      membership.push(dense[c]);
    }
    return {
      membership: membership,
      modularity: round5(modularity(nNodes, edges, membership, gamma)),
      levels: levels,
      parameters: params(gamma)
    };

    function params(g) {
      return { method: 'leiden', variant: 'deterministic-greedy',
        objective: 'modularity', resolution: g,
        order: 'ascending node id', seed: 0 };
    }
  }

  /**
   * Build the schema `communities` block for a CRA network.
   * nodes: [{id, word, display, influence}], edges: [{source,target,weight}]
   */
  function communitiesBlock(nodes, edges, opts) {
    var res = leiden(nodes.length, edges, opts);
    var groups = Object.create(null);
    nodes.forEach(function (nd, i) {
      var c = res.membership[i];
      (groups[c] = groups[c] || []).push(nd);
    });
    var list = Object.keys(groups).map(function (c) {
      var members = groups[c].slice().sort(function (a, b) {
        return b.influence - a.influence || (a.word < b.word ? -1 : 1);
      });
      var totalInfluence = 0;
      members.forEach(function (nd) { totalInfluence += nd.influence; });
      return {
        id: +c,
        label: members[0].display || members[0].word,
        size: members.length,
        totalInfluence: round5(totalInfluence),
        members: members.map(function (nd) {
          return { word: nd.display || nd.word, influence: nd.influence };
        })
      };
    }).sort(function (a, b) {
      return b.totalInfluence - a.totalInfluence || b.size - a.size || a.id - b.id;
    });
    return {
      parameters: res.parameters,
      modularity: res.modularity,
      count: list.length,
      membership: res.membership,
      communities: list
    };
  }

  /* ------------------------------------------------------------------ *
   * Disparity filter (Serrano et al., 2009)
   * ------------------------------------------------------------------ */

  function disparityAlpha(w, s, k) {
    if (k <= 1) { return 0; } // single-edge node: keep (see header note)
    return Math.pow(1 - w / s, k - 1);
  }

  /** Returns the retained edge list at significance `level` (default .05). */
  function disparityFilter(nNodes, edges, level) {
    level = level === undefined ? 0.05 : level;
    var s = new Array(nNodes).fill(0), k = new Array(nNodes).fill(0);
    edges.forEach(function (e) {
      s[e.source] += e.weight; s[e.target] += e.weight;
      k[e.source]++; k[e.target]++;
    });
    return edges.filter(function (e) {
      return disparityAlpha(e.weight, s[e.source], k[e.source]) < level ||
             disparityAlpha(e.weight, s[e.target], k[e.target]) < level;
    });
  }

  var api = {
    modularity: modularity,
    leiden: leiden,
    communitiesBlock: communitiesBlock,
    disparityAlpha: disparityAlpha,
    disparityFilter: disparityFilter
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadCommunities = api; }
})(typeof self !== 'undefined' ? self : this);
