/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M5 tests — Stylometry (Build Spec V2 §6.1, §11).
 * Node:    NODE_PATH=... node tests/test-stylometry.js  (needs pako for NCD)
 * Browser: open tests/test-stylometry.html
 * Oracles: independently coded numpy reference of the stylo-convention
 *          formulas on a real 11-doc two-author corpus (5 Lincoln + 6 WSJ;
 *          fixture-stylometry.json) + leave-one-out attribution benchmark;
 *          hand-worked z-score/Delta/Cosine example; NCD formula identity.
 *          NOTE: the R-stylo/Federalist cross-check could not run in this
 *          sandbox (no CRAN access); a ready-to-run script ships in
 *          validation-study/stylo-crosscheck.R — open validation item.
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var ST = isNode ? require('../js/stylometry.js') : root.CrawdadStylometry;
  var FIX = isNode ? require('./fixture-stylometry.json') : root.CrawdadFixture_stylometry;
  var deflateFn = null;
  if (isNode) {
    try {
      var pako = require('pako');
      deflateFn = function (u8) { return pako.deflate(u8); };
    } catch (e) { deflateFn = null; }
  } else if (root.pako) {
    deflateFn = function (u8) { return root.pako.deflate(u8); };
  }

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function close(a, b, tol, m) {
    if (Math.abs(a - b) > tol) { throw new Error((m || '') + ' |' + a + ' - ' + b + '| > ' + tol); }
  }

  function fixtureDocs() {
    return FIX.docs.map(function (d) {
      var counts = Object.create(null);
      d.sf.tokens.forEach(function (tk) { counts[tk[0]] = tk[1]; });
      return { name: d.name, n: d.sf.totalTokens, counts: counts };
    });
  }

  /* ---------------- reference-matched matrices ---------------- */

  t('MFW list matches the numpy reference exactly (ranking + culling)', function () {
    var prof = ST.mfwProfile(fixtureDocs(), { mfw: FIX.mfw, culling: FIX.culling });
    assert(prof.words.length === FIX.words.length, 'length');
    for (var i = 0; i < FIX.words.length; i++) {
      assert(prof.words[i] === FIX.words[i],
        'word ' + i + ': ' + prof.words[i] + ' vs ' + FIX.words[i]);
    }
  });

  t('Burrows Delta matrix matches the numpy reference at 1e-9', function () {
    var prof = ST.mfwProfile(fixtureDocs(), { mfw: FIX.mfw, culling: FIX.culling });
    var D = ST.burrowsDelta(prof.z);
    for (var i = 0; i < D.length; i++) {
      for (var j = 0; j < D.length; j++) {
        close(D[i][j], FIX.refDelta[i][j], 1e-9, 'delta[' + i + '][' + j + ']');
      }
    }
  });

  t('Cosine Delta matrix matches the numpy reference at 1e-9', function () {
    var prof = ST.mfwProfile(fixtureDocs(), { mfw: FIX.mfw, culling: FIX.culling });
    var D = ST.cosineDelta(prof.z);
    for (var i = 0; i < D.length; i++) {
      for (var j = 0; j < D.length; j++) {
        if (i === j) { continue; }
        close(D[i][j], FIX.refCosine[i][j], 1e-9, 'cosine[' + i + '][' + j + ']');
      }
    }
  });

  t('attribution benchmark: leave-one-out nearest neighbor recovers the author 11/11 (both metrics)', function () {
    var prof = ST.mfwProfile(fixtureDocs(), { mfw: FIX.mfw, culling: FIX.culling });
    [ST.burrowsDelta(prof.z), ST.cosineDelta(prof.z)].forEach(function (D, mi) {
      var correct = 0;
      for (var i = 0; i < D.length; i++) {
        var best = -1, bestD = Infinity;
        for (var j = 0; j < D.length; j++) {
          if (j !== i && D[i][j] < bestD) { bestD = D[i][j]; best = j; }
        }
        if (FIX.docs[best].author === FIX.docs[i].author) { correct++; }
      }
      assert(correct === FIX.docs.length,
        ['delta', 'cosine'][mi] + ': ' + correct + '/' + FIX.docs.length);
    });
  });

  /* ---------------- hand-worked example ---------------- */

  t('hand-worked: binary-exact rel freqs give z = -1/0/+1; Delta and Cosine exact', function () {
    // n=8 so relative frequencies are binary-exact: "the" .25/.5/.75 ->
    // mean .5, sample sd .25 -> z exactly -1/0/+1; "of" mirrors.
    var docs = [
      { name: 'A', n: 8, counts: { the: 2, of: 6 } },
      { name: 'B', n: 8, counts: { the: 4, of: 4 } },
      { name: 'C', n: 8, counts: { the: 6, of: 2 } }
    ];
    var prof = ST.mfwProfile(docs, { mfw: 2, culling: 0 });
    close(prof.z[0][0], -1, 1e-12, 'zA(the)');
    close(prof.z[1][0], 0, 1e-12, 'zB(the) exactly 0');
    close(prof.z[2][0], 1, 1e-12, 'zC(the)');
    var D = ST.burrowsDelta(prof.z);
    close(D[0][1], 1, 1e-12, 'Delta(A,B) = (1+1)/2');
    close(D[0][2], 2, 1e-12, 'Delta(A,C) = (2+2)/2');
    var Cd = ST.cosineDelta(prof.z);
    close(Cd[0][2], 2, 1e-12, 'Cosine(A,C): opposite vectors -> 1-(-1)');
    close(Cd[0][1], 1, 1e-12, 'Cosine vs zero-norm vector -> 1 by convention');
  });

  t('culling removes words absent from too many documents', function () {
    var docs = [
      { name: 'A', n: 10, counts: { the: 5, rare: 5 } },
      { name: 'B', n: 10, counts: { the: 10 } },
      { name: 'C', n: 10, counts: { the: 10 } }
    ];
    var full = ST.mfwProfile(docs, { mfw: 10, culling: 0 });
    assert(full.words.indexOf('rare') !== -1, 'kept at culling 0');
    var culled = ST.mfwProfile(docs, { mfw: 10, culling: 50 });
    assert(culled.words.indexOf('rare') === -1, 'dropped at culling 50 (1/3 of docs)');
  });

  /* ---------------- NCD ---------------- */

  t('NCD: formula identity, symmetry, and similar<dissimilar ordering', function () {
    if (!deflateFn) { throw new Error('pako unavailable for NCD test'); }
    var a = new Array(60).join('the market for satellites grew. ');
    var a2 = new Array(60).join('the market for satellites grew! ');
    var b = new Array(60).join('four score and seven years ago our fathers. ');
    var m = ST.ncdMatrix([a, a2, b], deflateFn);
    // formula identity recomputed directly
    var enc = function (s) { return deflateFn(new TextEncoder ? new TextEncoder().encode(s) : Buffer.from(s)).length; };
    var ca = m.sizes[0], cb = m.sizes[2];
    var catBytes = a + b;
    var cab = enc(catBytes);
    var expected = Math.round((cab - Math.min(ca, cb)) / Math.max(ca, cb) * 1e5) / 1e5;
    close(m.D[0][2], expected, 1e-9, 'formula identity');
    assert(m.D[0][1] === m.D[1][0] && m.D[0][2] === m.D[2][0], 'symmetric');
    assert(m.D[0][1] < m.D[0][2], 'near-duplicate closer than unrelated: ' +
      m.D[0][1] + ' vs ' + m.D[0][2]);
  });

  /* ---------------- module plumbing + report ---------------- */

  t('stylometry(): excludes V1-era files, records parameters, Eder warning fires', function () {
    var datas = FIX.docs.slice(0, 3).map(function (d) { return { surfaceFrequencies: d.sf }; });
    datas.push({}); // V1-era file without the block
    datas.push({ surfaceFrequencies: { totalTokens: 300,
      tokens: [['the', 30], ['of', 20], ['and', 15], ['to', 10]] } }); // tiny
    var names = ['a', 'b', 'c', 'old', 'tiny'];
    var res = ST.stylometry(datas, names, { mfw: 100, culling: 50 }, {});
    assert(res.excluded.length === 1 && res.excluded[0] === 'old', 'V1 file excluded');
    assert(res.names.length === 4, 'four analyzed');
    assert(res.parameters.zScores.indexOf('n-1') !== -1, 'SD convention recorded');
    assert(res.warnings.length === 1 && /tiny/.test(res.warnings[0]) &&
      /1500/.test(res.warnings[0]), 'Eder warning for the 300-token doc');
  });

  t('report: matrices, honest-use note, NCD-absent note, JSON block, citations', function () {
    var datas = FIX.docs.slice(0, 4).map(function (d) { return { surfaceFrequencies: d.sf }; });
    var names = FIX.docs.slice(0, 4).map(function (d) { return d.name; });
    var res = ST.stylometry(datas, names, { mfw: 100, culling: 50 }, {});
    var md = ST.serializeReport(res, 'CITE-1\n\nCITE-2\n\nDISC');
    assert(/## Burrows Delta \(Burrows, 2002\)/.test(md), 'delta matrix');
    assert(/## Cosine Delta \(Evert et al., 2017\)/.test(md), 'cosine matrix');
    assert(/HONEST-USE NOTE/.test(md) && /cannot verify\nauthorship absolutely/.test(md.replace(/\r/g, '')) ||
           /cannot verify/.test(md), 'honest-use note');
    assert(/Not computed: NCD needs the source byte sequences/.test(md), 'NCD absence explained');
    assert(/"crawdad-stylometry"/.test(md), 'machine block');
    assert(/CITE-1/.test(md) && /DISC/.test(md), 'citations');
  });

  t('report with NCD names the compressor (compressor-relative caveat)', function () {
    if (!deflateFn) { throw new Error('pako unavailable'); }
    var datas = FIX.docs.slice(0, 3).map(function (d) { return { surfaceFrequencies: d.sf }; });
    var names = ['x', 'y', 'z'];
    var srcs = { x: 'aaa bbb ccc ddd eee fff '.repeat(40),
                 y: 'aaa bbb ccc ddd eee ggg '.repeat(40),
                 z: 'zzz yyy xxx www vvv uuu '.repeat(40) };
    var res = ST.stylometry(datas, names, { mfw: 50, culling: 0, sourceTexts: srcs },
      { deflateFn: deflateFn, deflateLabel: 'pako 3.0.1 deflate (vendored)' });
    assert(res.ncd && res.ncd.D.length === 3, 'NCD computed');
    var md = ST.serializeReport(res, 'C');
    assert(/pako 3\.0\.1/.test(md) && /compressor-relative/.test(md), 'compressor pinned + caveat');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M5 stylometry tests: ' + passed + '/' + results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadStylometryTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
