# CRA Analysis: jhc2002.pdf

- Processed: 2026-07-09T18:42:22.927Z
- App version: 0.2.0-M2
- Parameters: stemming=porter, pronouns=dropped, inter-sentence linking=on, tokenization file=none

## Network summary

| Measure | Value |
|---|---|
| Nodes | 1644 |
| Edges | 6420 |
| Degree centralization | 0.11468 |
| Betweenness centralization | 0.10402 |
| Closeness centralization | 0.30680 |
| Eigenvector centralization | 0.97602 |
| Mean influence | 0.00150 |

## Influential words (influence > 0.005)

| Word | Degree | Influence | Connected to |
|---|---|---|---|
| communication | 171 | 0.10545 | acm, act, activ, agreement, aim, analysi, anderson, applic, approach, area, arizona, associ, attent, avalanch, behavior, board, bodi, botan, box, busi, categori, center, chain, church, claim, codabl, cognit, coher, collect, commit, compet, complex, comput, construct, content, context, coordin, cra, cultur, data, decis, deetz, detail, develop, disciplin, effect, effici, english, essay, event, evid, exchang, exemplari, explicit, focus, formal, foucault, goldhab, group, gudykunst, hillsdal, human, idea, illustr, import, individu, industri, interact, intern, interperson, interpret, introduct, investig, issu, journal, kevin, languag, larg, leacock, less, level, literatur, lthough, manag, manifest, mass, mclaughlin, measur, mediat, member, method, micro-practic, microanalyt, microlevel, model, monograph, move, need, network, norwood, notion, oak, observ, order, organ, organiz, pair, pattern, percept, person, perspect, phenomena, polit, pool, power, practic, procedur, process, progress, qualiti, quarter, relationship, relev, report, research, reson, respond, retriev, review, rhetor, richard, roloff, scheme, scholar, scienc, scope, scott, self, simul, site, small, social, sociolog, specif, steven, stream, structur, studi, substitut, system, term, theori, thing, time, tional, tradit, transcend, transmiss, trend, unacknowledg, understand, unproblemat, utter, vertic, volum, watt, way, wide, word, work, yearbook |
| text | 196 | 0.09627 | ab, abil, addit, adject, advantag, aggreg, agogino, analysi, analyt, applic, approach, april, associ, assumpt, attempt, author, autom, automat, bartel, base, best, bodi, catpac, character, claim, close, co-occur, coher, collect, column, comparison, comput, concept, conceptu, conclus, confer, connolli, consider, consist, content, context, convers, corman, corpora, corpus, correspond, cra, data, descript, differ, discours, domain, dong, edg, effort, element, email, emphasi, employe, entireti, exampl, extent, featur, field, form, frame, given, goal, good, grammat, guidelin, half, human, idea, import, incid, independ, infer, inferenti, influenc, inform, innov, instanc, interpret, interview, involv, japanes, jk, journal, keyword, knowledg, labor, languag, larger, length, littl, lsa, main, matric, matter, mean, meaning, measur, member, method, multipl, nativ, network, new, next, onlin, ontolog, organiz, origin, overal, pair, paper, part, particip, passag, pattern, percept, phrase, portion, posit, procedur, product, proper, properti, purpos, qualit, quantit, quantiti, queri, question, rang, raw, read, reader, refer, relat, relationship, relev, represent, research, residu, reson, retriev, robert, rule, sampl, scheme, second, segment, select, semant, sensibl, set, similar, singl, slide, sourc, speaker, spirit, statement, statist, structur, subnetwork, subsequ, summari, tag, techniqu, term, theoret, theori, thought, tradit, transcrib, transcript, type, uncov, understand, utter, valid, valu, vector, verbatim, volum, walker, way, wide, window, word, wr, written, yield |
| words | 180 | 0.08596 | ab, abstract, account, actor, adam, adjac, adject, advantag, ambigu, analysi, appoint, approach, appropri, april, associ, attent, author, axi, bag, basic, benchmark, bodi, bottom, branch, case, cell, center, choic, claim, cluster, co-occur, co-occurr, coher, collabor, column, combin, common, communic, compani, compon, concept, condit, connect, content, convers, cra, critic, cue, definit, demand, dictionari, dimens, disambigu, discurs, discuss, distanc, document, domain, employe, essenc, extent, fall, familiar, favor, figur, flow, frame, frequenc, function, given, goal, graph, group, high, highest, human, import, indic, infer, influenc, influenti, inform, interconnect, interview, jk, keyword, knowledg, lexic, link, lower, make, matric, matrix, mean, measur, member, method, name, network, next-most, node, noun, number, ontolog, overal, pair, part, particip, particular, path, peopl, phrase, placement, point, polysem, portant, posit, possibl, probabilist, process, promin, properti, question, rational, read, reader, realm, recommend, refer, referenti, relat, relationship, represent, reson, rule, score, select, sematech, sens, sentenc, sequenc, sequenti, set, singl, space, speaker, spread, standard, statist, step, stream, structur, subsequ, tag, technolog, term, text, textual, th, thought, time, tlc, top, topic, topteam, uniqu, unit, use, utter, valu, variant, various, vector, way, wheel, whole, wide, window, wordij, wrangler |
| cra | 156 | 0.08112 | abil, accommo, advantag, advic, agent, analysi, applic, approach, appropri, assess, associ, assumpt, attent, build, cancer, captur, case, cast, chain, cluster, coher, collect, common, communic, comparison, complet, complex, comput, conclus, contrast, convers, correl, correspond, data, degre, detail, differ, disambigu, display, dissimilar, distinct, dynam, element, employ, exampl, exhibit, extent, figur, first, flexibl, form, fourth, generat, good, graph, ground, group, hand, human, imagin, immens, import, index, interact, interview, introduct, investig, larger, linguist, link, main, map, matric, matrix, media, method, model, move, multipl, necessari, need, net, network, new, non-standard, noun, observ, oper, order, organiz, panacea, paper, particip, perform, phenomenon, phrase, point, posit, possibl, problem, process, product, purpos, qualif, question, read, reader, reason, relationship, represent, research, respect, respons, result, review, rule, score, section, select, seri, set, show, size, softwar, spatial, step, structur, studi, substant, summari, support, system, task, techniqu, technolog, term, test, text, theoret, theori, tradit, transcrib, unit, use, utter, valid, valu, verb, visual, vita, weak, web, whole, word, work, yield |
| analysis | 141 | 0.07075 | addit, aggreg, aid, albani, applic, approach, appropri, attempt, autom, basi, beyer, cambridg, care, casual, cen, cluster, code, collabor, collect, communic, compar, comput, computer, concept, content, convers, cra, criteria, critic, crowd, danowski, data, date, decis, descript, design, discours, dyadic, dynam, effort, ethnographi, excerpt, faction, factor, field, figur, frost, gender, general, goal, group, gumption, handbook, hcr, hierarch, hubert, human, hypothesi, import, incid, influenc, interact, intern, interview, journal, latent, less, level, lexic, limit, linguist, lsa, manifest, mcphee, mean, media, meet, messag, method, methodolog, microlevel, mileston, multipl, network, new, nonparametr, notion, number, numer, oak, organ, pair, particip, particular, polit, portant, possibl, practic, preconfer, procedur, pronoun, propon, qualit, quantit, questionnair, regress, repres, research, reson, result, rule, semant, sequenti, set, signific, social, spatial, spons, strategi, subsequ, substitut, systemat, task, techniqu, text, textual, themat, theori, time, tool, tradit, transcrib, transcript, unit, varieti, verb, visual, west, westport, word, world |
| network | 125 | 0.06353 | advoc, agent, analysi, applic, approach, argument, assumpt, bayesian, between, carley, case, certain, chang, circuit, cluster, communic, complet, comput, concept, conceptu, conclus, content, context, convers, cra, danowski, differ, discuss, document, dynam, end, entir, exampl, fall, figur, first, flow, focal, form, format, fragment, freeman, friedkin, general, given, grammar, idea, im, import, individu, influenc, inform, intellectu, intent, interconnect, interdisciplinari, interrelationship, interview, ital, journal, kind, knowledg, krackhardt, larger, link, local, locat, measur, member, metaphor, method, next, node, nonparametr, noun, number, ontolog, oppon, organ, organiz, part, path, peripher, physic, posit, presenc, press, properti, public, relationship, relev, represent, research, reson, resourc, review, rich, rule, rush, semant, sens, sequenc, set, side, signal, singl, social, specif, stohl, stori, strategi, structur, text, top, tradit, undirect, unpublish, utter, varieti, visual, way, wide, window, word, yield |
| research | 116 | 0.06256 | 1990s, abstract, academ, amount, analysi, approach, april, area, arizona, attempt, barley, bartel, behavior, boundari, cancer, categori, central, co-occurr, communic, complex, comput, context, corman, cra, cue, daft, data, databas, ditomaso, dong, eizirik, empir, essay, exemplari, exist, factor, faculti, field, find, flexibl, formal, futur, galileo, general, graduat, grant, group, hierarch, human, individu, industri, inform, interdisciplinari, interest, interperson, journal, key, knapp, knowledg, larg, lead, left, linguist, littl, mahwah, map, market, mass, matter, maximum, measur, method, network, new, newburi, nicat, note, organ, organiz, ovpr, person, pool, provost, psycholinguist, questionnair, record, roloff, section, set, similar, simul, sociolog, sourc, sperber, statement, stephen, structur, studi, subclust, tact, task, taylor, techniqu, technolog, term, terra, text, textual, theori, univers, use, vice-provost, videotap, way, window, wretch |
| structure | 102 | 0.04591 | access, adopt, algorithm, applic, approach, attempt, avalanch, axelrod, berkeley, burt, categori, chang, cognit, coher, collect, communic, competit, complex, conceptu, content, cooper, corman, cra, danowski, data, decis, discours, discoveri, discurs, domain, elabor, emerg, evid, exist, expertis, explicit, featur, form, futur, gersick, graph, group, hillsdal, hole, hook, human, import, industri, influenc, inform, institut, interact, interdisciplinari, intern, interpret, kind, knowledg, leader, locat, manag, map, march, media, medic, method, multipl, network, new, order, organ, organiz, parallel, pattern, period, presid, process, properti, repres, represent, research, rich, scientif, semant, seyfarth, social, sourc, spread, standard, statement, studi, successor, system, text, theori, time, type, uncov, unit, use, utter, window, word |
| approach | 97 | 0.03523 | accuraci, addit, altern, analysi, analyt, artifici, assumpt, attent, autom, automat, bayesian, branch, character, communic, complex, computer, connect, constructionist, content, contrast, corpus, cra, deal, discours, domain, first, frequenc, galileo, general, gersick, goal, humphrey, idea, impact, inclus, infer, inferenti, inform, integr, keyword, knowledg, leacock, lexic, linguist, lsa, machin, manag, matrix, mean, model, natur, network, new, next, number, oxford, pair, posit, power, problem, process, promin, qualit, quantit, re-pres, refer, relat, represent, research, rice, rule, schiffrin, second, semant, sematech, semiot, set, shortcom, sophist, sort, stock, stori, strateg, structur, sum, symbol, syntax, system, term, text, textual, theoret, tlc, track, valid, weight, word |
| organization | 84 | 0.03424 | academi, access, action, actual, american, analysi, behavior, beyer, boston, case, chang, communic, companion, compet, complex, comput, concept, conclus, consider, contagion, control, convers, daft, depart, depth, element, emerg, equival, explan, fit, form, formal, greenwich, heart, heed, identif, indic, individu, intellectu, interpret, issu, key, knowledg, level, mathemat, member, micropractic, mind, model, modest, network, oxford, paper, person, phenomenon, point, posit, problem, relationship, report, research, resourc, scienc, sens, set, singl, small, social, sociolog, structur, talk, tall, team, technolog, term, theori, thompson, understand, utter, virtual, volum, watt, way, wide |
| methods | 88 | 0.03068 | agglomer, analysi, answer, applic, argument, attempt, author, autom, baum, behavior, beyer, broad, capabl, capac, central, characterist, collect, communic, complex, convers, corpus, cra, criteria, critiqu, data, demand, detail, differ, difficulti, disciplinari, discurs, ethnograph, ethnographi, folger, form, formal, gap, good, greater, import, infer, insight, instrument, interpret, landauer, languag, larg, limit, multilevel, need, network, new, nutshel, observ, organiz, passag, phenomena, posit, practic, purpos, question, rang, refer, relationship, represent, research, root, scheme, scienc, scope, sens, shortcom, simul, sociolog, solut, statist, structur, studi, text, theori, time, train, understand, use, valid, volum, window, word |
| processes | 80 | 0.02989 | action, anderson, approach, april, author, barley, basic, biolog, center, chang, characterist, cognit, coher, collect, communic, complex, comput, concept, connect, connolli, correspond, cours, cra, deploy, diffus, discours, discurs, disord, dna, emerg, error, experiment, galileo, generat, genet, haphazard, high, hospit, idea, import, influenc, inform, innov, interact, introduct, langack, languag, level, linguist, london, manag, mental, natur, nois, noun, oak, organiz, perceptu, polit, psycholinguist, report, represent, resist, result, right, role, sematech, statist, structur, studi, subsystem, techniqu, technolog, theori, understand, variabl, virtual, wide, word, wors |
| theory | 76 | 0.02871 | account, action, activ, analysi, arbitrari, assumpt, author, behavior, berkeley, beyer, blank, carley, cognit, coher, collabor, communic, communicaiton, compet, complex, comput, cra, craig, data, decis, demand, design, dialogu, discours, equival, foundat, galileo, general, gersick, group, identif, iida, introduct, jone, languag, larger, level, limit, linguist, lsa, mahwah, mathemat, measur, mellish, method, model, observ, organ, organiz, outlin, paper, phenomena, point, princ, process, questionnair, research, reticul, richard, scienc, semant, semiot, sequenc, seyfarth, small, social, structur, system, text, verb, writer, xi |
| group | 79 | 0.02788 | addit, advoc, analysi, applic, author, base, biochemistri, bulk, busi, cell, center, chang, cluster, colleg, communic, construct, convers, cra, decis, degre, develop, disambigu, discuss, distinct, dyad, dynam, empow, faction, faculti, figur, finit, flexibl, heterogen, identif, iii, imag, interact, irv, kind, larg, larger, level, meet, mileston, model, natur, new, overal, peopl, period, prerog, presid, read, recommend, research, respons, sampl, scale, scholar, sens, small, social, stabil, stage, structur, studi, subclust, substanti, task, test, theori, time, topteam, transcript, utter, way, wise, word, work |
| new | 45 | 0.02517 | action, analysi, announc, applic, approach, cra, direct, disciplin, discours, emerg, entiti, extent, find, fragment, group, handbook, impact, insight, kind, map, method, mitkov, model, presid, psycholog, putnam, related, research, retriev, revis, scan, somer, structur, suit, team, technolog, term, text, theme, time, treatment, understand, way, york, yorker |
| interaction | 66 | 0.02399 | abil, access, activ, analysi, assess, assigne, associ, attent, chang, code, coher, communic, convers, cra, data, decis, dervin, dialogu, difficulti, discours, due, dynam, emerg, emot, exclus, face, first, futur, group, hospit, individu, inertia, introduct, less, machin, member, multigroup, non-ct, observ, occup, order, ovpr, particular, passonneau, pattern, perceptu, process, record, resolut, result, rigor, scheme, scholar, script, simul, social, sort, structur, studi, subtl, system, unrel, use, utter, valid, weick |
| study | 65 | 0.02270 | basic, behavior, beyer, biolog, bracket, case, challeng, chang, characterist, communic, communiti, complex, comput, conceptu, count, cra, critic, danowski, depart, detail, eisenberg, equilibrium, esteem, exampl, exemplari, exhibit, experiment, field, fink, gersick, gronn, group, half, human, individu, interact, introduct, larger, lewi, manifest, messag, method, multiyear, norm, organiz, paper, pertin, process, psycholog, questionnair, rang, relationship, research, resolut, scope, simpl, singl, structur, substant, system, talk, technolog, time, valuabl, women |
| organizational | 59 | 0.02257 | applic, behavior, chang, chart, commu, communic, complex, comput, concern, condit, consequ, context, control, cra, danowski, deal, decad, decis, descript, dialogu, discours, discuss, divers, form, handbook, harrison, hole, holm, imag, influenc, infograph, journal, knowledg, manag, manageri, method, network, occup, ongo, perform, phenomena, process, re-pres, research, review, role, seibold, self, share, show, structur, studi, system, text, theori, tompkin, understand, util, videotap |
| computer | 51 | 0.02190 | analog, analysi, applic, board, bookman, bulletin, communic, concept, consequ, content, cra, develop, discours, exampl, experi, flood, foundat, galileo, human, identif, illustr, increas, infograph, instrument, jone, linguist, mathemat, mckoon, mediat, methodolog, model, network, organ, organiz, power, practic, press, prietula, process, program, research, score, simpler, simul, softwar, stephen, studi, techniqu, text, theori, way |
| cluster | 56 | 0.02170 | analysi, bottom, cellular, center, charact, clear, corman, cra, curricula, dimension, diseas, disord, distinct, divers, dysfunct, faculti, figur, general, group, hierarch, higher, horizont, larg, left, link, linkag, main, map, mate, matrix, mds, measur, member, microsci, network, opportun, order, output, particular, physic, plot, procedur, right, scatter, shallow, space, step, stori, subclust, system, techniqu, tightest, univers, use, visual, word |
| human | 56 | 0.02099 | ablex, analysi, analyst, anim, applic, area, associ, assumpt, cen, code, cohort, commu, communic, comparison, comput, convers, cra, dictionari, effect, email, figur, influenc, inform, inquiri, intellig, jk, journal, kl, knowledg, mean, microsci, model, oppon, organiza, phenomena, point, popul, rater, read, reader, relationship, repr, represent, research, retriev, scheme, school, skill, space, structur, studi, text, tlc, way, word, year |
| press | 39 | 0.02085 | academ, alder, axley, baker, botan, busi, california, cambridg, carley, clarendon, comput, contractor, corman, desancti, doerfel, dooley, folger, gidden, givn, hart, harvard, illinoi, jackson, jai, kuhn, network, nomoto, oxford, passonneau, politi, princeton, resolut, schank, school, simul, stanford, ucl, univers, weick |
| discourse | 65 | 0.01991 | actual, adhes, analysi, anaphor, anderson, approach, assumpt, attent, basi, broadband, center, cognit, coher, collect, complex, comput, concept, corpus, develop, elli, empir, entiti, exampl, explicit, fairhurst, field, format, graph, iida, illustr, import, inform, interact, jone, languag, memoranda, mission, model, new, noun, ongo, order, organiz, oxford, particip, polit, process, pronoun, rang, raw, re-pres, represent, resolut, salient, sampl, schulz, social, structur, summar, task, techniqu, text, theori, thompson, type |
| systems | 64 | 0.01981 | activ, adapt, applic, approach, assumpt, automat, barnett, biochem, biolog, cabinet, claim, cluster, code, collect, communic, complex, confer, constructionist, content, convers, cra, critic, critiqu, detail, discoveri, discurs, distribut, document, effici, empir, general, given, imag, impact, interact, intern, knowledg, level, link, mail, medsyndik, memori, model, next, nonlinear, organiz, parliamentari, person, properti, reson, rule, scalabl, scientif, selforgan, social, steven, structur, studi, task, theoret, theori, transact, use, westport |
| corman | 40 | 0.01827 | ab, ablex, activ, arizona, bradford, cellular, chang, cheney, cluster, commerc, dooley, express, forc, frequenc, gumption, im, influenc, matter, mcphee, miller, node, phrase, postexamin, presid, press, professor, re, research, reson, sage, scienc, scott, sematech, sociolog, steven, structur, tact, text, transcript, trethewey |
| conversation | 51 | 0.01771 | analysi, analyst, capabl, casual, collect, complex, connected, cra, develop, discuss, equival, ethnographi, event, fragment, frame, group, human, impact, import, intent, interact, interrel, interview, margaret, meet, memori, method, mr, natur, network, note, organ, partner, place, portion, relev, role, rossi, segment, sharkey, situat, system, tape, techniqu, text, textual, time, transcrib, utter, word, yield |
| information | 50 | 0.01702 | accuraci, agent, approach, central, co-occurr, context, control, develop, discours, exchang, faculti, human, import, indirect, kind, klein, languag, limit, link, littl, market, modern, natur, necessari, network, observ, opinion, process, pronoun, proper, relev, report, research, retriev, scienc, select, sens, societi, structur, task, text, textual, transfer, type, univers, valuabl, verb, volum, word, yate |
| science | 31 | 0.01526 | administr, anthoniss, axi, cognit, communic, corman, diefenbach, dooley, drazin, elli, frake, gerken, gersick, gordon, gronn, hyatt, infer, inform, kohonen, life, method, norwood, numer, organ, physic, quarter, scale, selforgan, social, term, theori |
| relationships | 37 | 0.01477 | activ, appar, averag, beyer, causal, chairman, communic, comprehens, cooper, correl, cra, definit, domain, doubt, grow, human, intens, invers, level, manifest, method, network, organ, perceiv, person, posit, probabilist, problem, qualiti, reader, shift, studi, subordin, text, time, train, word |
| social | 48 | 0.01462 | account, affair, affili, aggreg, analysi, applic, central, chandler, clarif, code, collect, communic, data, discours, dynam, econom, empir, expertis, faust, flow, forc, freeman, given, group, hole, idea, impact, interact, journal, languag, larger, network, observ, order, organ, problem, psycholog, quarter, scale, scanner, scholar, scienc, spurious, structur, student, system, theori, weick |
| measure | 51 | 0.01443 | accur, appropri, associ, between, biolog, central, classic, cluster, communic, conceptu, corpora, correl, degre, densiti, exampl, explicit, extent, featur, fink, flow, general, given, graph, issu, landauer, meaning, metaphor, mutual, network, nois, noisi, pair, parsimoni, quantit, rational, recent, research, reson, sens, sensit, simpler, standard, stephenson, subgroup, text, textual, theori, variabl, varieti, way, word |
| change | 45 | 0.01401 | assess, barley, claim, compani, complex, conscious, corman, definit, divis, freedom, group, hat, innov, intent, interact, interrel, interrelationship, linkag, midpoint, model, motion, motiv, need, network, nonlinear, oppon, organ, organiz, parent, process, pronomin, psycholog, recognit, recommend, revolutionari, sematech, statement, steinberg, structur, studi, tabl, team, technolog, time, utter |
| representation | 54 | 0.01355 | adequ, approach, artifici, bookman, clariti, collect, conclus, condit, content, cra, descript, design, dimension, discours, effici, evid, exampl, face, favor, final, form, fundament, harrison, hendrick, human, independ, individu, interpret, intersubject, issu, level, lexic, mds, mean, method, network, node, posit, process, question, reader, reason, semant, space, spatial, statist, structur, summari, tabl, techniqu, test, text, valid, word |
| university | 35 | 0.01249 | area, arizona, author, berkeley, california, cambridg, categori, cluster, cognit, colorado, cours, faculti, harvard, icon, illinoi, inform, kevin, kuhn, languagespecif, larg, linguist, ovpr, oxford, press, princeton, professor, research, scholar, stanford, state, student, temp, timothi, today, turkish |
| linguistic | 24 | 0.01230 | analysi, anaphor, approach, bever, comput, constitu, cra, frawley, hahn, input, intuit, lecoeuch, mean, model, phrase, process, refer, research, semant, semanticist, speech, theori, unit, univers |
| example | 41 | 0.01213 | aggreg, author, chain, composit, comput, concern, cooper, cra, discours, discuss, earli, face, forego, health, infer, influenti, interdisciplinari, kind, limit, line, measur, network, particular, phrase, portion, posit, read, recent, represent, sam, second, sentenc, smaller, strategi, studi, text, time, use, vice, way, white |
| techniques | 53 | 0.01212 | agreement, analysi, case, casual, cluster, complex, comput, content, context, convers, cra, critic, data, degre, descript, disagr, discours, extent, face, form, frequencydomain, impact, import, incid, market, messag, minim, model, multidimension, nonparametr, object, observ, outcom, practic, process, quadrat, quantit, relat, represent, research, right, row, spatial, standard, support, tact, text, theoret, third, use, varieti, vector, visual |
| knowledge | 37 | 0.01197 | activ, approach, base, central, co-evolut, concept, conclus, content, develop, dictionari, distribut, divers, e-commerc, effect, field, human, logic, manag, manifest, model, network, organ, organiz, paper, pronomin, prusak, research, resourc, seeker, share, structur, system, text, valid, valuabl, word, work |
| members | 36 | 0.01162 | account, action, addit, assess, check, claim, cluster, communic, compani, compet, day, discurs, exig, faculti, fit, gronn, interact, interdisciplinari, interview, leader, matrix, modif, network, non-ct, oper, organ, resist, school, serious, similar, singl, strategi, subclust, text, wireless, word |
| data | 52 | 0.01154 | aggreg, analysi, attempt, beyer, communic, complex, cra, databas, detail, dyadic, empir, fit, flood, general, gersick, individu, interact, mds, method, model, note, ovpr, particip, purpos, questionnair, reduct, report, research, result, retriev, rich, richard, score, self, sequenc, similar, social, sociolog, sort, strategi, stress, structur, substanti, task, techniqu, text, textual, theori, ther, train, valuabl, warehous |
| way | 50 | 0.01131 | arnold, author, barley, behavior, board, cancer, center, co-occurr, communic, complex, comput, decreas, document, exampl, face, figur, given, group, haphazard, human, industri, insight, local, measur, need, network, new, observ, order, organ, paper, predict, presid, problem, queri, reader, research, reson, scheme, segment, semant, similar, speaker, strateg, text, time, topteam, utter, various, word |
| complex | 50 | 0.01109 | account, adapt, advantag, anderson, approach, associ, assumpt, burt, chang, claim, collect, communic, consequ, convers, cra, data, detect, disciplin, discours, discurs, dooley, explan, hypothes, kuhn, method, model, order, organ, organiz, pattern, phenomena, phrase, portion, possibl, process, research, scale, scope, simpl, simul, spread, structur, studi, system, techniqu, theori, transit, understand, use, way |
| participants | 44 | 0.01099 | adjac, aggreg, analysi, concept, correl, cra, credit, data, discours, distribut, effect, entireti, ethnographi, european, find, half, hand, hat, interpret, interview, like, link, manifest, matric, matrix, motiv, noun, observ, place, qualiti, re, realiz, resourc, respons, semant, sematech, session, smaller, student, subtl, task, text, understand, word |
| utterances | 55 | 0.01098 | aggreg, author, basic, center, chang, coher, communic, compon, connect, convers, cra, determin, differ, entiti, featur, generat, given, group, half, idea, intent, interact, interview, link, major, move, network, next, node, noun, object, organ, pair, particular, phrase, previous, princip, select, sequenc, seri, set, speaker, statement, stream, structur, text, turn, verb, volum, way, whole, word, workday, worth, yield |
| model | 45 | 0.01093 | adapt, anim, applic, approach, assumpt, automata, chang, communic, complex, comput, conting, cra, data, discours, dooley, equilibrium, exchang, group, guid, human, imag, knowledg, larg, linguist, mental, messag, new, organ, panopt, questionnair, scheme, simul, sophist, spatial, subclust, suitabl, surveil, system, task, team, techniqu, textual, theori, unintend, use |
| time | 45 | 0.01055 | activ, analysi, chang, claim, co-occur, collect, communic, convers, document, effect, element, exampl, frequencydomain, gersick, goal, gronn, group, identif, illustr, matter, method, mode, new, number, outcom, pattern, peopl, percept, period, place, pressur, prioriti, recognit, relationship, scope, seri, shortcom, sort, structur, studi, transit, wast, way, word, work |
| journal | 36 | 0.01038 | american, analysi, articl, associ, british, busi, central, communic, concept, descriptor, document, gidden, human, intern, investig, manag, mass, mathemat, medic, network, organiz, perspect, psycholinguist, psycholog, report, research, scalabl, sentenc, social, statist, strateg, strength, text, turan, user, web |
| association | 31 | 0.01008 | acapulco, bigger, chain, co-occurr, collabor, communic, complex, conceptu, cooren, cra, gender, human, interact, intern, journal, littl, matric, meaning, measur, page, pattern, posit, relat, result, san, strength, term, text, washington, woelfel, word |
| paper | 28 | 0.00950 | 15th, abstract, annual, applic, base, basi, collect, cra, dynam, extens, horizon, knowledg, methodolog, organ, preconfer, ream, retriev, sam, scale, scope, stack, studi, term, text, theori, transcrib, way, white |
| applications | 48 | 0.00948 | accuraci, analysi, april, area, array, basi, broader, claim, co-occurr, collect, communic, comput, conclus, cra, develop, distanc, equilibrium, final, general, gersick, group, human, key, linkag, media, medium, method, model, network, new, nonmetr, number, organiz, ovpr, paper, posit, practic, rang, reson, section, simul, social, structur, system, text, third, valid, wide |
| technologies | 23 | 0.00946 | adopt, barley, big, brother, chang, cra, dramat, extrem, hospit, manag, narrat, new, occas, organ, process, promis, realiti, recognit, research, scan, studi, voic, word |
| topteam | 37 | 0.00909 | advoc, anchor, argument, chain, compani, concept, consider, corpor, danger, day, discuss, duti, goal, group, hand, heat, individu, influenc, issu, jack, nerv, number, oppon, palomino, pattern, peopl, point, portion, presid, pronoun, recommend, respons, role, show, upper, way, word |
| positioning | 34 | 0.00885 | answer, applic, approach, associ, author, authorship, catpac, concept, cra, divis, document, dwell, exampl, expertis, extrem, faculti, incumb, infer, influenti, job, mean, method, network, organ, point, promin, relat, relationship, represent, space, strzalkowski, text, vector, word |
| individuals | 32 | 0.00881 | action, central, comment, communic, compani, data, depart, develop, expertis, famili, frame, hand, harm, instanti, interact, loss, nave, network, node, organ, palomino, percept, point, reader, refer, represent, research, respond, result, studi, topteam, user |
| management | 30 | 0.00873 | academi, approach, break, committe, communic, dialogu, discuss, european, half, industri, intern, interpret, journal, knowledg, number, organiz, palomino, perrow, process, professor, quarter, review, sandeland, steinberg, strateg, structur, technolog, top, user, work |
| media | 20 | 0.00866 | analysi, applic, broadcast, cancer, concern, content, cra, fico, find, life, messag, outlet, pictur, portray, print, sourc, stori, structur, talk, transcript |
| coherence | 29 | 0.00865 | aggreg, attribut, center, communic, cra, demand, desir, discours, folger, former, fundament, imposit, interact, latent, latter, local, meaning, pattern, process, repres, sleight, standpoint, stream, structur, text, textual, theori, utter, word |
| york | 12 | 0.00843 | ablex, academ, addison, cambridg, georg, mcgraw, new, ny, oxford, popul, springer, vintag |
| semantic | 40 | 0.00836 | analysi, analyz, approach, barnett, base, case, co-occurr, concern, connect, construct, corpus, creation, dimension, document, field, grammar, hillsdal, index, kaufer, languag, latent, linguist, lsa, machin, network, normal, overal, particip, related, represent, sort, space, structur, symbol, text, theori, train, unit, vector, way |
| documents | 31 | 0.00809 | avail, bag, check, claim, common, detail, differ, enterpris, futur, import, index, journal, kitchen, legitim, length, mean, million, network, opinion, posit, public, read, relat, report, search, semant, set, system, time, way, word |
| important | 45 | 0.00783 | analysi, attent, case, cell, colleagu, communic, concept, connect, convers, corpus, correspond, cra, detail, discours, discurs, document, drawback, event, index, inform, innov, issu, linkag, method, network, object, phenomenon, problem, process, purpos, relev, select, set, shade, similar, simul, statement, structur, tabl, techniqu, text, today, verb, window, word |
| set | 45 | 0.00779 | analysi, approach, author, concept, corpus, cra, criteria, cue, distanc, document, element, entir, equival, final, immens, import, influenc, issu, kl, larg, link, manner, map, matrix, mds, messag, network, node, object, organ, point, possibl, research, respons, rule, scholar, sentenc, statement, text, textual, train, unimport, utter, word, yield |
| influence | 45 | 0.00737 | abil, analysi, assess, between, central, close, concept, concern, corman, correspond, cycl, decreas, favor, frequenc, graph, high, highest, human, idea, ij, interrelationship, level, linkag, low, lower, messag, network, node, number, organiz, pair, place, process, relat, reson, score, seri, set, structur, text, topteam, valu, verb, weight, word |
| meanings | 38 | 0.00724 | analysi, approach, attempt, basi, boundari, conceptu, constraint, content, cooper, coordin, cue, document, domain, effect, flexibl, flow, foundat, framework, human, input, level, linguist, materi, meet, metaphor, opposit, overal, posit, program, referenti, represent, sequenc, shift, tag, text, topic, vector, word |
| terms | 28 | 0.00719 | approach, associ, buckley, communic, conduit, connect, cra, incumb, indic, influenti, link, new, organ, pair, paper, pattern, reader, relev, research, scienc, sentenc, shift, tempor, text, use, web, weight, word |
| value | 26 | 0.00717 | cell, central, correct, cra, decomposit, differ, equat, estim, gronn, heurist, ij, influenc, issu, link, matrix, number, pair, princip, sens, singular, small, text, true, weight, word, workday |
| patterns | 32 | 0.00715 | account, associ, co-occurr, coher, communic, complex, connect, consist, cultur, due, dynam, dysfunct, figur, friendship, interact, italian, manifest, micropractic, noun, ontolog, pathogen, reader, rule, similar, spread, structur, subtl, term, text, time, topteam, verb |
| introduction | 18 | 0.00714 | amsterdam, carley, communic, cra, discuss, hirokawa, interact, laham, languag, latent, mong, optim, process, sequenti, special, studi, theori, typolog |
| observations | 30 | 0.00711 | archiv, beyer, case, communic, compet, cost, cra, ct, demand, evid, foci, gottman, horizon, inform, instanc, interact, interview, larg, limit, messag, method, particip, size, social, substitut, techniqu, theori, unit, volum, way |
| authors | 35 | 0.00708 | act, aim, compani, compet, connect, correspond, domain, exampl, group, higherord, hugh, link, linkag, method, oblig, phrase, posit, possibl, power, process, rational, reson, respect, sens, set, similar, speaker, text, theori, ulrik, univers, utter, way, window, word |
| issue | 27 | 0.00701 | area, biochem, code, communic, concern, critic, disconnect, discuss, electron, ethic, expertis, finger, first, import, measur, negoti, organ, reader, represent, set, special, stock, topteam, valu, view, window, worrisom |
| april | 23 | 0.00663 | applic, argument, case, collegi, compani, correl, davenport, edit, figur, intern, jurafski, lthough, multiyear, nicat, process, program, reader, research, scale, text, tional, velop, word |
| case | 42 | 0.00653 | abstract, analyst, appropri, april, articl, basi, center, central, choic, correl, cra, disambigu, discuss, edg, entri, flow, import, index, local, major, matric, multidimension, need, network, noun, observ, organ, pair, phrase, practic, pronoun, record, respons, semant, sematech, sequenti, similar, speaker, studi, techniqu, white, word |
| concepts | 39 | 0.00645 | analysi, anthoniss, assumpt, chain, comput, differ, discours, distanc, entiti, figur, identif, import, influenc, influenti, interrelationship, ital, journal, knowledg, linkag, main, move, nerv, network, organ, particip, point, posit, process, relev, robert, set, space, specif, stablein, stephen, text, topteam, various, word |
| number | 42 | 0.00634 | addit, analysi, applic, approach, averag, base, basi, categori, compet, conceptu, dimens, distinct, equival, ethnograph, high, ij, influenc, jk, larg, length, manag, natur, network, page, path, respond, scale, score, shortest, similar, spatial, step, time, topteam, transcript, use, valu, verb, visual, wise, word, workweek |
| use | 40 | 0.00580 | bayesian, benign, best, beyer, broader, cluster, common, complex, content, context, cra, critic, domain, drawback, exampl, express, interact, lsa, manifest, method, model, necessari, number, procedur, refer, research, resourc, scholar, shift, sourc, spatial, structur, system, techniqu, term, textual, varieti, verb, window, word |
| centrality | 30 | 0.00580 | averag, between, case, classic, close, concern, degre, entir, extent, freeman, gidden, given, graph, individu, influenc, inform, journal, knowledg, measur, method, moment, node, problem, research, social, task, valu, wasserman, white, zelen |
| company | 27 | 0.00563 | advoc, april, author, chairman, chang, consortium, decreas, event, gumption, haphazard, hundr, individu, industri, member, mr, parent, particular, practic, present, presid, refer, resourc, standard, topteam, viewpoint, weak, word |
| collective | 34 | 0.00548 | analysi, applic, cognit, communic, complex, conceptu, control, convers, corpora, cra, discours, factor, interdepend, level, method, mind, oper, paper, percept, phenomena, pressur, process, relat, represent, reson, robert, small, social, space, structur, system, text, time, urgenc |
| danowski | 18 | 0.00545 | ablex, analysi, barnett, carley, colleagu, fanci, galal, md, metaphor, network, organiz, rice, structur, studi, west, wordij, work, yearbook |
| content | 36 | 0.00541 | analysi, approach, area, autom, carley, casual, challeng, communic, comput, descript, essenti, general, interest, knowledg, larg, latent, manifest, mean, meaning, media, messag, methodolog, network, origin, practic, procedur, quantit, represent, richard, sens, structur, system, techniqu, text, use, word |
| forms | 31 | 0.00537 | account, base, basi, basic, connect, cra, develop, differ, dynam, edit, es, figur, grammat, innov, method, network, nois, organ, organiz, question, recommend, represent, root, second, similar, singular, sourc, structur, tag, techniqu, text |
| centers | 32 | 0.00536 | assumpt, attent, case, cluster, coher, communic, concern, discours, go, group, japanes, link, matrix, name, next, node, noun, particular, phrase, predict, previous, process, pronoun, rank, sentenc, speaker, statement, stream, turkish, utter, way, word |
| units | 19 | 0.00527 | affair, analysi, attempt, clarendon, codabl, constitu, cra, dyad, focal, grammat, linguist, nation, observ, presid, semant, speaker, state, structur, word |
| development | 29 | 0.00516 | academi, action, algorithm, applic, beyer, cheney, communic, comput, convers, decis, diction, discours, form, foundat, gersick, group, individu, inform, knowledg, littl, point, proprietari, recent, small, stage, surveil, task, theoret, voic |
| board | 11 | 0.00513 | bulletin, canada, chairman, communic, comput, film, futur, nation, recommend, sam, way |

## Data (machine-readable — do not edit)

```json
{
 "schema": "crawdad-cra",
 "schemaVersion": "1.0",
 "source": {
  "filename": "jhc2002.pdf",
  "processedAt": "2026-07-09T18:42:22.927Z",
  "appVersion": "0.2.0-M2"
 },
 "parameters": {
  "stemming": "porter",
  "pronouns": false,
  "interSentenceLinking": true,
  "tokenizationFile": null,
  "stopWordList": "default"
 },
 "network": {
  "nodes": [
   {
    "id": 0,
    "word": "corman",
    "display": "corman",
    "degree": 40,
    "influence": 0.01827
   },
   {
    "id": 1,
    "word": "reson",
    "display": "resonance",
    "degree": 30,
    "influence": 0.00376
   },
   {
    "id": 2,
    "word": "analysi",
    "display": "analysis",
    "degree": 141,
    "influence": 0.07075
   },
   {
    "id": 3,
    "word": "human",
    "display": "human",
    "degree": 56,
    "influence": 0.02099
   },
   {
    "id": 4,
    "word": "communic",
    "display": "communication",
    "degree": 171,
    "influence": 0.10545
   },
   {
    "id": 5,
    "word": "research",
    "display": "research",
    "degree": 116,
    "influence": 0.06256
   },
   {
    "id": 6,
    "word": "april",
    "display": "april",
    "degree": 23,
    "influence": 0.00663
   },
   {
    "id": 7,
    "word": "intern",
    "display": "international",
    "degree": 10,
    "influence": 0.0005
   },
   {
    "id": 8,
    "word": "associ",
    "display": "association",
    "degree": 31,
    "influence": 0.01008
   },
   {
    "id": 9,
    "word": "complex",
    "display": "complex",
    "degree": 50,
    "influence": 0.01109
   },
   {
    "id": 10,
    "word": "discurs",
    "display": "discursive",
    "degree": 19,
    "influence": 0.0011
   },
   {
    "id": 11,
    "word": "system",
    "display": "systems",
    "degree": 64,
    "influence": 0.01981
   },
   {
    "id": 12,
    "word": "steven",
    "display": "steven",
    "degree": 3,
    "influence": 0.00003
   },
   {
    "id": 13,
    "word": "arizona",
    "display": "arizona",
    "degree": 10,
    "influence": 0.00226
   },
   {
    "id": 14,
    "word": "state",
    "display": "state",
    "degree": 6,
    "influence": 0.00165
   },
   {
    "id": 15,
    "word": "univers",
    "display": "university",
    "degree": 35,
    "influence": 0.01249
   },
   {
    "id": 16,
    "word": "timothi",
    "display": "timothy",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 17,
    "word": "kuhn",
    "display": "kuhn",
    "degree": 7,
    "influence": 0.00104
   },
   {
    "id": 18,
    "word": "colorado",
    "display": "colorado",
    "degree": 2,
    "influence": 0.00011
   },
   {
    "id": 19,
    "word": "boulder",
    "display": "boulder",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 20,
    "word": "robert",
    "display": "roberts",
    "degree": 8,
    "influence": 0.00187
   },
   {
    "id": 21,
    "word": "mcphee",
    "display": "mcphee",
    "degree": 15,
    "influence": 0.00362
   },
   {
    "id": 22,
    "word": "kevin",
    "display": "kevin",
    "degree": 3,
    "influence": 0.00008
   },
   {
    "id": 23,
    "word": "dooley",
    "display": "dooley",
    "degree": 13,
    "influence": 0.0033
   },
   {
    "id": 24,
    "word": "scholar",
    "display": "scholars",
    "degree": 14,
    "influence": 0.00106
   },
   {
    "id": 25,
    "word": "power",
    "display": "power",
    "degree": 7,
    "influence": 0.00042
   },
   {
    "id": 26,
    "word": "structur",
    "display": "structure",
    "degree": 102,
    "influence": 0.04591
   },
   {
    "id": 27,
    "word": "social",
    "display": "social",
    "degree": 48,
    "influence": 0.01462
   },
   {
    "id": 28,
    "word": "collect",
    "display": "collective",
    "degree": 34,
    "influence": 0.00548
   },
   {
    "id": 29,
    "word": "factor",
    "display": "factors",
    "degree": 6,
    "influence": 0.00011
   },
   {
    "id": 30,
    "word": "theori",
    "display": "theory",
    "degree": 76,
    "influence": 0.02871
   },
   {
    "id": 31,
    "word": "limit",
    "display": "limitations",
    "degree": 14,
    "influence": 0.00127
   },
   {
    "id": 32,
    "word": "scope",
    "display": "scope",
    "degree": 13,
    "influence": 0.00052
   },
   {
    "id": 33,
    "word": "rang",
    "display": "range",
    "degree": 17,
    "influence": 0.00197
   },
   {
    "id": 34,
    "word": "method",
    "display": "methods",
    "degree": 88,
    "influence": 0.03068
   },
   {
    "id": 35,
    "word": "larg",
    "display": "large",
    "degree": 26,
    "influence": 0.0036
   },
   {
    "id": 36,
    "word": "volum",
    "display": "volumes",
    "degree": 13,
    "influence": 0.00062
   },
   {
    "id": 37,
    "word": "small",
    "display": "small",
    "degree": 12,
    "influence": 0.00151
   },
   {
    "id": 38,
    "word": "cra",
    "display": "cra",
    "degree": 156,
    "influence": 0.08112
   },
   {
    "id": 39,
    "word": "new",
    "display": "new",
    "degree": 45,
    "influence": 0.02517
   },
   {
    "id": 40,
    "word": "text",
    "display": "text",
    "degree": 196,
    "influence": 0.09627
   },
   {
    "id": 41,
    "word": "broad",
    "display": "broad",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 42,
    "word": "quantiti",
    "display": "quantities",
    "degree": 6,
    "influence": 0.00058
   },
   {
    "id": 43,
    "word": "transcrib",
    "display": "transcribed",
    "degree": 11,
    "influence": 0.00104
   },
   {
    "id": 44,
    "word": "convers",
    "display": "conversation",
    "degree": 51,
    "influence": 0.01771
   },
   {
    "id": 45,
    "word": "import",
    "display": "important",
    "degree": 45,
    "influence": 0.00783
   },
   {
    "id": 46,
    "word": "word",
    "display": "words",
    "degree": 180,
    "influence": 0.08596
   },
   {
    "id": 47,
    "word": "network",
    "display": "network",
    "degree": 125,
    "influence": 0.06353
   },
   {
    "id": 48,
    "word": "properti",
    "display": "property",
    "degree": 13,
    "influence": 0.00181
   },
   {
    "id": 49,
    "word": "number",
    "display": "number",
    "degree": 42,
    "influence": 0.00634
   },
   {
    "id": 50,
    "word": "spatial",
    "display": "spatial",
    "degree": 11,
    "influence": 0.00067
   },
   {
    "id": 51,
    "word": "critiqu",
    "display": "critique",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 52,
    "word": "methodolog",
    "display": "methodological",
    "degree": 12,
    "influence": 0.00109
   },
   {
    "id": 53,
    "word": "paper",
    "display": "paper",
    "degree": 28,
    "influence": 0.0095
   },
   {
    "id": 54,
    "word": "basi",
    "display": "basis",
    "degree": 17,
    "influence": 0.00088
   },
   {
    "id": 55,
    "word": "oper",
    "display": "operational",
    "degree": 8,
    "influence": 0.00116
   },
   {
    "id": 56,
    "word": "detail",
    "display": "detailed",
    "degree": 17,
    "influence": 0.00065
   },
   {
    "id": 57,
    "word": "advantag",
    "display": "advantages",
    "degree": 7,
    "influence": 0.00027
   },
   {
    "id": 58,
    "word": "relat",
    "display": "relations",
    "degree": 23,
    "influence": 0.00413
   },
   {
    "id": 59,
    "word": "techniqu",
    "display": "techniques",
    "degree": 53,
    "influence": 0.01212
   },
   {
    "id": 60,
    "word": "face",
    "display": "face",
    "degree": 6,
    "influence": 0.00005
   },
   {
    "id": 61,
    "word": "valid",
    "display": "validity",
    "degree": 20,
    "influence": 0.00115
   },
   {
    "id": 62,
    "word": "represent",
    "display": "representation",
    "degree": 54,
    "influence": 0.01355
   },
   {
    "id": 63,
    "word": "util",
    "display": "utility",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 64,
    "word": "organiz",
    "display": "organizational",
    "degree": 59,
    "influence": 0.02257
   },
   {
    "id": 65,
    "word": "knowledg",
    "display": "knowledge",
    "degree": 37,
    "influence": 0.01197
   },
   {
    "id": 66,
    "word": "conclus",
    "display": "conclusion",
    "degree": 13,
    "influence": 0.00162
   },
   {
    "id": 67,
    "word": "applic",
    "display": "applications",
    "degree": 48,
    "influence": 0.00948
   },
   {
    "id": 68,
    "word": "context",
    "display": "contexts",
    "degree": 27,
    "influence": 0.0038
   },
   {
    "id": 69,
    "word": "use",
    "display": "use",
    "degree": 40,
    "influence": 0.0058
   },
   {
    "id": 70,
    "word": "broader",
    "display": "broader",
    "degree": 7,
    "influence": 0.00016
   },
   {
    "id": 71,
    "word": "media",
    "display": "media",
    "degree": 20,
    "influence": 0.00866
   },
   {
    "id": 72,
    "word": "content",
    "display": "content",
    "degree": 36,
    "influence": 0.00541
   },
   {
    "id": 73,
    "word": "comput",
    "display": "computer",
    "degree": 51,
    "influence": 0.0219
   },
   {
    "id": 74,
    "word": "simul",
    "display": "simulations",
    "degree": 19,
    "influence": 0.00395
   },
   {
    "id": 75,
    "word": "model",
    "display": "model",
    "degree": 45,
    "influence": 0.01093
   },
   {
    "id": 76,
    "word": "professor",
    "display": "professor",
    "degree": 9,
    "influence": 0.00116
   },
   {
    "id": 77,
    "word": "hugh",
    "display": "hugh",
    "degree": 4,
    "influence": 0.00031
   },
   {
    "id": 78,
    "word": "down",
    "display": "downs",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 79,
    "word": "school",
    "display": "school",
    "degree": 11,
    "influence": 0.00231
   },
   {
    "id": 80,
    "word": "assist",
    "display": "assistant",
    "degree": 4,
    "influence": 0.0001
   },
   {
    "id": 81,
    "word": "manag",
    "display": "management",
    "degree": 30,
    "influence": 0.00873
   },
   {
    "id": 82,
    "word": "industri",
    "display": "industry",
    "degree": 11,
    "influence": 0.00223
   },
   {
    "id": 83,
    "word": "engin",
    "display": "engineering",
    "degree": 4,
    "influence": 0.00008
   },
   {
    "id": 84,
    "word": "grant",
    "display": "grants",
    "degree": 4,
    "influence": 0.00021
   },
   {
    "id": 85,
    "word": "colleg",
    "display": "college",
    "degree": 8,
    "influence": 0.00046
   },
   {
    "id": 86,
    "word": "public",
    "display": "public",
    "degree": 10,
    "influence": 0.00065
   },
   {
    "id": 87,
    "word": "program",
    "display": "program",
    "degree": 15,
    "influence": 0.00202
   },
   {
    "id": 88,
    "word": "offic",
    "display": "office",
    "degree": 7,
    "influence": 0.00232
   },
   {
    "id": 89,
    "word": "vice-provost",
    "display": "vice-provost",
    "degree": 2,
    "influence": 0.0004
   },
   {
    "id": 90,
    "word": "author",
    "display": "authors",
    "degree": 35,
    "influence": 0.00708
   },
   {
    "id": 91,
    "word": "ulrik",
    "display": "ulrik",
    "degree": 2,
    "influence": 0.00008
   },
   {
    "id": 92,
    "word": "brand",
    "display": "brandes",
    "degree": 4,
    "influence": 0.00006
   },
   {
    "id": 93,
    "word": "valuabl",
    "display": "valuable",
    "degree": 10,
    "influence": 0.00098
   },
   {
    "id": 94,
    "word": "advic",
    "display": "advice",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 95,
    "word": "softwar",
    "display": "software",
    "degree": 6,
    "influence": 0.0014
   },
   {
    "id": 96,
    "word": "correspond",
    "display": "corresponding",
    "degree": 17,
    "influence": 0.00169
   },
   {
    "id": 97,
    "word": "box",
    "display": "box",
    "degree": 4,
    "influence": 0.00046
   },
   {
    "id": 98,
    "word": "temp",
    "display": "tempe",
    "degree": 3,
    "influence": 0.00019
   },
   {
    "id": 99,
    "word": "az",
    "display": "az",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 100,
    "word": "email",
    "display": "email",
    "degree": 4,
    "influence": 0.00124
   },
   {
    "id": 101,
    "word": "lthough",
    "display": "lthough",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 102,
    "word": "exchang",
    "display": "exchange",
    "degree": 8,
    "influence": 0.00018
   },
   {
    "id": 103,
    "word": "interpret",
    "display": "interpretation",
    "degree": 23,
    "influence": 0.00332
   },
   {
    "id": 104,
    "word": "messag",
    "display": "messages",
    "degree": 21,
    "influence": 0.00194
   },
   {
    "id": 105,
    "word": "recent",
    "display": "recent",
    "degree": 7,
    "influence": 0.00017
   },
   {
    "id": 106,
    "word": "theoret",
    "display": "theoretical",
    "degree": 14,
    "influence": 0.00114
   },
   {
    "id": 107,
    "word": "develop",
    "display": "development",
    "degree": 29,
    "influence": 0.00516
   },
   {
    "id": 108,
    "word": "littl",
    "display": "little",
    "degree": 14,
    "influence": 0.00166
   },
   {
    "id": 109,
    "word": "doubt",
    "display": "doubt",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 110,
    "word": "relationship",
    "display": "relationships",
    "degree": 37,
    "influence": 0.01477
   },
   {
    "id": 111,
    "word": "account",
    "display": "account",
    "degree": 20,
    "influence": 0.00133
   },
   {
    "id": 112,
    "word": "discours",
    "display": "discourse",
    "degree": 65,
    "influence": 0.01991
   },
   {
    "id": 113,
    "word": "elli",
    "display": "ellis",
    "degree": 3,
    "influence": 0.0001
   },
   {
    "id": 114,
    "word": "empir",
    "display": "empirical",
    "degree": 13,
    "influence": 0.00072
   },
   {
    "id": 115,
    "word": "organ",
    "display": "organization",
    "degree": 84,
    "influence": 0.03424
   },
   {
    "id": 116,
    "word": "level",
    "display": "level",
    "degree": 29,
    "influence": 0.00486
   },
   {
    "id": 117,
    "word": "construct",
    "display": "construction",
    "degree": 8,
    "influence": 0.00107
   },
   {
    "id": 118,
    "word": "class",
    "display": "class",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 119,
    "word": "ethnic",
    "display": "ethnicity",
    "degree": 3,
    "influence": 0.00006
   },
   {
    "id": 120,
    "word": "product",
    "display": "production",
    "degree": 10,
    "influence": 0.00338
   },
   {
    "id": 121,
    "word": "micro-practic",
    "display": "micro-practices",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 122,
    "word": "issu",
    "display": "issue",
    "degree": 27,
    "influence": 0.00701
   },
   {
    "id": 123,
    "word": "critic",
    "display": "critical",
    "degree": 16,
    "influence": 0.00085
   },
   {
    "id": 124,
    "word": "studi",
    "display": "study",
    "degree": 65,
    "influence": 0.0227
   },
   {
    "id": 125,
    "word": "foucault",
    "display": "foucault",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 126,
    "word": "idea",
    "display": "idea",
    "degree": 20,
    "influence": 0.0026
   },
   {
    "id": 127,
    "word": "format",
    "display": "formations",
    "degree": 6,
    "influence": 0.00007
   },
   {
    "id": 128,
    "word": "influenti",
    "display": "influential",
    "degree": 9,
    "influence": 0.00013
   },
   {
    "id": 129,
    "word": "exampl",
    "display": "example",
    "degree": 41,
    "influence": 0.01213
   },
   {
    "id": 130,
    "word": "review",
    "display": "review",
    "degree": 17,
    "influence": 0.00361
   },
   {
    "id": 131,
    "word": "taylor",
    "display": "taylor",
    "degree": 4,
    "influence": 0.00119
   },
   {
    "id": 132,
    "word": "flanagin",
    "display": "flanagin",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 133,
    "word": "cheney",
    "display": "cheney",
    "degree": 4,
    "influence": 0.00051
   },
   {
    "id": 134,
    "word": "seibold",
    "display": "seibold",
    "degree": 3,
    "influence": 0.00046
   },
   {
    "id": 135,
    "word": "call",
    "display": "call",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 136,
    "word": "elabor",
    "display": "elaboration",
    "degree": 2,
    "influence": 0.0008
   },
   {
    "id": 137,
    "word": "approach",
    "display": "approach",
    "degree": 97,
    "influence": 0.03523
   },
   {
    "id": 138,
    "word": "attent",
    "display": "attention",
    "degree": 14,
    "influence": 0.00055
   },
   {
    "id": 139,
    "word": "field",
    "display": "field",
    "degree": 15,
    "influence": 0.00184
   },
   {
    "id": 140,
    "word": "group",
    "display": "group",
    "degree": 79,
    "influence": 0.02788
   },
   {
    "id": 141,
    "word": "form",
    "display": "forms",
    "degree": 31,
    "influence": 0.00537
   },
   {
    "id": 142,
    "word": "microanalyt",
    "display": "microanalytic",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 143,
    "word": "area",
    "display": "area",
    "degree": 14,
    "influence": 0.00158
   },
   {
    "id": 144,
    "word": "interperson",
    "display": "interpersonal",
    "degree": 8,
    "influence": 0.00018
   },
   {
    "id": 145,
    "word": "person",
    "display": "personal",
    "degree": 16,
    "influence": 0.00129
   },
   {
    "id": 146,
    "word": "grow",
    "display": "growing",
    "degree": 4,
    "influence": 0.00007
   },
   {
    "id": 147,
    "word": "concern",
    "display": "concern",
    "degree": 16,
    "influence": 0.00225
   },
   {
    "id": 148,
    "word": "influenc",
    "display": "influence",
    "degree": 45,
    "influence": 0.00737
   },
   {
    "id": 149,
    "word": "phenomena",
    "display": "phenomena",
    "degree": 14,
    "influence": 0.00055
   },
   {
    "id": 150,
    "word": "assumpt",
    "display": "assumption",
    "degree": 22,
    "influence": 0.00147
   },
   {
    "id": 151,
    "word": "variabl",
    "display": "variables",
    "degree": 8,
    "influence": 0.0015
   },
   {
    "id": 152,
    "word": "process",
    "display": "processes",
    "degree": 80,
    "influence": 0.02989
   },
   {
    "id": 153,
    "word": "subsystem",
    "display": "subsystems",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 154,
    "word": "activ",
    "display": "activity",
    "degree": 18,
    "influence": 0.00351
   },
   {
    "id": 155,
    "word": "time",
    "display": "time",
    "degree": 45,
    "influence": 0.01055
   },
   {
    "id": 156,
    "word": "element",
    "display": "elements",
    "degree": 27,
    "influence": 0.00425
   },
   {
    "id": 157,
    "word": "control",
    "display": "control",
    "degree": 10,
    "influence": 0.00053
   },
   {
    "id": 158,
    "word": "interdepend",
    "display": "interdependent",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 159,
    "word": "environ",
    "display": "environment",
    "degree": 4,
    "influence": 0.00008
   },
   {
    "id": 160,
    "word": "circumst",
    "display": "circumstances",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 161,
    "word": "particular",
    "display": "particular",
    "degree": 23,
    "influence": 0.00344
   },
   {
    "id": 162,
    "word": "perspect",
    "display": "perspectives",
    "degree": 6,
    "influence": 0.00134
   },
   {
    "id": 163,
    "word": "hospit",
    "display": "hospital",
    "degree": 13,
    "influence": 0.00147
   },
   {
    "id": 164,
    "word": "emerg",
    "display": "emergent",
    "degree": 15,
    "influence": 0.0034
   },
   {
    "id": 165,
    "word": "individu",
    "display": "individuals",
    "degree": 32,
    "influence": 0.00881
   },
   {
    "id": 166,
    "word": "point",
    "display": "point",
    "degree": 23,
    "influence": 0.00238
   },
   {
    "id": 167,
    "word": "problem",
    "display": "problem",
    "degree": 25,
    "influence": 0.00432
   },
   {
    "id": 168,
    "word": "horizon",
    "display": "horizon",
    "degree": 5,
    "influence": 0.00007
   },
   {
    "id": 169,
    "word": "manifest",
    "display": "manifest",
    "degree": 15,
    "influence": 0.0008
   },
   {
    "id": 170,
    "word": "behavior",
    "display": "behavior",
    "degree": 25,
    "influence": 0.0016
   },
   {
    "id": 171,
    "word": "modest",
    "display": "modest",
    "degree": 4,
    "influence": 0.00007
   },
   {
    "id": 172,
    "word": "scale",
    "display": "scaling",
    "degree": 25,
    "influence": 0.00408
   },
   {
    "id": 173,
    "word": "aggreg",
    "display": "aggregation",
    "degree": 18,
    "influence": 0.00113
   },
   {
    "id": 174,
    "word": "principl",
    "display": "principle",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 175,
    "word": "appar",
    "display": "apparent",
    "degree": 3,
    "influence": 0.00013
   },
   {
    "id": 176,
    "word": "invers",
    "display": "inverse",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 177,
    "word": "interact",
    "display": "interaction",
    "degree": 66,
    "influence": 0.02399
   },
   {
    "id": 178,
    "word": "greatest",
    "display": "greatest",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 179,
    "word": "focus",
    "display": "focus",
    "degree": 8,
    "influence": 0.00047
   },
   {
    "id": 180,
    "word": "difficulti",
    "display": "difficulty",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 181,
    "word": "less",
    "display": "less",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 182,
    "word": "disciplin",
    "display": "discipline",
    "degree": 12,
    "influence": 0.00067
   },
   {
    "id": 183,
    "word": "multigroup",
    "display": "multigroup",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 184,
    "word": "guid",
    "display": "guides",
    "degree": 4,
    "influence": 0.00011
   },
   {
    "id": 185,
    "word": "exist",
    "display": "existing",
    "degree": 4,
    "influence": 0.00006
   },
   {
    "id": 186,
    "word": "bodi",
    "display": "body",
    "degree": 5,
    "influence": 0.00009
   },
   {
    "id": 187,
    "word": "articl",
    "display": "article",
    "degree": 12,
    "influence": 0.00114
   },
   {
    "id": 188,
    "word": "general",
    "display": "general",
    "degree": 22,
    "influence": 0.00464
   },
   {
    "id": 189,
    "word": "analyt",
    "display": "analytic",
    "degree": 6,
    "influence": 0.00018
   },
   {
    "id": 190,
    "word": "framework",
    "display": "framework",
    "degree": 9,
    "influence": 0.0009
   },
   {
    "id": 191,
    "word": "flexibl",
    "display": "flexible",
    "degree": 5,
    "influence": 0.0001
   },
   {
    "id": 192,
    "word": "mean",
    "display": "meanings",
    "degree": 38,
    "influence": 0.00724
   },
   {
    "id": 193,
    "word": "set",
    "display": "set",
    "degree": 45,
    "influence": 0.00779
   },
   {
    "id": 194,
    "word": "formal",
    "display": "formalized",
    "degree": 4,
    "influence": 0
   },
   {
    "id": 195,
    "word": "report",
    "display": "reports",
    "degree": 16,
    "influence": 0.00231
   },
   {
    "id": 196,
    "word": "letter",
    "display": "letters",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 197,
    "word": "memo",
    "display": "memos",
    "degree": 6,
    "influence": 0.00017
   },
   {
    "id": 198,
    "word": "voic",
    "display": "voice",
    "degree": 9,
    "influence": 0.00028
   },
   {
    "id": 199,
    "word": "recognit",
    "display": "recognition",
    "degree": 7,
    "influence": 0.00053
   },
   {
    "id": 200,
    "word": "technolog",
    "display": "technologies",
    "degree": 23,
    "influence": 0.00946
   },
   {
    "id": 201,
    "word": "promis",
    "display": "promise",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 202,
    "word": "abil",
    "display": "ability",
    "degree": 12,
    "influence": 0.00076
   },
   {
    "id": 203,
    "word": "textual",
    "display": "textual",
    "degree": 19,
    "influence": 0.00237
   },
   {
    "id": 204,
    "word": "need",
    "display": "need",
    "degree": 9,
    "influence": 0.00013
   },
   {
    "id": 205,
    "word": "ground",
    "display": "ground",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 206,
    "word": "argument",
    "display": "arguments",
    "degree": 21,
    "influence": 0.00271
   },
   {
    "id": 207,
    "word": "rhetor",
    "display": "rhetoric",
    "degree": 7,
    "influence": 0.00057
   },
   {
    "id": 208,
    "word": "mass",
    "display": "mass",
    "degree": 7,
    "influence": 0.0002
   },
   {
    "id": 209,
    "word": "microlevel",
    "display": "microlevel",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 210,
    "word": "next",
    "display": "next",
    "degree": 13,
    "influence": 0.00118
   },
   {
    "id": 211,
    "word": "section",
    "display": "section",
    "degree": 10,
    "influence": 0.00041
   },
   {
    "id": 212,
    "word": "ethnographi",
    "display": "ethnography",
    "degree": 8,
    "influence": 0.00111
   },
   {
    "id": 213,
    "word": "questionnair",
    "display": "questionnaires",
    "degree": 14,
    "influence": 0.00089
   },
   {
    "id": 214,
    "word": "task",
    "display": "task",
    "degree": 31,
    "influence": 0.00469
   },
   {
    "id": 215,
    "word": "test",
    "display": "test",
    "degree": 20,
    "influence": 0.00371
   },
   {
    "id": 216,
    "word": "claim",
    "display": "claims",
    "degree": 19,
    "influence": 0.00232
   },
   {
    "id": 217,
    "word": "definit",
    "display": "definitions",
    "degree": 9,
    "influence": 0.00042
   },
   {
    "id": 218,
    "word": "meet",
    "display": "meeting",
    "degree": 14,
    "influence": 0.0012
   },
   {
    "id": 219,
    "word": "comparison",
    "display": "comparison",
    "degree": 5,
    "influence": 0.00004
   },
   {
    "id": 220,
    "word": "read",
    "display": "reading",
    "degree": 14,
    "influence": 0.00192
   },
   {
    "id": 221,
    "word": "interview",
    "display": "interviews",
    "degree": 26,
    "influence": 0.0033
   },
   {
    "id": 222,
    "word": "uncov",
    "display": "uncovering",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 223,
    "word": "interdisciplinari",
    "display": "interdisciplinary",
    "degree": 8,
    "influence": 0.00015
   },
   {
    "id": 224,
    "word": "like",
    "display": "likely",
    "degree": 6,
    "influence": 0.00028
   },
   {
    "id": 225,
    "word": "illustr",
    "display": "illustration",
    "degree": 10,
    "influence": 0.0005
   },
   {
    "id": 226,
    "word": "difficult",
    "display": "difficult",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 227,
    "word": "understand",
    "display": "understanding",
    "degree": 25,
    "influence": 0.00437
   },
   {
    "id": 228,
    "word": "beyer",
    "display": "beyer",
    "degree": 18,
    "influence": 0.00171
   },
   {
    "id": 229,
    "word": "velop",
    "display": "velopment",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 230,
    "word": "standard",
    "display": "standards",
    "degree": 16,
    "influence": 0.00472
   },
   {
    "id": 231,
    "word": "sematech",
    "display": "sematech",
    "degree": 20,
    "influence": 0.00438
   },
   {
    "id": 232,
    "word": "consortium",
    "display": "consortium",
    "degree": 4,
    "influence": 0.00127
   },
   {
    "id": 233,
    "word": "supplier",
    "display": "suppliers",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 234,
    "word": "manufactur",
    "display": "manufacturers",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 235,
    "word": "semiconductor",
    "display": "semiconductor",
    "degree": 3,
    "influence": 0.00118
   },
   {
    "id": 236,
    "word": "aim",
    "display": "aim",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 237,
    "word": "event",
    "display": "events",
    "degree": 15,
    "influence": 0.00184
   },
   {
    "id": 238,
    "word": "compani",
    "display": "company",
    "degree": 27,
    "influence": 0.00563
   },
   {
    "id": 239,
    "word": "coordin",
    "display": "coordination",
    "degree": 5,
    "influence": 0.00009
   },
   {
    "id": 240,
    "word": "cooper",
    "display": "cooperation",
    "degree": 9,
    "influence": 0.00071
   },
   {
    "id": 241,
    "word": "adopt",
    "display": "adoption",
    "degree": 4,
    "influence": 0.00107
   },
   {
    "id": 242,
    "word": "heart",
    "display": "heart",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 243,
    "word": "incid",
    "display": "incident",
    "degree": 5,
    "influence": 0.00004
   },
   {
    "id": 244,
    "word": "outcom",
    "display": "outcomes",
    "degree": 8,
    "influence": 0.00027
   },
   {
    "id": 245,
    "word": "year",
    "display": "years",
    "degree": 8,
    "influence": 0.00085
   },
   {
    "id": 246,
    "word": "observ",
    "display": "observations",
    "degree": 30,
    "influence": 0.00711
   },
   {
    "id": 247,
    "word": "archiv",
    "display": "archival",
    "degree": 4,
    "influence": 0.00054
   },
   {
    "id": 248,
    "word": "materi",
    "display": "material",
    "degree": 8,
    "influence": 0.00121
   },
   {
    "id": 249,
    "word": "member",
    "display": "members",
    "degree": 36,
    "influence": 0.01162
   },
   {
    "id": 250,
    "word": "check",
    "display": "checks",
    "degree": 4,
    "influence": 0.00013
   },
   {
    "id": 251,
    "word": "document",
    "display": "documents",
    "degree": 31,
    "influence": 0.00809
   },
   {
    "id": 252,
    "word": "search",
    "display": "searches",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 253,
    "word": "support",
    "display": "support",
    "degree": 8,
    "influence": 0.00066
   },
   {
    "id": 254,
    "word": "way",
    "display": "way",
    "degree": 50,
    "influence": 0.01131
   },
   {
    "id": 255,
    "word": "team",
    "display": "team",
    "degree": 14,
    "influence": 0.00065
   },
   {
    "id": 256,
    "word": "chang",
    "display": "change",
    "degree": 45,
    "influence": 0.01401
   },
   {
    "id": 257,
    "word": "conscious",
    "display": "consciousness",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 258,
    "word": "action",
    "display": "action",
    "degree": 18,
    "influence": 0.00182
   },
   {
    "id": 259,
    "word": "constraint",
    "display": "constraints",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 260,
    "word": "oblig",
    "display": "obligations",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 261,
    "word": "symbol",
    "display": "symbols",
    "degree": 8,
    "influence": 0.00037
   },
   {
    "id": 262,
    "word": "characterist",
    "display": "characteristics",
    "degree": 6,
    "influence": 0.00018
   },
   {
    "id": 263,
    "word": "ethnograph",
    "display": "ethnographic",
    "degree": 8,
    "influence": 0.00029
   },
   {
    "id": 264,
    "word": "insight",
    "display": "insights",
    "degree": 11,
    "influence": 0.00308
   },
   {
    "id": 265,
    "word": "specif",
    "display": "specific",
    "degree": 17,
    "influence": 0.00103
   },
   {
    "id": 266,
    "word": "link",
    "display": "links",
    "degree": 25,
    "influence": 0.00383
   },
   {
    "id": 267,
    "word": "pattern",
    "display": "patterns",
    "degree": 32,
    "influence": 0.00715
   },
   {
    "id": 268,
    "word": "micropractic",
    "display": "micropractices",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 269,
    "word": "inform",
    "display": "information",
    "degree": 50,
    "influence": 0.01702
   },
   {
    "id": 270,
    "word": "select",
    "display": "selection",
    "degree": 7,
    "influence": 0.00004
   },
   {
    "id": 271,
    "word": "demand",
    "display": "demand",
    "degree": 9,
    "influence": 0.00027
   },
   {
    "id": 272,
    "word": "effect",
    "display": "effects",
    "degree": 23,
    "influence": 0.00272
   },
   {
    "id": 273,
    "word": "percept",
    "display": "perceptions",
    "degree": 9,
    "influence": 0.00199
   },
   {
    "id": 274,
    "word": "past",
    "display": "past",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 275,
    "word": "phenomenon",
    "display": "phenomenon",
    "degree": 10,
    "influence": 0.00217
   },
   {
    "id": 276,
    "word": "cost",
    "display": "costs",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 277,
    "word": "non-standard",
    "display": "non-standardization",
    "degree": 3,
    "influence": 0.00015
   },
   {
    "id": 278,
    "word": "major",
    "display": "major",
    "degree": 8,
    "influence": 0.00028
   },
   {
    "id": 279,
    "word": "find",
    "display": "findings",
    "degree": 12,
    "influence": 0.00102
   },
   {
    "id": 280,
    "word": "regard",
    "display": "regard",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 281,
    "word": "particip",
    "display": "participants",
    "degree": 44,
    "influence": 0.01099
   },
   {
    "id": 282,
    "word": "realiz",
    "display": "realization",
    "degree": 3,
    "influence": 0.00007
   },
   {
    "id": 283,
    "word": "secreci",
    "display": "secrecy",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 284,
    "word": "practic",
    "display": "practical",
    "degree": 19,
    "influence": 0.00354
   },
   {
    "id": 285,
    "word": "benefit",
    "display": "benefit",
    "degree": 6,
    "influence": 0.00123
   },
   {
    "id": 286,
    "word": "entir",
    "display": "entire",
    "degree": 6,
    "influence": 0.00077
   },
   {
    "id": 287,
    "word": "data",
    "display": "data",
    "degree": 52,
    "influence": 0.01154
   },
   {
    "id": 288,
    "word": "ther",
    "display": "ther",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 289,
    "word": "collabor",
    "display": "collaboration",
    "degree": 12,
    "influence": 0.00289
   },
   {
    "id": 290,
    "word": "equip",
    "display": "equipment",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 291,
    "word": "preced",
    "display": "precedent",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 292,
    "word": "discuss",
    "display": "discussion",
    "degree": 18,
    "influence": 0.00432
   },
   {
    "id": 293,
    "word": "assigne",
    "display": "assignees",
    "degree": 5,
    "influence": 0.00025
   },
   {
    "id": 294,
    "word": "hat",
    "display": "hats",
    "degree": 5,
    "influence": 0.00012
   },
   {
    "id": 295,
    "word": "parent",
    "display": "parent",
    "degree": 3,
    "influence": 0.00003
   },
   {
    "id": 296,
    "word": "viewpoint",
    "display": "viewpoint",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 297,
    "word": "decis",
    "display": "decision",
    "degree": 20,
    "influence": 0.00442
   },
   {
    "id": 298,
    "word": "share",
    "display": "shared",
    "degree": 8,
    "influence": 0.00182
   },
   {
    "id": 299,
    "word": "mission",
    "display": "mission",
    "degree": 6,
    "influence": 0.00021
   },
   {
    "id": 300,
    "word": "sens",
    "display": "sense",
    "degree": 27,
    "influence": 0.00407
   },
   {
    "id": 301,
    "word": "earli",
    "display": "early",
    "degree": 11,
    "influence": 0.00346
   },
   {
    "id": 302,
    "word": "day",
    "display": "days",
    "degree": 10,
    "influence": 0.00373
   },
   {
    "id": 303,
    "word": "note",
    "display": "note",
    "degree": 14,
    "influence": 0.00157
   },
   {
    "id": 304,
    "word": "initi",
    "display": "initial",
    "degree": 4,
    "influence": 0.00009
   },
   {
    "id": 305,
    "word": "resist",
    "display": "resistance",
    "degree": 4,
    "influence": 0.00026
   },
   {
    "id": 306,
    "word": "go",
    "display": "going",
    "degree": 3,
    "influence": 0.00009
   },
   {
    "id": 307,
    "word": "spirit",
    "display": "spirit",
    "degree": 4,
    "influence": 0.00009
   },
   {
    "id": 308,
    "word": "resourc",
    "display": "resources",
    "degree": 13,
    "influence": 0.00092
   },
   {
    "id": 309,
    "word": "answer",
    "display": "answer",
    "degree": 8,
    "influence": 0.00036
   },
   {
    "id": 310,
    "word": "cours",
    "display": "course",
    "degree": 8,
    "influence": 0.00049
   },
   {
    "id": 311,
    "word": "order",
    "display": "order",
    "degree": 19,
    "influence": 0.00317
   },
   {
    "id": 312,
    "word": "shift",
    "display": "shifts",
    "degree": 13,
    "influence": 0.00181
   },
   {
    "id": 313,
    "word": "institut",
    "display": "institutional",
    "degree": 6,
    "influence": 0.00127
   },
   {
    "id": 314,
    "word": "realm",
    "display": "realm",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 315,
    "word": "fait",
    "display": "fait",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 316,
    "word": "accompli",
    "display": "accomplis",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 317,
    "word": "case",
    "display": "case",
    "degree": 42,
    "influence": 0.00653
   },
   {
    "id": 318,
    "word": "serial",
    "display": "serial",
    "degree": 5,
    "influence": 0.00072
   },
   {
    "id": 319,
    "word": "fashion",
    "display": "fashions",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 320,
    "word": "long",
    "display": "long",
    "degree": 4,
    "influence": 0.00066
   },
   {
    "id": 321,
    "word": "period",
    "display": "period",
    "degree": 11,
    "influence": 0.00204
   },
   {
    "id": 322,
    "word": "multipl",
    "display": "multiple",
    "degree": 7,
    "influence": 0.00017
   },
   {
    "id": 323,
    "word": "numer",
    "display": "numerous",
    "degree": 5,
    "influence": 0.00032
   },
   {
    "id": 324,
    "word": "environment",
    "display": "environmental",
    "degree": 6,
    "influence": 0.00008
   },
   {
    "id": 325,
    "word": "exig",
    "display": "exigencies",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 326,
    "word": "cognit",
    "display": "cognitive",
    "degree": 22,
    "influence": 0.00398
   },
   {
    "id": 327,
    "word": "bias",
    "display": "biases",
    "degree": 5,
    "influence": 0.00015
   },
   {
    "id": 328,
    "word": "transmiss",
    "display": "transmission",
    "degree": 4,
    "influence": 0.00026
   },
   {
    "id": 329,
    "word": "polit",
    "display": "political",
    "degree": 9,
    "influence": 0.00241
   },
   {
    "id": 330,
    "word": "access",
    "display": "access",
    "degree": 7,
    "influence": 0.00076
   },
   {
    "id": 331,
    "word": "actual",
    "display": "actual",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 332,
    "word": "wide",
    "display": "wide",
    "degree": 16,
    "influence": 0.0013
   },
   {
    "id": 333,
    "word": "wors",
    "display": "worse",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 334,
    "word": "detect",
    "display": "detecting",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 335,
    "word": "spread",
    "display": "spread",
    "degree": 6,
    "influence": 0.00044
   },
   {
    "id": 336,
    "word": "vast",
    "display": "vast",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 337,
    "word": "analyst",
    "display": "analysts",
    "degree": 8,
    "influence": 0.00009
   },
   {
    "id": 338,
    "word": "residu",
    "display": "residual",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 339,
    "word": "re-pres",
    "display": "re-present",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 340,
    "word": "ongo",
    "display": "ongoing",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 341,
    "word": "contribut",
    "display": "contributions",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 342,
    "word": "multiyear",
    "display": "multiyear",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 343,
    "word": "norm",
    "display": "norm",
    "degree": 2,
    "influence": 0.00009
   },
   {
    "id": 344,
    "word": "unexplain",
    "display": "unexplained",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 345,
    "word": "signific",
    "display": "significant",
    "degree": 12,
    "influence": 0.00178
   },
   {
    "id": 346,
    "word": "uniqu",
    "display": "unique",
    "degree": 4,
    "influence": 0.00007
   },
   {
    "id": 347,
    "word": "esteem",
    "display": "esteemed",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 348,
    "word": "exhibit",
    "display": "exhibits",
    "degree": 7,
    "influence": 0.0002
   },
   {
    "id": 349,
    "word": "drawback",
    "display": "drawbacks",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 350,
    "word": "instanc",
    "display": "instance",
    "degree": 11,
    "influence": 0.00035
   },
   {
    "id": 351,
    "word": "barley",
    "display": "barley",
    "degree": 14,
    "influence": 0.00165
   },
   {
    "id": 352,
    "word": "impact",
    "display": "impact",
    "degree": 14,
    "influence": 0.00204
   },
   {
    "id": 353,
    "word": "scan",
    "display": "scanning",
    "degree": 4,
    "influence": 0.00035
   },
   {
    "id": 354,
    "word": "employe",
    "display": "employee",
    "degree": 12,
    "influence": 0.00113
   },
   {
    "id": 355,
    "word": "script",
    "display": "scripts",
    "degree": 6,
    "influence": 0.00194
   },
   {
    "id": 356,
    "word": "machin",
    "display": "machine",
    "degree": 9,
    "influence": 0.00102
   },
   {
    "id": 357,
    "word": "role",
    "display": "role",
    "degree": 10,
    "influence": 0.00232
   },
   {
    "id": 358,
    "word": "participantobserv",
    "display": "participantobserver",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 359,
    "word": "session",
    "display": "sessions",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 360,
    "word": "differ",
    "display": "different",
    "degree": 28,
    "influence": 0.00385
   },
   {
    "id": 361,
    "word": "occup",
    "display": "occupants",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 362,
    "word": "ct",
    "display": "ct",
    "degree": 9,
    "influence": 0.00054
   },
   {
    "id": 363,
    "word": "profound",
    "display": "profound",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 364,
    "word": "evid",
    "display": "evidence",
    "degree": 14,
    "influence": 0.00146
   },
   {
    "id": 365,
    "word": "assess",
    "display": "assessment",
    "degree": 6,
    "influence": 0.00008
   },
   {
    "id": 366,
    "word": "non-ct",
    "display": "non-ct",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 367,
    "word": "memoranda",
    "display": "memoranda",
    "degree": 4,
    "influence": 0.00026
   },
   {
    "id": 368,
    "word": "newslett",
    "display": "newsletters",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 369,
    "word": "strategi",
    "display": "strategy",
    "degree": 12,
    "influence": 0.00175
   },
   {
    "id": 370,
    "word": "statement",
    "display": "statements",
    "degree": 19,
    "influence": 0.00233
   },
   {
    "id": 371,
    "word": "exemplari",
    "display": "exemplary",
    "degree": 5,
    "influence": 0.00027
   },
   {
    "id": 372,
    "word": "gersick",
    "display": "gersick",
    "degree": 17,
    "influence": 0.00091
   },
   {
    "id": 373,
    "word": "equilibrium",
    "display": "equilibrium",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 374,
    "word": "work",
    "display": "work",
    "degree": 18,
    "influence": 0.00291
   },
   {
    "id": 375,
    "word": "depart",
    "display": "departments",
    "degree": 11,
    "influence": 0.00127
   },
   {
    "id": 376,
    "word": "move",
    "display": "moves",
    "degree": 8,
    "influence": 0.00222
   },
   {
    "id": 377,
    "word": "stage",
    "display": "stages",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 378,
    "word": "transcript",
    "display": "transcript",
    "degree": 23,
    "influence": 0.00393
   },
   {
    "id": 379,
    "word": "sequenc",
    "display": "sequences",
    "degree": 9,
    "influence": 0.00112
   },
   {
    "id": 380,
    "word": "utter",
    "display": "utterances",
    "degree": 55,
    "influence": 0.01098
   },
   {
    "id": 381,
    "word": "addit",
    "display": "additional",
    "degree": 10,
    "influence": 0.0005
   },
   {
    "id": 382,
    "word": "substanti",
    "display": "substantial",
    "degree": 4,
    "influence": 0.00005
   },
   {
    "id": 383,
    "word": "mileston",
    "display": "milestones",
    "degree": 4,
    "influence": 0.00037
   },
   {
    "id": 384,
    "word": "inertia",
    "display": "inertia",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 385,
    "word": "first",
    "display": "first",
    "degree": 11,
    "influence": 0.00108
   },
   {
    "id": 386,
    "word": "brief",
    "display": "brief",
    "degree": 4,
    "influence": 0.00007
   },
   {
    "id": 387,
    "word": "revolutionari",
    "display": "revolutionary",
    "degree": 4,
    "influence": 0.00083
   },
   {
    "id": 388,
    "word": "midpoint",
    "display": "midpoint",
    "degree": 2,
    "influence": 0.00044
   },
   {
    "id": 389,
    "word": "live",
    "display": "lives",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 390,
    "word": "futur",
    "display": "future",
    "degree": 12,
    "influence": 0.00238
   },
   {
    "id": 391,
    "word": "rigor",
    "display": "rigorous",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 392,
    "word": "natur",
    "display": "natural",
    "degree": 17,
    "influence": 0.00297
   },
   {
    "id": 393,
    "word": "transit",
    "display": "transitions",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 394,
    "word": "qualiti",
    "display": "quality",
    "degree": 8,
    "influence": 0.00018
   },
   {
    "id": 395,
    "word": "thread",
    "display": "threads",
    "degree": 2,
    "influence": 0.00029
   },
   {
    "id": 396,
    "word": "socio",
    "display": "socio",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 397,
    "word": "emot",
    "display": "emotional",
    "degree": 2,
    "influence": 0.00093
   },
   {
    "id": 398,
    "word": "avalanch",
    "display": "avalanche",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 399,
    "word": "pressur",
    "display": "pressures",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 400,
    "word": "sort",
    "display": "sort",
    "degree": 9,
    "influence": 0.00017
   },
   {
    "id": 401,
    "word": "equival",
    "display": "equivalent",
    "degree": 9,
    "influence": 0.0006
   },
   {
    "id": 402,
    "word": "bracket",
    "display": "bracket",
    "degree": 4,
    "influence": 0.00011
   },
   {
    "id": 403,
    "word": "portion",
    "display": "portion",
    "degree": 10,
    "influence": 0.00108
   },
   {
    "id": 404,
    "word": "generat",
    "display": "generating",
    "degree": 10,
    "influence": 0.00038
   },
   {
    "id": 405,
    "word": "pertin",
    "display": "pertinent",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 406,
    "word": "question",
    "display": "question",
    "degree": 20,
    "influence": 0.0017
   },
   {
    "id": 407,
    "word": "multilevel",
    "display": "multilevel",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 408,
    "word": "simpl",
    "display": "simple",
    "degree": 6,
    "influence": 0.00104
   },
   {
    "id": 409,
    "word": "disciplinari",
    "display": "disciplinary",
    "degree": 4,
    "influence": 0.00059
   },
   {
    "id": 410,
    "word": "arsenal",
    "display": "arsenal",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 411,
    "word": "job",
    "display": "job",
    "degree": 10,
    "influence": 0.00116
   },
   {
    "id": 412,
    "word": "candid",
    "display": "candidates",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 413,
    "word": "local",
    "display": "local",
    "degree": 13,
    "influence": 0.00074
   },
   {
    "id": 414,
    "word": "skill",
    "display": "skills",
    "degree": 8,
    "influence": 0.00059
   },
   {
    "id": 415,
    "word": "compet",
    "display": "competent",
    "degree": 10,
    "influence": 0.00032
   },
   {
    "id": 416,
    "word": "high",
    "display": "high",
    "degree": 5,
    "influence": 0.00033
   },
   {
    "id": 417,
    "word": "situat",
    "display": "situation",
    "degree": 6,
    "influence": 0.00021
   },
   {
    "id": 418,
    "word": "perceiv",
    "display": "perceived",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 419,
    "word": "intens",
    "display": "intense",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 420,
    "word": "micro-interpret",
    "display": "micro-interpretation",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 421,
    "word": "systemlevel",
    "display": "systemlevel",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 422,
    "word": "simultan",
    "display": "simultaneity",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 423,
    "word": "place",
    "display": "place",
    "degree": 12,
    "influence": 0.00104
   },
   {
    "id": 424,
    "word": "matter",
    "display": "matter",
    "degree": 12,
    "influence": 0.00228
   },
   {
    "id": 425,
    "word": "respond",
    "display": "respondents",
    "degree": 6,
    "influence": 0.00013
   },
   {
    "id": 426,
    "word": "self",
    "display": "self",
    "degree": 16,
    "influence": 0.00424
   },
   {
    "id": 427,
    "word": "purpos",
    "display": "purpose",
    "degree": 18,
    "influence": 0.00091
   },
   {
    "id": 428,
    "word": "serious",
    "display": "serious",
    "degree": 2,
    "influence": 0.00009
   },
   {
    "id": 429,
    "word": "mistak",
    "display": "mistake",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 430,
    "word": "substitut",
    "display": "substitute",
    "degree": 6,
    "influence": 0.00066
   },
   {
    "id": 431,
    "word": "unacknowledg",
    "display": "unacknowledged",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 432,
    "word": "condit",
    "display": "condition",
    "degree": 17,
    "influence": 0.00176
   },
   {
    "id": 433,
    "word": "unintend",
    "display": "unintended",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 434,
    "word": "consequ",
    "display": "consequences",
    "degree": 7,
    "influence": 0.0007
   },
   {
    "id": 435,
    "word": "ipso",
    "display": "ipso",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 436,
    "word": "peopl",
    "display": "people",
    "degree": 14,
    "influence": 0.00098
   },
   {
    "id": 437,
    "word": "organiza",
    "display": "organiza",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 438,
    "word": "tional",
    "display": "tional",
    "degree": 3,
    "influence": 0.00003
   },
   {
    "id": 439,
    "word": "explan",
    "display": "explanations",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 440,
    "word": "weick",
    "display": "weick",
    "degree": 6,
    "influence": 0.00107
   },
   {
    "id": 441,
    "word": "interest",
    "display": "interesting",
    "degree": 17,
    "influence": 0.00213
   },
   {
    "id": 442,
    "word": "possibl",
    "display": "possible",
    "degree": 19,
    "influence": 0.00348
   },
   {
    "id": 443,
    "word": "deal",
    "display": "deal",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 444,
    "word": "thing",
    "display": "things",
    "degree": 9,
    "influence": 0.0034
   },
   {
    "id": 445,
    "word": "contemporari",
    "display": "contemporary",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 446,
    "word": "usag",
    "display": "usage",
    "degree": 2,
    "influence": 0.0001
   },
   {
    "id": 447,
    "word": "hypothesi",
    "display": "hypothesis",
    "degree": 4,
    "influence": 0.00005
   },
   {
    "id": 448,
    "word": "descript",
    "display": "description",
    "degree": 10,
    "influence": 0.00042
   },
   {
    "id": 449,
    "word": "narrow",
    "display": "narrow",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 450,
    "word": "hypothes",
    "display": "hypotheses",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 451,
    "word": "unproblemat",
    "display": "unproblematic",
    "degree": 3,
    "influence": 0.00012
   },
   {
    "id": 452,
    "word": "transfer",
    "display": "transfer",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 453,
    "word": "agent",
    "display": "agents",
    "degree": 7,
    "influence": 0.00081
   },
   {
    "id": 454,
    "word": "sophist",
    "display": "sophisticated",
    "degree": 4,
    "influence": 0.00008
   },
   {
    "id": 455,
    "word": "nutshel",
    "display": "nutshell",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 456,
    "word": "deep",
    "display": "deep",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 457,
    "word": "consider",
    "display": "consideration",
    "degree": 10,
    "influence": 0.00233
   },
   {
    "id": 458,
    "word": "care",
    "display": "careful",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 459,
    "word": "indic",
    "display": "indicator",
    "degree": 7,
    "influence": 0.00018
   },
   {
    "id": 460,
    "word": "size",
    "display": "size",
    "degree": 14,
    "influence": 0.00166
   },
   {
    "id": 461,
    "word": "scari",
    "display": "scary",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 462,
    "word": "resolut",
    "display": "resolution",
    "degree": 6,
    "influence": 0.0004
   },
   {
    "id": 463,
    "word": "singl",
    "display": "single",
    "degree": 15,
    "influence": 0.00076
   },
   {
    "id": 464,
    "word": "gronn",
    "display": "gronn",
    "degree": 16,
    "influence": 0.00323
   },
   {
    "id": 465,
    "word": "talk",
    "display": "talk",
    "degree": 9,
    "influence": 0.0013
   },
   {
    "id": 466,
    "word": "princip",
    "display": "principal",
    "degree": 10,
    "influence": 0.00211
   },
   {
    "id": 467,
    "word": "unobtrus",
    "display": "unobtrusive",
    "degree": 3,
    "influence": 0.00045
   },
   {
    "id": 468,
    "word": "radio",
    "display": "radio",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 469,
    "word": "microphon",
    "display": "microphone",
    "degree": 5,
    "influence": 0.00084
   },
   {
    "id": 470,
    "word": "lapel",
    "display": "lapel",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 471,
    "word": "record",
    "display": "recordings",
    "degree": 8,
    "influence": 0.00079
   },
   {
    "id": 472,
    "word": "page",
    "display": "pages",
    "degree": 15,
    "influence": 0.00153
   },
   {
    "id": 473,
    "word": "tran",
    "display": "trans",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 474,
    "word": "honor",
    "display": "honor",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 475,
    "word": "challeng",
    "display": "challenging",
    "degree": 6,
    "influence": 0.00106
   },
   {
    "id": 476,
    "word": "workweek",
    "display": "workweek",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 477,
    "word": "estim",
    "display": "estimate",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 478,
    "word": "valu",
    "display": "value",
    "degree": 26,
    "influence": 0.00717
   },
   {
    "id": 479,
    "word": "half",
    "display": "half",
    "degree": 9,
    "influence": 0.00063
   },
   {
    "id": 480,
    "word": "count",
    "display": "count",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 481,
    "word": "partner",
    "display": "partners",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 482,
    "word": "worth",
    "display": "worth",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 483,
    "word": "workday",
    "display": "workday",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 484,
    "word": "investig",
    "display": "investigation",
    "degree": 8,
    "influence": 0.00049
   },
   {
    "id": 485,
    "word": "fit",
    "display": "fitted",
    "degree": 4,
    "influence": 0.00013
   },
   {
    "id": 486,
    "word": "wireless",
    "display": "wireless",
    "degree": 2,
    "influence": 0.00038
   },
   {
    "id": 487,
    "word": "week",
    "display": "week",
    "degree": 4,
    "influence": 0.00043
   },
   {
    "id": 488,
    "word": "ream",
    "display": "reams",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 489,
    "word": "stack",
    "display": "stack",
    "degree": 2,
    "influence": 0.00033
   },
   {
    "id": 490,
    "word": "feet",
    "display": "feet",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 491,
    "word": "tall",
    "display": "tall",
    "degree": 2,
    "influence": 0.00089
   },
   {
    "id": 492,
    "word": "true",
    "display": "true",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 493,
    "word": "whole",
    "display": "whole",
    "degree": 7,
    "influence": 0.0004
   },
   {
    "id": 494,
    "word": "corpus",
    "display": "corpus",
    "degree": 15,
    "influence": 0.00108
   },
   {
    "id": 495,
    "word": "corpor",
    "display": "corporation",
    "degree": 7,
    "influence": 0.00045
   },
   {
    "id": 496,
    "word": "web",
    "display": "web",
    "degree": 7,
    "influence": 0.00029
   },
   {
    "id": 497,
    "word": "intranet",
    "display": "intranet",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 498,
    "word": "various",
    "display": "various",
    "degree": 7,
    "influence": 0.00093
   },
   {
    "id": 499,
    "word": "databas",
    "display": "database",
    "degree": 12,
    "influence": 0.00051
   },
   {
    "id": 500,
    "word": "warehous",
    "display": "warehouses",
    "degree": 2,
    "influence": 0.00075
   },
   {
    "id": 501,
    "word": "store",
    "display": "store",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 502,
    "word": "million",
    "display": "millions",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 503,
    "word": "refer",
    "display": "reference",
    "degree": 17,
    "influence": 0.00151
   },
   {
    "id": 504,
    "word": "hundr",
    "display": "hundreds",
    "degree": 2,
    "influence": 0.00031
   },
   {
    "id": 505,
    "word": "piec",
    "display": "pieces",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 506,
    "word": "electron",
    "display": "electronic",
    "degree": 7,
    "influence": 0.00109
   },
   {
    "id": 507,
    "word": "mail",
    "display": "mail",
    "degree": 6,
    "influence": 0.00036
   },
   {
    "id": 508,
    "word": "daili",
    "display": "daily",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 509,
    "word": "opinion",
    "display": "opinion",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 510,
    "word": "show",
    "display": "shows",
    "degree": 7,
    "influence": 0.00017
   },
   {
    "id": 511,
    "word": "commu",
    "display": "commu",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 512,
    "word": "nicat",
    "display": "nication",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 513,
    "word": "lead",
    "display": "leading",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 514,
    "word": "edg",
    "display": "edge",
    "degree": 4,
    "influence": 0.00009
   },
   {
    "id": 515,
    "word": "larger",
    "display": "larger",
    "degree": 22,
    "influence": 0.00207
   },
   {
    "id": 516,
    "word": "capac",
    "display": "capacities",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 517,
    "word": "capabl",
    "display": "capable",
    "degree": 5,
    "influence": 0.00009
   },
   {
    "id": 518,
    "word": "autom",
    "display": "automated",
    "degree": 6,
    "influence": 0.00002
   },
   {
    "id": 519,
    "word": "tabl",
    "display": "table",
    "degree": 11,
    "influence": 0.00138
   },
   {
    "id": 520,
    "word": "summari",
    "display": "summary",
    "degree": 8,
    "influence": 0.00061
   },
   {
    "id": 521,
    "word": "goal",
    "display": "goal",
    "degree": 18,
    "influence": 0.00399
   },
   {
    "id": 522,
    "word": "repres",
    "display": "representative",
    "degree": 7,
    "influence": 0.00087
   },
   {
    "id": 523,
    "word": "infer",
    "display": "inference",
    "degree": 17,
    "influence": 0.00123
   },
   {
    "id": 524,
    "word": "connolli",
    "display": "connolly",
    "degree": 4,
    "influence": 0.0009
   },
   {
    "id": 525,
    "word": "dong",
    "display": "dong",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 526,
    "word": "agogino",
    "display": "agogino",
    "degree": 3,
    "influence": 0.00013
   },
   {
    "id": 527,
    "word": "eizirik",
    "display": "eizirik",
    "degree": 4,
    "influence": 0.00179
   },
   {
    "id": 528,
    "word": "federici",
    "display": "federici",
    "degree": 4,
    "influence": 0.00045
   },
   {
    "id": 529,
    "word": "pirelli",
    "display": "pirelli",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 530,
    "word": "hahn",
    "display": "hahn",
    "degree": 4,
    "influence": 0.0014
   },
   {
    "id": 531,
    "word": "medsyndik",
    "display": "medsyndikate",
    "degree": 4,
    "influence": 0.00058
   },
   {
    "id": 532,
    "word": "jacob",
    "display": "jacobs",
    "degree": 5,
    "influence": 0.00016
   },
   {
    "id": 533,
    "word": "rau",
    "display": "rau",
    "degree": 3,
    "influence": 0.00009
   },
   {
    "id": 534,
    "word": "leacock",
    "display": "leacock",
    "degree": 6,
    "influence": 0.00127
   },
   {
    "id": 535,
    "word": "mitkov",
    "display": "mitkov",
    "degree": 4,
    "influence": 0.00092
   },
   {
    "id": 536,
    "word": "perez",
    "display": "perez",
    "degree": 3,
    "influence": 0.00013
   },
   {
    "id": 537,
    "word": "carballo",
    "display": "carballo",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 538,
    "word": "strzalkowski",
    "display": "strzalkowski",
    "degree": 3,
    "influence": 0.00113
   },
   {
    "id": 539,
    "word": "posit",
    "display": "positioning",
    "degree": 34,
    "influence": 0.00885
   },
   {
    "id": 540,
    "word": "bartel",
    "display": "bartell",
    "degree": 4,
    "influence": 0.00121
   },
   {
    "id": 541,
    "word": "catpac",
    "display": "catpac",
    "degree": 4,
    "influence": 0.00037
   },
   {
    "id": 542,
    "word": "doerfel",
    "display": "doerfel",
    "degree": 3,
    "influence": 0.00012
   },
   {
    "id": 543,
    "word": "barnett",
    "display": "barnett",
    "degree": 11,
    "influence": 0.00238
   },
   {
    "id": 544,
    "word": "fraenkel",
    "display": "fraenkel",
    "degree": 3,
    "influence": 0.00089
   },
   {
    "id": 545,
    "word": "klein",
    "display": "klein",
    "degree": 3,
    "influence": 0.00069
   },
   {
    "id": 546,
    "word": "lsa",
    "display": "lsa",
    "degree": 16,
    "influence": 0.00293
   },
   {
    "id": 547,
    "word": "lund",
    "display": "lund",
    "degree": 3,
    "influence": 0.00013
   },
   {
    "id": 548,
    "word": "burgess",
    "display": "burgess",
    "degree": 3,
    "influence": 0.00006
   },
   {
    "id": 549,
    "word": "nomoto",
    "display": "nomoto",
    "degree": 3,
    "influence": 0.00021
   },
   {
    "id": 550,
    "word": "nitta",
    "display": "nitta",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 551,
    "word": "stephen",
    "display": "stephen",
    "degree": 5,
    "influence": 0.0013
   },
   {
    "id": 552,
    "word": "treadwel",
    "display": "treadwell",
    "degree": 3,
    "influence": 0.00005
   },
   {
    "id": 553,
    "word": "harrison",
    "display": "harrison",
    "degree": 3,
    "influence": 0.00043
   },
   {
    "id": 554,
    "word": "effici",
    "display": "efficient",
    "degree": 8,
    "influence": 0.00091
   },
   {
    "id": 555,
    "word": "alterman",
    "display": "alterman",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 556,
    "word": "bookman",
    "display": "bookman",
    "degree": 3,
    "influence": 0.00027
   },
   {
    "id": 557,
    "word": "carley",
    "display": "carley",
    "degree": 12,
    "influence": 0.00165
   },
   {
    "id": 558,
    "word": "danowski",
    "display": "danowski",
    "degree": 18,
    "influence": 0.00545
   },
   {
    "id": 559,
    "word": "galal",
    "display": "galal",
    "degree": 4,
    "influence": 0.00045
   },
   {
    "id": 560,
    "word": "humphrey",
    "display": "humphrey",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 561,
    "word": "keyword",
    "display": "keyword",
    "degree": 7,
    "influence": 0.00013
   },
   {
    "id": 562,
    "word": "frequenc",
    "display": "frequency",
    "degree": 13,
    "influence": 0.00117
   },
   {
    "id": 563,
    "word": "rice",
    "display": "rice",
    "degree": 4,
    "influence": 0.00035
   },
   {
    "id": 564,
    "word": "wordij",
    "display": "wordij",
    "degree": 3,
    "influence": 0.00008
   },
   {
    "id": 565,
    "word": "tact",
    "display": "tact",
    "degree": 4,
    "influence": 0.00009
   },
   {
    "id": 566,
    "word": "flood",
    "display": "floods",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 567,
    "word": "computer",
    "display": "computerized",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 568,
    "word": "replac",
    "display": "replacement",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 569,
    "word": "complet",
    "display": "complete",
    "degree": 9,
    "influence": 0.00129
   },
   {
    "id": 570,
    "word": "prioriti",
    "display": "priority",
    "degree": 5,
    "influence": 0.00022
   },
   {
    "id": 571,
    "word": "crowd",
    "display": "crowded",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 572,
    "word": "respect",
    "display": "respect",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 573,
    "word": "effort",
    "display": "efforts",
    "degree": 7,
    "influence": 0.00015
   },
   {
    "id": 574,
    "word": "list",
    "display": "lists",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 575,
    "word": "linguist",
    "display": "linguistic",
    "degree": 24,
    "influence": 0.0123
   },
   {
    "id": 576,
    "word": "input",
    "display": "input",
    "degree": 6,
    "influence": 0.00158
   },
   {
    "id": 577,
    "word": "abstract",
    "display": "abstracts",
    "degree": 18,
    "influence": 0.00351
   },
   {
    "id": 578,
    "word": "branch",
    "display": "branches",
    "degree": 4,
    "influence": 0.00011
   },
   {
    "id": 579,
    "word": "root",
    "display": "roots",
    "degree": 6,
    "influence": 0.0014
   },
   {
    "id": 580,
    "word": "passag",
    "display": "passage",
    "degree": 5,
    "influence": 0.00033
   },
   {
    "id": 581,
    "word": "tree",
    "display": "trees",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 582,
    "word": "rule",
    "display": "rules",
    "degree": 20,
    "influence": 0.00224
   },
   {
    "id": 583,
    "word": "ontolog",
    "display": "ontologies",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 584,
    "word": "unimport",
    "display": "unimportant",
    "degree": 5,
    "influence": 0.00013
   },
   {
    "id": 585,
    "word": "foundat",
    "display": "foundations",
    "degree": 6,
    "influence": 0.00112
   },
   {
    "id": 586,
    "word": "probabilist",
    "display": "probabilistic",
    "degree": 3,
    "influence": 0.00009
   },
   {
    "id": 587,
    "word": "causal",
    "display": "causal",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 588,
    "word": "common",
    "display": "common",
    "degree": 11,
    "influence": 0.00066
   },
   {
    "id": 589,
    "word": "bayesian",
    "display": "bayesian",
    "degree": 5,
    "influence": 0.00131
   },
   {
    "id": 590,
    "word": "artifici",
    "display": "artificial",
    "degree": 4,
    "influence": 0.00014
   },
   {
    "id": 591,
    "word": "intellig",
    "display": "intelligence",
    "degree": 6,
    "influence": 0.00142
   },
   {
    "id": 592,
    "word": "primari",
    "display": "primary",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 593,
    "word": "distinct",
    "display": "distinct",
    "degree": 13,
    "influence": 0.00103
   },
   {
    "id": 594,
    "word": "syntax",
    "display": "syntax",
    "degree": 7,
    "influence": 0.00109
   },
   {
    "id": 595,
    "word": "lexic",
    "display": "lexical",
    "degree": 12,
    "influence": 0.00242
   },
   {
    "id": 596,
    "word": "semant",
    "display": "semantic",
    "degree": 40,
    "influence": 0.00836
   },
   {
    "id": 597,
    "word": "grammar",
    "display": "grammars",
    "degree": 9,
    "influence": 0.00232
   },
   {
    "id": 598,
    "word": "constitu",
    "display": "constituent",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 599,
    "word": "unit",
    "display": "units",
    "degree": 19,
    "influence": 0.00527
   },
   {
    "id": 600,
    "word": "analyz",
    "display": "analyzer",
    "degree": 6,
    "influence": 0.00041
   },
   {
    "id": 601,
    "word": "crucial",
    "display": "crucial",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 602,
    "word": "co-occurr",
    "display": "co-occurrence",
    "degree": 17,
    "influence": 0.00095
   },
   {
    "id": 603,
    "word": "grammat",
    "display": "grammatical",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 604,
    "word": "second",
    "display": "second",
    "degree": 15,
    "influence": 0.00318
   },
   {
    "id": 605,
    "word": "entiti",
    "display": "entities",
    "degree": 10,
    "influence": 0.00025
   },
   {
    "id": 606,
    "word": "domain",
    "display": "domain",
    "degree": 18,
    "influence": 0.00101
   },
   {
    "id": 607,
    "word": "ambigu",
    "display": "ambiguous",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 608,
    "word": "metaphor",
    "display": "metaphors",
    "degree": 9,
    "influence": 0.00047
   },
   {
    "id": 609,
    "word": "pronoun",
    "display": "pronouns",
    "degree": 24,
    "influence": 0.00323
   },
   {
    "id": 610,
    "word": "dictionari",
    "display": "dictionary",
    "degree": 8,
    "influence": 0.00016
   },
   {
    "id": 611,
    "word": "nativ",
    "display": "native",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 612,
    "word": "familiar",
    "display": "familiarity",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 613,
    "word": "miller",
    "display": "miller",
    "degree": 9,
    "influence": 0.00141
   },
   {
    "id": 614,
    "word": "chodorow",
    "display": "chodorow",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 615,
    "word": "topic",
    "display": "topic",
    "degree": 8,
    "influence": 0.00035
   },
   {
    "id": 616,
    "word": "classifi",
    "display": "classifier",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 617,
    "word": "tlc",
    "display": "tlc",
    "degree": 9,
    "influence": 0.00332
   },
   {
    "id": 618,
    "word": "verb",
    "display": "verbs",
    "degree": 22,
    "influence": 0.00426
   },
   {
    "id": 619,
    "word": "noun",
    "display": "noun",
    "degree": 39,
    "influence": 0.00403
   },
   {
    "id": 620,
    "word": "adject",
    "display": "adjectives",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 621,
    "word": "neighborhood",
    "display": "neighborhood",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 622,
    "word": "cue",
    "display": "cues",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 623,
    "word": "window",
    "display": "window",
    "degree": 20,
    "influence": 0.00257
   },
   {
    "id": 624,
    "word": "polysem",
    "display": "polysemous",
    "degree": 1,
    "influence": 0
   },
   {
    "id": 625,
    "word": "tag",
    "display": "tags",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 626,
    "word": "variant",
    "display": "variants",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 627,
    "word": "base",
    "display": "bases",
    "degree": 12,
    "influence": 0.00068
   },
   {
    "id": 628,
    "word": "code",
    "display": "coding",
    "degree": 13,
    "influence": 0.00069
   },
   {
    "id": 629,
    "word": "wordnet",
    "display": "wordnet",
    "degree": 6,
    "influence": 0.00009
   },
   {
    "id": 630,
    "word": "synonym",
    "display": "synonyms",
    "degree": 2,
    "influence": 0.00142
   },
   {
    "id": 631,
    "word": "antonym",
    "display": "antonyms",
    "degree": 2,
    "influence": 0.00021
   },
   {
    "id": 632,
    "word": "hyponym",
    "display": "hyponyms",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 633,
    "word": "superordin",
    "display": "superordinate",
    "degree": 2,
    "influence": 0.00101
   },
   {
    "id": 634,
    "word": "subordin",
    "display": "subordinate",
    "degree": 2,
    "influence": 0.00222
   },
   {
    "id": 635,
    "word": "train",
    "display": "training",
    "degree": 12,
    "influence": 0.00054
   },
   {
    "id": 636,
    "word": "subsequ",
    "display": "subsequent",
    "degree": 5,
    "influence": 0.00001
   },
   {
    "id": 637,
    "word": "inferenti",
    "display": "inferential",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 638,
    "word": "given",
    "display": "given",
    "degree": 13,
    "influence": 0.0004
   },
   {
    "id": 639,
    "word": "increas",
    "display": "increases",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 640,
    "word": "accuraci",
    "display": "accuracy",
    "degree": 10,
    "influence": 0.00035
   },
   {
    "id": 641,
    "word": "identif",
    "display": "identification",
    "degree": 14,
    "influence": 0.00106
   },
   {
    "id": 642,
    "word": "shortcom",
    "display": "shortcomings",
    "degree": 6,
    "influence": 0.00008
   },
   {
    "id": 643,
    "word": "semiot",
    "display": "semiotic",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 644,
    "word": "necessari",
    "display": "necessary",
    "degree": 5,
    "influence": 0.00005
   },
   {
    "id": 645,
    "word": "character",
    "display": "characterization",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 646,
    "word": "key",
    "display": "key",
    "degree": 15,
    "influence": 0.00164
   },
   {
    "id": 647,
    "word": "creation",
    "display": "creation",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 648,
    "word": "space",
    "display": "space",
    "degree": 40,
    "influence": 0.00459
   },
   {
    "id": 649,
    "word": "dimens",
    "display": "dimensions",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 650,
    "word": "concept",
    "display": "concepts",
    "degree": 39,
    "influence": 0.00645
   },
   {
    "id": 651,
    "word": "axi",
    "display": "axis",
    "degree": 5,
    "influence": 0.00027
   },
   {
    "id": 652,
    "word": "rater",
    "display": "raters",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 653,
    "word": "vector",
    "display": "vectors",
    "degree": 12,
    "influence": 0.00056
   },
   {
    "id": 654,
    "word": "focal",
    "display": "focal",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 655,
    "word": "adjac",
    "display": "adjacency",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 656,
    "word": "matrix",
    "display": "matrix",
    "degree": 29,
    "influence": 0.00398
   },
   {
    "id": 657,
    "word": "pair",
    "display": "pair",
    "degree": 25,
    "influence": 0.00177
   },
   {
    "id": 658,
    "word": "co-occur",
    "display": "co-occur",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 659,
    "word": "slide",
    "display": "slides",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 660,
    "word": "cluster",
    "display": "cluster",
    "degree": 56,
    "influence": 0.0217
   },
   {
    "id": 661,
    "word": "multidimension",
    "display": "multidimensional",
    "degree": 6,
    "influence": 0.00128
   },
   {
    "id": 662,
    "word": "comprehens",
    "display": "comprehension",
    "degree": 10,
    "influence": 0.00035
   },
   {
    "id": 663,
    "word": "similar",
    "display": "similar",
    "degree": 27,
    "influence": 0.00198
   },
   {
    "id": 664,
    "word": "consist",
    "display": "consistent",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 665,
    "word": "line",
    "display": "line",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 666,
    "word": "hoov",
    "display": "hooves",
    "degree": 2,
    "influence": 0.00016
   },
   {
    "id": 667,
    "word": "tail",
    "display": "tails",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 668,
    "word": "mane",
    "display": "manes",
    "degree": 2,
    "influence": 0.00106
   },
   {
    "id": 669,
    "word": "galileo",
    "display": "galileo",
    "degree": 12,
    "influence": 0.00148
   },
   {
    "id": 670,
    "word": "joseph",
    "display": "joseph",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 671,
    "word": "woelfel",
    "display": "woelfel",
    "degree": 7,
    "influence": 0.00039
   },
   {
    "id": 672,
    "word": "varieti",
    "display": "variety",
    "degree": 9,
    "influence": 0.0001
   },
   {
    "id": 673,
    "word": "casual",
    "display": "casual",
    "degree": 5,
    "influence": 0.00004
   },
   {
    "id": 674,
    "word": "relev",
    "display": "relevant",
    "degree": 16,
    "influence": 0.00264
   },
   {
    "id": 675,
    "word": "subject",
    "display": "subjects",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 676,
    "word": "psycholog",
    "display": "psychology",
    "degree": 17,
    "influence": 0.00303
   },
   {
    "id": 677,
    "word": "distanc",
    "display": "distances",
    "degree": 19,
    "influence": 0.00272
   },
   {
    "id": 678,
    "word": "score",
    "display": "scores",
    "degree": 14,
    "influence": 0.00093
   },
   {
    "id": 679,
    "word": "mds",
    "display": "mds",
    "degree": 10,
    "influence": 0.00043
   },
   {
    "id": 680,
    "word": "conceptu",
    "display": "conceptual",
    "degree": 17,
    "influence": 0.00157
   },
   {
    "id": 681,
    "word": "creator",
    "display": "creators",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 682,
    "word": "law",
    "display": "laws",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 683,
    "word": "motion",
    "display": "motion",
    "degree": 4,
    "influence": 0.00038
   },
   {
    "id": 684,
    "word": "promin",
    "display": "prominent",
    "degree": 5,
    "influence": 0.00012
   },
   {
    "id": 685,
    "word": "landauer",
    "display": "landauer",
    "degree": 6,
    "influence": 0.00177
   },
   {
    "id": 686,
    "word": "colleaug",
    "display": "colleauges",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 687,
    "word": "readabl",
    "display": "readable",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 688,
    "word": "languag",
    "display": "language",
    "degree": 22,
    "influence": 0.00497
   },
   {
    "id": 689,
    "word": "row",
    "display": "row",
    "degree": 6,
    "influence": 0.00005
   },
   {
    "id": 690,
    "word": "column",
    "display": "column",
    "degree": 6,
    "influence": 0.00009
   },
   {
    "id": 691,
    "word": "cell",
    "display": "cell",
    "degree": 13,
    "influence": 0.00066
   },
   {
    "id": 692,
    "word": "entri",
    "display": "entries",
    "degree": 5,
    "influence": 0.00009
   },
   {
    "id": 693,
    "word": "singular",
    "display": "singular",
    "degree": 5,
    "influence": 0.00129
   },
   {
    "id": 694,
    "word": "decomposit",
    "display": "decomposition",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 695,
    "word": "type",
    "display": "type",
    "degree": 12,
    "influence": 0.00106
   },
   {
    "id": 696,
    "word": "contrast",
    "display": "contrast",
    "degree": 8,
    "influence": 0.00143
   },
   {
    "id": 697,
    "word": "syntact",
    "display": "syntactic",
    "degree": 2,
    "influence": 0.00091
   },
   {
    "id": 698,
    "word": "parser",
    "display": "parsers",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 699,
    "word": "morpholog",
    "display": "morphologies",
    "degree": 2,
    "influence": 0.00031
   },
   {
    "id": 700,
    "word": "raw",
    "display": "raw",
    "degree": 4,
    "influence": 0.0008
   },
   {
    "id": 701,
    "word": "altern",
    "display": "alternative",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 702,
    "word": "overal",
    "display": "overall",
    "degree": 10,
    "influence": 0.00045
   },
   {
    "id": 703,
    "word": "repr",
    "display": "repre",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 704,
    "word": "related",
    "display": "relatedness",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 705,
    "word": "hear",
    "display": "hearing",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 706,
    "word": "combin",
    "display": "combinations",
    "degree": 5,
    "influence": 0.00019
   },
   {
    "id": 707,
    "word": "suitabl",
    "display": "suitable",
    "degree": 5,
    "influence": 0.00032
   },
   {
    "id": 708,
    "word": "sourc",
    "display": "sources",
    "degree": 13,
    "influence": 0.00093
   },
   {
    "id": 709,
    "word": "gender",
    "display": "gender",
    "degree": 4,
    "influence": 0.00016
   },
   {
    "id": 710,
    "word": "women",
    "display": "women",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 711,
    "word": "communiti",
    "display": "community",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 712,
    "word": "placement",
    "display": "placement",
    "degree": 4,
    "influence": 0.00013
   },
   {
    "id": 713,
    "word": "term",
    "display": "terms",
    "degree": 28,
    "influence": 0.00719
   },
   {
    "id": 714,
    "word": "tempor",
    "display": "temporal",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 715,
    "word": "divis",
    "display": "division",
    "degree": 8,
    "influence": 0.00174
   },
   {
    "id": 716,
    "word": "final",
    "display": "final",
    "degree": 6,
    "influence": 0.00012
   },
   {
    "id": 717,
    "word": "attempt",
    "display": "attempts",
    "degree": 13,
    "influence": 0.00126
   },
   {
    "id": 718,
    "word": "meaning",
    "display": "meaningful",
    "degree": 10,
    "influence": 0.0009
   },
   {
    "id": 719,
    "word": "criteria",
    "display": "criteria",
    "degree": 6,
    "influence": 0.00044
   },
   {
    "id": 720,
    "word": "function",
    "display": "function",
    "degree": 6,
    "influence": 0.00032
   },
   {
    "id": 721,
    "word": "index",
    "display": "indexing",
    "degree": 9,
    "influence": 0.00018
   },
   {
    "id": 722,
    "word": "occurr",
    "display": "occurrence",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 723,
    "word": "procedur",
    "display": "procedure",
    "degree": 17,
    "influence": 0.0033
   },
   {
    "id": 724,
    "word": "latent",
    "display": "latent",
    "degree": 9,
    "influence": 0.00136
   },
   {
    "id": 725,
    "word": "emphasi",
    "display": "emphasis",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 726,
    "word": "object",
    "display": "objects",
    "degree": 19,
    "influence": 0.00128
   },
   {
    "id": 727,
    "word": "quantit",
    "display": "quantitative",
    "degree": 8,
    "influence": 0.0001
   },
   {
    "id": 728,
    "word": "measur",
    "display": "measure",
    "degree": 51,
    "influence": 0.01443
   },
   {
    "id": 729,
    "word": "featur",
    "display": "features",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 730,
    "word": "categori",
    "display": "categories",
    "degree": 12,
    "influence": 0.00086
   },
   {
    "id": 731,
    "word": "colleagu",
    "display": "colleagues",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 732,
    "word": "frame",
    "display": "frame",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 733,
    "word": "step",
    "display": "step",
    "degree": 19,
    "influence": 0.00179
   },
   {
    "id": 734,
    "word": "market",
    "display": "market",
    "degree": 4,
    "influence": 0.00014
   },
   {
    "id": 735,
    "word": "financi",
    "display": "financial",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 736,
    "word": "perform",
    "display": "performance",
    "degree": 6,
    "influence": 0.00147
   },
   {
    "id": 737,
    "word": "introduct",
    "display": "introduction",
    "degree": 18,
    "influence": 0.00714
   },
   {
    "id": 738,
    "word": "optim",
    "display": "optimal",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 739,
    "word": "intent",
    "display": "intentional",
    "degree": 9,
    "influence": 0.00031
   },
   {
    "id": 740,
    "word": "speaker",
    "display": "speakers",
    "degree": 15,
    "influence": 0.00076
   },
   {
    "id": 741,
    "word": "writer",
    "display": "writer",
    "degree": 3,
    "influence": 0.00001
   },
   {
    "id": 742,
    "word": "scheme",
    "display": "scheme",
    "degree": 14,
    "influence": 0.00069
   },
   {
    "id": 743,
    "word": "thought",
    "display": "thoughts",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 744,
    "word": "mental",
    "display": "mental",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 745,
    "word": "connect",
    "display": "connections",
    "degree": 17,
    "influence": 0.00106
   },
   {
    "id": 746,
    "word": "coher",
    "display": "coherence",
    "degree": 29,
    "influence": 0.00865
   },
   {
    "id": 747,
    "word": "composit",
    "display": "composition",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 748,
    "word": "basic",
    "display": "basic",
    "degree": 8,
    "influence": 0.00028
   },
   {
    "id": 749,
    "word": "worrisom",
    "display": "worrisome",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 750,
    "word": "nois",
    "display": "noise",
    "degree": 4,
    "influence": 0.00007
   },
   {
    "id": 751,
    "word": "correct",
    "display": "correct",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 752,
    "word": "innov",
    "display": "innovation",
    "degree": 7,
    "influence": 0.00081
   },
   {
    "id": 753,
    "word": "interconnect",
    "display": "interconnected",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 754,
    "word": "referenti",
    "display": "referential",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 755,
    "word": "scienc",
    "display": "science",
    "degree": 31,
    "influence": 0.01526
   },
   {
    "id": 756,
    "word": "rich",
    "display": "rich",
    "degree": 3,
    "influence": 0.00001
   },
   {
    "id": 757,
    "word": "statist",
    "display": "statistical",
    "degree": 12,
    "influence": 0.00058
   },
   {
    "id": 758,
    "word": "open",
    "display": "opening",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 759,
    "word": "choic",
    "display": "choice",
    "degree": 19,
    "influence": 0.00404
   },
   {
    "id": 760,
    "word": "aid",
    "display": "aid",
    "degree": 6,
    "influence": 0.00009
   },
   {
    "id": 761,
    "word": "retriev",
    "display": "retrieval",
    "degree": 18,
    "influence": 0.00225
   },
   {
    "id": 762,
    "word": "labor",
    "display": "labor",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 763,
    "word": "error",
    "display": "error",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 764,
    "word": "result",
    "display": "results",
    "degree": 20,
    "influence": 0.00258
   },
   {
    "id": 765,
    "word": "wretch",
    "display": "wretched",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 766,
    "word": "graduat",
    "display": "graduate",
    "degree": 2,
    "influence": 0.00041
   },
   {
    "id": 767,
    "word": "pre-tag",
    "display": "pre-tag",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 768,
    "word": "dataset",
    "display": "dataset",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 769,
    "word": "sum",
    "display": "sum",
    "degree": 2,
    "influence": 0.00031
   },
   {
    "id": 770,
    "word": "act",
    "display": "acts",
    "degree": 10,
    "influence": 0.00018
   },
   {
    "id": 771,
    "word": "third",
    "display": "third",
    "degree": 10,
    "influence": 0.00013
   },
   {
    "id": 772,
    "word": "independ",
    "display": "independent",
    "degree": 3,
    "influence": 0.00001
   },
   {
    "id": 773,
    "word": "corpora",
    "display": "corpora",
    "degree": 7,
    "influence": 0.00007
   },
   {
    "id": 774,
    "word": "maximum",
    "display": "maximum",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 775,
    "word": "kind",
    "display": "kind",
    "degree": 12,
    "influence": 0.00039
   },
   {
    "id": 776,
    "word": "overview",
    "display": "overview",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 777,
    "word": "im",
    "display": "im",
    "degree": 4,
    "influence": 0.00093
   },
   {
    "id": 778,
    "word": "portant",
    "display": "portant",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 779,
    "word": "make",
    "display": "making",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 780,
    "word": "phrase",
    "display": "phrases",
    "degree": 25,
    "influence": 0.00446
   },
   {
    "id": 781,
    "word": "center",
    "display": "centers",
    "degree": 32,
    "influence": 0.00536
   },
   {
    "id": 782,
    "word": "segment",
    "display": "segment",
    "degree": 9,
    "influence": 0.00069
   },
   {
    "id": 783,
    "word": "yield",
    "display": "yields",
    "degree": 9,
    "influence": 0.00072
   },
   {
    "id": 784,
    "word": "locat",
    "display": "location",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 785,
    "word": "written",
    "display": "written",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 786,
    "word": "sentenc",
    "display": "sentences",
    "degree": 19,
    "influence": 0.00116
   },
   {
    "id": 787,
    "word": "previous",
    "display": "previous",
    "degree": 4,
    "influence": 0.00027
   },
   {
    "id": 788,
    "word": "predict",
    "display": "predictable",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 789,
    "word": "stream",
    "display": "stream",
    "degree": 7,
    "influence": 0.0002
   },
   {
    "id": 790,
    "word": "strateg",
    "display": "strategic",
    "degree": 5,
    "influence": 0.00005
   },
   {
    "id": 791,
    "word": "fundament",
    "display": "fundamental",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 792,
    "word": "criterion",
    "display": "criterion",
    "degree": 10,
    "influence": 0.00026
   },
   {
    "id": 793,
    "word": "notion",
    "display": "notion",
    "degree": 10,
    "influence": 0.00035
   },
   {
    "id": 794,
    "word": "automat",
    "display": "automatic",
    "degree": 11,
    "influence": 0.00125
   },
   {
    "id": 795,
    "word": "arbitrari",
    "display": "arbitrary",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 796,
    "word": "stock",
    "display": "stock",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 797,
    "word": "codabl",
    "display": "codable",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 798,
    "word": "finit",
    "display": "finite",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 799,
    "word": "cen",
    "display": "cen",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 800,
    "word": "deploy",
    "display": "deployment",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 801,
    "word": "essenti",
    "display": "essential",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 802,
    "word": "former",
    "display": "former",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 803,
    "word": "latter",
    "display": "latter",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 804,
    "word": "greater",
    "display": "greater",
    "degree": 4,
    "influence": 0.00005
   },
   {
    "id": 805,
    "word": "depth",
    "display": "depth",
    "degree": 4,
    "influence": 0.00007
   },
   {
    "id": 806,
    "word": "involv",
    "display": "involved",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 807,
    "word": "fall",
    "display": "fall",
    "degree": 4,
    "influence": 0.00024
   },
   {
    "id": 808,
    "word": "compon",
    "display": "component",
    "degree": 6,
    "influence": 0.00003
   },
   {
    "id": 809,
    "word": "determin",
    "display": "determiners",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 810,
    "word": "filter",
    "display": "filter",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 811,
    "word": "main",
    "display": "main",
    "degree": 11,
    "influence": 0.00034
   },
   {
    "id": 812,
    "word": "exclus",
    "display": "exclusion",
    "degree": 5,
    "influence": 0.00019
   },
   {
    "id": 813,
    "word": "semanticist",
    "display": "semanticists",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 814,
    "word": "salient",
    "display": "salient",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 815,
    "word": "express",
    "display": "expression",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 816,
    "word": "concomit",
    "display": "concomitant",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 817,
    "word": "align",
    "display": "aligns",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 818,
    "word": "desir",
    "display": "desire",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 819,
    "word": "amount",
    "display": "amount",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 820,
    "word": "inclus",
    "display": "inclusion",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 821,
    "word": "conting",
    "display": "contingent",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 822,
    "word": "logic",
    "display": "logic",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 823,
    "word": "comment",
    "display": "comments",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 824,
    "word": "due",
    "display": "due",
    "degree": 7,
    "influence": 0.00009
   },
   {
    "id": 825,
    "word": "user",
    "display": "users",
    "degree": 7,
    "influence": 0.00014
   },
   {
    "id": 826,
    "word": "disambigu",
    "display": "disambiguation",
    "degree": 7,
    "influence": 0.00013
   },
   {
    "id": 827,
    "word": "proper",
    "display": "proper",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 828,
    "word": "actor",
    "display": "actors",
    "degree": 4,
    "influence": 0.00132
   },
   {
    "id": 829,
    "word": "appropri",
    "display": "appropriate",
    "degree": 10,
    "influence": 0.0009
   },
   {
    "id": 830,
    "word": "shade",
    "display": "shades",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 831,
    "word": "negoti",
    "display": "negotiators",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 832,
    "word": "disconnect",
    "display": "disconnect",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 833,
    "word": "opposit",
    "display": "opposite",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 834,
    "word": "minim",
    "display": "minimal",
    "degree": 2,
    "influence": 0.00118
   },
   {
    "id": 835,
    "word": "affix",
    "display": "affix",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 836,
    "word": "plural",
    "display": "plural",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 837,
    "word": "es",
    "display": "es",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 838,
    "word": "suffix",
    "display": "suffixes",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 839,
    "word": "rational",
    "display": "rationale",
    "degree": 6,
    "influence": 0.00025
   },
   {
    "id": 840,
    "word": "string",
    "display": "strings",
    "degree": 1,
    "influence": 0
   },
   {
    "id": 841,
    "word": "sequenti",
    "display": "sequential",
    "degree": 6,
    "influence": 0.00011
   },
   {
    "id": 842,
    "word": "linkag",
    "display": "linkage",
    "degree": 10,
    "influence": 0.0002
   },
   {
    "id": 843,
    "word": "higherord",
    "display": "higherorder",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 844,
    "word": "boundari",
    "display": "boundaries",
    "degree": 11,
    "influence": 0.00159
   },
   {
    "id": 845,
    "word": "exhaust",
    "display": "exhaust",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 846,
    "word": "connected",
    "display": "connectedness",
    "degree": 4,
    "influence": 0.00063
   },
   {
    "id": 847,
    "word": "speak",
    "display": "speaking",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 848,
    "word": "undirect",
    "display": "undirected",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 849,
    "word": "node",
    "display": "nodes",
    "degree": 33,
    "influence": 0.00456
   },
   {
    "id": 850,
    "word": "flow",
    "display": "flow",
    "degree": 15,
    "influence": 0.00085
   },
   {
    "id": 851,
    "word": "extent",
    "display": "extent",
    "degree": 13,
    "influence": 0.00197
   },
   {
    "id": 852,
    "word": "operation",
    "display": "operationalize",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 853,
    "word": "central",
    "display": "centrality",
    "degree": 30,
    "influence": 0.0058
   },
   {
    "id": 854,
    "word": "between",
    "display": "betweenness",
    "degree": 13,
    "influence": 0.00055
   },
   {
    "id": 855,
    "word": "anthoniss",
    "display": "anthonisse",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 856,
    "word": "rush",
    "display": "rush",
    "degree": 8,
    "influence": 0.00043
   },
   {
    "id": 857,
    "word": "graph",
    "display": "graph",
    "degree": 19,
    "influence": 0.00346
   },
   {
    "id": 858,
    "word": "total",
    "display": "total",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 859,
    "word": "vertic",
    "display": "vertices",
    "degree": 5,
    "influence": 0.00011
   },
   {
    "id": 860,
    "word": "freeman",
    "display": "freeman",
    "degree": 10,
    "influence": 0.00139
   },
   {
    "id": 861,
    "word": "classic",
    "display": "classic",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 862,
    "word": "peripher",
    "display": "peripheral",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 863,
    "word": "middl",
    "display": "middle",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 864,
    "word": "degre",
    "display": "degree",
    "degree": 9,
    "influence": 0.0002
   },
   {
    "id": 865,
    "word": "close",
    "display": "closeness",
    "degree": 9,
    "influence": 0.00048
   },
   {
    "id": 866,
    "word": "averag",
    "display": "average",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 867,
    "word": "path",
    "display": "paths",
    "degree": 9,
    "influence": 0.00082
   },
   {
    "id": 868,
    "word": "dispar",
    "display": "disparate",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 869,
    "word": "part",
    "display": "parts",
    "degree": 12,
    "influence": 0.00279
   },
   {
    "id": 870,
    "word": "higher",
    "display": "higher",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 871,
    "word": "standpoint",
    "display": "standpoint",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 872,
    "word": "chain",
    "display": "chains",
    "degree": 17,
    "influence": 0.00265
   },
   {
    "id": 873,
    "word": "channel",
    "display": "channels",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 874,
    "word": "jk",
    "display": "jk",
    "degree": 5,
    "influence": 0.00009
   },
   {
    "id": 875,
    "word": "shortest",
    "display": "shortest",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 876,
    "word": "th",
    "display": "th",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 877,
    "word": "presenc",
    "display": "presence",
    "degree": 2,
    "influence": 0.00061
   },
   {
    "id": 878,
    "word": "extern",
    "display": "external",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 879,
    "word": "signal",
    "display": "signal",
    "degree": 2,
    "influence": 0.00061
   },
   {
    "id": 880,
    "word": "physic",
    "display": "physical",
    "degree": 4,
    "influence": 0.00031
   },
   {
    "id": 881,
    "word": "contact",
    "display": "contact",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 882,
    "word": "wave",
    "display": "wave",
    "degree": 2,
    "influence": 0.00022
   },
   {
    "id": 883,
    "word": "net",
    "display": "net",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 884,
    "word": "queri",
    "display": "query",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 885,
    "word": "ij",
    "display": "ij",
    "degree": 10,
    "influence": 0.0002
   },
   {
    "id": 886,
    "word": "ab",
    "display": "ab",
    "degree": 10,
    "influence": 0.00107
   },
   {
    "id": 887,
    "word": "wr",
    "display": "wr",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 888,
    "word": "mutual",
    "display": "mutual",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 889,
    "word": "length",
    "display": "length",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 890,
    "word": "manner",
    "display": "manner",
    "degree": 3,
    "influence": 0.00111
   },
   {
    "id": 891,
    "word": "covari",
    "display": "covariance",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 892,
    "word": "random",
    "display": "random",
    "degree": 2,
    "influence": 0.00011
   },
   {
    "id": 893,
    "word": "correl",
    "display": "correlation",
    "degree": 16,
    "influence": 0.00156
   },
   {
    "id": 894,
    "word": "weight",
    "display": "weighted",
    "degree": 6,
    "influence": 0.00003
   },
   {
    "id": 895,
    "word": "ijkl",
    "display": "ijkl",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 896,
    "word": "kl",
    "display": "kl",
    "degree": 4,
    "influence": 0.00022
   },
   {
    "id": 897,
    "word": "pr",
    "display": "pr",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 898,
    "word": "sensit",
    "display": "sensitive",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 899,
    "word": "reason",
    "display": "reasons",
    "degree": 8,
    "influence": 0.00096
   },
   {
    "id": 900,
    "word": "sensibl",
    "display": "sensible",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 901,
    "word": "accommo",
    "display": "accommo",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 902,
    "word": "advoc",
    "display": "advocates",
    "degree": 11,
    "influence": 0.00123
   },
   {
    "id": 903,
    "word": "jame",
    "display": "james",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 904,
    "word": "topteam",
    "display": "topteam",
    "degree": 37,
    "influence": 0.00909
   },
   {
    "id": 905,
    "word": "palomino",
    "display": "palomino",
    "degree": 4,
    "influence": 0.00014
   },
   {
    "id": 906,
    "word": "incumb",
    "display": "incumbency",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 907,
    "word": "view",
    "display": "view",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 908,
    "word": "finger",
    "display": "finger",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 909,
    "word": "jack",
    "display": "jack",
    "degree": 3,
    "influence": 0.00005
   },
   {
    "id": 910,
    "word": "nerv",
    "display": "nerve",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 911,
    "word": "gumption",
    "display": "gumption",
    "degree": 7,
    "influence": 0.00027
   },
   {
    "id": 912,
    "word": "present",
    "display": "present",
    "degree": 4,
    "influence": 0.00005
   },
   {
    "id": 913,
    "word": "presid",
    "display": "president",
    "degree": 26,
    "influence": 0.00401
   },
   {
    "id": 914,
    "word": "mr",
    "display": "mr",
    "degree": 8,
    "influence": 0.00143
   },
   {
    "id": 915,
    "word": "certain",
    "display": "certain",
    "degree": 4,
    "influence": 0.00026
   },
   {
    "id": 916,
    "word": "weak",
    "display": "weaknesses",
    "degree": 6,
    "influence": 0.00177
   },
   {
    "id": 917,
    "word": "loss",
    "display": "losses",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 918,
    "word": "respons",
    "display": "responses",
    "degree": 18,
    "influence": 0.00128
   },
   {
    "id": 919,
    "word": "recommend",
    "display": "recommendation",
    "degree": 17,
    "influence": 0.00118
   },
   {
    "id": 920,
    "word": "board",
    "display": "board",
    "degree": 11,
    "influence": 0.00513
   },
   {
    "id": 921,
    "word": "haphazard",
    "display": "haphazard",
    "degree": 7,
    "influence": 0.00079
   },
   {
    "id": 922,
    "word": "oppon",
    "display": "opponents",
    "degree": 12,
    "influence": 0.00066
   },
   {
    "id": 923,
    "word": "arnold",
    "display": "arnold",
    "degree": 4,
    "influence": 0.00025
   },
   {
    "id": 924,
    "word": "exercis",
    "display": "exercise",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 925,
    "word": "hour",
    "display": "hours",
    "degree": 2,
    "influence": 0.00014
   },
   {
    "id": 926,
    "word": "heat",
    "display": "heated",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 927,
    "word": "wast",
    "display": "waste",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 928,
    "word": "chairman",
    "display": "chairman",
    "degree": 10,
    "influence": 0.00134
   },
   {
    "id": 929,
    "word": "sam",
    "display": "sam",
    "degree": 12,
    "influence": 0.00488
   },
   {
    "id": 930,
    "word": "man",
    "display": "man",
    "degree": 2,
    "influence": 0.00017
   },
   {
    "id": 931,
    "word": "chief",
    "display": "chief",
    "degree": 3,
    "influence": 0.00003
   },
   {
    "id": 932,
    "word": "execut",
    "display": "executive",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 933,
    "word": "prime",
    "display": "prime",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 934,
    "word": "minist",
    "display": "minister",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 935,
    "word": "parliamentari",
    "display": "parliamentary",
    "degree": 2,
    "influence": 0.00119
   },
   {
    "id": 936,
    "word": "cabinet",
    "display": "cabinet",
    "degree": 6,
    "influence": 0.00018
   },
   {
    "id": 937,
    "word": "kennedi",
    "display": "kennedy",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 938,
    "word": "secretari",
    "display": "secretary",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 939,
    "word": "disadvantag",
    "display": "disadvantage",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 940,
    "word": "irv",
    "display": "irving",
    "degree": 2,
    "influence": 0.00025
   },
   {
    "id": 941,
    "word": "prerog",
    "display": "prerogative",
    "degree": 6,
    "influence": 0.00007
   },
   {
    "id": 942,
    "word": "busi",
    "display": "business",
    "degree": 13,
    "influence": 0.00403
   },
   {
    "id": 943,
    "word": "wise",
    "display": "wise",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 944,
    "word": "avail",
    "display": "available",
    "degree": 7,
    "influence": 0.0005
   },
   {
    "id": 945,
    "word": "judgment",
    "display": "judgment",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 946,
    "word": "best",
    "display": "best",
    "degree": 4,
    "influence": 0.00006
   },
   {
    "id": 947,
    "word": "suggest",
    "display": "suggestion",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 948,
    "word": "date",
    "display": "dates",
    "degree": 4,
    "influence": 0.00009
   },
   {
    "id": 949,
    "word": "fourth",
    "display": "fourth",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 950,
    "word": "imposit",
    "display": "imposition",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 951,
    "word": "visual",
    "display": "visualization",
    "degree": 13,
    "influence": 0.00113
   },
   {
    "id": 952,
    "word": "origin",
    "display": "original",
    "degree": 6,
    "influence": 0.00006
   },
   {
    "id": 953,
    "word": "presumpt",
    "display": "presumption",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 954,
    "word": "intellectu",
    "display": "intellectual",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 955,
    "word": "medium",
    "display": "medium",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 956,
    "word": "themat",
    "display": "thematic",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 957,
    "word": "videotap",
    "display": "videotape",
    "degree": 6,
    "influence": 0.00025
   },
   {
    "id": 958,
    "word": "documentari",
    "display": "documentary",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 959,
    "word": "film",
    "display": "film",
    "degree": 4,
    "influence": 0.00015
   },
   {
    "id": 960,
    "word": "resort",
    "display": "resort",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 961,
    "word": "steinberg",
    "display": "steinberg",
    "degree": 6,
    "influence": 0.00026
   },
   {
    "id": 962,
    "word": "canadian",
    "display": "canadian",
    "degree": 3,
    "influence": 0.00003
   },
   {
    "id": 963,
    "word": "retail",
    "display": "retail",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 964,
    "word": "1970s",
    "display": "1970s",
    "degree": 2,
    "influence": 0.00047
   },
   {
    "id": 965,
    "word": "founder",
    "display": "founder",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 966,
    "word": "ceo",
    "display": "ceo",
    "degree": 2,
    "influence": 0.00076
   },
   {
    "id": 967,
    "word": "successor",
    "display": "successor",
    "degree": 3,
    "influence": 0.00025
   },
   {
    "id": 968,
    "word": "edit",
    "display": "edited",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 969,
    "word": "figur",
    "display": "figure",
    "degree": 30,
    "influence": 0.00436
   },
   {
    "id": 970,
    "word": "display",
    "display": "display",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 971,
    "word": "sampl",
    "display": "sample",
    "degree": 12,
    "influence": 0.00131
   },
   {
    "id": 972,
    "word": "top",
    "display": "top",
    "degree": 4,
    "influence": 0.00005
   },
   {
    "id": 973,
    "word": "committe",
    "display": "committee",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 974,
    "word": "empow",
    "display": "empowered",
    "degree": 2,
    "influence": 0.00011
   },
   {
    "id": 975,
    "word": "personnel",
    "display": "personnel",
    "degree": 4,
    "influence": 0.00009
   },
   {
    "id": 976,
    "word": "advocatesnetwork",
    "display": "advocatesnetwork",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 977,
    "word": "ital",
    "display": "italics",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 978,
    "word": "next-most",
    "display": "next-most",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 979,
    "word": "look",
    "display": "look",
    "degree": 4,
    "influence": 0.00048
   },
   {
    "id": 980,
    "word": "duti",
    "display": "duty",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 981,
    "word": "concert",
    "display": "concert",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 982,
    "word": "freedom",
    "display": "freedom",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 983,
    "word": "appoint",
    "display": "appointments",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 984,
    "word": "danger",
    "display": "danger",
    "degree": 4,
    "influence": 0.00017
   },
   {
    "id": 985,
    "word": "presidenti",
    "display": "presidential",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 986,
    "word": "foci",
    "display": "foci",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 987,
    "word": "subnetwork",
    "display": "subnetworks",
    "degree": 4,
    "influence": 0.0005
   },
   {
    "id": 988,
    "word": "upper",
    "display": "upper",
    "degree": 6,
    "influence": 0.00189
   },
   {
    "id": 989,
    "word": "anchor",
    "display": "anchor",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 990,
    "word": "lower",
    "display": "lower",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 991,
    "word": "highest",
    "display": "highest",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 992,
    "word": "bottom",
    "display": "bottom",
    "degree": 7,
    "influence": 0.00013
   },
   {
    "id": 993,
    "word": "vice",
    "display": "vice",
    "degree": 4,
    "influence": 0.00022
   },
   {
    "id": 994,
    "word": "side",
    "display": "side",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 995,
    "word": "hand",
    "display": "hand",
    "degree": 6,
    "influence": 0.00128
   },
   {
    "id": 996,
    "word": "reader",
    "display": "readers",
    "degree": 23,
    "influence": 0.00358
   },
   {
    "id": 997,
    "word": "forego",
    "display": "foregoing",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 998,
    "word": "map",
    "display": "maps",
    "degree": 15,
    "influence": 0.00167
   },
   {
    "id": 999,
    "word": "end",
    "display": "end",
    "degree": 4,
    "influence": 0.0006
   },
   {
    "id": 1000,
    "word": "undergradu",
    "display": "undergraduate",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1001,
    "word": "student",
    "display": "students",
    "degree": 12,
    "influence": 0.00242
   },
   {
    "id": 1002,
    "word": "excerpt",
    "display": "excerpts",
    "degree": 4,
    "influence": 0.00008
   },
   {
    "id": 1003,
    "word": "ident",
    "display": "identical",
    "degree": 5,
    "influence": 0.00003
   },
   {
    "id": 1004,
    "word": "municip",
    "display": "municipal",
    "degree": 2,
    "influence": 0.00027
   },
   {
    "id": 1005,
    "word": "govern",
    "display": "government",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1006,
    "word": "southwestern",
    "display": "southwestern",
    "degree": 2,
    "influence": 0.00095
   },
   {
    "id": 1007,
    "word": "verbatim",
    "display": "verbatim",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1008,
    "word": "interviewe",
    "display": "interviewee",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 1009,
    "word": "re",
    "display": "re",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1010,
    "word": "spons",
    "display": "sponses",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1011,
    "word": "smaller",
    "display": "smaller",
    "degree": 5,
    "influence": 0.00007
   },
   {
    "id": 1012,
    "word": "motiv",
    "display": "motivation",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1013,
    "word": "credit",
    "display": "credit",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1014,
    "word": "mark",
    "display": "mark",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 1015,
    "word": "name",
    "display": "name",
    "degree": 4,
    "influence": 0.0001
   },
   {
    "id": 1016,
    "word": "equat",
    "display": "equation",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1017,
    "word": "matric",
    "display": "matrices",
    "degree": 12,
    "influence": 0.00022
   },
   {
    "id": 1018,
    "word": "quadrat",
    "display": "quadratic",
    "degree": 4,
    "influence": 0.00036
   },
   {
    "id": 1019,
    "word": "assign",
    "display": "assignment",
    "degree": 3,
    "influence": 0.00001
   },
   {
    "id": 1020,
    "word": "qap",
    "display": "qap",
    "degree": 6,
    "influence": 0.00011
   },
   {
    "id": 1021,
    "word": "nonparametr",
    "display": "nonparametric",
    "degree": 6,
    "influence": 0.00017
   },
   {
    "id": 1022,
    "word": "ucinet",
    "display": "ucinet",
    "degree": 2,
    "influence": 0.00016
   },
   {
    "id": 1023,
    "word": "permut",
    "display": "permutations",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1024,
    "word": "distribut",
    "display": "distribution",
    "degree": 7,
    "influence": 0.00265
   },
   {
    "id": 1025,
    "word": "pearson",
    "display": "pearson",
    "degree": 4,
    "influence": 0.00112
   },
   {
    "id": 1026,
    "word": "moment",
    "display": "moment",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 1027,
    "word": "nave",
    "display": "nave",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1028,
    "word": "glanc",
    "display": "glance",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1029,
    "word": "percentag",
    "display": "percentage",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1030,
    "word": "stark",
    "display": "stark",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1031,
    "word": "nonsignific",
    "display": "nonsignificant",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1032,
    "word": "favor",
    "display": "favor",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 1033,
    "word": "popul",
    "display": "populations",
    "degree": 7,
    "influence": 0.00094
   },
   {
    "id": 1034,
    "word": "bigger",
    "display": "bigger",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1035,
    "word": "captur",
    "display": "captures",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1036,
    "word": "attribut",
    "display": "attribute",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1037,
    "word": "folger",
    "display": "folger",
    "degree": 6,
    "influence": 0.00045
   },
   {
    "id": 1038,
    "word": "intersubject",
    "display": "intersubjective",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1039,
    "word": "instanti",
    "display": "instantiation",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1040,
    "word": "fink",
    "display": "fink",
    "degree": 3,
    "influence": 0.00006
   },
   {
    "id": 1041,
    "word": "interconcept",
    "display": "interconcept",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1042,
    "word": "reliabl",
    "display": "reliability",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1043,
    "word": "stabil",
    "display": "stability",
    "degree": 4,
    "influence": 0.00031
   },
   {
    "id": 1044,
    "word": "subgroup",
    "display": "subgroup",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1045,
    "word": "heterogen",
    "display": "heterogeneous",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1046,
    "word": "good",
    "display": "good",
    "degree": 8,
    "influence": 0.00109
   },
   {
    "id": 1047,
    "word": "journal",
    "display": "journal",
    "degree": 36,
    "influence": 0.01038
   },
   {
    "id": 1048,
    "word": "european",
    "display": "european",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 1049,
    "word": "imag",
    "display": "image",
    "degree": 5,
    "influence": 0.00007
   },
   {
    "id": 1050,
    "word": "cultur",
    "display": "culture",
    "degree": 6,
    "influence": 0.00025
   },
   {
    "id": 1051,
    "word": "recogn",
    "display": "recognized",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1052,
    "word": "faculti",
    "display": "faculty",
    "degree": 13,
    "influence": 0.00138
   },
   {
    "id": 1053,
    "word": "seeker",
    "display": "seekers",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1054,
    "word": "expertis",
    "display": "expertise",
    "degree": 8,
    "influence": 0.00048
   },
   {
    "id": 1055,
    "word": "chart",
    "display": "chart",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1056,
    "word": "academ",
    "display": "academic",
    "degree": 4,
    "influence": 0.0006
   },
   {
    "id": 1057,
    "word": "tough",
    "display": "tough",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1058,
    "word": "today",
    "display": "today",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1059,
    "word": "expert",
    "display": "experts",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1060,
    "word": "cohort",
    "display": "cohorts",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1061,
    "word": "collegi",
    "display": "collegiate",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1062,
    "word": "fund",
    "display": "funding",
    "degree": 4,
    "influence": 0.00005
   },
   {
    "id": 1063,
    "word": "health",
    "display": "health",
    "degree": 6,
    "influence": 0.00031
   },
   {
    "id": 1064,
    "word": "provost",
    "display": "provost",
    "degree": 2,
    "influence": 0.0001
   },
   {
    "id": 1065,
    "word": "ovpr",
    "display": "ovpr",
    "degree": 14,
    "influence": 0.0015
   },
   {
    "id": 1066,
    "word": "belief",
    "display": "belief",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1067,
    "word": "propos",
    "display": "proposal",
    "degree": 4,
    "influence": 0.00006
   },
   {
    "id": 1068,
    "word": "titl",
    "display": "titles",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1069,
    "word": "authorship",
    "display": "authorship",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1070,
    "word": "legitim",
    "display": "legitimate",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1071,
    "word": "hierarch",
    "display": "hierarchical",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 1072,
    "word": "agglomer",
    "display": "agglomeration",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1073,
    "word": "tightest",
    "display": "tightest",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1074,
    "word": "shallow",
    "display": "shallow",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1075,
    "word": "left",
    "display": "left",
    "degree": 6,
    "influence": 0.00014
   },
   {
    "id": 1076,
    "word": "plot",
    "display": "plots",
    "degree": 4,
    "influence": 0.0002
   },
   {
    "id": 1077,
    "word": "clean",
    "display": "clean",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1078,
    "word": "break",
    "display": "breaks",
    "degree": 2,
    "influence": 0.00076
   },
   {
    "id": 1079,
    "word": "clear",
    "display": "clear",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1080,
    "word": "subclust",
    "display": "subclusters",
    "degree": 17,
    "influence": 0.00162
   },
   {
    "id": 1081,
    "word": "dissimilar",
    "display": "dissimilarities",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1082,
    "word": "special",
    "display": "special",
    "degree": 6,
    "influence": 0.00014
   },
   {
    "id": 1083,
    "word": "charact",
    "display": "characters",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1084,
    "word": "iter",
    "display": "iterative",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1085,
    "word": "dimension",
    "display": "dimensional",
    "degree": 9,
    "influence": 0.0012
   },
   {
    "id": 1086,
    "word": "nonmetr",
    "display": "nonmetric",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1087,
    "word": "tendenc",
    "display": "tendency",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1088,
    "word": "kyst2a",
    "display": "kyst2a",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1089,
    "word": "adequ",
    "display": "adequate",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1090,
    "word": "stress",
    "display": "stress",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1091,
    "word": "output",
    "display": "output",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1092,
    "word": "scatter",
    "display": "scatter",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1093,
    "word": "disagr",
    "display": "disagreement",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1094,
    "word": "right",
    "display": "right",
    "degree": 7,
    "influence": 0.0001
   },
   {
    "id": 1095,
    "word": "horizont",
    "display": "horizontal",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1096,
    "word": "circl",
    "display": "circles",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1097,
    "word": "bulk",
    "display": "bulk",
    "degree": 2,
    "influence": 0.00013
   },
   {
    "id": 1098,
    "word": "agreement",
    "display": "agreement",
    "degree": 3,
    "influence": 0.00003
   },
   {
    "id": 1099,
    "word": "curricula",
    "display": "curricula",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1100,
    "word": "vita",
    "display": "vitae",
    "degree": 2,
    "influence": 0.0001
   },
   {
    "id": 1101,
    "word": "chemic",
    "display": "chemical",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1102,
    "word": "biolog",
    "display": "biological",
    "degree": 9,
    "influence": 0.00068
   },
   {
    "id": 1103,
    "word": "microsci",
    "display": "microscience",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1104,
    "word": "dna",
    "display": "dna",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1105,
    "word": "genet",
    "display": "genetic",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1106,
    "word": "disord",
    "display": "disorders",
    "degree": 4,
    "influence": 0.00015
   },
   {
    "id": 1107,
    "word": "cellular",
    "display": "cellular",
    "degree": 4,
    "influence": 0.0003
   },
   {
    "id": 1108,
    "word": "generic",
    "display": "generics",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1109,
    "word": "biochem",
    "display": "biochemical",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1110,
    "word": "experiment",
    "display": "experimental",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 1111,
    "word": "anim",
    "display": "animal",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1112,
    "word": "biochemistri",
    "display": "biochemistry",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1113,
    "word": "diseas",
    "display": "diseases",
    "degree": 4,
    "influence": 0.00081
   },
   {
    "id": 1114,
    "word": "stressor",
    "display": "stressors",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1115,
    "word": "pathogen",
    "display": "pathogens",
    "degree": 2,
    "influence": 0.00044
   },
   {
    "id": 1116,
    "word": "dysfunct",
    "display": "dysfunctions",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1117,
    "word": "sociolog",
    "display": "sociology",
    "degree": 10,
    "influence": 0.00056
   },
   {
    "id": 1118,
    "word": "famili",
    "display": "families",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1119,
    "word": "label",
    "display": "label",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1120,
    "word": "heurist",
    "display": "heuristic",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1121,
    "word": "breadth",
    "display": "breadth",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1122,
    "word": "divers",
    "display": "diverse",
    "degree": 5,
    "influence": 0.00019
   },
   {
    "id": 1123,
    "word": "hole",
    "display": "holes",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 1124,
    "word": "opportun",
    "display": "opportunity",
    "degree": 1,
    "influence": 0
   },
   {
    "id": 1125,
    "word": "mate",
    "display": "mates",
    "degree": 1,
    "influence": 0
   },
   {
    "id": 1126,
    "word": "essay",
    "display": "essay",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1127,
    "word": "gap",
    "display": "gap",
    "degree": 2,
    "influence": 0.00008
   },
   {
    "id": 1128,
    "word": "endeavor",
    "display": "endeavors",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1129,
    "word": "panacea",
    "display": "panacea",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1130,
    "word": "tradit",
    "display": "traditional",
    "degree": 8,
    "influence": 0.0007
   },
   {
    "id": 1131,
    "word": "cast",
    "display": "cast",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1132,
    "word": "suffici",
    "display": "sufficient",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1133,
    "word": "build",
    "display": "build",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1134,
    "word": "low",
    "display": "low",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1135,
    "word": "wheel",
    "display": "wheels",
    "degree": 2,
    "influence": 0.00011
   },
   {
    "id": 1136,
    "word": "contagion",
    "display": "contagion",
    "degree": 2,
    "influence": 0.00062
   },
   {
    "id": 1137,
    "word": "bandwagon",
    "display": "bandwagon",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1138,
    "word": "diffus",
    "display": "diffusion",
    "degree": 2,
    "influence": 0.0006
   },
   {
    "id": 1139,
    "word": "decreas",
    "display": "decrease",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 1140,
    "word": "pronomin",
    "display": "pronominalization",
    "degree": 4,
    "influence": 0.0001
   },
   {
    "id": 1141,
    "word": "unrel",
    "display": "unrelated",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1142,
    "word": "scanner",
    "display": "scanners",
    "degree": 3,
    "influence": 0.00016
   },
   {
    "id": 1143,
    "word": "conjunct",
    "display": "conjunction",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1144,
    "word": "tape",
    "display": "tape",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1145,
    "word": "postexamin",
    "display": "postexamination",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1146,
    "word": "evalu",
    "display": "evaluations",
    "degree": 2,
    "influence": 0.00009
   },
   {
    "id": 1147,
    "word": "radiologist",
    "display": "radiologists",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1148,
    "word": "experi",
    "display": "experiments",
    "degree": 6,
    "influence": 0.00187
   },
   {
    "id": 1149,
    "word": "qualif",
    "display": "qualifications",
    "degree": 2,
    "influence": 0.00013
   },
   {
    "id": 1150,
    "word": "modif",
    "display": "modifications",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1151,
    "word": "immens",
    "display": "immense",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1152,
    "word": "condens",
    "display": "condensing",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1153,
    "word": "reduct",
    "display": "reduction",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1154,
    "word": "substant",
    "display": "substantively",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1155,
    "word": "urgenc",
    "display": "urgency",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1156,
    "word": "subtl",
    "display": "subtle",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1157,
    "word": "dynam",
    "display": "dynamic",
    "degree": 18,
    "influence": 0.00287
   },
   {
    "id": 1158,
    "word": "longstand",
    "display": "longstanding",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1159,
    "word": "qualit",
    "display": "qualitative",
    "degree": 4,
    "influence": 0
   },
   {
    "id": 1160,
    "word": "propon",
    "display": "proponents",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1161,
    "word": "option",
    "display": "option",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1162,
    "word": "news",
    "display": "news",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1163,
    "word": "stori",
    "display": "stories",
    "degree": 7,
    "influence": 0.00069
   },
   {
    "id": 1164,
    "word": "interrelationship",
    "display": "interrelationships",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 1165,
    "word": "cancer",
    "display": "cancer",
    "degree": 9,
    "influence": 0.00465
   },
   {
    "id": 1166,
    "word": "treatment",
    "display": "treatments",
    "degree": 2,
    "influence": 0.00085
   },
   {
    "id": 1167,
    "word": "fals",
    "display": "false",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1168,
    "word": "expect",
    "display": "expectations",
    "degree": 4,
    "influence": 0.00043
   },
   {
    "id": 1169,
    "word": "patient",
    "display": "patients",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1170,
    "word": "progress",
    "display": "progress",
    "degree": 9,
    "influence": 0.00434
   },
   {
    "id": 1171,
    "word": "clinic",
    "display": "clinical",
    "degree": 2,
    "influence": 0.00118
   },
   {
    "id": 1172,
    "word": "trial",
    "display": "trials",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1173,
    "word": "activist",
    "display": "activist",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1174,
    "word": "coverag",
    "display": "coverage",
    "degree": 4,
    "influence": 0.00126
   },
   {
    "id": 1175,
    "word": "pornographi",
    "display": "pornography",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1176,
    "word": "print",
    "display": "print",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1177,
    "word": "broadcast",
    "display": "broadcast",
    "degree": 1,
    "influence": 0
   },
   {
    "id": 1178,
    "word": "pictur",
    "display": "picture",
    "degree": 4,
    "influence": 0.00013
   },
   {
    "id": 1179,
    "word": "life",
    "display": "life",
    "degree": 4,
    "influence": 0.0024
   },
   {
    "id": 1180,
    "word": "breakthrough",
    "display": "breakthroughs",
    "degree": 2,
    "influence": 0.00109
   },
   {
    "id": 1181,
    "word": "magic",
    "display": "magic",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1182,
    "word": "bullet",
    "display": "bullets",
    "degree": 2,
    "influence": 0.00014
   },
   {
    "id": 1183,
    "word": "gain",
    "display": "gain",
    "degree": 2,
    "influence": 0.00134
   },
   {
    "id": 1184,
    "word": "portray",
    "display": "portrayals",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1185,
    "word": "announc",
    "display": "announcements",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1186,
    "word": "outlet",
    "display": "outlets",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1187,
    "word": "dyad",
    "display": "dyads",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1188,
    "word": "seri",
    "display": "series",
    "degree": 6,
    "influence": 0.00006
   },
   {
    "id": 1189,
    "word": "turn",
    "display": "turn",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1190,
    "word": "fragment",
    "display": "fragment",
    "degree": 11,
    "influence": 0.00108
   },
   {
    "id": 1191,
    "word": "decay",
    "display": "decay",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1192,
    "word": "interrel",
    "display": "interrelations",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1193,
    "word": "absenc",
    "display": "absence",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1194,
    "word": "press",
    "display": "press",
    "degree": 39,
    "influence": 0.02085
   },
   {
    "id": 1195,
    "word": "receiv",
    "display": "received",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1196,
    "word": "clariti",
    "display": "clarity",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1197,
    "word": "circuit",
    "display": "circuit",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1198,
    "word": "reorgan",
    "display": "reorganization",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1199,
    "word": "hook",
    "display": "hook",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1200,
    "word": "benign",
    "display": "benign",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1201,
    "word": "imagin",
    "display": "imagination",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1202,
    "word": "tool",
    "display": "tools",
    "degree": 5,
    "influence": 0.00072
   },
   {
    "id": 1203,
    "word": "big",
    "display": "big",
    "degree": 3,
    "influence": 0.00003
   },
   {
    "id": 1204,
    "word": "brother",
    "display": "brother",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1205,
    "word": "dramat",
    "display": "dramatic",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1206,
    "word": "employ",
    "display": "employers",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1207,
    "word": "narrat",
    "display": "narratives",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1208,
    "word": "extrem",
    "display": "extreme",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1209,
    "word": "dwell",
    "display": "dwelling",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1210,
    "word": "harm",
    "display": "harm",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1211,
    "word": "utopian",
    "display": "utopian",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1212,
    "word": "realiti",
    "display": "reality",
    "degree": 2,
    "influence": 0.00008
   },
   {
    "id": 1213,
    "word": "trend",
    "display": "trends",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1214,
    "word": "solut",
    "display": "solution",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1215,
    "word": "array",
    "display": "array",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1216,
    "word": "faction",
    "display": "factionalism",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1217,
    "word": "episod",
    "display": "episode",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1218,
    "word": "80s",
    "display": "80s",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1219,
    "word": "90s",
    "display": "90s",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1220,
    "word": "lion",
    "display": "lion",
    "degree": 2,
    "influence": 0.00008
   },
   {
    "id": 1221,
    "word": "laboratori",
    "display": "laboratory",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1222,
    "word": "reticul",
    "display": "reticulation",
    "degree": 2,
    "influence": 0.00008
   },
   {
    "id": 1223,
    "word": "preliminari",
    "display": "preliminary",
    "degree": 4,
    "influence": 0.00004
   },
   {
    "id": 1224,
    "word": "essenc",
    "display": "essence",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1225,
    "word": "english",
    "display": "english",
    "degree": 4,
    "influence": 0.00006
   },
   {
    "id": 1226,
    "word": "italian",
    "display": "italian",
    "degree": 4,
    "influence": 0.00111
   },
   {
    "id": 1227,
    "word": "turkish",
    "display": "turkish",
    "degree": 4,
    "influence": 0.00018
   },
   {
    "id": 1228,
    "word": "japanes",
    "display": "japanese",
    "degree": 4,
    "influence": 0.00048
   },
   {
    "id": 1229,
    "word": "frawley",
    "display": "frawley",
    "degree": 4,
    "influence": 0.00127
   },
   {
    "id": 1230,
    "word": "layer",
    "display": "layers",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1231,
    "word": "known",
    "display": "known",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1232,
    "word": "normal",
    "display": "normalization",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1233,
    "word": "white",
    "display": "white",
    "degree": 8,
    "influence": 0.00309
   },
   {
    "id": 1234,
    "word": "stray",
    "display": "stray",
    "degree": 3,
    "influence": 0.00001
   },
   {
    "id": 1235,
    "word": "wasserman",
    "display": "wasserman",
    "degree": 3,
    "influence": 0.00004
   },
   {
    "id": 1236,
    "word": "faust",
    "display": "faust",
    "degree": 3,
    "influence": 0.00006
   },
   {
    "id": 1237,
    "word": "stephenson",
    "display": "stephenson",
    "degree": 3,
    "influence": 0.00008
   },
   {
    "id": 1238,
    "word": "zelen",
    "display": "zelen",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1239,
    "word": "indirect",
    "display": "indirect",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1240,
    "word": "parsimoni",
    "display": "parsimonious",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1241,
    "word": "algorithm",
    "display": "algorithmic",
    "degree": 6,
    "influence": 0.00168
   },
   {
    "id": 1242,
    "word": "simpler",
    "display": "simpler",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1243,
    "word": "preconfer",
    "display": "preconference",
    "degree": 6,
    "influence": 0.00032
   },
   {
    "id": 1244,
    "word": "dialogu",
    "display": "dialogue",
    "degree": 4,
    "influence": 0.00005
   },
   {
    "id": 1245,
    "word": "washington",
    "display": "washington",
    "degree": 3,
    "influence": 0.0002
   },
   {
    "id": 1246,
    "word": "dc",
    "display": "dc",
    "degree": 4,
    "influence": 0.00032
   },
   {
    "id": 1247,
    "word": "francoi",
    "display": "francois",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1248,
    "word": "cooren",
    "display": "cooren",
    "degree": 4,
    "influence": 0.00131
   },
   {
    "id": 1249,
    "word": "suni",
    "display": "suny",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1250,
    "word": "albani",
    "display": "albany",
    "degree": 2,
    "influence": 0.00089
   },
   {
    "id": 1251,
    "word": "uneven",
    "display": "uneven",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1252,
    "word": "instructor",
    "display": "instructor",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1253,
    "word": "willing",
    "display": "willingness",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1254,
    "word": "unequ",
    "display": "unequal",
    "degree": 3,
    "influence": 0.00009
   },
   {
    "id": 1255,
    "word": "onlin",
    "display": "online",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1256,
    "word": "dietari",
    "display": "dietary",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1257,
    "word": "guidelin",
    "display": "guidelines",
    "degree": 2,
    "influence": 0.00059
   },
   {
    "id": 1258,
    "word": "entireti",
    "display": "entirety",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1259,
    "word": "benchmark",
    "display": "benchmark",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1260,
    "word": "noisi",
    "display": "noisy",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1261,
    "word": "explicit",
    "display": "explicit",
    "degree": 4,
    "influence": 0.00003
   },
   {
    "id": 1262,
    "word": "accur",
    "display": "accurate",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1263,
    "word": "frequencydomain",
    "display": "frequencydomain",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1264,
    "word": "cycl",
    "display": "cycles",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1265,
    "word": "densiti",
    "display": "density",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1266,
    "word": "adam",
    "display": "adams",
    "degree": 4,
    "influence": 0.00259
   },
   {
    "id": 1267,
    "word": "wrangler",
    "display": "wranglers",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1268,
    "word": "classif",
    "display": "classification",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1269,
    "word": "enterpris",
    "display": "enterprise",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1270,
    "word": "bag",
    "display": "bags",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1271,
    "word": "km",
    "display": "km",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1272,
    "word": "februari",
    "display": "february",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1273,
    "word": "allen",
    "display": "allen",
    "degree": 4,
    "influence": 0.00099
   },
   {
    "id": 1274,
    "word": "friendship",
    "display": "friendship",
    "degree": 4,
    "influence": 0.00089
   },
   {
    "id": 1275,
    "word": "cambridg",
    "display": "cambridge",
    "degree": 10,
    "influence": 0.0029
   },
   {
    "id": 1276,
    "word": "uk",
    "display": "uk",
    "degree": 5,
    "influence": 0.00015
   },
   {
    "id": 1277,
    "word": "alder",
    "display": "alder",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1278,
    "word": "ethic",
    "display": "ethical",
    "degree": 4,
    "influence": 0.00046
   },
   {
    "id": 1279,
    "word": "monitor",
    "display": "monitoring",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1280,
    "word": "deontolog",
    "display": "deontological",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1281,
    "word": "teleolog",
    "display": "teleological",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1282,
    "word": "gotcher",
    "display": "gotcher",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1283,
    "word": "seibert",
    "display": "seibert",
    "degree": 2,
    "influence": 0.00026
   },
   {
    "id": 1284,
    "word": "decad",
    "display": "decade",
    "degree": 2,
    "influence": 0.00146
   },
   {
    "id": 1285,
    "word": "deetz",
    "display": "deetz",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 1286,
    "word": "yearbook",
    "display": "yearbook",
    "degree": 6,
    "influence": 0.00154
   },
   {
    "id": 1287,
    "word": "newburi",
    "display": "newbury",
    "degree": 3,
    "influence": 0.00081
   },
   {
    "id": 1288,
    "word": "park",
    "display": "park",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1289,
    "word": "sage",
    "display": "sage",
    "degree": 16,
    "influence": 0.0047
   },
   {
    "id": 1290,
    "word": "summar",
    "display": "summarization",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 1291,
    "word": "anderson",
    "display": "anderson",
    "degree": 4,
    "influence": 0.00001
   },
   {
    "id": 1292,
    "word": "direct",
    "display": "directed",
    "degree": 4,
    "influence": 0.00015
   },
   {
    "id": 1293,
    "word": "amsterdam",
    "display": "amsterdam",
    "degree": 5,
    "influence": 0.00331
   },
   {
    "id": 1294,
    "word": "sticht",
    "display": "stichting",
    "degree": 2,
    "influence": 0.00112
   },
   {
    "id": 1295,
    "word": "mathematisch",
    "display": "mathematisch",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1296,
    "word": "centrum",
    "display": "centrum",
    "degree": 2,
    "influence": 0.00012
   },
   {
    "id": 1297,
    "word": "auld",
    "display": "auld",
    "degree": 2,
    "influence": 0.00132
   },
   {
    "id": 1298,
    "word": "axelrod",
    "display": "axelrod",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1299,
    "word": "elit",
    "display": "elites",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1300,
    "word": "princeton",
    "display": "princeton",
    "degree": 4,
    "influence": 0.00041
   },
   {
    "id": 1301,
    "word": "nj",
    "display": "nj",
    "degree": 9,
    "influence": 0.00307
   },
   {
    "id": 1302,
    "word": "axley",
    "display": "axley",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1303,
    "word": "manageri",
    "display": "managerial",
    "degree": 2,
    "influence": 0.00017
   },
   {
    "id": 1304,
    "word": "conduit",
    "display": "conduit",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1305,
    "word": "academi",
    "display": "academy",
    "degree": 4,
    "influence": 0.00006
   },
   {
    "id": 1306,
    "word": "baeza",
    "display": "baeza",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1307,
    "word": "yate",
    "display": "yates",
    "degree": 4,
    "influence": 0.00213
   },
   {
    "id": 1308,
    "word": "ribiero",
    "display": "ribiero",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1309,
    "word": "neto",
    "display": "neto",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1310,
    "word": "modern",
    "display": "modern",
    "degree": 5,
    "influence": 0.00134
   },
   {
    "id": 1311,
    "word": "york",
    "display": "york",
    "degree": 12,
    "influence": 0.00843
   },
   {
    "id": 1312,
    "word": "addison",
    "display": "addison",
    "degree": 2,
    "influence": 0.00107
   },
   {
    "id": 1313,
    "word": "wesley",
    "display": "wesley",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1314,
    "word": "bak",
    "display": "bak",
    "degree": 2,
    "influence": 0.00018
   },
   {
    "id": 1315,
    "word": "chen",
    "display": "chen",
    "degree": 2,
    "influence": 0.00136
   },
   {
    "id": 1316,
    "word": "scientif",
    "display": "scientific",
    "degree": 5,
    "influence": 0.00012
   },
   {
    "id": 1317,
    "word": "american",
    "display": "american",
    "degree": 10,
    "influence": 0.00257
   },
   {
    "id": 1318,
    "word": "bakeman",
    "display": "bakeman",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1319,
    "word": "gottman",
    "display": "gottman",
    "degree": 2,
    "influence": 0.0002
   },
   {
    "id": 1320,
    "word": "baker",
    "display": "baker",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 1321,
    "word": "hubert",
    "display": "hubert",
    "degree": 4,
    "influence": 0.00125
   },
   {
    "id": 1322,
    "word": "occas",
    "display": "occasion",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1323,
    "word": "radiolog",
    "display": "radiology",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1324,
    "word": "administr",
    "display": "administrative",
    "degree": 5,
    "influence": 0.0013
   },
   {
    "id": 1325,
    "word": "quarter",
    "display": "quarterly",
    "degree": 13,
    "influence": 0.0032
   },
   {
    "id": 1326,
    "word": "cottrel",
    "display": "cottrell",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1327,
    "word": "belew",
    "display": "belew",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1328,
    "word": "15th",
    "display": "15th",
    "degree": 3,
    "influence": 0.00037
   },
   {
    "id": 1329,
    "word": "annual",
    "display": "annual",
    "degree": 8,
    "influence": 0.00117
   },
   {
    "id": 1330,
    "word": "sigir",
    "display": "sigir",
    "degree": 3,
    "influence": 0.00022
   },
   {
    "id": 1331,
    "word": "denmark",
    "display": "denmark",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1332,
    "word": "boden",
    "display": "boden",
    "degree": 2,
    "influence": 0.00101
   },
   {
    "id": 1333,
    "word": "politi",
    "display": "polity",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1334,
    "word": "botan",
    "display": "botan",
    "degree": 2,
    "influence": 0.00015
   },
   {
    "id": 1335,
    "word": "surveil",
    "display": "surveillance",
    "degree": 4,
    "influence": 0.00018
   },
   {
    "id": 1336,
    "word": "panopt",
    "display": "panoptic",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1337,
    "word": "monograph",
    "display": "monographs",
    "degree": 8,
    "influence": 0.00196
   },
   {
    "id": 1338,
    "word": "mathemat",
    "display": "mathematical",
    "degree": 5,
    "influence": 0.00003
   },
   {
    "id": 1339,
    "word": "voluntari",
    "display": "voluntary",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1340,
    "word": "brunt",
    "display": "brunt",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1341,
    "word": "burt",
    "display": "burt",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1342,
    "word": "competit",
    "display": "competition",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1343,
    "word": "ma",
    "display": "ma",
    "degree": 3,
    "influence": 0.00005
   },
   {
    "id": 1344,
    "word": "harvard",
    "display": "harvard",
    "degree": 6,
    "influence": 0.00027
   },
   {
    "id": 1345,
    "word": "mahwah",
    "display": "mahwah",
    "degree": 5,
    "influence": 0.00168
   },
   {
    "id": 1346,
    "word": "erlbaum",
    "display": "erlbaum",
    "degree": 11,
    "influence": 0.00167
   },
   {
    "id": 1347,
    "word": "kaufer",
    "display": "kaufer",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1348,
    "word": "prietula",
    "display": "prietula",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1349,
    "word": "xi",
    "display": "xi",
    "degree": 2,
    "influence": 0.00023
   },
   {
    "id": 1350,
    "word": "xvii",
    "display": "xvii",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1351,
    "word": "hillsdal",
    "display": "hillsdale",
    "degree": 5,
    "influence": 0.0022
   },
   {
    "id": 1352,
    "word": "cloitr",
    "display": "cloitre",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1353,
    "word": "bever",
    "display": "bever",
    "degree": 6,
    "influence": 0.00105
   },
   {
    "id": 1354,
    "word": "anaphor",
    "display": "anaphors",
    "degree": 5,
    "influence": 0.00004
   },
   {
    "id": 1355,
    "word": "burger",
    "display": "burger",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1356,
    "word": "jone",
    "display": "jones",
    "degree": 9,
    "influence": 0.00101
   },
   {
    "id": 1357,
    "word": "somer",
    "display": "somers",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1358,
    "word": "london",
    "display": "london",
    "degree": 2,
    "influence": 0.00021
   },
   {
    "id": 1359,
    "word": "ucl",
    "display": "ucl",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1360,
    "word": "contractor",
    "display": "contractor",
    "degree": 6,
    "influence": 0.00212
   },
   {
    "id": 1361,
    "word": "danner",
    "display": "danner",
    "degree": 2,
    "influence": 0.00055
   },
   {
    "id": 1362,
    "word": "palazzolo",
    "display": "palazzolo",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1363,
    "word": "serb",
    "display": "serb",
    "degree": 2,
    "influence": 0.00068
   },
   {
    "id": 1364,
    "word": "co-evolut",
    "display": "co-evolution",
    "degree": 2,
    "influence": 0.00188
   },
   {
    "id": 1365,
    "word": "transact",
    "display": "transactive",
    "degree": 3,
    "influence": 0.00001
   },
   {
    "id": 1366,
    "word": "memori",
    "display": "memory",
    "degree": 8,
    "influence": 0.00143
   },
   {
    "id": 1367,
    "word": "integr",
    "display": "integration",
    "degree": 4,
    "influence": 0.00015
   },
   {
    "id": 1368,
    "word": "extens",
    "display": "extension",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1369,
    "word": "confer",
    "display": "conference",
    "degree": 7,
    "influence": 0.00193
   },
   {
    "id": 1370,
    "word": "watt",
    "display": "watt",
    "degree": 3,
    "influence": 0.00029
   },
   {
    "id": 1371,
    "word": "vanlear",
    "display": "vanlear",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1372,
    "word": "oak",
    "display": "oaks",
    "degree": 6,
    "influence": 0.001
   },
   {
    "id": 1373,
    "word": "automata",
    "display": "automata",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1374,
    "word": "houston",
    "display": "houston",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1375,
    "word": "selforgan",
    "display": "selforganizing",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1376,
    "word": "westport",
    "display": "westport",
    "degree": 3,
    "influence": 0.00016
   },
   {
    "id": 1377,
    "word": "ablex",
    "display": "ablex",
    "degree": 10,
    "influence": 0.00369
   },
   {
    "id": 1378,
    "word": "bradford",
    "display": "bradford",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1379,
    "word": "scott",
    "display": "scott",
    "degree": 3,
    "influence": 0.00111
   },
   {
    "id": 1380,
    "word": "craig",
    "display": "craig",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1381,
    "word": "daft",
    "display": "daft",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1382,
    "word": "design",
    "display": "design",
    "degree": 4,
    "influence": 0.00199
   },
   {
    "id": 1383,
    "word": "st",
    "display": "st",
    "degree": 2,
    "influence": 0.00077
   },
   {
    "id": 1384,
    "word": "paul",
    "display": "paul",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1385,
    "word": "mn",
    "display": "mn",
    "degree": 2,
    "influence": 0.00045
   },
   {
    "id": 1386,
    "word": "west",
    "display": "west",
    "degree": 5,
    "influence": 0.00183
   },
   {
    "id": 1387,
    "word": "mediat",
    "display": "mediated",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1388,
    "word": "bulletin",
    "display": "bulletin",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1389,
    "word": "infograph",
    "display": "infographics",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1390,
    "word": "goldhab",
    "display": "goldhaber",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1391,
    "word": "handbook",
    "display": "handbook",
    "degree": 5,
    "influence": 0.00019
   },
   {
    "id": 1392,
    "word": "norwood",
    "display": "norwood",
    "degree": 3,
    "influence": 0.00069
   },
   {
    "id": 1393,
    "word": "trec-1",
    "display": "trec-1",
    "degree": 2,
    "influence": 0.00039
   },
   {
    "id": 1394,
    "word": "gaithersburg",
    "display": "gaithersburg",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1395,
    "word": "md",
    "display": "md",
    "degree": 2,
    "influence": 0.00084
   },
   {
    "id": 1396,
    "word": "richard",
    "display": "richards",
    "degree": 5,
    "influence": 0.00014
   },
   {
    "id": 1397,
    "word": "davenport",
    "display": "davenport",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1398,
    "word": "prusak",
    "display": "prusak",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1399,
    "word": "boston",
    "display": "boston",
    "degree": 2,
    "influence": 0.00009
   },
   {
    "id": 1400,
    "word": "desancti",
    "display": "desanctis",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1401,
    "word": "mong",
    "display": "monge",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1402,
    "word": "virtual",
    "display": "virtual",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1403,
    "word": "diefenbach",
    "display": "diefenbach",
    "degree": 2,
    "influence": 0.00013
   },
   {
    "id": 1404,
    "word": "histor",
    "display": "historical",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1405,
    "word": "di",
    "display": "di",
    "degree": 2,
    "influence": 0.00016
   },
   {
    "id": 1406,
    "word": "eugenio",
    "display": "eugenio",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1407,
    "word": "walker",
    "display": "walker",
    "degree": 6,
    "influence": 0.00265
   },
   {
    "id": 1408,
    "word": "joshi",
    "display": "joshi",
    "degree": 4,
    "influence": 0.00099
   },
   {
    "id": 1409,
    "word": "princ",
    "display": "prince",
    "degree": 2,
    "influence": 0.00045
   },
   {
    "id": 1410,
    "word": "oxford",
    "display": "oxford",
    "degree": 8,
    "influence": 0.00247
   },
   {
    "id": 1411,
    "word": "clarendon",
    "display": "clarendon",
    "degree": 4,
    "influence": 0.00065
   },
   {
    "id": 1412,
    "word": "adapt",
    "display": "adaptive",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 1413,
    "word": "nonlinear",
    "display": "nonlinear",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1414,
    "word": "baum",
    "display": "baum",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1415,
    "word": "companion",
    "display": "companion",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1416,
    "word": "blackwel",
    "display": "blackwell",
    "degree": 5,
    "influence": 0.00116
   },
   {
    "id": 1417,
    "word": "broadband",
    "display": "broadband",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1418,
    "word": "drazin",
    "display": "drazin",
    "degree": 2,
    "influence": 0.00018
   },
   {
    "id": 1419,
    "word": "rao",
    "display": "rao",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1420,
    "word": "eisenberg",
    "display": "eisenberg",
    "degree": 2,
    "influence": 0.00033
   },
   {
    "id": 1421,
    "word": "jam",
    "display": "jamming",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1422,
    "word": "transcend",
    "display": "transcendence",
    "degree": 2,
    "influence": 0.00088
   },
   {
    "id": 1423,
    "word": "barbosa",
    "display": "barbosa",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1424,
    "word": "mend",
    "display": "mendes",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1425,
    "word": "societi",
    "display": "society",
    "degree": 6,
    "influence": 0.00079
   },
   {
    "id": 1426,
    "word": "communicaiton",
    "display": "communicaiton",
    "degree": 2,
    "influence": 0.00022
   },
   {
    "id": 1427,
    "word": "fairhurst",
    "display": "fairhurst",
    "degree": 4,
    "influence": 0.00021
   },
   {
    "id": 1428,
    "word": "chandler",
    "display": "chandler",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1429,
    "word": "leader",
    "display": "leader",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1430,
    "word": "pirrelli",
    "display": "pirrelli",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1431,
    "word": "analog",
    "display": "analogy",
    "degree": 2,
    "influence": 0.00107
   },
   {
    "id": 1432,
    "word": "hew",
    "display": "hewes",
    "degree": 4,
    "influence": 0.00002
   },
   {
    "id": 1433,
    "word": "pool",
    "display": "poole",
    "degree": 12,
    "influence": 0.00241
   },
   {
    "id": 1434,
    "word": "dervin",
    "display": "dervin",
    "degree": 2,
    "influence": 0.00024
   },
   {
    "id": 1435,
    "word": "voight",
    "display": "voight",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1436,
    "word": "foltz",
    "display": "foltz",
    "degree": 4,
    "influence": 0.00011
   },
   {
    "id": 1437,
    "word": "kintsch",
    "display": "kintsch",
    "degree": 4,
    "influence": 0.00009
   },
   {
    "id": 1438,
    "word": "vintag",
    "display": "vintage",
    "degree": 2,
    "influence": 0.00035
   },
   {
    "id": 1439,
    "word": "book",
    "display": "books",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1440,
    "word": "frake",
    "display": "frakes",
    "degree": 2,
    "influence": 0.00038
   },
   {
    "id": 1441,
    "word": "bazea",
    "display": "bazea",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1442,
    "word": "englewood",
    "display": "englewood",
    "degree": 2,
    "influence": 0.00016
   },
   {
    "id": 1443,
    "word": "cliff",
    "display": "cliffs",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1444,
    "word": "prentic",
    "display": "prentice",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1445,
    "word": "hall",
    "display": "hall",
    "degree": 3,
    "influence": 0.00012
   },
   {
    "id": 1446,
    "word": "clarif",
    "display": "clarification",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1447,
    "word": "blank",
    "display": "blanks",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1448,
    "word": "affili",
    "display": "affiliation",
    "degree": 1,
    "influence": 0
   },
   {
    "id": 1449,
    "word": "march",
    "display": "march",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1450,
    "word": "borgatti",
    "display": "borgatti",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1451,
    "word": "friedkin",
    "display": "friedkin",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1452,
    "word": "forc",
    "display": "forces",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1453,
    "word": "frost",
    "display": "frost",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1454,
    "word": "stablein",
    "display": "stablein",
    "degree": 4,
    "influence": 0.00009
   },
   {
    "id": 1455,
    "word": "holder",
    "display": "holder",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1456,
    "word": "parallel",
    "display": "parallelism",
    "degree": 2,
    "influence": 0.00087
   },
   {
    "id": 1457,
    "word": "discoveri",
    "display": "discovery",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 1458,
    "word": "scalabl",
    "display": "scalability",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1459,
    "word": "gerken",
    "display": "gerken",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1460,
    "word": "intuit",
    "display": "intuitions",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1461,
    "word": "perceptu",
    "display": "perceptual",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1462,
    "word": "gidden",
    "display": "giddens",
    "degree": 5,
    "influence": 0.00088
   },
   {
    "id": 1463,
    "word": "berkeley",
    "display": "berkeley",
    "degree": 3,
    "influence": 0.00006
   },
   {
    "id": 1464,
    "word": "california",
    "display": "california",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1465,
    "word": "constitut",
    "display": "constitution",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1466,
    "word": "outlin",
    "display": "outline",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1467,
    "word": "stanford",
    "display": "stanford",
    "degree": 3,
    "influence": 0.00009
   },
   {
    "id": 1468,
    "word": "givn",
    "display": "givn",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1469,
    "word": "typolog",
    "display": "typological",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1470,
    "word": "benjamin",
    "display": "benjamins",
    "degree": 3,
    "influence": 0.00032
   },
   {
    "id": 1471,
    "word": "gordon",
    "display": "gordon",
    "degree": 4,
    "influence": 0.00104
   },
   {
    "id": 1472,
    "word": "grosz",
    "display": "grosz",
    "degree": 4,
    "influence": 0.00028
   },
   {
    "id": 1473,
    "word": "gilliom",
    "display": "gilliom",
    "degree": 2,
    "influence": 0.00025
   },
   {
    "id": 1474,
    "word": "hendrick",
    "display": "hendrick",
    "degree": 2,
    "influence": 0.00016
   },
   {
    "id": 1475,
    "word": "accomplish",
    "display": "accomplishment",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1476,
    "word": "groopman",
    "display": "groopman",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1477,
    "word": "war",
    "display": "war",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1478,
    "word": "yorker",
    "display": "yorker",
    "degree": 2,
    "influence": 0.00076
   },
   {
    "id": 1479,
    "word": "weinstein",
    "display": "weinstein",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1480,
    "word": "romack",
    "display": "romacker",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1481,
    "word": "schulz",
    "display": "schulz",
    "degree": 2,
    "influence": 0.00079
   },
   {
    "id": 1482,
    "word": "medic",
    "display": "medical",
    "degree": 4,
    "influence": 0.00148
   },
   {
    "id": 1483,
    "word": "informat",
    "display": "informatics",
    "degree": 2,
    "influence": 0.00026
   },
   {
    "id": 1484,
    "word": "hammond",
    "display": "hammond",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1485,
    "word": "produc",
    "display": "producers",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1486,
    "word": "nation",
    "display": "nations",
    "degree": 6,
    "influence": 0.00092
   },
   {
    "id": 1487,
    "word": "canada",
    "display": "canada",
    "degree": 4,
    "influence": 0.00161
   },
   {
    "id": 1488,
    "word": "fifth",
    "display": "fifth",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1489,
    "word": "avenu",
    "display": "avenue",
    "degree": 2,
    "influence": 0.00016
   },
   {
    "id": 1490,
    "word": "suit",
    "display": "suite",
    "degree": 2,
    "influence": 0.00136
   },
   {
    "id": 1491,
    "word": "ny",
    "display": "ny",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1492,
    "word": "hart",
    "display": "hart",
    "degree": 4,
    "influence": 0.00034
   },
   {
    "id": 1493,
    "word": "systemat",
    "display": "systematic",
    "degree": 2,
    "influence": 0.00033
   },
   {
    "id": 1494,
    "word": "diction",
    "display": "diction",
    "degree": 4,
    "influence": 0.00022
   },
   {
    "id": 1495,
    "word": "sander",
    "display": "sanders",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1496,
    "word": "carbondal",
    "display": "carbondale",
    "degree": 2,
    "influence": 0.00024
   },
   {
    "id": 1497,
    "word": "southern",
    "display": "southern",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1498,
    "word": "illinoi",
    "display": "illinois",
    "degree": 3,
    "influence": 0.00101
   },
   {
    "id": 1499,
    "word": "hopper",
    "display": "hopper",
    "degree": 3,
    "influence": 0.00005
   },
   {
    "id": 1500,
    "word": "thompson",
    "display": "thompson",
    "degree": 5,
    "influence": 0.00049
   },
   {
    "id": 1501,
    "word": "icon",
    "display": "iconicity",
    "degree": 4,
    "influence": 0.00015
   },
   {
    "id": 1502,
    "word": "haiman",
    "display": "haiman",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1503,
    "word": "howard",
    "display": "howard",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1504,
    "word": "nasti",
    "display": "nasty",
    "degree": 2,
    "influence": 0.00093
   },
   {
    "id": 1505,
    "word": "schultz",
    "display": "schultz",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1506,
    "word": "british",
    "display": "british",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1507,
    "word": "descriptor",
    "display": "descriptors",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1508,
    "word": "hyatt",
    "display": "hyatt",
    "degree": 2,
    "influence": 0.00009
   },
   {
    "id": 1509,
    "word": "iida",
    "display": "iida",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1510,
    "word": "jackson",
    "display": "jackson",
    "degree": 2,
    "influence": 0.00012
   },
   {
    "id": 1511,
    "word": "rossi",
    "display": "rossi",
    "degree": 2,
    "influence": 0.00033
   },
   {
    "id": 1512,
    "word": "pragmat",
    "display": "pragmatic",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1513,
    "word": "margaret",
    "display": "margaret",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1514,
    "word": "mclaughlin",
    "display": "mclaughlin",
    "degree": 4,
    "influence": 0.00101
   },
   {
    "id": 1515,
    "word": "jurafski",
    "display": "jurafsky",
    "degree": 2,
    "influence": 0.00034
   },
   {
    "id": 1516,
    "word": "martin",
    "display": "martin",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1517,
    "word": "speech",
    "display": "speech",
    "degree": 4,
    "influence": 0.00093
   },
   {
    "id": 1518,
    "word": "saddl",
    "display": "saddle",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1519,
    "word": "river",
    "display": "river",
    "degree": 3,
    "influence": 0.00012
   },
   {
    "id": 1520,
    "word": "kellerman",
    "display": "kellerman",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1521,
    "word": "sleight",
    "display": "sleight",
    "degree": 2,
    "influence": 0.00118
   },
   {
    "id": 1522,
    "word": "adhes",
    "display": "adhesive",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1523,
    "word": "predic",
    "display": "predication",
    "degree": 2,
    "influence": 0.0001
   },
   {
    "id": 1524,
    "word": "kohonen",
    "display": "kohonen",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1525,
    "word": "springer",
    "display": "springer",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1526,
    "word": "verlag",
    "display": "verlag",
    "degree": 2,
    "influence": 0.00008
   },
   {
    "id": 1527,
    "word": "krackhardt",
    "display": "krackhardt",
    "degree": 4,
    "influence": 0.00212
   },
   {
    "id": 1528,
    "word": "spurious",
    "display": "spuriousness",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1529,
    "word": "regress",
    "display": "regression",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 1530,
    "word": "dyadic",
    "display": "dyadic",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1531,
    "word": "kilduff",
    "display": "kilduff",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1532,
    "word": "anthropologist",
    "display": "anthropologist",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 1533,
    "word": "kruskal",
    "display": "kruskal",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1534,
    "word": "hill",
    "display": "hills",
    "degree": 5,
    "influence": 0.00032
   },
   {
    "id": 1535,
    "word": "unpublish",
    "display": "unpublished",
    "degree": 3,
    "influence": 0.00142
   },
   {
    "id": 1536,
    "word": "doctor",
    "display": "doctoral",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1537,
    "word": "dissert",
    "display": "dissertation",
    "degree": 3,
    "influence": 0.00014
   },
   {
    "id": 1538,
    "word": "laham",
    "display": "laham",
    "degree": 2,
    "influence": 0.0001
   },
   {
    "id": 1539,
    "word": "langack",
    "display": "langacker",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1540,
    "word": "latan",
    "display": "latane",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1541,
    "word": "lecoeuch",
    "display": "lecoeuche",
    "degree": 2,
    "influence": 0.00116
   },
   {
    "id": 1542,
    "word": "robertson",
    "display": "robertson",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1543,
    "word": "barri",
    "display": "barry",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1544,
    "word": "mellish",
    "display": "mellish",
    "degree": 2,
    "influence": 0.00127
   },
   {
    "id": 1545,
    "word": "lewi",
    "display": "lewis",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1546,
    "word": "acm",
    "display": "acm",
    "degree": 5,
    "influence": 0.00067
   },
   {
    "id": 1547,
    "word": "instrument",
    "display": "instruments",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1548,
    "word": "mckoon",
    "display": "mckoon",
    "degree": 2,
    "influence": 0.00035
   },
   {
    "id": 1549,
    "word": "ratcliff",
    "display": "ratcliff",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1550,
    "word": "psycholinguist",
    "display": "psycholinguistic",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1551,
    "word": "1990s",
    "display": "1990s",
    "degree": 2,
    "influence": 0.00014
   },
   {
    "id": 1552,
    "word": "mcmillan",
    "display": "mcmillan",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1553,
    "word": "microscop",
    "display": "microscope",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1554,
    "word": "target",
    "display": "target",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1555,
    "word": "world",
    "display": "world",
    "degree": 6,
    "influence": 0.00094
   },
   {
    "id": 1556,
    "word": "proprietari",
    "display": "proprietary",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1557,
    "word": "acapulco",
    "display": "acapulco",
    "degree": 2,
    "influence": 0.00016
   },
   {
    "id": 1558,
    "word": "mexico",
    "display": "mexico",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1559,
    "word": "church",
    "display": "church",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1560,
    "word": "san",
    "display": "san",
    "degree": 2,
    "influence": 0.00042
   },
   {
    "id": 1561,
    "word": "francisco",
    "display": "francisco",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1562,
    "word": "codi",
    "display": "cody",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1563,
    "word": "knapp",
    "display": "knapp",
    "degree": 2,
    "influence": 0.0001
   },
   {
    "id": 1564,
    "word": "track",
    "display": "tracking",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1565,
    "word": "passonneau",
    "display": "passonneau",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1566,
    "word": "perrow",
    "display": "perrow",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1567,
    "word": "compar",
    "display": "comparative",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1568,
    "word": "iii",
    "display": "iii",
    "degree": 3,
    "influence": 0
   },
   {
    "id": 1569,
    "word": "hirokawa",
    "display": "hirokawa",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1570,
    "word": "roth",
    "display": "roth",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1571,
    "word": "van",
    "display": "van",
    "degree": 5,
    "influence": 0.00114
   },
   {
    "id": 1572,
    "word": "de",
    "display": "de",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1573,
    "word": "ven",
    "display": "ven",
    "degree": 3,
    "influence": 0.00025
   },
   {
    "id": 1574,
    "word": "holm",
    "display": "holmes",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1575,
    "word": "putnam",
    "display": "putnam",
    "degree": 4,
    "influence": 0.00033
   },
   {
    "id": 1576,
    "word": "jablin",
    "display": "jablin",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1577,
    "word": "fanci",
    "display": "fancy",
    "degree": 3,
    "influence": 0.00002
   },
   {
    "id": 1578,
    "word": "tompkin",
    "display": "tompkins",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1579,
    "word": "theme",
    "display": "themes",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1580,
    "word": "riff",
    "display": "riffe",
    "degree": 2,
    "influence": 0.00018
   },
   {
    "id": 1581,
    "word": "laci",
    "display": "lacy",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1582,
    "word": "fico",
    "display": "fico",
    "degree": 2,
    "influence": 0.00105
   },
   {
    "id": 1583,
    "word": "salton",
    "display": "salton",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1584,
    "word": "buckley",
    "display": "buckley",
    "degree": 2,
    "influence": 0.0006
   },
   {
    "id": 1585,
    "word": "sandeland",
    "display": "sandelands",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1586,
    "word": "mind",
    "display": "mind",
    "degree": 3,
    "influence": 0.00063
   },
   {
    "id": 1587,
    "word": "bacharach",
    "display": "bacharach",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1588,
    "word": "ditomaso",
    "display": "ditomaso",
    "degree": 2,
    "influence": 0.00059
   },
   {
    "id": 1589,
    "word": "greenwich",
    "display": "greenwich",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1590,
    "word": "jai",
    "display": "jai",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1591,
    "word": "schank",
    "display": "schank",
    "degree": 2,
    "influence": 0.00023
   },
   {
    "id": 1592,
    "word": "abelson",
    "display": "abelson",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1593,
    "word": "plan",
    "display": "plans",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1594,
    "word": "inquiri",
    "display": "inquiry",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1595,
    "word": "schiffrin",
    "display": "schiffrin",
    "degree": 2,
    "influence": 0.00015
   },
   {
    "id": 1596,
    "word": "seyfarth",
    "display": "seyfarth",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1597,
    "word": "agenda",
    "display": "agenda",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1598,
    "word": "roloff",
    "display": "roloff",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1599,
    "word": "shapiro",
    "display": "shapiro",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1600,
    "word": "markoff",
    "display": "markoff",
    "degree": 2,
    "influence": 0.00019
   },
   {
    "id": 1601,
    "word": "siemen",
    "display": "siemens",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1602,
    "word": "kitchen",
    "display": "kitchener",
    "degree": 2,
    "influence": 0.00021
   },
   {
    "id": 1603,
    "word": "spenc",
    "display": "spence",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1604,
    "word": "owen",
    "display": "owens",
    "degree": 2,
    "influence": 0.0007
   },
   {
    "id": 1605,
    "word": "strength",
    "display": "strength",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1606,
    "word": "sperber",
    "display": "sperber",
    "degree": 2,
    "influence": 0.00017
   },
   {
    "id": 1607,
    "word": "wilson",
    "display": "wilson",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1608,
    "word": "stafford",
    "display": "stafford",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1609,
    "word": "burggraf",
    "display": "burggraf",
    "degree": 2,
    "influence": 0.00017
   },
   {
    "id": 1610,
    "word": "sharkey",
    "display": "sharkey",
    "degree": 2,
    "influence": 0.00135
   },
   {
    "id": 1611,
    "word": "mode",
    "display": "mode",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1612,
    "word": "remembr",
    "display": "remembrances",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1613,
    "word": "hcr",
    "display": "hcr",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1614,
    "word": "literatur",
    "display": "literature",
    "degree": 1,
    "influence": 0
   },
   {
    "id": 1615,
    "word": "stohl",
    "display": "stohl",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1616,
    "word": "gudykunst",
    "display": "gudykunst",
    "degree": 2,
    "influence": 0.00006
   },
   {
    "id": 1617,
    "word": "site",
    "display": "site",
    "degree": 2,
    "influence": 0.0005
   },
   {
    "id": 1618,
    "word": "surfac",
    "display": "surface",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1619,
    "word": "terra",
    "display": "terra",
    "degree": 4,
    "influence": 0.0014
   },
   {
    "id": 1620,
    "word": "birmingham",
    "display": "birmingham",
    "degree": 2,
    "influence": 0.00007
   },
   {
    "id": 1621,
    "word": "mi",
    "display": "mi",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1622,
    "word": "mcgraw",
    "display": "mcgraw",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1623,
    "word": "commit",
    "display": "commitment",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1624,
    "word": "trethewey",
    "display": "trethewey",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1625,
    "word": "commerc",
    "display": "commerce",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 1626,
    "word": "e-commerc",
    "display": "e-commerce",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 1627,
    "word": "tsouka",
    "display": "tsoukas",
    "degree": 2,
    "influence": 0.0001
   },
   {
    "id": 1628,
    "word": "firm",
    "display": "firm",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1629,
    "word": "constructionist",
    "display": "constructionist",
    "degree": 2,
    "influence": 0
   },
   {
    "id": 1630,
    "word": "turan",
    "display": "turan",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 1631,
    "word": "rank",
    "display": "ranking",
    "degree": 2,
    "influence": 0.00003
   },
   {
    "id": 1632,
    "word": "languagespecif",
    "display": "languagespecific",
    "degree": 2,
    "influence": 0.00002
   },
   {
    "id": 1633,
    "word": "prospect",
    "display": "prospects",
    "degree": 3,
    "influence": 0.00001
   },
   {
    "id": 1634,
    "word": "revis",
    "display": "revision",
    "degree": 2,
    "influence": 0.00018
   },
   {
    "id": 1635,
    "word": "econom",
    "display": "economic",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1636,
    "word": "affair",
    "display": "affairs",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1637,
    "word": "von",
    "display": "von",
    "degree": 2,
    "influence": 0.00001
   },
   {
    "id": 1638,
    "word": "bertalanffi",
    "display": "bertalanffy",
    "degree": 2,
    "influence": 0.0005
   },
   {
    "id": 1639,
    "word": "georg",
    "display": "george",
    "degree": 2,
    "influence": 0.00005
   },
   {
    "id": 1640,
    "word": "brazili",
    "display": "brazilier",
    "degree": 2,
    "influence": 0.00009
   },
   {
    "id": 1641,
    "word": "heed",
    "display": "heedful",
    "degree": 2,
    "influence": 0.00122
   },
   {
    "id": 1642,
    "word": "flight",
    "display": "flight",
    "degree": 2,
    "influence": 0.00004
   },
   {
    "id": 1643,
    "word": "deck",
    "display": "decks",
    "degree": 2,
    "influence": 0.00004
   }
  ],
  "edges": [
   {
    "source": 0,
    "target": 1,
    "weight": 23
   },
   {
    "source": 1,
    "target": 2,
    "weight": 27
   },
   {
    "source": 2,
    "target": 3,
    "weight": 3
   },
   {
    "source": 3,
    "target": 4,
    "weight": 37
   },
   {
    "source": 4,
    "target": 5,
    "weight": 46
   },
   {
    "source": 3,
    "target": 5,
    "weight": 34
   },
   {
    "source": 6,
    "target": 7,
    "weight": 1
   },
   {
    "source": 4,
    "target": 7,
    "weight": 10
   },
   {
    "source": 4,
    "target": 8,
    "weight": 10
   },
   {
    "source": 8,
    "target": 9,
    "weight": 2
   },
   {
    "source": 9,
    "target": 10,
    "weight": 4
   },
   {
    "source": 10,
    "target": 11,
    "weight": 3
   },
   {
    "source": 1,
    "target": 11,
    "weight": 1
   },
   {
    "source": 2,
    "target": 4,
    "weight": 1
   },
   {
    "source": 4,
    "target": 12,
    "weight": 1
   },
   {
    "source": 0,
    "target": 12,
    "weight": 2
   },
   {
    "source": 0,
    "target": 13,
    "weight": 1
   },
   {
    "source": 13,
    "target": 14,
    "weight": 8
   },
   {
    "source": 14,
    "target": 15,
    "weight": 8
   },
   {
    "source": 15,
    "target": 16,
    "weight": 2
   },
   {
    "source": 16,
    "target": 17,
    "weight": 2
   },
   {
    "source": 15,
    "target": 17,
    "weight": 1
   },
   {
    "source": 15,
    "target": 18,
    "weight": 2
   },
   {
    "source": 18,
    "target": 19,
    "weight": 2
   },
   {
    "source": 19,
    "target": 20,
    "weight": 2
   },
   {
    "source": 20,
    "target": 21,
    "weight": 2
   },
   {
    "source": 13,
    "target": 21,
    "weight": 1
   },
   {
    "source": 15,
    "target": 22,
    "weight": 1
   },
   {
    "source": 22,
    "target": 23,
    "weight": 2
   },
   {
    "source": 13,
    "target": 23,
    "weight": 1
   },
   {
    "source": 15,
    "target": 24,
    "weight": 1
   },
   {
    "source": 24,
    "target": 25,
    "weight": 1
   },
   {
    "source": 4,
    "target": 25,
    "weight": 1
   },
   {
    "source": 4,
    "target": 26,
    "weight": 2
   },
   {
    "source": 26,
    "target": 27,
    "weight": 6
   },
   {
    "source": 27,
    "target": 28,
    "weight": 2
   },
   {
    "source": 7,
    "target": 8,
    "weight": 9
   },
   {
    "source": 9,
    "target": 11,
    "weight": 19
   },
   {
    "source": 13,
    "target": 15,
    "weight": 8
   },
   {
    "source": 5,
    "target": 6,
    "weight": 24
   },
   {
    "source": 5,
    "target": 29,
    "weight": 1
   },
   {
    "source": 5,
    "target": 30,
    "weight": 2
   },
   {
    "source": 30,
    "target": 31,
    "weight": 1
   },
   {
    "source": 31,
    "target": 32,
    "weight": 1
   },
   {
    "source": 32,
    "target": 33,
    "weight": 2
   },
   {
    "source": 33,
    "target": 34,
    "weight": 3
   },
   {
    "source": 9,
    "target": 34,
    "weight": 4
   },
   {
    "source": 4,
    "target": 11,
    "weight": 10
   },
   {
    "source": 4,
    "target": 35,
    "weight": 1
   },
   {
    "source": 35,
    "target": 36,
    "weight": 6
   },
   {
    "source": 4,
    "target": 36,
    "weight": 3
   },
   {
    "source": 4,
    "target": 37,
    "weight": 2
   },
   {
    "source": 28,
    "target": 37,
    "weight": 1
   },
   {
    "source": 28,
    "target": 29,
    "weight": 1
   },
   {
    "source": 2,
    "target": 38,
    "weight": 10
   },
   {
    "source": 38,
    "target": 39,
    "weight": 2
   },
   {
    "source": 39,
    "target": 40,
    "weight": 1
   },
   {
    "source": 2,
    "target": 40,
    "weight": 29
   },
   {
    "source": 2,
    "target": 34,
    "weight": 8
   },
   {
    "source": 34,
    "target": 41,
    "weight": 1
   },
   {
    "source": 32,
    "target": 41,
    "weight": 1
   },
   {
    "source": 33,
    "target": 35,
    "weight": 1
   },
   {
    "source": 35,
    "target": 42,
    "weight": 3
   },
   {
    "source": 40,
    "target": 42,
    "weight": 3
   },
   {
    "source": 40,
    "target": 43,
    "weight": 2
   },
   {
    "source": 43,
    "target": 44,
    "weight": 4
   },
   {
    "source": 2,
    "target": 39,
    "weight": 2
   },
   {
    "source": 34,
    "target": 39,
    "weight": 7
   },
   {
    "source": 34,
    "target": 40,
    "weight": 6
   },
   {
    "source": 1,
    "target": 28,
    "weight": 1
   },
   {
    "source": 45,
    "target": 46,
    "weight": 7
   },
   {
    "source": 46,
    "target": 47,
    "weight": 15
   },
   {
    "source": 26,
    "target": 47,
    "weight": 5
   },
   {
    "source": 26,
    "target": 48,
    "weight": 2
   },
   {
    "source": 47,
    "target": 48,
    "weight": 2
   },
   {
    "source": 44,
    "target": 45,
    "weight": 1
   },
   {
    "source": 38,
    "target": 47,
    "weight": 42
   },
   {
    "source": 1,
    "target": 47,
    "weight": 5
   },
   {
    "source": 47,
    "target": 49,
    "weight": 3
   },
   {
    "source": 49,
    "target": 50,
    "weight": 1
   },
   {
    "source": 2,
    "target": 50,
    "weight": 1
   },
   {
    "source": 38,
    "target": 45,
    "weight": 1
   },
   {
    "source": 51,
    "target": 52,
    "weight": 1
   },
   {
    "source": 52,
    "target": 53,
    "weight": 1
   },
   {
    "source": 53,
    "target": 54,
    "weight": 1
   },
   {
    "source": 54,
    "target": 55,
    "weight": 1
   },
   {
    "source": 55,
    "target": 56,
    "weight": 1
   },
   {
    "source": 38,
    "target": 56,
    "weight": 3
   },
   {
    "source": 38,
    "target": 57,
    "weight": 2
   },
   {
    "source": 57,
    "target": 58,
    "weight": 1
   },
   {
    "source": 58,
    "target": 59,
    "weight": 1
   },
   {
    "source": 59,
    "target": 60,
    "weight": 1
   },
   {
    "source": 60,
    "target": 61,
    "weight": 3
   },
   {
    "source": 61,
    "target": 62,
    "weight": 8
   },
   {
    "source": 61,
    "target": 63,
    "weight": 1
   },
   {
    "source": 63,
    "target": 64,
    "weight": 1
   },
   {
    "source": 64,
    "target": 65,
    "weight": 2
   },
   {
    "source": 34,
    "target": 51,
    "weight": 1
   },
   {
    "source": 66,
    "target": 67,
    "weight": 1
   },
   {
    "source": 64,
    "target": 67,
    "weight": 1
   },
   {
    "source": 5,
    "target": 64,
    "weight": 6
   },
   {
    "source": 5,
    "target": 68,
    "weight": 1
   },
   {
    "source": 68,
    "target": 69,
    "weight": 1
   },
   {
    "source": 69,
    "target": 70,
    "weight": 1
   },
   {
    "source": 33,
    "target": 70,
    "weight": 1
   },
   {
    "source": 33,
    "target": 67,
    "weight": 1
   },
   {
    "source": 67,
    "target": 71,
    "weight": 1
   },
   {
    "source": 71,
    "target": 72,
    "weight": 1
   },
   {
    "source": 2,
    "target": 72,
    "weight": 15
   },
   {
    "source": 2,
    "target": 44,
    "weight": 7
   },
   {
    "source": 2,
    "target": 73,
    "weight": 3
   },
   {
    "source": 73,
    "target": 74,
    "weight": 3
   },
   {
    "source": 74,
    "target": 75,
    "weight": 1
   },
   {
    "source": 4,
    "target": 75,
    "weight": 3
   },
   {
    "source": 64,
    "target": 68,
    "weight": 2
   },
   {
    "source": 2,
    "target": 71,
    "weight": 1
   },
   {
    "source": 65,
    "target": 66,
    "weight": 1
   },
   {
    "source": 0,
    "target": 76,
    "weight": 1
   },
   {
    "source": 76,
    "target": 77,
    "weight": 2
   },
   {
    "source": 77,
    "target": 78,
    "weight": 3
   },
   {
    "source": 78,
    "target": 79,
    "weight": 3
   },
   {
    "source": 3,
    "target": 79,
    "weight": 3
   },
   {
    "source": 4,
    "target": 13,
    "weight": 1
   },
   {
    "source": 77,
    "target": 79,
    "weight": 3
   },
   {
    "source": 11,
    "target": 12,
    "weight": 1
   },
   {
    "source": 17,
    "target": 80,
    "weight": 1
   },
   {
    "source": 76,
    "target": 80,
    "weight": 1
   },
   {
    "source": 15,
    "target": 76,
    "weight": 1
   },
   {
    "source": 21,
    "target": 76,
    "weight": 1
   },
   {
    "source": 4,
    "target": 22,
    "weight": 1
   },
   {
    "source": 23,
    "target": 76,
    "weight": 1
   },
   {
    "source": 76,
    "target": 81,
    "weight": 1
   },
   {
    "source": 81,
    "target": 82,
    "weight": 1
   },
   {
    "source": 82,
    "target": 83,
    "weight": 1
   },
   {
    "source": 13,
    "target": 83,
    "weight": 1
   },
   {
    "source": 5,
    "target": 84,
    "weight": 1
   },
   {
    "source": 84,
    "target": 85,
    "weight": 1
   },
   {
    "source": 85,
    "target": 86,
    "weight": 1
   },
   {
    "source": 86,
    "target": 87,
    "weight": 1
   },
   {
    "source": 87,
    "target": 88,
    "weight": 1
   },
   {
    "source": 88,
    "target": 89,
    "weight": 1
   },
   {
    "source": 5,
    "target": 89,
    "weight": 1
   },
   {
    "source": 5,
    "target": 13,
    "weight": 1
   },
   {
    "source": 5,
    "target": 15,
    "weight": 1
   },
   {
    "source": 90,
    "target": 91,
    "weight": 1
   },
   {
    "source": 91,
    "target": 92,
    "weight": 1
   },
   {
    "source": 92,
    "target": 93,
    "weight": 1
   },
   {
    "source": 93,
    "target": 94,
    "weight": 1
   },
   {
    "source": 38,
    "target": 94,
    "weight": 1
   },
   {
    "source": 38,
    "target": 95,
    "weight": 1
   },
   {
    "source": 15,
    "target": 90,
    "weight": 1
   },
   {
    "source": 90,
    "target": 96,
    "weight": 1
   },
   {
    "source": 77,
    "target": 90,
    "weight": 1
   },
   {
    "source": 4,
    "target": 97,
    "weight": 1
   },
   {
    "source": 13,
    "target": 97,
    "weight": 1
   },
   {
    "source": 15,
    "target": 98,
    "weight": 2
   },
   {
    "source": 98,
    "target": 99,
    "weight": 1
   },
   {
    "source": 99,
    "target": 100,
    "weight": 1
   },
   {
    "source": 95,
    "target": 96,
    "weight": 1
   },
   {
    "source": 6,
    "target": 101,
    "weight": 1
   },
   {
    "source": 4,
    "target": 101,
    "weight": 1
   },
   {
    "source": 4,
    "target": 24,
    "weight": 1
   },
   {
    "source": 24,
    "target": 102,
    "weight": 1
   },
   {
    "source": 102,
    "target": 103,
    "weight": 1
   },
   {
    "source": 103,
    "target": 104,
    "weight": 1
   },
   {
    "source": 104,
    "target": 105,
    "weight": 1
   },
   {
    "source": 105,
    "target": 106,
    "weight": 1
   },
   {
    "source": 106,
    "target": 107,
    "weight": 1
   },
   {
    "source": 107,
    "target": 108,
    "weight": 1
   },
   {
    "source": 108,
    "target": 109,
    "weight": 1
   },
   {
    "source": 109,
    "target": 110,
    "weight": 1
   },
   {
    "source": 4,
    "target": 110,
    "weight": 4
   },
   {
    "source": 4,
    "target": 27,
    "weight": 1
   },
   {
    "source": 24,
    "target": 101,
    "weight": 1
   },
   {
    "source": 105,
    "target": 107,
    "weight": 2
   },
   {
    "source": 3,
    "target": 100,
    "weight": 1
   },
   {
    "source": 30,
    "target": 111,
    "weight": 1
   },
   {
    "source": 27,
    "target": 111,
    "weight": 2
   },
   {
    "source": 27,
    "target": 112,
    "weight": 1
   },
   {
    "source": 26,
    "target": 30,
    "weight": 5
   },
   {
    "source": 112,
    "target": 113,
    "weight": 2
   },
   {
    "source": 112,
    "target": 114,
    "weight": 1
   },
   {
    "source": 27,
    "target": 114,
    "weight": 1
   },
   {
    "source": 27,
    "target": 115,
    "weight": 3
   },
   {
    "source": 26,
    "target": 115,
    "weight": 2
   },
   {
    "source": 26,
    "target": 28,
    "weight": 3
   },
   {
    "source": 28,
    "target": 116,
    "weight": 1
   },
   {
    "source": 116,
    "target": 117,
    "weight": 1
   },
   {
    "source": 117,
    "target": 118,
    "weight": 1
   },
   {
    "source": 118,
    "target": 119,
    "weight": 2
   },
   {
    "source": 119,
    "target": 120,
    "weight": 1
   },
   {
    "source": 120,
    "target": 121,
    "weight": 1
   },
   {
    "source": 4,
    "target": 121,
    "weight": 1
   },
   {
    "source": 28,
    "target": 112,
    "weight": 1
   },
   {
    "source": 45,
    "target": 112,
    "weight": 1
   },
   {
    "source": 45,
    "target": 122,
    "weight": 2
   },
   {
    "source": 122,
    "target": 123,
    "weight": 1
   },
   {
    "source": 123,
    "target": 124,
    "weight": 1
   },
   {
    "source": 4,
    "target": 124,
    "weight": 7
   },
   {
    "source": 4,
    "target": 125,
    "weight": 1
   },
   {
    "source": 125,
    "target": 126,
    "weight": 1
   },
   {
    "source": 10,
    "target": 126,
    "weight": 1
   },
   {
    "source": 10,
    "target": 127,
    "weight": 1
   },
   {
    "source": 127,
    "target": 128,
    "weight": 1
   },
   {
    "source": 128,
    "target": 129,
    "weight": 1
   },
   {
    "source": 4,
    "target": 28,
    "weight": 3
   },
   {
    "source": 105,
    "target": 130,
    "weight": 1
   },
   {
    "source": 64,
    "target": 130,
    "weight": 1
   },
   {
    "source": 4,
    "target": 64,
    "weight": 20
   },
   {
    "source": 4,
    "target": 30,
    "weight": 10
   },
   {
    "source": 5,
    "target": 131,
    "weight": 2
   },
   {
    "source": 131,
    "target": 132,
    "weight": 2
   },
   {
    "source": 132,
    "target": 133,
    "weight": 2
   },
   {
    "source": 133,
    "target": 134,
    "weight": 2
   },
   {
    "source": 134,
    "target": 135,
    "weight": 1
   },
   {
    "source": 135,
    "target": 136,
    "weight": 1
   },
   {
    "source": 26,
    "target": 136,
    "weight": 1
   },
   {
    "source": 26,
    "target": 137,
    "weight": 1
   },
   {
    "source": 137,
    "target": 138,
    "weight": 1
   },
   {
    "source": 10,
    "target": 138,
    "weight": 1
   },
   {
    "source": 10,
    "target": 139,
    "weight": 1
   },
   {
    "source": 124,
    "target": 139,
    "weight": 1
   },
   {
    "source": 124,
    "target": 140,
    "weight": 2
   },
   {
    "source": 26,
    "target": 140,
    "weight": 3
   },
   {
    "source": 5,
    "target": 26,
    "weight": 1
   },
   {
    "source": 64,
    "target": 141,
    "weight": 1
   },
   {
    "source": 115,
    "target": 141,
    "weight": 1
   },
   {
    "source": 115,
    "target": 116,
    "weight": 2
   },
   {
    "source": 4,
    "target": 116,
    "weight": 4
   },
   {
    "source": 30,
    "target": 64,
    "weight": 2
   },
   {
    "source": 105,
    "target": 129,
    "weight": 1
   },
   {
    "source": 142,
    "target": 143,
    "weight": 1
   },
   {
    "source": 143,
    "target": 144,
    "weight": 1
   },
   {
    "source": 4,
    "target": 144,
    "weight": 4
   },
   {
    "source": 4,
    "target": 145,
    "weight": 1
   },
   {
    "source": 110,
    "target": 145,
    "weight": 1
   },
   {
    "source": 110,
    "target": 146,
    "weight": 1
   },
   {
    "source": 146,
    "target": 147,
    "weight": 1
   },
   {
    "source": 147,
    "target": 148,
    "weight": 1
   },
   {
    "source": 116,
    "target": 148,
    "weight": 1
   },
   {
    "source": 116,
    "target": 149,
    "weight": 2
   },
   {
    "source": 4,
    "target": 142,
    "weight": 1
   },
   {
    "source": 27,
    "target": 30,
    "weight": 2
   },
   {
    "source": 9,
    "target": 28,
    "weight": 2
   },
   {
    "source": 30,
    "target": 149,
    "weight": 2
   },
   {
    "source": 9,
    "target": 150,
    "weight": 1
   },
   {
    "source": 150,
    "target": 151,
    "weight": 1
   },
   {
    "source": 151,
    "target": 152,
    "weight": 1
   },
   {
    "source": 152,
    "target": 153,
    "weight": 1
   },
   {
    "source": 153,
    "target": 154,
    "weight": 1
   },
   {
    "source": 154,
    "target": 155,
    "weight": 1
   },
   {
    "source": 155,
    "target": 156,
    "weight": 1
   },
   {
    "source": 156,
    "target": 157,
    "weight": 1
   },
   {
    "source": 28,
    "target": 158,
    "weight": 1
   },
   {
    "source": 156,
    "target": 158,
    "weight": 1
   },
   {
    "source": 70,
    "target": 156,
    "weight": 1
   },
   {
    "source": 70,
    "target": 159,
    "weight": 1
   },
   {
    "source": 159,
    "target": 160,
    "weight": 1
   },
   {
    "source": 28,
    "target": 157,
    "weight": 1
   },
   {
    "source": 24,
    "target": 161,
    "weight": 1
   },
   {
    "source": 24,
    "target": 33,
    "weight": 1
   },
   {
    "source": 33,
    "target": 162,
    "weight": 1
   },
   {
    "source": 146,
    "target": 162,
    "weight": 1
   },
   {
    "source": 146,
    "target": 163,
    "weight": 1
   },
   {
    "source": 126,
    "target": 163,
    "weight": 1
   },
   {
    "source": 27,
    "target": 126,
    "weight": 1
   },
   {
    "source": 115,
    "target": 164,
    "weight": 2
   },
   {
    "source": 48,
    "target": 164,
    "weight": 2
   },
   {
    "source": 11,
    "target": 48,
    "weight": 1
   },
   {
    "source": 4,
    "target": 165,
    "weight": 3
   },
   {
    "source": 160,
    "target": 161,
    "weight": 1
   },
   {
    "source": 107,
    "target": 166,
    "weight": 1
   },
   {
    "source": 114,
    "target": 166,
    "weight": 1
   },
   {
    "source": 114,
    "target": 167,
    "weight": 1
   },
   {
    "source": 167,
    "target": 168,
    "weight": 1
   },
   {
    "source": 53,
    "target": 168,
    "weight": 1
   },
   {
    "source": 53,
    "target": 124,
    "weight": 1
   },
   {
    "source": 124,
    "target": 169,
    "weight": 1
   },
   {
    "source": 4,
    "target": 169,
    "weight": 1
   },
   {
    "source": 4,
    "target": 170,
    "weight": 7
   },
   {
    "source": 170,
    "target": 171,
    "weight": 1
   },
   {
    "source": 171,
    "target": 172,
    "weight": 1
   },
   {
    "source": 27,
    "target": 172,
    "weight": 1
   },
   {
    "source": 27,
    "target": 173,
    "weight": 1
   },
   {
    "source": 124,
    "target": 170,
    "weight": 2
   },
   {
    "source": 169,
    "target": 170,
    "weight": 1
   },
   {
    "source": 107,
    "target": 165,
    "weight": 1
   },
   {
    "source": 55,
    "target": 173,
    "weight": 1
   },
   {
    "source": 174,
    "target": 175,
    "weight": 1
   },
   {
    "source": 175,
    "target": 176,
    "weight": 1
   },
   {
    "source": 110,
    "target": 176,
    "weight": 1
   },
   {
    "source": 110,
    "target": 116,
    "weight": 1
   },
   {
    "source": 116,
    "target": 173,
    "weight": 1
   },
   {
    "source": 138,
    "target": 173,
    "weight": 1
   },
   {
    "source": 138,
    "target": 177,
    "weight": 1
   },
   {
    "source": 4,
    "target": 177,
    "weight": 3
   },
   {
    "source": 110,
    "target": 175,
    "weight": 1
   },
   {
    "source": 55,
    "target": 174,
    "weight": 1
   },
   {
    "source": 116,
    "target": 144,
    "weight": 1
   },
   {
    "source": 116,
    "target": 178,
    "weight": 1
   },
   {
    "source": 178,
    "target": 179,
    "weight": 1
   },
   {
    "source": 4,
    "target": 179,
    "weight": 1
   },
   {
    "source": 177,
    "target": 180,
    "weight": 1
   },
   {
    "source": 34,
    "target": 180,
    "weight": 1
   },
   {
    "source": 34,
    "target": 44,
    "weight": 2
   },
   {
    "source": 44,
    "target": 177,
    "weight": 1
   },
   {
    "source": 2,
    "target": 177,
    "weight": 1
   },
   {
    "source": 2,
    "target": 181,
    "weight": 1
   },
   {
    "source": 4,
    "target": 181,
    "weight": 1
   },
   {
    "source": 4,
    "target": 182,
    "weight": 3
   },
   {
    "source": 177,
    "target": 181,
    "weight": 1
   },
   {
    "source": 5,
    "target": 144,
    "weight": 3
   },
   {
    "source": 37,
    "target": 140,
    "weight": 4
   },
   {
    "source": 116,
    "target": 140,
    "weight": 1
   },
   {
    "source": 56,
    "target": 116,
    "weight": 1
   },
   {
    "source": 56,
    "target": 124,
    "weight": 1
   },
   {
    "source": 124,
    "target": 177,
    "weight": 2
   },
   {
    "source": 177,
    "target": 183,
    "weight": 1
   },
   {
    "source": 116,
    "target": 183,
    "weight": 1
   },
   {
    "source": 37,
    "target": 116,
    "weight": 1
   },
   {
    "source": 37,
    "target": 182,
    "weight": 1
   },
   {
    "source": 30,
    "target": 75,
    "weight": 1
   },
   {
    "source": 4,
    "target": 32,
    "weight": 1
   },
   {
    "source": 9,
    "target": 32,
    "weight": 2
   },
   {
    "source": 28,
    "target": 149,
    "weight": 1
   },
   {
    "source": 149,
    "target": 184,
    "weight": 1
   },
   {
    "source": 114,
    "target": 184,
    "weight": 1
   },
   {
    "source": 5,
    "target": 114,
    "weight": 1
   },
   {
    "source": 9,
    "target": 149,
    "weight": 3
   },
   {
    "source": 30,
    "target": 116,
    "weight": 1
   },
   {
    "source": 185,
    "target": 186,
    "weight": 1
   },
   {
    "source": 4,
    "target": 186,
    "weight": 1
   },
   {
    "source": 5,
    "target": 34,
    "weight": 7
   },
   {
    "source": 9,
    "target": 182,
    "weight": 1
   },
   {
    "source": 5,
    "target": 185,
    "weight": 1
   },
   {
    "source": 187,
    "target": 188,
    "weight": 1
   },
   {
    "source": 188,
    "target": 189,
    "weight": 1
   },
   {
    "source": 189,
    "target": 190,
    "weight": 1
   },
   {
    "source": 1,
    "target": 190,
    "weight": 1
   },
   {
    "source": 38,
    "target": 191,
    "weight": 1
   },
   {
    "source": 191,
    "target": 192,
    "weight": 1
   },
   {
    "source": 72,
    "target": 192,
    "weight": 1
   },
   {
    "source": 35,
    "target": 72,
    "weight": 1
   },
   {
    "source": 35,
    "target": 193,
    "weight": 1
   },
   {
    "source": 104,
    "target": 193,
    "weight": 1
   },
   {
    "source": 2,
    "target": 104,
    "weight": 2
   },
   {
    "source": 188,
    "target": 190,
    "weight": 1
   },
   {
    "source": 182,
    "target": 187,
    "weight": 1
   },
   {
    "source": 38,
    "target": 40,
    "weight": 10
   },
   {
    "source": 34,
    "target": 194,
    "weight": 1
   },
   {
    "source": 4,
    "target": 194,
    "weight": 1
   },
   {
    "source": 4,
    "target": 195,
    "weight": 2
   },
   {
    "source": 195,
    "target": 196,
    "weight": 1
   },
   {
    "source": 196,
    "target": 197,
    "weight": 1
   },
   {
    "source": 100,
    "target": 197,
    "weight": 1
   },
   {
    "source": 40,
    "target": 100,
    "weight": 1
   },
   {
    "source": 38,
    "target": 43,
    "weight": 1
   },
   {
    "source": 107,
    "target": 198,
    "weight": 1
   },
   {
    "source": 198,
    "target": 199,
    "weight": 1
   },
   {
    "source": 199,
    "target": 200,
    "weight": 1
   },
   {
    "source": 200,
    "target": 201,
    "weight": 1
   },
   {
    "source": 201,
    "target": 202,
    "weight": 1
   },
   {
    "source": 202,
    "target": 203,
    "weight": 1
   },
   {
    "source": 44,
    "target": 203,
    "weight": 1
   },
   {
    "source": 38,
    "target": 44,
    "weight": 2
   },
   {
    "source": 34,
    "target": 38,
    "weight": 6
   },
   {
    "source": 198,
    "target": 200,
    "weight": 1
   },
   {
    "source": 198,
    "target": 201,
    "weight": 1
   },
   {
    "source": 199,
    "target": 201,
    "weight": 1
   },
   {
    "source": 44,
    "target": 107,
    "weight": 1
   },
   {
    "source": 38,
    "target": 204,
    "weight": 1
   },
   {
    "source": 38,
    "target": 205,
    "weight": 1
   },
   {
    "source": 205,
    "target": 206,
    "weight": 1
   },
   {
    "source": 147,
    "target": 206,
    "weight": 1
   },
   {
    "source": 64,
    "target": 147,
    "weight": 1
   },
   {
    "source": 4,
    "target": 204,
    "weight": 2
   },
   {
    "source": 35,
    "target": 204,
    "weight": 1
   },
   {
    "source": 34,
    "target": 204,
    "weight": 1
   },
   {
    "source": 5,
    "target": 38,
    "weight": 1
   },
   {
    "source": 5,
    "target": 194,
    "weight": 1
   },
   {
    "source": 115,
    "target": 194,
    "weight": 1
   },
   {
    "source": 4,
    "target": 38,
    "weight": 2
   },
   {
    "source": 38,
    "target": 66,
    "weight": 3
   },
   {
    "source": 38,
    "target": 67,
    "weight": 9
   },
   {
    "source": 67,
    "target": 70,
    "weight": 2
   },
   {
    "source": 70,
    "target": 182,
    "weight": 1
   },
   {
    "source": 167,
    "target": 182,
    "weight": 1
   },
   {
    "source": 167,
    "target": 207,
    "weight": 1
   },
   {
    "source": 207,
    "target": 208,
    "weight": 2
   },
   {
    "source": 4,
    "target": 208,
    "weight": 5
   },
   {
    "source": 4,
    "target": 209,
    "weight": 1
   },
   {
    "source": 2,
    "target": 209,
    "weight": 1
   },
   {
    "source": 2,
    "target": 140,
    "weight": 2
   },
   {
    "source": 140,
    "target": 177,
    "weight": 6
   },
   {
    "source": 74,
    "target": 177,
    "weight": 1
   },
   {
    "source": 4,
    "target": 74,
    "weight": 3
   },
   {
    "source": 66,
    "target": 115,
    "weight": 1
   },
   {
    "source": 210,
    "target": 211,
    "weight": 5
   },
   {
    "source": 5,
    "target": 211,
    "weight": 1
   },
   {
    "source": 34,
    "target": 212,
    "weight": 1
   },
   {
    "source": 44,
    "target": 212,
    "weight": 2
   },
   {
    "source": 2,
    "target": 213,
    "weight": 1
   },
   {
    "source": 75,
    "target": 213,
    "weight": 1
   },
   {
    "source": 75,
    "target": 214,
    "weight": 1
   },
   {
    "source": 214,
    "target": 215,
    "weight": 1
   },
   {
    "source": 215,
    "target": 216,
    "weight": 1
   },
   {
    "source": 9,
    "target": 216,
    "weight": 2
   },
   {
    "source": 9,
    "target": 64,
    "weight": 7
   },
   {
    "source": 4,
    "target": 9,
    "weight": 6
   },
   {
    "source": 11,
    "target": 64,
    "weight": 4
   },
   {
    "source": 11,
    "target": 210,
    "weight": 1
   },
   {
    "source": 38,
    "target": 55,
    "weight": 1
   },
   {
    "source": 55,
    "target": 217,
    "weight": 1
   },
   {
    "source": 110,
    "target": 217,
    "weight": 1
   },
   {
    "source": 34,
    "target": 110,
    "weight": 1
   },
   {
    "source": 11,
    "target": 38,
    "weight": 2
   },
   {
    "source": 61,
    "target": 67,
    "weight": 1
   },
   {
    "source": 2,
    "target": 67,
    "weight": 1
   },
   {
    "source": 44,
    "target": 218,
    "weight": 1
   },
   {
    "source": 218,
    "target": 219,
    "weight": 1
   },
   {
    "source": 3,
    "target": 219,
    "weight": 1
   },
   {
    "source": 3,
    "target": 220,
    "weight": 1
   },
   {
    "source": 220,
    "target": 221,
    "weight": 1
   },
   {
    "source": 40,
    "target": 221,
    "weight": 6
   },
   {
    "source": 40,
    "target": 222,
    "weight": 1
   },
   {
    "source": 26,
    "target": 222,
    "weight": 1
   },
   {
    "source": 26,
    "target": 223,
    "weight": 1
   },
   {
    "source": 5,
    "target": 223,
    "weight": 2
   },
   {
    "source": 5,
    "target": 47,
    "weight": 2
   },
   {
    "source": 47,
    "target": 223,
    "weight": 2
   },
   {
    "source": 34,
    "target": 61,
    "weight": 1
   },
   {
    "source": 66,
    "target": 224,
    "weight": 1
   },
   {
    "source": 57,
    "target": 224,
    "weight": 1
   },
   {
    "source": 9,
    "target": 38,
    "weight": 1
   },
   {
    "source": 11,
    "target": 67,
    "weight": 1
   },
   {
    "source": 67,
    "target": 143,
    "weight": 1
   },
   {
    "source": 4,
    "target": 143,
    "weight": 2
   },
   {
    "source": 47,
    "target": 66,
    "weight": 1
   },
   {
    "source": 64,
    "target": 112,
    "weight": 4
   },
   {
    "source": 112,
    "target": 225,
    "weight": 1
   },
   {
    "source": 225,
    "target": 226,
    "weight": 1
   },
   {
    "source": 214,
    "target": 226,
    "weight": 1
   },
   {
    "source": 214,
    "target": 227,
    "weight": 2
   },
   {
    "source": 9,
    "target": 227,
    "weight": 3
   },
   {
    "source": 4,
    "target": 149,
    "weight": 2
   },
   {
    "source": 34,
    "target": 149,
    "weight": 1
   },
   {
    "source": 34,
    "target": 228,
    "weight": 1
   },
   {
    "source": 30,
    "target": 228,
    "weight": 1
   },
   {
    "source": 2,
    "target": 30,
    "weight": 1
   },
   {
    "source": 9,
    "target": 112,
    "weight": 2
   },
   {
    "source": 64,
    "target": 227,
    "weight": 1
   },
   {
    "source": 4,
    "target": 227,
    "weight": 2
   },
   {
    "source": 149,
    "target": 227,
    "weight": 1
   },
   {
    "source": 64,
    "target": 149,
    "weight": 2
   },
   {
    "source": 5,
    "target": 9,
    "weight": 1
   },
   {
    "source": 6,
    "target": 229,
    "weight": 1
   },
   {
    "source": 229,
    "target": 230,
    "weight": 1
   },
   {
    "source": 230,
    "target": 231,
    "weight": 1
   },
   {
    "source": 231,
    "target": 232,
    "weight": 1
   },
   {
    "source": 232,
    "target": 233,
    "weight": 1
   },
   {
    "source": 233,
    "target": 234,
    "weight": 1
   },
   {
    "source": 234,
    "target": 235,
    "weight": 1
   },
   {
    "source": 82,
    "target": 235,
    "weight": 2
   },
   {
    "source": 30,
    "target": 90,
    "weight": 1
   },
   {
    "source": 90,
    "target": 236,
    "weight": 1
   },
   {
    "source": 4,
    "target": 236,
    "weight": 1
   },
   {
    "source": 4,
    "target": 237,
    "weight": 1
   },
   {
    "source": 237,
    "target": 238,
    "weight": 1
   },
   {
    "source": 82,
    "target": 238,
    "weight": 1
   },
   {
    "source": 82,
    "target": 239,
    "weight": 1
   },
   {
    "source": 192,
    "target": 239,
    "weight": 1
   },
   {
    "source": 192,
    "target": 240,
    "weight": 1
   },
   {
    "source": 26,
    "target": 240,
    "weight": 1
   },
   {
    "source": 26,
    "target": 230,
    "weight": 2
   },
   {
    "source": 26,
    "target": 82,
    "weight": 1
   },
   {
    "source": 4,
    "target": 216,
    "weight": 1
   },
   {
    "source": 4,
    "target": 152,
    "weight": 12
   },
   {
    "source": 152,
    "target": 164,
    "weight": 1
   },
   {
    "source": 26,
    "target": 164,
    "weight": 1
   },
   {
    "source": 26,
    "target": 241,
    "weight": 1
   },
   {
    "source": 230,
    "target": 241,
    "weight": 1
   },
   {
    "source": 230,
    "target": 242,
    "weight": 1
   },
   {
    "source": 115,
    "target": 242,
    "weight": 1
   },
   {
    "source": 4,
    "target": 115,
    "weight": 11
   },
   {
    "source": 216,
    "target": 230,
    "weight": 1
   },
   {
    "source": 69,
    "target": 228,
    "weight": 1
   },
   {
    "source": 69,
    "target": 123,
    "weight": 1
   },
   {
    "source": 123,
    "target": 243,
    "weight": 2
   },
   {
    "source": 59,
    "target": 243,
    "weight": 1
   },
   {
    "source": 59,
    "target": 244,
    "weight": 1
   },
   {
    "source": 244,
    "target": 245,
    "weight": 1
   },
   {
    "source": 221,
    "target": 245,
    "weight": 1
   },
   {
    "source": 221,
    "target": 246,
    "weight": 1
   },
   {
    "source": 246,
    "target": 247,
    "weight": 1
   },
   {
    "source": 247,
    "target": 248,
    "weight": 1
   },
   {
    "source": 59,
    "target": 123,
    "weight": 1
   },
   {
    "source": 110,
    "target": 228,
    "weight": 1
   },
   {
    "source": 221,
    "target": 249,
    "weight": 2
   },
   {
    "source": 249,
    "target": 250,
    "weight": 1
   },
   {
    "source": 250,
    "target": 251,
    "weight": 1
   },
   {
    "source": 251,
    "target": 252,
    "weight": 1
   },
   {
    "source": 252,
    "target": 253,
    "weight": 1
   },
   {
    "source": 216,
    "target": 253,
    "weight": 1
   },
   {
    "source": 221,
    "target": 248,
    "weight": 1
   },
   {
    "source": 251,
    "target": 254,
    "weight": 1
   },
   {
    "source": 82,
    "target": 254,
    "weight": 1
   },
   {
    "source": 82,
    "target": 167,
    "weight": 1
   },
   {
    "source": 167,
    "target": 231,
    "weight": 1
   },
   {
    "source": 231,
    "target": 255,
    "weight": 1
   },
   {
    "source": 255,
    "target": 256,
    "weight": 2
   },
   {
    "source": 256,
    "target": 257,
    "weight": 1
   },
   {
    "source": 257,
    "target": 258,
    "weight": 1
   },
   {
    "source": 190,
    "target": 258,
    "weight": 1
   },
   {
    "source": 190,
    "target": 192,
    "weight": 1
   },
   {
    "source": 192,
    "target": 259,
    "weight": 1
   },
   {
    "source": 25,
    "target": 259,
    "weight": 1
   },
   {
    "source": 25,
    "target": 90,
    "weight": 1
   },
   {
    "source": 90,
    "target": 260,
    "weight": 1
   },
   {
    "source": 260,
    "target": 261,
    "weight": 1
   },
   {
    "source": 244,
    "target": 261,
    "weight": 1
   },
   {
    "source": 155,
    "target": 244,
    "weight": 1
   },
   {
    "source": 39,
    "target": 155,
    "weight": 1
   },
   {
    "source": 26,
    "target": 39,
    "weight": 1
   },
   {
    "source": 167,
    "target": 254,
    "weight": 1
   },
   {
    "source": 216,
    "target": 251,
    "weight": 1
   },
   {
    "source": 152,
    "target": 195,
    "weight": 1
   },
   {
    "source": 195,
    "target": 251,
    "weight": 1
   },
   {
    "source": 26,
    "target": 152,
    "weight": 2
   },
   {
    "source": 32,
    "target": 155,
    "weight": 2
   },
   {
    "source": 32,
    "target": 227,
    "weight": 1
   },
   {
    "source": 227,
    "target": 228,
    "weight": 1
   },
   {
    "source": 124,
    "target": 228,
    "weight": 3
   },
   {
    "source": 124,
    "target": 262,
    "weight": 1
   },
   {
    "source": 34,
    "target": 262,
    "weight": 1
   },
   {
    "source": 155,
    "target": 251,
    "weight": 1
   },
   {
    "source": 103,
    "target": 263,
    "weight": 1
   },
   {
    "source": 34,
    "target": 263,
    "weight": 2
   },
   {
    "source": 34,
    "target": 264,
    "weight": 2
   },
   {
    "source": 264,
    "target": 265,
    "weight": 1
   },
   {
    "source": 111,
    "target": 265,
    "weight": 1
   },
   {
    "source": 111,
    "target": 266,
    "weight": 2
   },
   {
    "source": 111,
    "target": 267,
    "weight": 1
   },
   {
    "source": 267,
    "target": 268,
    "weight": 1
   },
   {
    "source": 115,
    "target": 268,
    "weight": 1
   },
   {
    "source": 34,
    "target": 103,
    "weight": 1
   },
   {
    "source": 107,
    "target": 228,
    "weight": 1
   },
   {
    "source": 107,
    "target": 269,
    "weight": 1
   },
   {
    "source": 115,
    "target": 228,
    "weight": 1
   },
   {
    "source": 270,
    "target": 271,
    "weight": 1
   },
   {
    "source": 271,
    "target": 272,
    "weight": 1
   },
   {
    "source": 123,
    "target": 272,
    "weight": 1
   },
   {
    "source": 56,
    "target": 123,
    "weight": 1
   },
   {
    "source": 4,
    "target": 56,
    "weight": 2
   },
   {
    "source": 269,
    "target": 270,
    "weight": 1
   },
   {
    "source": 28,
    "target": 273,
    "weight": 3
   },
   {
    "source": 273,
    "target": 274,
    "weight": 1
   },
   {
    "source": 237,
    "target": 274,
    "weight": 1
   },
   {
    "source": 45,
    "target": 237,
    "weight": 1
   },
   {
    "source": 45,
    "target": 275,
    "weight": 1
   },
   {
    "source": 263,
    "target": 275,
    "weight": 1
   },
   {
    "source": 28,
    "target": 152,
    "weight": 1
   },
   {
    "source": 155,
    "target": 273,
    "weight": 1
   },
   {
    "source": 28,
    "target": 34,
    "weight": 1
   },
   {
    "source": 216,
    "target": 228,
    "weight": 2
   },
   {
    "source": 228,
    "target": 246,
    "weight": 2
   },
   {
    "source": 246,
    "target": 276,
    "weight": 2
   },
   {
    "source": 276,
    "target": 277,
    "weight": 2
   },
   {
    "source": 155,
    "target": 216,
    "weight": 1
   },
   {
    "source": 278,
    "target": 279,
    "weight": 1
   },
   {
    "source": 279,
    "target": 280,
    "weight": 1
   },
   {
    "source": 231,
    "target": 280,
    "weight": 1
   },
   {
    "source": 231,
    "target": 281,
    "weight": 1
   },
   {
    "source": 281,
    "target": 282,
    "weight": 2
   },
   {
    "source": 282,
    "target": 283,
    "weight": 1
   },
   {
    "source": 283,
    "target": 284,
    "weight": 1
   },
   {
    "source": 238,
    "target": 284,
    "weight": 1
   },
   {
    "source": 230,
    "target": 238,
    "weight": 1
   },
   {
    "source": 230,
    "target": 285,
    "weight": 1
   },
   {
    "source": 285,
    "target": 286,
    "weight": 1
   },
   {
    "source": 82,
    "target": 286,
    "weight": 1
   },
   {
    "source": 277,
    "target": 278,
    "weight": 1
   },
   {
    "source": 5,
    "target": 287,
    "weight": 1
   },
   {
    "source": 287,
    "target": 288,
    "weight": 1
   },
   {
    "source": 244,
    "target": 288,
    "weight": 1
   },
   {
    "source": 5,
    "target": 82,
    "weight": 1
   },
   {
    "source": 289,
    "target": 290,
    "weight": 1
   },
   {
    "source": 290,
    "target": 291,
    "weight": 1
   },
   {
    "source": 240,
    "target": 291,
    "weight": 2
   },
   {
    "source": 244,
    "target": 289,
    "weight": 1
   },
   {
    "source": 129,
    "target": 292,
    "weight": 1
   },
   {
    "source": 292,
    "target": 293,
    "weight": 1
   },
   {
    "source": 293,
    "target": 294,
    "weight": 2
   },
   {
    "source": 256,
    "target": 294,
    "weight": 1
   },
   {
    "source": 256,
    "target": 295,
    "weight": 1
   },
   {
    "source": 238,
    "target": 295,
    "weight": 2
   },
   {
    "source": 238,
    "target": 296,
    "weight": 1
   },
   {
    "source": 231,
    "target": 296,
    "weight": 1
   },
   {
    "source": 129,
    "target": 240,
    "weight": 1
   },
   {
    "source": 2,
    "target": 297,
    "weight": 1
   },
   {
    "source": 0,
    "target": 231,
    "weight": 1
   },
   {
    "source": 297,
    "target": 298,
    "weight": 1
   },
   {
    "source": 298,
    "target": 299,
    "weight": 1
   },
   {
    "source": 295,
    "target": 299,
    "weight": 1
   },
   {
    "source": 90,
    "target": 300,
    "weight": 1
   },
   {
    "source": 299,
    "target": 300,
    "weight": 2
   },
   {
    "source": 293,
    "target": 299,
    "weight": 1
   },
   {
    "source": 293,
    "target": 301,
    "weight": 1
   },
   {
    "source": 301,
    "target": 302,
    "weight": 1
   },
   {
    "source": 231,
    "target": 302,
    "weight": 1
   },
   {
    "source": 231,
    "target": 303,
    "weight": 1
   },
   {
    "source": 90,
    "target": 238,
    "weight": 1
   },
   {
    "source": 126,
    "target": 304,
    "weight": 1
   },
   {
    "source": 289,
    "target": 304,
    "weight": 1
   },
   {
    "source": 289,
    "target": 291,
    "weight": 1
   },
   {
    "source": 227,
    "target": 240,
    "weight": 1
   },
   {
    "source": 152,
    "target": 227,
    "weight": 1
   },
   {
    "source": 126,
    "target": 303,
    "weight": 1
   },
   {
    "source": 301,
    "target": 305,
    "weight": 1
   },
   {
    "source": 301,
    "target": 306,
    "weight": 2
   },
   {
    "source": 152,
    "target": 305,
    "weight": 1
   },
   {
    "source": 289,
    "target": 307,
    "weight": 1
   },
   {
    "source": 305,
    "target": 307,
    "weight": 1
   },
   {
    "source": 249,
    "target": 305,
    "weight": 1
   },
   {
    "source": 238,
    "target": 249,
    "weight": 2
   },
   {
    "source": 238,
    "target": 308,
    "weight": 1
   },
   {
    "source": 69,
    "target": 308,
    "weight": 1
   },
   {
    "source": 69,
    "target": 177,
    "weight": 1
   },
   {
    "source": 289,
    "target": 306,
    "weight": 1
   },
   {
    "source": 177,
    "target": 293,
    "weight": 1
   },
   {
    "source": 228,
    "target": 309,
    "weight": 1
   },
   {
    "source": 228,
    "target": 287,
    "weight": 1
   },
   {
    "source": 165,
    "target": 287,
    "weight": 1
   },
   {
    "source": 115,
    "target": 165,
    "weight": 1
   },
   {
    "source": 115,
    "target": 170,
    "weight": 2
   },
   {
    "source": 103,
    "target": 170,
    "weight": 1
   },
   {
    "source": 103,
    "target": 310,
    "weight": 1
   },
   {
    "source": 152,
    "target": 310,
    "weight": 1
   },
   {
    "source": 294,
    "target": 309,
    "weight": 1
   },
   {
    "source": 177,
    "target": 311,
    "weight": 4
   },
   {
    "source": 189,
    "target": 311,
    "weight": 1
   },
   {
    "source": 179,
    "target": 189,
    "weight": 1
   },
   {
    "source": 179,
    "target": 312,
    "weight": 1
   },
   {
    "source": 312,
    "target": 313,
    "weight": 1
   },
   {
    "source": 313,
    "target": 314,
    "weight": 1
   },
   {
    "source": 152,
    "target": 177,
    "weight": 2
   },
   {
    "source": 46,
    "target": 123,
    "weight": 1
   },
   {
    "source": 2,
    "target": 243,
    "weight": 1
   },
   {
    "source": 2,
    "target": 289,
    "weight": 1
   },
   {
    "source": 275,
    "target": 289,
    "weight": 1
   },
   {
    "source": 275,
    "target": 315,
    "weight": 1
   },
   {
    "source": 315,
    "target": 316,
    "weight": 1
   },
   {
    "source": 313,
    "target": 316,
    "weight": 1
   },
   {
    "source": 26,
    "target": 313,
    "weight": 1
   },
   {
    "source": 2,
    "target": 123,
    "weight": 1
   },
   {
    "source": 46,
    "target": 314,
    "weight": 1
   },
   {
    "source": 108,
    "target": 275,
    "weight": 1
   },
   {
    "source": 108,
    "target": 126,
    "weight": 1
   },
   {
    "source": 115,
    "target": 275,
    "weight": 1
   },
   {
    "source": 9,
    "target": 152,
    "weight": 5
   },
   {
    "source": 11,
    "target": 137,
    "weight": 1
   },
   {
    "source": 137,
    "target": 231,
    "weight": 1
   },
   {
    "source": 231,
    "target": 317,
    "weight": 1
   },
   {
    "source": 124,
    "target": 317,
    "weight": 1
   },
   {
    "source": 32,
    "target": 124,
    "weight": 1
   },
   {
    "source": 9,
    "target": 137,
    "weight": 1
   },
   {
    "source": 126,
    "target": 152,
    "weight": 1
   },
   {
    "source": 230,
    "target": 318,
    "weight": 1
   },
   {
    "source": 318,
    "target": 319,
    "weight": 1
   },
   {
    "source": 319,
    "target": 320,
    "weight": 1
   },
   {
    "source": 320,
    "target": 321,
    "weight": 1
   },
   {
    "source": 28,
    "target": 155,
    "weight": 1
   },
   {
    "source": 26,
    "target": 322,
    "weight": 1
   },
   {
    "source": 116,
    "target": 322,
    "weight": 1
   },
   {
    "source": 2,
    "target": 116,
    "weight": 1
   },
   {
    "source": 2,
    "target": 323,
    "weight": 1
   },
   {
    "source": 151,
    "target": 323,
    "weight": 1
   },
   {
    "source": 151,
    "target": 237,
    "weight": 1
   },
   {
    "source": 237,
    "target": 324,
    "weight": 1
   },
   {
    "source": 324,
    "target": 325,
    "weight": 1
   },
   {
    "source": 249,
    "target": 325,
    "weight": 1
   },
   {
    "source": 249,
    "target": 258,
    "weight": 1
   },
   {
    "source": 26,
    "target": 321,
    "weight": 1
   },
   {
    "source": 195,
    "target": 243,
    "weight": 1
   },
   {
    "source": 40,
    "target": 243,
    "weight": 1
   },
   {
    "source": 40,
    "target": 249,
    "weight": 2
   },
   {
    "source": 111,
    "target": 249,
    "weight": 1
   },
   {
    "source": 9,
    "target": 111,
    "weight": 1
   },
   {
    "source": 11,
    "target": 145,
    "weight": 1
   },
   {
    "source": 145,
    "target": 326,
    "weight": 1
   },
   {
    "source": 326,
    "target": 327,
    "weight": 1
   },
   {
    "source": 318,
    "target": 327,
    "weight": 1
   },
   {
    "source": 318,
    "target": 328,
    "weight": 1
   },
   {
    "source": 272,
    "target": 328,
    "weight": 1
   },
   {
    "source": 272,
    "target": 329,
    "weight": 1
   },
   {
    "source": 152,
    "target": 329,
    "weight": 1
   },
   {
    "source": 64,
    "target": 152,
    "weight": 2
   },
   {
    "source": 26,
    "target": 64,
    "weight": 1
   },
   {
    "source": 145,
    "target": 327,
    "weight": 1
   },
   {
    "source": 272,
    "target": 318,
    "weight": 1
   },
   {
    "source": 195,
    "target": 258,
    "weight": 1
   },
   {
    "source": 330,
    "target": 331,
    "weight": 1
   },
   {
    "source": 115,
    "target": 331,
    "weight": 1
   },
   {
    "source": 115,
    "target": 332,
    "weight": 4
   },
   {
    "source": 4,
    "target": 332,
    "weight": 3
   },
   {
    "source": 5,
    "target": 170,
    "weight": 2
   },
   {
    "source": 5,
    "target": 115,
    "weight": 1
   },
   {
    "source": 152,
    "target": 332,
    "weight": 1
   },
   {
    "source": 170,
    "target": 332,
    "weight": 2
   },
   {
    "source": 26,
    "target": 330,
    "weight": 1
   },
   {
    "source": 330,
    "target": 333,
    "weight": 1
   },
   {
    "source": 115,
    "target": 330,
    "weight": 2
   },
   {
    "source": 167,
    "target": 170,
    "weight": 1
   },
   {
    "source": 152,
    "target": 333,
    "weight": 1
   },
   {
    "source": 9,
    "target": 334,
    "weight": 1
   },
   {
    "source": 9,
    "target": 267,
    "weight": 2
   },
   {
    "source": 267,
    "target": 335,
    "weight": 1
   },
   {
    "source": 335,
    "target": 336,
    "weight": 1
   },
   {
    "source": 139,
    "target": 336,
    "weight": 1
   },
   {
    "source": 112,
    "target": 139,
    "weight": 1
   },
   {
    "source": 112,
    "target": 214,
    "weight": 1
   },
   {
    "source": 214,
    "target": 269,
    "weight": 2
   },
   {
    "source": 3,
    "target": 269,
    "weight": 1
   },
   {
    "source": 3,
    "target": 337,
    "weight": 1
   },
   {
    "source": 111,
    "target": 337,
    "weight": 1
   },
   {
    "source": 111,
    "target": 338,
    "weight": 1
   },
   {
    "source": 40,
    "target": 338,
    "weight": 1
   },
   {
    "source": 9,
    "target": 335,
    "weight": 1
   },
   {
    "source": 167,
    "target": 334,
    "weight": 1
   },
   {
    "source": 137,
    "target": 189,
    "weight": 1
   },
   {
    "source": 137,
    "target": 339,
    "weight": 1
   },
   {
    "source": 339,
    "target": 340,
    "weight": 1
   },
   {
    "source": 64,
    "target": 340,
    "weight": 1
   },
   {
    "source": 64,
    "target": 339,
    "weight": 1
   },
   {
    "source": 112,
    "target": 339,
    "weight": 1
   },
   {
    "source": 112,
    "target": 340,
    "weight": 1
   },
   {
    "source": 40,
    "target": 189,
    "weight": 1
   },
   {
    "source": 228,
    "target": 299,
    "weight": 1
   },
   {
    "source": 93,
    "target": 124,
    "weight": 1
   },
   {
    "source": 93,
    "target": 341,
    "weight": 1
   },
   {
    "source": 227,
    "target": 341,
    "weight": 2
   },
   {
    "source": 152,
    "target": 231,
    "weight": 1
   },
   {
    "source": 112,
    "target": 299,
    "weight": 2
   },
   {
    "source": 166,
    "target": 231,
    "weight": 1
   },
   {
    "source": 6,
    "target": 342,
    "weight": 1
   },
   {
    "source": 124,
    "target": 342,
    "weight": 1
   },
   {
    "source": 124,
    "target": 343,
    "weight": 1
   },
   {
    "source": 343,
    "target": 344,
    "weight": 1
   },
   {
    "source": 344,
    "target": 345,
    "weight": 1
   },
   {
    "source": 156,
    "target": 345,
    "weight": 1
   },
   {
    "source": 115,
    "target": 156,
    "weight": 1
   },
   {
    "source": 110,
    "target": 115,
    "weight": 2
   },
   {
    "source": 156,
    "target": 344,
    "weight": 1
   },
   {
    "source": 3,
    "target": 166,
    "weight": 1
   },
   {
    "source": 167,
    "target": 346,
    "weight": 1
   },
   {
    "source": 228,
    "target": 346,
    "weight": 1
   },
   {
    "source": 110,
    "target": 167,
    "weight": 1
   },
   {
    "source": 124,
    "target": 347,
    "weight": 2
   },
   {
    "source": 124,
    "target": 348,
    "weight": 1
   },
   {
    "source": 52,
    "target": 348,
    "weight": 1
   },
   {
    "source": 52,
    "target": 349,
    "weight": 1
   },
   {
    "source": 347,
    "target": 348,
    "weight": 1
   },
   {
    "source": 350,
    "target": 351,
    "weight": 2
   },
   {
    "source": 5,
    "target": 351,
    "weight": 2
   },
   {
    "source": 5,
    "target": 200,
    "weight": 1
   },
   {
    "source": 200,
    "target": 256,
    "weight": 2
   },
   {
    "source": 152,
    "target": 256,
    "weight": 2
   },
   {
    "source": 152,
    "target": 163,
    "weight": 1
   },
   {
    "source": 138,
    "target": 163,
    "weight": 1
   },
   {
    "source": 45,
    "target": 138,
    "weight": 1
   },
   {
    "source": 4,
    "target": 45,
    "weight": 1
   },
   {
    "source": 152,
    "target": 200,
    "weight": 3
   },
   {
    "source": 45,
    "target": 152,
    "weight": 1
   },
   {
    "source": 349,
    "target": 350,
    "weight": 1
   },
   {
    "source": 351,
    "target": 352,
    "weight": 1
   },
   {
    "source": 39,
    "target": 352,
    "weight": 2
   },
   {
    "source": 39,
    "target": 353,
    "weight": 1
   },
   {
    "source": 200,
    "target": 353,
    "weight": 1
   },
   {
    "source": 163,
    "target": 200,
    "weight": 1
   },
   {
    "source": 163,
    "target": 354,
    "weight": 1
   },
   {
    "source": 354,
    "target": 355,
    "weight": 1
   },
   {
    "source": 177,
    "target": 355,
    "weight": 1
   },
   {
    "source": 177,
    "target": 356,
    "weight": 1
   },
   {
    "source": 39,
    "target": 200,
    "weight": 1
   },
   {
    "source": 152,
    "target": 351,
    "weight": 1
   },
   {
    "source": 357,
    "target": 358,
    "weight": 1
   },
   {
    "source": 353,
    "target": 358,
    "weight": 1
   },
   {
    "source": 353,
    "target": 359,
    "weight": 1
   },
   {
    "source": 281,
    "target": 359,
    "weight": 1
   },
   {
    "source": 103,
    "target": 281,
    "weight": 3
   },
   {
    "source": 103,
    "target": 237,
    "weight": 1
   },
   {
    "source": 237,
    "target": 310,
    "weight": 1
   },
   {
    "source": 245,
    "target": 310,
    "weight": 1
   },
   {
    "source": 245,
    "target": 360,
    "weight": 1
   },
   {
    "source": 244,
    "target": 360,
    "weight": 1
   },
   {
    "source": 163,
    "target": 244,
    "weight": 1
   },
   {
    "source": 163,
    "target": 177,
    "weight": 1
   },
   {
    "source": 356,
    "target": 357,
    "weight": 1
   },
   {
    "source": 254,
    "target": 351,
    "weight": 1
   },
   {
    "source": 313,
    "target": 351,
    "weight": 1
   },
   {
    "source": 258,
    "target": 313,
    "weight": 1
   },
   {
    "source": 152,
    "target": 258,
    "weight": 1
   },
   {
    "source": 177,
    "target": 361,
    "weight": 1
   },
   {
    "source": 64,
    "target": 361,
    "weight": 1
   },
   {
    "source": 64,
    "target": 357,
    "weight": 1
   },
   {
    "source": 357,
    "target": 362,
    "weight": 1
   },
   {
    "source": 254,
    "target": 311,
    "weight": 2
   },
   {
    "source": 216,
    "target": 363,
    "weight": 1
   },
   {
    "source": 216,
    "target": 249,
    "weight": 1
   },
   {
    "source": 4,
    "target": 249,
    "weight": 1
   },
   {
    "source": 4,
    "target": 103,
    "weight": 2
   },
   {
    "source": 26,
    "target": 103,
    "weight": 1
   },
   {
    "source": 26,
    "target": 364,
    "weight": 1
   },
   {
    "source": 362,
    "target": 363,
    "weight": 1
   },
   {
    "source": 249,
    "target": 365,
    "weight": 1
   },
   {
    "source": 249,
    "target": 366,
    "weight": 1
   },
   {
    "source": 177,
    "target": 366,
    "weight": 1
   },
   {
    "source": 177,
    "target": 365,
    "weight": 1
   },
   {
    "source": 148,
    "target": 365,
    "weight": 1
   },
   {
    "source": 64,
    "target": 148,
    "weight": 2
   },
   {
    "source": 112,
    "target": 367,
    "weight": 1
   },
   {
    "source": 367,
    "target": 368,
    "weight": 1
   },
   {
    "source": 163,
    "target": 368,
    "weight": 1
   },
   {
    "source": 163,
    "target": 369,
    "weight": 1
   },
   {
    "source": 369,
    "target": 370,
    "weight": 1
   },
   {
    "source": 164,
    "target": 370,
    "weight": 1
   },
   {
    "source": 164,
    "target": 177,
    "weight": 1
   },
   {
    "source": 163,
    "target": 370,
    "weight": 1
   },
   {
    "source": 164,
    "target": 311,
    "weight": 1
   },
   {
    "source": 364,
    "target": 365,
    "weight": 1
   },
   {
    "source": 225,
    "target": 371,
    "weight": 1
   },
   {
    "source": 124,
    "target": 371,
    "weight": 2
   },
   {
    "source": 124,
    "target": 372,
    "weight": 4
   },
   {
    "source": 124,
    "target": 373,
    "weight": 1
   },
   {
    "source": 373,
    "target": 374,
    "weight": 1
   },
   {
    "source": 255,
    "target": 374,
    "weight": 2
   },
   {
    "source": 225,
    "target": 311,
    "weight": 1
   },
   {
    "source": 115,
    "target": 375,
    "weight": 1
   },
   {
    "source": 124,
    "target": 375,
    "weight": 1
   },
   {
    "source": 4,
    "target": 376,
    "weight": 1
   },
   {
    "source": 214,
    "target": 376,
    "weight": 1
   },
   {
    "source": 140,
    "target": 214,
    "weight": 1
   },
   {
    "source": 140,
    "target": 377,
    "weight": 1
   },
   {
    "source": 107,
    "target": 377,
    "weight": 1
   },
   {
    "source": 107,
    "target": 214,
    "weight": 1
   },
   {
    "source": 115,
    "target": 255,
    "weight": 1
   },
   {
    "source": 56,
    "target": 372,
    "weight": 1
   },
   {
    "source": 56,
    "target": 378,
    "weight": 2
   },
   {
    "source": 140,
    "target": 378,
    "weight": 1
   },
   {
    "source": 140,
    "target": 218,
    "weight": 2
   },
   {
    "source": 192,
    "target": 218,
    "weight": 1
   },
   {
    "source": 192,
    "target": 379,
    "weight": 1
   },
   {
    "source": 379,
    "target": 380,
    "weight": 2
   },
   {
    "source": 221,
    "target": 380,
    "weight": 1
   },
   {
    "source": 249,
    "target": 381,
    "weight": 1
   },
   {
    "source": 140,
    "target": 381,
    "weight": 1
   },
   {
    "source": 214,
    "target": 372,
    "weight": 1
   },
   {
    "source": 287,
    "target": 382,
    "weight": 1
   },
   {
    "source": 287,
    "target": 372,
    "weight": 2
   },
   {
    "source": 372,
    "target": 383,
    "weight": 1
   },
   {
    "source": 140,
    "target": 383,
    "weight": 1
   },
   {
    "source": 140,
    "target": 297,
    "weight": 5
   },
   {
    "source": 177,
    "target": 297,
    "weight": 2
   },
   {
    "source": 140,
    "target": 321,
    "weight": 2
   },
   {
    "source": 321,
    "target": 384,
    "weight": 1
   },
   {
    "source": 177,
    "target": 384,
    "weight": 1
   },
   {
    "source": 177,
    "target": 385,
    "weight": 1
   },
   {
    "source": 218,
    "target": 385,
    "weight": 1
   },
   {
    "source": 218,
    "target": 386,
    "weight": 1
   },
   {
    "source": 321,
    "target": 386,
    "weight": 1
   },
   {
    "source": 321,
    "target": 387,
    "weight": 2
   },
   {
    "source": 256,
    "target": 387,
    "weight": 2
   },
   {
    "source": 256,
    "target": 388,
    "weight": 1
   },
   {
    "source": 388,
    "target": 389,
    "weight": 1
   },
   {
    "source": 140,
    "target": 382,
    "weight": 1
   },
   {
    "source": 26,
    "target": 390,
    "weight": 1
   },
   {
    "source": 177,
    "target": 390,
    "weight": 1
   },
   {
    "source": 387,
    "target": 389,
    "weight": 1
   },
   {
    "source": 391,
    "target": 392,
    "weight": 1
   },
   {
    "source": 137,
    "target": 392,
    "weight": 1
   },
   {
    "source": 137,
    "target": 372,
    "weight": 1
   },
   {
    "source": 216,
    "target": 372,
    "weight": 1
   },
   {
    "source": 216,
    "target": 393,
    "weight": 1
   },
   {
    "source": 9,
    "target": 393,
    "weight": 1
   },
   {
    "source": 4,
    "target": 394,
    "weight": 1
   },
   {
    "source": 177,
    "target": 391,
    "weight": 1
   },
   {
    "source": 123,
    "target": 237,
    "weight": 1
   },
   {
    "source": 237,
    "target": 297,
    "weight": 1
   },
   {
    "source": 154,
    "target": 177,
    "weight": 1
   },
   {
    "source": 154,
    "target": 395,
    "weight": 1
   },
   {
    "source": 395,
    "target": 396,
    "weight": 1
   },
   {
    "source": 396,
    "target": 397,
    "weight": 1
   },
   {
    "source": 177,
    "target": 397,
    "weight": 1
   },
   {
    "source": 123,
    "target": 394,
    "weight": 1
   },
   {
    "source": 140,
    "target": 155,
    "weight": 1
   },
   {
    "source": 26,
    "target": 155,
    "weight": 3
   },
   {
    "source": 26,
    "target": 398,
    "weight": 1
   },
   {
    "source": 4,
    "target": 267,
    "weight": 3
   },
   {
    "source": 155,
    "target": 267,
    "weight": 1
   },
   {
    "source": 155,
    "target": 399,
    "weight": 2
   },
   {
    "source": 120,
    "target": 399,
    "weight": 1
   },
   {
    "source": 120,
    "target": 387,
    "weight": 1
   },
   {
    "source": 4,
    "target": 398,
    "weight": 1
   },
   {
    "source": 2,
    "target": 137,
    "weight": 11
   },
   {
    "source": 137,
    "target": 400,
    "weight": 1
   },
   {
    "source": 216,
    "target": 400,
    "weight": 1
   },
   {
    "source": 228,
    "target": 351,
    "weight": 1
   },
   {
    "source": 351,
    "target": 372,
    "weight": 1
   },
   {
    "source": 30,
    "target": 372,
    "weight": 1
   },
   {
    "source": 30,
    "target": 401,
    "weight": 1
   },
   {
    "source": 115,
    "target": 401,
    "weight": 1
   },
   {
    "source": 0,
    "target": 256,
    "weight": 1
   },
   {
    "source": 124,
    "target": 402,
    "weight": 1
   },
   {
    "source": 345,
    "target": 402,
    "weight": 1
   },
   {
    "source": 345,
    "target": 403,
    "weight": 1
   },
   {
    "source": 9,
    "target": 403,
    "weight": 1
   },
   {
    "source": 152,
    "target": 404,
    "weight": 1
   },
   {
    "source": 264,
    "target": 404,
    "weight": 1
   },
   {
    "source": 4,
    "target": 371,
    "weight": 1
   },
   {
    "source": 34,
    "target": 124,
    "weight": 2
   },
   {
    "source": 124,
    "target": 405,
    "weight": 1
   },
   {
    "source": 405,
    "target": 406,
    "weight": 1
   },
   {
    "source": 34,
    "target": 406,
    "weight": 1
   },
   {
    "source": 34,
    "target": 407,
    "weight": 1
   },
   {
    "source": 330,
    "target": 407,
    "weight": 1
   },
   {
    "source": 116,
    "target": 152,
    "weight": 2
   },
   {
    "source": 309,
    "target": 408,
    "weight": 1
   },
   {
    "source": 34,
    "target": 309,
    "weight": 1
   },
   {
    "source": 34,
    "target": 409,
    "weight": 1
   },
   {
    "source": 409,
    "target": 410,
    "weight": 1
   },
   {
    "source": 410,
    "target": 411,
    "weight": 1
   },
   {
    "source": 9,
    "target": 408,
    "weight": 1
   },
   {
    "source": 224,
    "target": 412,
    "weight": 1
   },
   {
    "source": 224,
    "target": 411,
    "weight": 1
   },
   {
    "source": 212,
    "target": 281,
    "weight": 1
   },
   {
    "source": 246,
    "target": 281,
    "weight": 2
   },
   {
    "source": 246,
    "target": 254,
    "weight": 2
   },
   {
    "source": 9,
    "target": 254,
    "weight": 1
   },
   {
    "source": 212,
    "target": 412,
    "weight": 1
   },
   {
    "source": 32,
    "target": 413,
    "weight": 1
   },
   {
    "source": 68,
    "target": 413,
    "weight": 2
   },
   {
    "source": 68,
    "target": 263,
    "weight": 1
   },
   {
    "source": 11,
    "target": 214,
    "weight": 1
   },
   {
    "source": 263,
    "target": 414,
    "weight": 2
   },
   {
    "source": 168,
    "target": 263,
    "weight": 1
   },
   {
    "source": 168,
    "target": 246,
    "weight": 2
   },
   {
    "source": 246,
    "target": 415,
    "weight": 1
   },
   {
    "source": 115,
    "target": 415,
    "weight": 1
   },
   {
    "source": 115,
    "target": 249,
    "weight": 5
   },
   {
    "source": 55,
    "target": 249,
    "weight": 1
   },
   {
    "source": 28,
    "target": 55,
    "weight": 1
   },
   {
    "source": 11,
    "target": 28,
    "weight": 1
   },
   {
    "source": 249,
    "target": 415,
    "weight": 1
   },
   {
    "source": 152,
    "target": 416,
    "weight": 1
   },
   {
    "source": 49,
    "target": 416,
    "weight": 1
   },
   {
    "source": 49,
    "target": 263,
    "weight": 1
   },
   {
    "source": 11,
    "target": 116,
    "weight": 2
   },
   {
    "source": 44,
    "target": 417,
    "weight": 1
   },
   {
    "source": 263,
    "target": 417,
    "weight": 1
   },
   {
    "source": 212,
    "target": 265,
    "weight": 1
   },
   {
    "source": 4,
    "target": 265,
    "weight": 1
   },
   {
    "source": 4,
    "target": 284,
    "weight": 1
   },
   {
    "source": 159,
    "target": 284,
    "weight": 1
   },
   {
    "source": 154,
    "target": 159,
    "weight": 1
   },
   {
    "source": 154,
    "target": 418,
    "weight": 1
   },
   {
    "source": 110,
    "target": 418,
    "weight": 1
   },
   {
    "source": 265,
    "target": 284,
    "weight": 1
   },
   {
    "source": 2,
    "target": 212,
    "weight": 1
   },
   {
    "source": 419,
    "target": 420,
    "weight": 1
   },
   {
    "source": 33,
    "target": 420,
    "weight": 1
   },
   {
    "source": 33,
    "target": 212,
    "weight": 2
   },
   {
    "source": 110,
    "target": 419,
    "weight": 1
   },
   {
    "source": 167,
    "target": 421,
    "weight": 1
   },
   {
    "source": 421,
    "target": 422,
    "weight": 1
   },
   {
    "source": 167,
    "target": 212,
    "weight": 1
   },
   {
    "source": 11,
    "target": 352,
    "weight": 1
   },
   {
    "source": 11,
    "target": 44,
    "weight": 1
   },
   {
    "source": 44,
    "target": 155,
    "weight": 1
   },
   {
    "source": 155,
    "target": 423,
    "weight": 1
   },
   {
    "source": 44,
    "target": 423,
    "weight": 1
   },
   {
    "source": 44,
    "target": 337,
    "weight": 1
   },
   {
    "source": 352,
    "target": 422,
    "weight": 1
   },
   {
    "source": 33,
    "target": 213,
    "weight": 1
   },
   {
    "source": 2,
    "target": 31,
    "weight": 1
   },
   {
    "source": 213,
    "target": 337,
    "weight": 1
   },
   {
    "source": 284,
    "target": 424,
    "weight": 1
   },
   {
    "source": 213,
    "target": 424,
    "weight": 1
   },
   {
    "source": 124,
    "target": 213,
    "weight": 1
   },
   {
    "source": 104,
    "target": 124,
    "weight": 1
   },
   {
    "source": 104,
    "target": 170,
    "weight": 2
   },
   {
    "source": 31,
    "target": 284,
    "weight": 1
   },
   {
    "source": 213,
    "target": 287,
    "weight": 1
   },
   {
    "source": 4,
    "target": 287,
    "weight": 2
   },
   {
    "source": 4,
    "target": 425,
    "weight": 1
   },
   {
    "source": 425,
    "target": 426,
    "weight": 1
   },
   {
    "source": 195,
    "target": 426,
    "weight": 4
   },
   {
    "source": 195,
    "target": 287,
    "weight": 1
   },
   {
    "source": 170,
    "target": 213,
    "weight": 1
   },
   {
    "source": 273,
    "target": 426,
    "weight": 1
   },
   {
    "source": 93,
    "target": 273,
    "weight": 1
   },
   {
    "source": 93,
    "target": 287,
    "weight": 1
   },
   {
    "source": 287,
    "target": 427,
    "weight": 1
   },
   {
    "source": 287,
    "target": 426,
    "weight": 1
   },
   {
    "source": 170,
    "target": 427,
    "weight": 1
   },
   {
    "source": 428,
    "target": 429,
    "weight": 1
   },
   {
    "source": 273,
    "target": 429,
    "weight": 1
   },
   {
    "source": 4,
    "target": 273,
    "weight": 2
   },
   {
    "source": 4,
    "target": 430,
    "weight": 1
   },
   {
    "source": 246,
    "target": 430,
    "weight": 1
   },
   {
    "source": 104,
    "target": 246,
    "weight": 1
   },
   {
    "source": 249,
    "target": 428,
    "weight": 1
   },
   {
    "source": 165,
    "target": 258,
    "weight": 1
   },
   {
    "source": 4,
    "target": 431,
    "weight": 1
   },
   {
    "source": 431,
    "target": 432,
    "weight": 1
   },
   {
    "source": 432,
    "target": 433,
    "weight": 1
   },
   {
    "source": 433,
    "target": 434,
    "weight": 2
   },
   {
    "source": 434,
    "target": 435,
    "weight": 1
   },
   {
    "source": 426,
    "target": 435,
    "weight": 1
   },
   {
    "source": 170,
    "target": 258,
    "weight": 1
   },
   {
    "source": 436,
    "target": 437,
    "weight": 1
   },
   {
    "source": 195,
    "target": 436,
    "weight": 1
   },
   {
    "source": 6,
    "target": 438,
    "weight": 1
   },
   {
    "source": 4,
    "target": 438,
    "weight": 1
   },
   {
    "source": 170,
    "target": 254,
    "weight": 1
   },
   {
    "source": 254,
    "target": 413,
    "weight": 1
   },
   {
    "source": 64,
    "target": 432,
    "weight": 1
   },
   {
    "source": 426,
    "target": 432,
    "weight": 1
   },
   {
    "source": 116,
    "target": 170,
    "weight": 1
   },
   {
    "source": 170,
    "target": 438,
    "weight": 1
   },
   {
    "source": 3,
    "target": 437,
    "weight": 1
   },
   {
    "source": 123,
    "target": 166,
    "weight": 1
   },
   {
    "source": 166,
    "target": 439,
    "weight": 1
   },
   {
    "source": 9,
    "target": 439,
    "weight": 1
   },
   {
    "source": 11,
    "target": 56,
    "weight": 1
   },
   {
    "source": 56,
    "target": 287,
    "weight": 1
   },
   {
    "source": 287,
    "target": 379,
    "weight": 1
   },
   {
    "source": 170,
    "target": 379,
    "weight": 1
   },
   {
    "source": 170,
    "target": 400,
    "weight": 1
   },
   {
    "source": 177,
    "target": 400,
    "weight": 2
   },
   {
    "source": 177,
    "target": 440,
    "weight": 1
   },
   {
    "source": 11,
    "target": 123,
    "weight": 1
   },
   {
    "source": 441,
    "target": 442,
    "weight": 1
   },
   {
    "source": 9,
    "target": 442,
    "weight": 1
   },
   {
    "source": 11,
    "target": 216,
    "weight": 1
   },
   {
    "source": 67,
    "target": 216,
    "weight": 1
   },
   {
    "source": 67,
    "target": 73,
    "weight": 1
   },
   {
    "source": 73,
    "target": 75,
    "weight": 1
   },
   {
    "source": 440,
    "target": 441,
    "weight": 1
   },
   {
    "source": 137,
    "target": 443,
    "weight": 1
   },
   {
    "source": 64,
    "target": 443,
    "weight": 1
   },
   {
    "source": 9,
    "target": 434,
    "weight": 1
   },
   {
    "source": 73,
    "target": 434,
    "weight": 1
   },
   {
    "source": 75,
    "target": 137,
    "weight": 1
   },
   {
    "source": 74,
    "target": 180,
    "weight": 1
   },
   {
    "source": 35,
    "target": 180,
    "weight": 1
   },
   {
    "source": 36,
    "target": 269,
    "weight": 1
   },
   {
    "source": 246,
    "target": 269,
    "weight": 2
   },
   {
    "source": 35,
    "target": 246,
    "weight": 1
   },
   {
    "source": 36,
    "target": 246,
    "weight": 1
   },
   {
    "source": 444,
    "target": 445,
    "weight": 1
   },
   {
    "source": 445,
    "target": 446,
    "weight": 1
   },
   {
    "source": 74,
    "target": 446,
    "weight": 1
   },
   {
    "source": 74,
    "target": 447,
    "weight": 1
   },
   {
    "source": 404,
    "target": 447,
    "weight": 1
   },
   {
    "source": 404,
    "target": 448,
    "weight": 1
   },
   {
    "source": 2,
    "target": 448,
    "weight": 2
   },
   {
    "source": 2,
    "target": 447,
    "weight": 1
   },
   {
    "source": 215,
    "target": 447,
    "weight": 1
   },
   {
    "source": 4,
    "target": 444,
    "weight": 1
   },
   {
    "source": 74,
    "target": 449,
    "weight": 1
   },
   {
    "source": 449,
    "target": 450,
    "weight": 1
   },
   {
    "source": 9,
    "target": 450,
    "weight": 1
   },
   {
    "source": 11,
    "target": 150,
    "weight": 1
   },
   {
    "source": 74,
    "target": 150,
    "weight": 2
   },
   {
    "source": 74,
    "target": 215,
    "weight": 1
   },
   {
    "source": 74,
    "target": 271,
    "weight": 1
   },
   {
    "source": 246,
    "target": 271,
    "weight": 2
   },
   {
    "source": 34,
    "target": 246,
    "weight": 1
   },
   {
    "source": 34,
    "target": 35,
    "weight": 2
   },
   {
    "source": 36,
    "target": 331,
    "weight": 1
   },
   {
    "source": 112,
    "target": 331,
    "weight": 1
   },
   {
    "source": 34,
    "target": 74,
    "weight": 2
   },
   {
    "source": 45,
    "target": 74,
    "weight": 1
   },
   {
    "source": 10,
    "target": 45,
    "weight": 2
   },
   {
    "source": 10,
    "target": 56,
    "weight": 1
   },
   {
    "source": 4,
    "target": 451,
    "weight": 2
   },
   {
    "source": 451,
    "target": 452,
    "weight": 1
   },
   {
    "source": 269,
    "target": 452,
    "weight": 1
   },
   {
    "source": 269,
    "target": 453,
    "weight": 2
   },
   {
    "source": 45,
    "target": 56,
    "weight": 1
   },
   {
    "source": 33,
    "target": 112,
    "weight": 1
   },
   {
    "source": 38,
    "target": 442,
    "weight": 1
   },
   {
    "source": 442,
    "target": 454,
    "weight": 1
   },
   {
    "source": 75,
    "target": 454,
    "weight": 1
   },
   {
    "source": 4,
    "target": 73,
    "weight": 2
   },
   {
    "source": 9,
    "target": 74,
    "weight": 1
   },
   {
    "source": 9,
    "target": 115,
    "weight": 1
   },
   {
    "source": 66,
    "target": 453,
    "weight": 1
   },
   {
    "source": 167,
    "target": 455,
    "weight": 1
   },
   {
    "source": 34,
    "target": 455,
    "weight": 1
   },
   {
    "source": 34,
    "target": 227,
    "weight": 2
   },
   {
    "source": 33,
    "target": 227,
    "weight": 2
   },
   {
    "source": 115,
    "target": 167,
    "weight": 1
   },
   {
    "source": 9,
    "target": 124,
    "weight": 1
   },
   {
    "source": 11,
    "target": 124,
    "weight": 1
   },
   {
    "source": 33,
    "target": 124,
    "weight": 1
   },
   {
    "source": 34,
    "target": 360,
    "weight": 1
   },
   {
    "source": 172,
    "target": 360,
    "weight": 1
   },
   {
    "source": 172,
    "target": 173,
    "weight": 1
   },
   {
    "source": 68,
    "target": 173,
    "weight": 1
   },
   {
    "source": 4,
    "target": 34,
    "weight": 1
   },
   {
    "source": 227,
    "target": 456,
    "weight": 1
   },
   {
    "source": 115,
    "target": 227,
    "weight": 1
   },
   {
    "source": 46,
    "target": 110,
    "weight": 6
   },
   {
    "source": 46,
    "target": 436,
    "weight": 1
   },
   {
    "source": 68,
    "target": 456,
    "weight": 1
   },
   {
    "source": 4,
    "target": 155,
    "weight": 1
   },
   {
    "source": 4,
    "target": 328,
    "weight": 1
   },
   {
    "source": 155,
    "target": 436,
    "weight": 2
   },
   {
    "source": 114,
    "target": 364,
    "weight": 1
   },
   {
    "source": 4,
    "target": 364,
    "weight": 1
   },
   {
    "source": 4,
    "target": 239,
    "weight": 1
   },
   {
    "source": 157,
    "target": 239,
    "weight": 2
   },
   {
    "source": 154,
    "target": 157,
    "weight": 2
   },
   {
    "source": 4,
    "target": 154,
    "weight": 3
   },
   {
    "source": 114,
    "target": 328,
    "weight": 1
   },
   {
    "source": 204,
    "target": 254,
    "weight": 1
   },
   {
    "source": 115,
    "target": 457,
    "weight": 1
   },
   {
    "source": 321,
    "target": 457,
    "weight": 1
   },
   {
    "source": 155,
    "target": 321,
    "weight": 2
   },
   {
    "source": 155,
    "target": 424,
    "weight": 1
   },
   {
    "source": 115,
    "target": 254,
    "weight": 1
   },
   {
    "source": 2,
    "target": 458,
    "weight": 1
   },
   {
    "source": 458,
    "target": 459,
    "weight": 1
   },
   {
    "source": 115,
    "target": 459,
    "weight": 1
   },
   {
    "source": 115,
    "target": 171,
    "weight": 1
   },
   {
    "source": 171,
    "target": 460,
    "weight": 1
   },
   {
    "source": 460,
    "target": 461,
    "weight": 1
   },
   {
    "source": 42,
    "target": 461,
    "weight": 1
   },
   {
    "source": 42,
    "target": 104,
    "weight": 1
   },
   {
    "source": 0,
    "target": 424,
    "weight": 1
   },
   {
    "source": 225,
    "target": 462,
    "weight": 1
   },
   {
    "source": 177,
    "target": 462,
    "weight": 1
   },
   {
    "source": 124,
    "target": 463,
    "weight": 1
   },
   {
    "source": 115,
    "target": 463,
    "weight": 1
   },
   {
    "source": 124,
    "target": 462,
    "weight": 1
   },
   {
    "source": 249,
    "target": 463,
    "weight": 1
   },
   {
    "source": 104,
    "target": 225,
    "weight": 1
   },
   {
    "source": 124,
    "target": 464,
    "weight": 1
   },
   {
    "source": 124,
    "target": 465,
    "weight": 1
   },
   {
    "source": 79,
    "target": 465,
    "weight": 1
   },
   {
    "source": 79,
    "target": 466,
    "weight": 2
   },
   {
    "source": 302,
    "target": 466,
    "weight": 1
   },
   {
    "source": 302,
    "target": 467,
    "weight": 1
   },
   {
    "source": 467,
    "target": 468,
    "weight": 1
   },
   {
    "source": 468,
    "target": 469,
    "weight": 1
   },
   {
    "source": 466,
    "target": 469,
    "weight": 1
   },
   {
    "source": 466,
    "target": 470,
    "weight": 1
   },
   {
    "source": 467,
    "target": 469,
    "weight": 1
   },
   {
    "source": 249,
    "target": 464,
    "weight": 1
   },
   {
    "source": 465,
    "target": 470,
    "weight": 1
   },
   {
    "source": 464,
    "target": 471,
    "weight": 1
   },
   {
    "source": 471,
    "target": 472,
    "weight": 1
   },
   {
    "source": 472,
    "target": 473,
    "weight": 1
   },
   {
    "source": 355,
    "target": 473,
    "weight": 1
   },
   {
    "source": 464,
    "target": 465,
    "weight": 2
   },
   {
    "source": 474,
    "target": 475,
    "weight": 1
   },
   {
    "source": 124,
    "target": 475,
    "weight": 1
   },
   {
    "source": 124,
    "target": 155,
    "weight": 2
   },
   {
    "source": 155,
    "target": 464,
    "weight": 1
   },
   {
    "source": 36,
    "target": 464,
    "weight": 1
   },
   {
    "source": 36,
    "target": 380,
    "weight": 2
   },
   {
    "source": 115,
    "target": 380,
    "weight": 1
   },
   {
    "source": 249,
    "target": 302,
    "weight": 1
   },
   {
    "source": 302,
    "target": 476,
    "weight": 1
   },
   {
    "source": 49,
    "target": 476,
    "weight": 1
   },
   {
    "source": 49,
    "target": 378,
    "weight": 3
   },
   {
    "source": 378,
    "target": 472,
    "weight": 4
   },
   {
    "source": 104,
    "target": 472,
    "weight": 1
   },
   {
    "source": 355,
    "target": 474,
    "weight": 1
   },
   {
    "source": 304,
    "target": 477,
    "weight": 1
   },
   {
    "source": 477,
    "target": 478,
    "weight": 1
   },
   {
    "source": 464,
    "target": 478,
    "weight": 3
   },
   {
    "source": 464,
    "target": 466,
    "weight": 2
   },
   {
    "source": 380,
    "target": 466,
    "weight": 1
   },
   {
    "source": 380,
    "target": 479,
    "weight": 2
   },
   {
    "source": 472,
    "target": 479,
    "weight": 1
   },
   {
    "source": 472,
    "target": 480,
    "weight": 1
   },
   {
    "source": 124,
    "target": 480,
    "weight": 1
   },
   {
    "source": 124,
    "target": 479,
    "weight": 1
   },
   {
    "source": 44,
    "target": 380,
    "weight": 2
   },
   {
    "source": 44,
    "target": 481,
    "weight": 1
   },
   {
    "source": 104,
    "target": 304,
    "weight": 1
   },
   {
    "source": 466,
    "target": 472,
    "weight": 1
   },
   {
    "source": 472,
    "target": 482,
    "weight": 1
   },
   {
    "source": 380,
    "target": 482,
    "weight": 1
   },
   {
    "source": 380,
    "target": 483,
    "weight": 1
   },
   {
    "source": 478,
    "target": 483,
    "weight": 1
   },
   {
    "source": 466,
    "target": 481,
    "weight": 1
   },
   {
    "source": 126,
    "target": 464,
    "weight": 1
   },
   {
    "source": 126,
    "target": 484,
    "weight": 1
   },
   {
    "source": 4,
    "target": 484,
    "weight": 1
   },
   {
    "source": 145,
    "target": 240,
    "weight": 1
   },
   {
    "source": 115,
    "target": 145,
    "weight": 1
   },
   {
    "source": 115,
    "target": 485,
    "weight": 1
   },
   {
    "source": 249,
    "target": 485,
    "weight": 1
   },
   {
    "source": 249,
    "target": 486,
    "weight": 1
   },
   {
    "source": 469,
    "target": 486,
    "weight": 1
   },
   {
    "source": 469,
    "target": 487,
    "weight": 1
   },
   {
    "source": 110,
    "target": 240,
    "weight": 1
   },
   {
    "source": 464,
    "target": 472,
    "weight": 1
   },
   {
    "source": 378,
    "target": 487,
    "weight": 1
   },
   {
    "source": 321,
    "target": 487,
    "weight": 1
   },
   {
    "source": 466,
    "target": 487,
    "weight": 1
   },
   {
    "source": 53,
    "target": 488,
    "weight": 1
   },
   {
    "source": 53,
    "target": 489,
    "weight": 1
   },
   {
    "source": 489,
    "target": 490,
    "weight": 1
   },
   {
    "source": 490,
    "target": 491,
    "weight": 1
   },
   {
    "source": 321,
    "target": 488,
    "weight": 1
   },
   {
    "source": 79,
    "target": 249,
    "weight": 1
   },
   {
    "source": 115,
    "target": 491,
    "weight": 1
   },
   {
    "source": 464,
    "target": 492,
    "weight": 1
   },
   {
    "source": 478,
    "target": 492,
    "weight": 1
   },
   {
    "source": 37,
    "target": 478,
    "weight": 1
   },
   {
    "source": 37,
    "target": 115,
    "weight": 1
   },
   {
    "source": 36,
    "target": 115,
    "weight": 1
   },
   {
    "source": 380,
    "target": 493,
    "weight": 2
   },
   {
    "source": 378,
    "target": 493,
    "weight": 1
   },
   {
    "source": 466,
    "target": 478,
    "weight": 1
   },
   {
    "source": 45,
    "target": 251,
    "weight": 1
   },
   {
    "source": 45,
    "target": 494,
    "weight": 1
   },
   {
    "source": 112,
    "target": 494,
    "weight": 1
   },
   {
    "source": 112,
    "target": 311,
    "weight": 1
   },
   {
    "source": 9,
    "target": 311,
    "weight": 1
   },
   {
    "source": 56,
    "target": 251,
    "weight": 1
   },
   {
    "source": 35,
    "target": 463,
    "weight": 1
   },
   {
    "source": 35,
    "target": 495,
    "weight": 1
   },
   {
    "source": 495,
    "target": 496,
    "weight": 1
   },
   {
    "source": 472,
    "target": 496,
    "weight": 1
   },
   {
    "source": 472,
    "target": 495,
    "weight": 1
   },
   {
    "source": 495,
    "target": 497,
    "weight": 1
   },
   {
    "source": 463,
    "target": 495,
    "weight": 1
   },
   {
    "source": 149,
    "target": 463,
    "weight": 1
   },
   {
    "source": 498,
    "target": 499,
    "weight": 1
   },
   {
    "source": 287,
    "target": 499,
    "weight": 1
   },
   {
    "source": 287,
    "target": 500,
    "weight": 1
   },
   {
    "source": 500,
    "target": 501,
    "weight": 1
   },
   {
    "source": 247,
    "target": 501,
    "weight": 1
   },
   {
    "source": 247,
    "target": 502,
    "weight": 1
   },
   {
    "source": 251,
    "target": 502,
    "weight": 1
   },
   {
    "source": 251,
    "target": 390,
    "weight": 1
   },
   {
    "source": 390,
    "target": 503,
    "weight": 1
   },
   {
    "source": 238,
    "target": 503,
    "weight": 1
   },
   {
    "source": 238,
    "target": 504,
    "weight": 1
   },
   {
    "source": 504,
    "target": 505,
    "weight": 1
   },
   {
    "source": 505,
    "target": 506,
    "weight": 1
   },
   {
    "source": 506,
    "target": 507,
    "weight": 1
   },
   {
    "source": 197,
    "target": 507,
    "weight": 1
   },
   {
    "source": 197,
    "target": 508,
    "weight": 1
   },
   {
    "source": 497,
    "target": 498,
    "weight": 1
   },
   {
    "source": 96,
    "target": 508,
    "weight": 1
   },
   {
    "source": 45,
    "target": 269,
    "weight": 2
   },
   {
    "source": 269,
    "target": 509,
    "weight": 1
   },
   {
    "source": 251,
    "target": 509,
    "weight": 1
   },
   {
    "source": 220,
    "target": 251,
    "weight": 1
   },
   {
    "source": 197,
    "target": 220,
    "weight": 1
   },
   {
    "source": 197,
    "target": 479,
    "weight": 1
   },
   {
    "source": 81,
    "target": 479,
    "weight": 1
   },
   {
    "source": 81,
    "target": 374,
    "weight": 1
   },
   {
    "source": 155,
    "target": 374,
    "weight": 1
   },
   {
    "source": 45,
    "target": 96,
    "weight": 1
   },
   {
    "source": 225,
    "target": 510,
    "weight": 1
   },
   {
    "source": 64,
    "target": 510,
    "weight": 1
   },
   {
    "source": 64,
    "target": 511,
    "weight": 1
   },
   {
    "source": 155,
    "target": 225,
    "weight": 1
   },
   {
    "source": 6,
    "target": 512,
    "weight": 1
   },
   {
    "source": 5,
    "target": 512,
    "weight": 1
   },
   {
    "source": 5,
    "target": 513,
    "weight": 1
   },
   {
    "source": 513,
    "target": 514,
    "weight": 1
   },
   {
    "source": 317,
    "target": 514,
    "weight": 1
   },
   {
    "source": 204,
    "target": 317,
    "weight": 1
   },
   {
    "source": 36,
    "target": 204,
    "weight": 1
   },
   {
    "source": 34,
    "target": 36,
    "weight": 1
   },
   {
    "source": 3,
    "target": 511,
    "weight": 1
   },
   {
    "source": 30,
    "target": 515,
    "weight": 1
   },
   {
    "source": 172,
    "target": 515,
    "weight": 2
   },
   {
    "source": 9,
    "target": 172,
    "weight": 1
   },
   {
    "source": 11,
    "target": 114,
    "weight": 1
   },
   {
    "source": 114,
    "target": 287,
    "weight": 2
   },
   {
    "source": 30,
    "target": 287,
    "weight": 1
   },
   {
    "source": 30,
    "target": 271,
    "weight": 1
   },
   {
    "source": 271,
    "target": 516,
    "weight": 1
   },
   {
    "source": 34,
    "target": 516,
    "weight": 1
   },
   {
    "source": 30,
    "target": 34,
    "weight": 7
   },
   {
    "source": 115,
    "target": 300,
    "weight": 1
   },
   {
    "source": 114,
    "target": 275,
    "weight": 1
   },
   {
    "source": 34,
    "target": 300,
    "weight": 1
   },
   {
    "source": 34,
    "target": 517,
    "weight": 2
   },
   {
    "source": 464,
    "target": 517,
    "weight": 1
   },
   {
    "source": 43,
    "target": 464,
    "weight": 1
   },
   {
    "source": 38,
    "target": 275,
    "weight": 1
   },
   {
    "source": 34,
    "target": 287,
    "weight": 2
   },
   {
    "source": 56,
    "target": 518,
    "weight": 1
   },
   {
    "source": 40,
    "target": 518,
    "weight": 1
   },
   {
    "source": 137,
    "target": 210,
    "weight": 1
   },
   {
    "source": 2,
    "target": 518,
    "weight": 2
   },
   {
    "source": 137,
    "target": 518,
    "weight": 1
   },
   {
    "source": 40,
    "target": 137,
    "weight": 10
   },
   {
    "source": 38,
    "target": 287,
    "weight": 3
   },
   {
    "source": 519,
    "target": 520,
    "weight": 1
   },
   {
    "source": 40,
    "target": 520,
    "weight": 1
   },
   {
    "source": 137,
    "target": 521,
    "weight": 2
   },
   {
    "source": 2,
    "target": 521,
    "weight": 1
   },
   {
    "source": 2,
    "target": 522,
    "weight": 1
   },
   {
    "source": 522,
    "target": 523,
    "weight": 2
   },
   {
    "source": 66,
    "target": 523,
    "weight": 2
   },
   {
    "source": 66,
    "target": 524,
    "weight": 1
   },
   {
    "source": 40,
    "target": 524,
    "weight": 1
   },
   {
    "source": 40,
    "target": 525,
    "weight": 1
   },
   {
    "source": 525,
    "target": 526,
    "weight": 2
   },
   {
    "source": 526,
    "target": 527,
    "weight": 1
   },
   {
    "source": 527,
    "target": 528,
    "weight": 1
   },
   {
    "source": 528,
    "target": 529,
    "weight": 1
   },
   {
    "source": 529,
    "target": 530,
    "weight": 1
   },
   {
    "source": 530,
    "target": 531,
    "weight": 1
   },
   {
    "source": 531,
    "target": 532,
    "weight": 1
   },
   {
    "source": 532,
    "target": 533,
    "weight": 2
   },
   {
    "source": 533,
    "target": 534,
    "weight": 1
   },
   {
    "source": 534,
    "target": 535,
    "weight": 1
   },
   {
    "source": 535,
    "target": 536,
    "weight": 1
   },
   {
    "source": 536,
    "target": 537,
    "weight": 2
   },
   {
    "source": 537,
    "target": 538,
    "weight": 2
   },
   {
    "source": 538,
    "target": 539,
    "weight": 1
   },
   {
    "source": 40,
    "target": 539,
    "weight": 4
   },
   {
    "source": 40,
    "target": 139,
    "weight": 3
   },
   {
    "source": 139,
    "target": 540,
    "weight": 1
   },
   {
    "source": 40,
    "target": 540,
    "weight": 1
   },
   {
    "source": 40,
    "target": 541,
    "weight": 1
   },
   {
    "source": 541,
    "target": 542,
    "weight": 1
   },
   {
    "source": 542,
    "target": 543,
    "weight": 2
   },
   {
    "source": 543,
    "target": 544,
    "weight": 1
   },
   {
    "source": 544,
    "target": 545,
    "weight": 2
   },
   {
    "source": 545,
    "target": 546,
    "weight": 1
   },
   {
    "source": 546,
    "target": 547,
    "weight": 1
   },
   {
    "source": 547,
    "target": 548,
    "weight": 2
   },
   {
    "source": 548,
    "target": 549,
    "weight": 1
   },
   {
    "source": 549,
    "target": 550,
    "weight": 2
   },
   {
    "source": 550,
    "target": 551,
    "weight": 1
   },
   {
    "source": 551,
    "target": 552,
    "weight": 1
   },
   {
    "source": 552,
    "target": 553,
    "weight": 2
   },
   {
    "source": 62,
    "target": 553,
    "weight": 1
   },
   {
    "source": 62,
    "target": 554,
    "weight": 1
   },
   {
    "source": 554,
    "target": 555,
    "weight": 1
   },
   {
    "source": 555,
    "target": 556,
    "weight": 2
   },
   {
    "source": 62,
    "target": 556,
    "weight": 1
   },
   {
    "source": 62,
    "target": 72,
    "weight": 1
   },
   {
    "source": 72,
    "target": 557,
    "weight": 1
   },
   {
    "source": 557,
    "target": 558,
    "weight": 1
   },
   {
    "source": 558,
    "target": 559,
    "weight": 1
   },
   {
    "source": 188,
    "target": 559,
    "weight": 1
   },
   {
    "source": 72,
    "target": 188,
    "weight": 1
   },
   {
    "source": 137,
    "target": 560,
    "weight": 1
   },
   {
    "source": 560,
    "target": 561,
    "weight": 1
   },
   {
    "source": 561,
    "target": 562,
    "weight": 1
   },
   {
    "source": 137,
    "target": 562,
    "weight": 1
   },
   {
    "source": 137,
    "target": 563,
    "weight": 1
   },
   {
    "source": 558,
    "target": 563,
    "weight": 3
   },
   {
    "source": 558,
    "target": 564,
    "weight": 2
   },
   {
    "source": 564,
    "target": 565,
    "weight": 1
   },
   {
    "source": 2,
    "target": 188,
    "weight": 2
   },
   {
    "source": 137,
    "target": 188,
    "weight": 2
   },
   {
    "source": 72,
    "target": 137,
    "weight": 1
   },
   {
    "source": 137,
    "target": 561,
    "weight": 1
   },
   {
    "source": 211,
    "target": 519,
    "weight": 1
   },
   {
    "source": 2,
    "target": 155,
    "weight": 1
   },
   {
    "source": 34,
    "target": 155,
    "weight": 1
   },
   {
    "source": 287,
    "target": 566,
    "weight": 2
   },
   {
    "source": 73,
    "target": 566,
    "weight": 2
   },
   {
    "source": 73,
    "target": 152,
    "weight": 2
   },
   {
    "source": 137,
    "target": 152,
    "weight": 1
   },
   {
    "source": 0,
    "target": 565,
    "weight": 1
   },
   {
    "source": 2,
    "target": 567,
    "weight": 1
   },
   {
    "source": 2,
    "target": 430,
    "weight": 1
   },
   {
    "source": 430,
    "target": 568,
    "weight": 1
   },
   {
    "source": 568,
    "target": 569,
    "weight": 1
   },
   {
    "source": 220,
    "target": 569,
    "weight": 1
   },
   {
    "source": 40,
    "target": 220,
    "weight": 4
   },
   {
    "source": 137,
    "target": 567,
    "weight": 1
   },
   {
    "source": 155,
    "target": 521,
    "weight": 1
   },
   {
    "source": 155,
    "target": 570,
    "weight": 1
   },
   {
    "source": 139,
    "target": 570,
    "weight": 1
   },
   {
    "source": 40,
    "target": 521,
    "weight": 2
   },
   {
    "source": 2,
    "target": 571,
    "weight": 1
   },
   {
    "source": 139,
    "target": 571,
    "weight": 1
   },
   {
    "source": 139,
    "target": 187,
    "weight": 1
   },
   {
    "source": 187,
    "target": 423,
    "weight": 1
   },
   {
    "source": 56,
    "target": 423,
    "weight": 1
   },
   {
    "source": 56,
    "target": 130,
    "weight": 1
   },
   {
    "source": 38,
    "target": 572,
    "weight": 1
   },
   {
    "source": 572,
    "target": 573,
    "weight": 1
   },
   {
    "source": 188,
    "target": 573,
    "weight": 1
   },
   {
    "source": 137,
    "target": 523,
    "weight": 9
   },
   {
    "source": 523,
    "target": 539,
    "weight": 3
   },
   {
    "source": 62,
    "target": 539,
    "weight": 2
   },
   {
    "source": 38,
    "target": 130,
    "weight": 1
   },
   {
    "source": 519,
    "target": 574,
    "weight": 1
   },
   {
    "source": 522,
    "target": 574,
    "weight": 1
   },
   {
    "source": 62,
    "target": 519,
    "weight": 1
   },
   {
    "source": 385,
    "target": 523,
    "weight": 1
   },
   {
    "source": 137,
    "target": 385,
    "weight": 2
   },
   {
    "source": 137,
    "target": 203,
    "weight": 1
   },
   {
    "source": 2,
    "target": 203,
    "weight": 3
   },
   {
    "source": 2,
    "target": 192,
    "weight": 3
   },
   {
    "source": 192,
    "target": 575,
    "weight": 1
   },
   {
    "source": 575,
    "target": 576,
    "weight": 1
   },
   {
    "source": 192,
    "target": 576,
    "weight": 1
   },
   {
    "source": 116,
    "target": 192,
    "weight": 1
   },
   {
    "source": 116,
    "target": 577,
    "weight": 1
   },
   {
    "source": 46,
    "target": 577,
    "weight": 1
   },
   {
    "source": 46,
    "target": 72,
    "weight": 2
   },
   {
    "source": 40,
    "target": 72,
    "weight": 5
   },
   {
    "source": 40,
    "target": 350,
    "weight": 3
   },
   {
    "source": 40,
    "target": 46,
    "weight": 21
   },
   {
    "source": 46,
    "target": 578,
    "weight": 1
   },
   {
    "source": 578,
    "target": 579,
    "weight": 3
   },
   {
    "source": 34,
    "target": 579,
    "weight": 1
   },
   {
    "source": 34,
    "target": 580,
    "weight": 1
   },
   {
    "source": 580,
    "target": 581,
    "weight": 1
   },
   {
    "source": 137,
    "target": 582,
    "weight": 1
   },
   {
    "source": 267,
    "target": 582,
    "weight": 1
   },
   {
    "source": 267,
    "target": 583,
    "weight": 1
   },
   {
    "source": 40,
    "target": 583,
    "weight": 1
   },
   {
    "source": 40,
    "target": 254,
    "weight": 3
   },
   {
    "source": 73,
    "target": 254,
    "weight": 1
   },
   {
    "source": 73,
    "target": 87,
    "weight": 3
   },
   {
    "source": 87,
    "target": 584,
    "weight": 1
   },
   {
    "source": 248,
    "target": 584,
    "weight": 1
   },
   {
    "source": 192,
    "target": 248,
    "weight": 1
   },
   {
    "source": 66,
    "target": 581,
    "weight": 1
   },
   {
    "source": 150,
    "target": 585,
    "weight": 1
   },
   {
    "source": 137,
    "target": 150,
    "weight": 1
   },
   {
    "source": 137,
    "target": 192,
    "weight": 1
   },
   {
    "source": 46,
    "target": 192,
    "weight": 7
   },
   {
    "source": 46,
    "target": 586,
    "weight": 1
   },
   {
    "source": 586,
    "target": 587,
    "weight": 1
   },
   {
    "source": 110,
    "target": 587,
    "weight": 1
   },
   {
    "source": 40,
    "target": 150,
    "weight": 1
   },
   {
    "source": 150,
    "target": 588,
    "weight": 1
   },
   {
    "source": 69,
    "target": 588,
    "weight": 1
   },
   {
    "source": 69,
    "target": 589,
    "weight": 1
   },
   {
    "source": 47,
    "target": 589,
    "weight": 2
   },
   {
    "source": 47,
    "target": 137,
    "weight": 4
   },
   {
    "source": 137,
    "target": 590,
    "weight": 1
   },
   {
    "source": 590,
    "target": 591,
    "weight": 3
   },
   {
    "source": 110,
    "target": 586,
    "weight": 1
   },
   {
    "source": 192,
    "target": 585,
    "weight": 1
   },
   {
    "source": 52,
    "target": 592,
    "weight": 1
   },
   {
    "source": 52,
    "target": 593,
    "weight": 1
   },
   {
    "source": 523,
    "target": 593,
    "weight": 1
   },
   {
    "source": 137,
    "target": 594,
    "weight": 1
   },
   {
    "source": 594,
    "target": 595,
    "weight": 2
   },
   {
    "source": 2,
    "target": 595,
    "weight": 2
   },
   {
    "source": 2,
    "target": 596,
    "weight": 5
   },
   {
    "source": 596,
    "target": 597,
    "weight": 2
   },
   {
    "source": 592,
    "target": 593,
    "weight": 1
   },
   {
    "source": 591,
    "target": 592,
    "weight": 1
   },
   {
    "source": 203,
    "target": 576,
    "weight": 1
   },
   {
    "source": 576,
    "target": 598,
    "weight": 1
   },
   {
    "source": 575,
    "target": 598,
    "weight": 1
   },
   {
    "source": 575,
    "target": 599,
    "weight": 1
   },
   {
    "source": 26,
    "target": 599,
    "weight": 1
   },
   {
    "source": 26,
    "target": 62,
    "weight": 1
   },
   {
    "source": 40,
    "target": 62,
    "weight": 8
   },
   {
    "source": 40,
    "target": 596,
    "weight": 1
   },
   {
    "source": 596,
    "target": 600,
    "weight": 3
   },
   {
    "source": 95,
    "target": 600,
    "weight": 1
   },
   {
    "source": 87,
    "target": 95,
    "weight": 1
   },
   {
    "source": 87,
    "target": 192,
    "weight": 1
   },
   {
    "source": 62,
    "target": 192,
    "weight": 1
   },
   {
    "source": 598,
    "target": 599,
    "weight": 1
   },
   {
    "source": 594,
    "target": 597,
    "weight": 1
   },
   {
    "source": 600,
    "target": 601,
    "weight": 1
   },
   {
    "source": 357,
    "target": 601,
    "weight": 1
   },
   {
    "source": 357,
    "target": 600,
    "weight": 1
   },
   {
    "source": 161,
    "target": 600,
    "weight": 1
   },
   {
    "source": 46,
    "target": 161,
    "weight": 4
   },
   {
    "source": 46,
    "target": 602,
    "weight": 5
   },
   {
    "source": 602,
    "target": 603,
    "weight": 1
   },
   {
    "source": 141,
    "target": 603,
    "weight": 1
   },
   {
    "source": 161,
    "target": 602,
    "weight": 1
   },
   {
    "source": 62,
    "target": 596,
    "weight": 2
   },
   {
    "source": 523,
    "target": 604,
    "weight": 1
   },
   {
    "source": 137,
    "target": 596,
    "weight": 2
   },
   {
    "source": 582,
    "target": 597,
    "weight": 1
   },
   {
    "source": 582,
    "target": 605,
    "weight": 1
   },
   {
    "source": 58,
    "target": 605,
    "weight": 1
   },
   {
    "source": 58,
    "target": 161,
    "weight": 1
   },
   {
    "source": 161,
    "target": 606,
    "weight": 1
   },
   {
    "source": 40,
    "target": 606,
    "weight": 2
   },
   {
    "source": 46,
    "target": 521,
    "weight": 1
   },
   {
    "source": 46,
    "target": 607,
    "weight": 3
   },
   {
    "source": 161,
    "target": 607,
    "weight": 1
   },
   {
    "source": 68,
    "target": 161,
    "weight": 1
   },
   {
    "source": 137,
    "target": 604,
    "weight": 1
   },
   {
    "source": 141,
    "target": 604,
    "weight": 2
   },
   {
    "source": 300,
    "target": 582,
    "weight": 1
   },
   {
    "source": 300,
    "target": 607,
    "weight": 2
   },
   {
    "source": 46,
    "target": 606,
    "weight": 1
   },
   {
    "source": 192,
    "target": 606,
    "weight": 1
   },
   {
    "source": 192,
    "target": 608,
    "weight": 1
   },
   {
    "source": 608,
    "target": 609,
    "weight": 1
   },
   {
    "source": 68,
    "target": 582,
    "weight": 3
   },
   {
    "source": 317,
    "target": 596,
    "weight": 1
   },
   {
    "source": 582,
    "target": 600,
    "weight": 1
   },
   {
    "source": 11,
    "target": 582,
    "weight": 1
   },
   {
    "source": 11,
    "target": 69,
    "weight": 1
   },
   {
    "source": 69,
    "target": 606,
    "weight": 1
   },
   {
    "source": 265,
    "target": 606,
    "weight": 2
   },
   {
    "source": 265,
    "target": 610,
    "weight": 1
   },
   {
    "source": 317,
    "target": 609,
    "weight": 2
   },
   {
    "source": 6,
    "target": 87,
    "weight": 1
   },
   {
    "source": 87,
    "target": 494,
    "weight": 1
   },
   {
    "source": 40,
    "target": 494,
    "weight": 2
   },
   {
    "source": 40,
    "target": 611,
    "weight": 1
   },
   {
    "source": 606,
    "target": 611,
    "weight": 1
   },
   {
    "source": 606,
    "target": 612,
    "weight": 1
   },
   {
    "source": 46,
    "target": 612,
    "weight": 1
   },
   {
    "source": 46,
    "target": 69,
    "weight": 1
   },
   {
    "source": 3,
    "target": 610,
    "weight": 1
   },
   {
    "source": 129,
    "target": 523,
    "weight": 1
   },
   {
    "source": 137,
    "target": 534,
    "weight": 1
   },
   {
    "source": 534,
    "target": 613,
    "weight": 1
   },
   {
    "source": 613,
    "target": 614,
    "weight": 2
   },
   {
    "source": 300,
    "target": 614,
    "weight": 1
   },
   {
    "source": 46,
    "target": 300,
    "weight": 3
   },
   {
    "source": 69,
    "target": 129,
    "weight": 1
   },
   {
    "source": 413,
    "target": 615,
    "weight": 1
   },
   {
    "source": 413,
    "target": 616,
    "weight": 1
   },
   {
    "source": 616,
    "target": 617,
    "weight": 1
   },
   {
    "source": 300,
    "target": 617,
    "weight": 1
   },
   {
    "source": 300,
    "target": 618,
    "weight": 1
   },
   {
    "source": 618,
    "target": 619,
    "weight": 6
   },
   {
    "source": 619,
    "target": 620,
    "weight": 3
   },
   {
    "source": 46,
    "target": 620,
    "weight": 1
   },
   {
    "source": 46,
    "target": 203,
    "weight": 1
   },
   {
    "source": 203,
    "target": 621,
    "weight": 1
   },
   {
    "source": 46,
    "target": 615,
    "weight": 1
   },
   {
    "source": 589,
    "target": 617,
    "weight": 1
   },
   {
    "source": 137,
    "target": 589,
    "weight": 1
   },
   {
    "source": 46,
    "target": 137,
    "weight": 2
   },
   {
    "source": 46,
    "target": 193,
    "weight": 5
   },
   {
    "source": 193,
    "target": 622,
    "weight": 1
   },
   {
    "source": 5,
    "target": 622,
    "weight": 1
   },
   {
    "source": 5,
    "target": 623,
    "weight": 2
   },
   {
    "source": 46,
    "target": 623,
    "weight": 5
   },
   {
    "source": 46,
    "target": 624,
    "weight": 2
   },
   {
    "source": 617,
    "target": 621,
    "weight": 1
   },
   {
    "source": 40,
    "target": 625,
    "weight": 1
   },
   {
    "source": 40,
    "target": 603,
    "weight": 1
   },
   {
    "source": 599,
    "target": 603,
    "weight": 1
   },
   {
    "source": 46,
    "target": 599,
    "weight": 2
   },
   {
    "source": 46,
    "target": 626,
    "weight": 1
   },
   {
    "source": 626,
    "target": 627,
    "weight": 1
   },
   {
    "source": 141,
    "target": 627,
    "weight": 1
   },
   {
    "source": 46,
    "target": 625,
    "weight": 1
   },
   {
    "source": 192,
    "target": 625,
    "weight": 1
   },
   {
    "source": 192,
    "target": 622,
    "weight": 1
   },
   {
    "source": 46,
    "target": 622,
    "weight": 1
   },
   {
    "source": 46,
    "target": 617,
    "weight": 2
   },
   {
    "source": 3,
    "target": 617,
    "weight": 1
   },
   {
    "source": 3,
    "target": 628,
    "weight": 1
   },
   {
    "source": 628,
    "target": 629,
    "weight": 1
   },
   {
    "source": 595,
    "target": 629,
    "weight": 2
   },
   {
    "source": 499,
    "target": 595,
    "weight": 2
   },
   {
    "source": 499,
    "target": 610,
    "weight": 1
   },
   {
    "source": 46,
    "target": 610,
    "weight": 1
   },
   {
    "source": 617,
    "target": 630,
    "weight": 1
   },
   {
    "source": 630,
    "target": 631,
    "weight": 1
   },
   {
    "source": 631,
    "target": 632,
    "weight": 1
   },
   {
    "source": 632,
    "target": 633,
    "weight": 1
   },
   {
    "source": 633,
    "target": 634,
    "weight": 1
   },
   {
    "source": 110,
    "target": 634,
    "weight": 1
   },
   {
    "source": 499,
    "target": 629,
    "weight": 1
   },
   {
    "source": 141,
    "target": 625,
    "weight": 1
   },
   {
    "source": 616,
    "target": 635,
    "weight": 1
   },
   {
    "source": 615,
    "target": 616,
    "weight": 1
   },
   {
    "source": 192,
    "target": 615,
    "weight": 1
   },
   {
    "source": 46,
    "target": 636,
    "weight": 1
   },
   {
    "source": 40,
    "target": 636,
    "weight": 2
   },
   {
    "source": 110,
    "target": 635,
    "weight": 1
   },
   {
    "source": 137,
    "target": 637,
    "weight": 1
   },
   {
    "source": 137,
    "target": 617,
    "weight": 1
   },
   {
    "source": 521,
    "target": 617,
    "weight": 1
   },
   {
    "source": 300,
    "target": 521,
    "weight": 1
   },
   {
    "source": 46,
    "target": 58,
    "weight": 1
   },
   {
    "source": 40,
    "target": 58,
    "weight": 2
   },
   {
    "source": 40,
    "target": 638,
    "weight": 2
   },
   {
    "source": 606,
    "target": 638,
    "weight": 1
   },
   {
    "source": 40,
    "target": 637,
    "weight": 1
   },
   {
    "source": 73,
    "target": 639,
    "weight": 1
   },
   {
    "source": 25,
    "target": 73,
    "weight": 2
   },
   {
    "source": 25,
    "target": 137,
    "weight": 1
   },
   {
    "source": 137,
    "target": 640,
    "weight": 1
   },
   {
    "source": 640,
    "target": 641,
    "weight": 1
   },
   {
    "source": 155,
    "target": 641,
    "weight": 1
   },
   {
    "source": 606,
    "target": 639,
    "weight": 1
   },
   {
    "source": 137,
    "target": 642,
    "weight": 1
   },
   {
    "source": 137,
    "target": 606,
    "weight": 1
   },
   {
    "source": 265,
    "target": 597,
    "weight": 1
   },
   {
    "source": 87,
    "target": 597,
    "weight": 1
   },
   {
    "source": 87,
    "target": 582,
    "weight": 1
   },
   {
    "source": 155,
    "target": 642,
    "weight": 1
   },
   {
    "source": 137,
    "target": 381,
    "weight": 2
   },
   {
    "source": 137,
    "target": 643,
    "weight": 1
   },
   {
    "source": 30,
    "target": 643,
    "weight": 1
   },
   {
    "source": 30,
    "target": 596,
    "weight": 1
   },
   {
    "source": 62,
    "target": 595,
    "weight": 1
   },
   {
    "source": 595,
    "target": 602,
    "weight": 3
   },
   {
    "source": 269,
    "target": 602,
    "weight": 1
   },
   {
    "source": 269,
    "target": 644,
    "weight": 1
   },
   {
    "source": 300,
    "target": 644,
    "weight": 1
   },
   {
    "source": 68,
    "target": 381,
    "weight": 1
   },
   {
    "source": 137,
    "target": 645,
    "weight": 1
   },
   {
    "source": 40,
    "target": 645,
    "weight": 3
   },
   {
    "source": 28,
    "target": 58,
    "weight": 2
   },
   {
    "source": 28,
    "target": 40,
    "weight": 2
   },
   {
    "source": 40,
    "target": 193,
    "weight": 2
   },
   {
    "source": 193,
    "target": 494,
    "weight": 1
   },
   {
    "source": 137,
    "target": 494,
    "weight": 1
   },
   {
    "source": 65,
    "target": 137,
    "weight": 1
   },
   {
    "source": 65,
    "target": 81,
    "weight": 2
   },
   {
    "source": 81,
    "target": 200,
    "weight": 1
   },
   {
    "source": 115,
    "target": 200,
    "weight": 1
   },
   {
    "source": 192,
    "target": 539,
    "weight": 2
   },
   {
    "source": 156,
    "target": 646,
    "weight": 1
   },
   {
    "source": 156,
    "target": 647,
    "weight": 1
   },
   {
    "source": 596,
    "target": 647,
    "weight": 1
   },
   {
    "source": 596,
    "target": 648,
    "weight": 14
   },
   {
    "source": 35,
    "target": 648,
    "weight": 1
   },
   {
    "source": 35,
    "target": 49,
    "weight": 1
   },
   {
    "source": 49,
    "target": 649,
    "weight": 1
   },
   {
    "source": 46,
    "target": 649,
    "weight": 1
   },
   {
    "source": 46,
    "target": 650,
    "weight": 4
   },
   {
    "source": 166,
    "target": 650,
    "weight": 1
   },
   {
    "source": 166,
    "target": 539,
    "weight": 2
   },
   {
    "source": 166,
    "target": 651,
    "weight": 1
   },
   {
    "source": 46,
    "target": 651,
    "weight": 1
   },
   {
    "source": 115,
    "target": 646,
    "weight": 1
   },
   {
    "source": 3,
    "target": 648,
    "weight": 1
   },
   {
    "source": 3,
    "target": 652,
    "weight": 1
   },
   {
    "source": 217,
    "target": 652,
    "weight": 1
   },
   {
    "source": 46,
    "target": 217,
    "weight": 1
   },
   {
    "source": 46,
    "target": 595,
    "weight": 1
   },
   {
    "source": 602,
    "target": 653,
    "weight": 1
   },
   {
    "source": 653,
    "target": 654,
    "weight": 1
   },
   {
    "source": 599,
    "target": 654,
    "weight": 1
   },
   {
    "source": 596,
    "target": 599,
    "weight": 1
   },
   {
    "source": 46,
    "target": 648,
    "weight": 2
   },
   {
    "source": 350,
    "target": 541,
    "weight": 1
   },
   {
    "source": 539,
    "target": 541,
    "weight": 1
   },
   {
    "source": 137,
    "target": 539,
    "weight": 7
   },
   {
    "source": 46,
    "target": 655,
    "weight": 2
   },
   {
    "source": 655,
    "target": 656,
    "weight": 3
   },
   {
    "source": 562,
    "target": 656,
    "weight": 2
   },
   {
    "source": 46,
    "target": 656,
    "weight": 4
   },
   {
    "source": 350,
    "target": 648,
    "weight": 1
   },
   {
    "source": 2,
    "target": 657,
    "weight": 1
   },
   {
    "source": 46,
    "target": 657,
    "weight": 9
   },
   {
    "source": 46,
    "target": 658,
    "weight": 4
   },
   {
    "source": 40,
    "target": 658,
    "weight": 2
   },
   {
    "source": 40,
    "target": 623,
    "weight": 6
   },
   {
    "source": 623,
    "target": 659,
    "weight": 2
   },
   {
    "source": 40,
    "target": 659,
    "weight": 2
   },
   {
    "source": 40,
    "target": 523,
    "weight": 5
   },
   {
    "source": 0,
    "target": 562,
    "weight": 1
   },
   {
    "source": 656,
    "target": 660,
    "weight": 1
   },
   {
    "source": 59,
    "target": 660,
    "weight": 3
   },
   {
    "source": 59,
    "target": 661,
    "weight": 2
   },
   {
    "source": 172,
    "target": 661,
    "weight": 4
   },
   {
    "source": 172,
    "target": 662,
    "weight": 1
   },
   {
    "source": 110,
    "target": 662,
    "weight": 1
   },
   {
    "source": 137,
    "target": 656,
    "weight": 1
   },
   {
    "source": 34,
    "target": 539,
    "weight": 1
   },
   {
    "source": 34,
    "target": 90,
    "weight": 1
   },
   {
    "source": 40,
    "target": 90,
    "weight": 2
   },
   {
    "source": 26,
    "target": 606,
    "weight": 1
   },
   {
    "source": 26,
    "target": 46,
    "weight": 5
   },
   {
    "source": 254,
    "target": 602,
    "weight": 1
   },
   {
    "source": 254,
    "target": 663,
    "weight": 1
   },
   {
    "source": 90,
    "target": 663,
    "weight": 1
   },
   {
    "source": 90,
    "target": 606,
    "weight": 1
   },
   {
    "source": 110,
    "target": 606,
    "weight": 1
   },
   {
    "source": 46,
    "target": 186,
    "weight": 1
   },
   {
    "source": 40,
    "target": 186,
    "weight": 2
   },
   {
    "source": 40,
    "target": 664,
    "weight": 1
   },
   {
    "source": 267,
    "target": 664,
    "weight": 1
   },
   {
    "source": 267,
    "target": 602,
    "weight": 1
   },
   {
    "source": 596,
    "target": 602,
    "weight": 1
   },
   {
    "source": 40,
    "target": 653,
    "weight": 1
   },
   {
    "source": 110,
    "target": 539,
    "weight": 1
   },
   {
    "source": 129,
    "target": 665,
    "weight": 1
   },
   {
    "source": 40,
    "target": 129,
    "weight": 2
   },
   {
    "source": 578,
    "target": 648,
    "weight": 1
   },
   {
    "source": 579,
    "target": 666,
    "weight": 1
   },
   {
    "source": 666,
    "target": 667,
    "weight": 1
   },
   {
    "source": 667,
    "target": 668,
    "weight": 1
   },
   {
    "source": 653,
    "target": 665,
    "weight": 1
   },
   {
    "source": 58,
    "target": 539,
    "weight": 2
   },
   {
    "source": 4,
    "target": 137,
    "weight": 1
   },
   {
    "source": 182,
    "target": 669,
    "weight": 1
   },
   {
    "source": 669,
    "target": 670,
    "weight": 1
   },
   {
    "source": 670,
    "target": 671,
    "weight": 1
   },
   {
    "source": 8,
    "target": 671,
    "weight": 1
   },
   {
    "source": 8,
    "target": 289,
    "weight": 1
   },
   {
    "source": 58,
    "target": 137,
    "weight": 1
   },
   {
    "source": 58,
    "target": 668,
    "weight": 1
   },
   {
    "source": 9,
    "target": 69,
    "weight": 1
   },
   {
    "source": 69,
    "target": 672,
    "weight": 1
   },
   {
    "source": 59,
    "target": 672,
    "weight": 1
   },
   {
    "source": 59,
    "target": 673,
    "weight": 1
   },
   {
    "source": 72,
    "target": 673,
    "weight": 1
   },
   {
    "source": 62,
    "target": 448,
    "weight": 1
   },
   {
    "source": 62,
    "target": 137,
    "weight": 9
   },
   {
    "source": 137,
    "target": 193,
    "weight": 1
   },
   {
    "source": 45,
    "target": 193,
    "weight": 1
   },
   {
    "source": 45,
    "target": 650,
    "weight": 3
   },
   {
    "source": 650,
    "target": 674,
    "weight": 1
   },
   {
    "source": 615,
    "target": 674,
    "weight": 1
   },
   {
    "source": 34,
    "target": 69,
    "weight": 1
   },
   {
    "source": 2,
    "target": 673,
    "weight": 1
   },
   {
    "source": 45,
    "target": 674,
    "weight": 1
   },
   {
    "source": 30,
    "target": 289,
    "weight": 1
   },
   {
    "source": 213,
    "target": 675,
    "weight": 1
   },
   {
    "source": 675,
    "target": 676,
    "weight": 1
   },
   {
    "source": 676,
    "target": 677,
    "weight": 1
   },
   {
    "source": 650,
    "target": 677,
    "weight": 2
   },
   {
    "source": 213,
    "target": 615,
    "weight": 1
   },
   {
    "source": 677,
    "target": 678,
    "weight": 1
   },
   {
    "source": 287,
    "target": 678,
    "weight": 1
   },
   {
    "source": 287,
    "target": 679,
    "weight": 2
   },
   {
    "source": 62,
    "target": 679,
    "weight": 1
   },
   {
    "source": 28,
    "target": 62,
    "weight": 1
   },
   {
    "source": 28,
    "target": 680,
    "weight": 1
   },
   {
    "source": 648,
    "target": 680,
    "weight": 2
   },
   {
    "source": 28,
    "target": 648,
    "weight": 1
   },
   {
    "source": 521,
    "target": 681,
    "weight": 1
   },
   {
    "source": 408,
    "target": 521,
    "weight": 1
   },
   {
    "source": 408,
    "target": 682,
    "weight": 1
   },
   {
    "source": 682,
    "target": 683,
    "weight": 1
   },
   {
    "source": 256,
    "target": 683,
    "weight": 1
   },
   {
    "source": 256,
    "target": 676,
    "weight": 1
   },
   {
    "source": 648,
    "target": 676,
    "weight": 1
   },
   {
    "source": 104,
    "target": 648,
    "weight": 1
   },
   {
    "source": 104,
    "target": 148,
    "weight": 1
   },
   {
    "source": 148,
    "target": 152,
    "weight": 1
   },
   {
    "source": 152,
    "target": 650,
    "weight": 1
   },
   {
    "source": 648,
    "target": 650,
    "weight": 2
   },
   {
    "source": 648,
    "target": 681,
    "weight": 1
   },
   {
    "source": 539,
    "target": 684,
    "weight": 1
   },
   {
    "source": 2,
    "target": 139,
    "weight": 1
   },
   {
    "source": 139,
    "target": 596,
    "weight": 1
   },
   {
    "source": 2,
    "target": 546,
    "weight": 1
   },
   {
    "source": 30,
    "target": 546,
    "weight": 1
   },
   {
    "source": 34,
    "target": 685,
    "weight": 1
   },
   {
    "source": 685,
    "target": 686,
    "weight": 1
   },
   {
    "source": 137,
    "target": 684,
    "weight": 1
   },
   {
    "source": 648,
    "target": 684,
    "weight": 1
   },
   {
    "source": 35,
    "target": 546,
    "weight": 1
   },
   {
    "source": 35,
    "target": 494,
    "weight": 1
   },
   {
    "source": 356,
    "target": 494,
    "weight": 1
   },
   {
    "source": 356,
    "target": 687,
    "weight": 1
   },
   {
    "source": 687,
    "target": 688,
    "weight": 1
   },
   {
    "source": 596,
    "target": 688,
    "weight": 1
   },
   {
    "source": 648,
    "target": 656,
    "weight": 1
   },
   {
    "source": 656,
    "target": 689,
    "weight": 1
   },
   {
    "source": 346,
    "target": 689,
    "weight": 1
   },
   {
    "source": 46,
    "target": 346,
    "weight": 1
   },
   {
    "source": 46,
    "target": 690,
    "weight": 1
   },
   {
    "source": 40,
    "target": 690,
    "weight": 2
   },
   {
    "source": 40,
    "target": 580,
    "weight": 2
   },
   {
    "source": 68,
    "target": 580,
    "weight": 1
   },
   {
    "source": 68,
    "target": 691,
    "weight": 1
   },
   {
    "source": 691,
    "target": 692,
    "weight": 2
   },
   {
    "source": 562,
    "target": 692,
    "weight": 1
   },
   {
    "source": 562,
    "target": 689,
    "weight": 1
   },
   {
    "source": 156,
    "target": 689,
    "weight": 1
   },
   {
    "source": 156,
    "target": 690,
    "weight": 2
   },
   {
    "source": 546,
    "target": 686,
    "weight": 1
   },
   {
    "source": 656,
    "target": 693,
    "weight": 1
   },
   {
    "source": 478,
    "target": 693,
    "weight": 1
   },
   {
    "source": 478,
    "target": 694,
    "weight": 1
   },
   {
    "source": 694,
    "target": 695,
    "weight": 1
   },
   {
    "source": 29,
    "target": 695,
    "weight": 1
   },
   {
    "source": 2,
    "target": 29,
    "weight": 1
   },
   {
    "source": 46,
    "target": 653,
    "weight": 2
   },
   {
    "source": 648,
    "target": 653,
    "weight": 1
   },
   {
    "source": 693,
    "target": 694,
    "weight": 1
   },
   {
    "source": 156,
    "target": 656,
    "weight": 1
   },
   {
    "source": 523,
    "target": 696,
    "weight": 1
   },
   {
    "source": 137,
    "target": 546,
    "weight": 1
   },
   {
    "source": 546,
    "target": 610,
    "weight": 1
   },
   {
    "source": 65,
    "target": 610,
    "weight": 1
   },
   {
    "source": 65,
    "target": 627,
    "weight": 2
   },
   {
    "source": 596,
    "target": 627,
    "weight": 1
   },
   {
    "source": 47,
    "target": 596,
    "weight": 6
   },
   {
    "source": 47,
    "target": 597,
    "weight": 1
   },
   {
    "source": 597,
    "target": 697,
    "weight": 1
   },
   {
    "source": 697,
    "target": 698,
    "weight": 1
   },
   {
    "source": 698,
    "target": 699,
    "weight": 1
   },
   {
    "source": 576,
    "target": 699,
    "weight": 1
   },
   {
    "source": 576,
    "target": 700,
    "weight": 1
   },
   {
    "source": 40,
    "target": 700,
    "weight": 1
   },
   {
    "source": 648,
    "target": 696,
    "weight": 1
   },
   {
    "source": 546,
    "target": 596,
    "weight": 1
   },
   {
    "source": 494,
    "target": 648,
    "weight": 1
   },
   {
    "source": 40,
    "target": 546,
    "weight": 1
   },
   {
    "source": 427,
    "target": 546,
    "weight": 1
   },
   {
    "source": 523,
    "target": 546,
    "weight": 1
   },
   {
    "source": 137,
    "target": 701,
    "weight": 1
   },
   {
    "source": 300,
    "target": 701,
    "weight": 1
   },
   {
    "source": 596,
    "target": 653,
    "weight": 2
   },
   {
    "source": 636,
    "target": 648,
    "weight": 1
   },
   {
    "source": 40,
    "target": 702,
    "weight": 1
   },
   {
    "source": 596,
    "target": 702,
    "weight": 1
   },
   {
    "source": 648,
    "target": 649,
    "weight": 1
   },
   {
    "source": 648,
    "target": 702,
    "weight": 1
   },
   {
    "source": 40,
    "target": 427,
    "weight": 2
   },
   {
    "source": 546,
    "target": 703,
    "weight": 1
   },
   {
    "source": 546,
    "target": 649,
    "weight": 1
   },
   {
    "source": 6,
    "target": 46,
    "weight": 2
   },
   {
    "source": 46,
    "target": 251,
    "weight": 5
   },
   {
    "source": 192,
    "target": 251,
    "weight": 1
   },
   {
    "source": 192,
    "target": 653,
    "weight": 1
   },
   {
    "source": 59,
    "target": 653,
    "weight": 1
   },
   {
    "source": 648,
    "target": 661,
    "weight": 1
   },
   {
    "source": 596,
    "target": 704,
    "weight": 1
   },
   {
    "source": 39,
    "target": 704,
    "weight": 1
   },
   {
    "source": 39,
    "target": 605,
    "weight": 1
   },
   {
    "source": 605,
    "target": 648,
    "weight": 1
   },
   {
    "source": 3,
    "target": 703,
    "weight": 1
   },
   {
    "source": 106,
    "target": 137,
    "weight": 1
   },
   {
    "source": 106,
    "target": 150,
    "weight": 1
   },
   {
    "source": 3,
    "target": 150,
    "weight": 1
   },
   {
    "source": 3,
    "target": 192,
    "weight": 1
   },
   {
    "source": 46,
    "target": 220,
    "weight": 1
   },
   {
    "source": 220,
    "target": 705,
    "weight": 1
   },
   {
    "source": 161,
    "target": 705,
    "weight": 1
   },
   {
    "source": 161,
    "target": 706,
    "weight": 1
   },
   {
    "source": 46,
    "target": 706,
    "weight": 2
   },
   {
    "source": 602,
    "target": 707,
    "weight": 1
   },
   {
    "source": 54,
    "target": 707,
    "weight": 1
   },
   {
    "source": 54,
    "target": 192,
    "weight": 1
   },
   {
    "source": 539,
    "target": 648,
    "weight": 1
   },
   {
    "source": 5,
    "target": 137,
    "weight": 1
   },
   {
    "source": 5,
    "target": 69,
    "weight": 1
   },
   {
    "source": 69,
    "target": 203,
    "weight": 1
   },
   {
    "source": 203,
    "target": 708,
    "weight": 1
   },
   {
    "source": 261,
    "target": 708,
    "weight": 1
   },
   {
    "source": 261,
    "target": 638,
    "weight": 1
   },
   {
    "source": 27,
    "target": 638,
    "weight": 1
   },
   {
    "source": 11,
    "target": 27,
    "weight": 1
   },
   {
    "source": 7,
    "target": 11,
    "weight": 2
   },
   {
    "source": 8,
    "target": 709,
    "weight": 1
   },
   {
    "source": 709,
    "target": 710,
    "weight": 3
   },
   {
    "source": 124,
    "target": 710,
    "weight": 3
   },
   {
    "source": 124,
    "target": 711,
    "weight": 1
   },
   {
    "source": 5,
    "target": 203,
    "weight": 1
   },
   {
    "source": 5,
    "target": 708,
    "weight": 1
   },
   {
    "source": 69,
    "target": 708,
    "weight": 1
   },
   {
    "source": 11,
    "target": 638,
    "weight": 1
   },
   {
    "source": 46,
    "target": 712,
    "weight": 1
   },
   {
    "source": 251,
    "target": 596,
    "weight": 1
   },
   {
    "source": 227,
    "target": 648,
    "weight": 1
   },
   {
    "source": 40,
    "target": 227,
    "weight": 2
   },
   {
    "source": 40,
    "target": 219,
    "weight": 2
   },
   {
    "source": 40,
    "target": 457,
    "weight": 1
   },
   {
    "source": 457,
    "target": 515,
    "weight": 1
   },
   {
    "source": 494,
    "target": 515,
    "weight": 1
   },
   {
    "source": 711,
    "target": 712,
    "weight": 1
   },
   {
    "source": 34,
    "target": 635,
    "weight": 1
   },
   {
    "source": 596,
    "target": 635,
    "weight": 1
   },
   {
    "source": 546,
    "target": 648,
    "weight": 1
   },
   {
    "source": 69,
    "target": 546,
    "weight": 1
   },
   {
    "source": 69,
    "target": 713,
    "weight": 1
   },
   {
    "source": 713,
    "target": 714,
    "weight": 1
   },
   {
    "source": 714,
    "target": 715,
    "weight": 1
   },
   {
    "source": 539,
    "target": 715,
    "weight": 1
   },
   {
    "source": 539,
    "target": 653,
    "weight": 1
   },
   {
    "source": 34,
    "target": 494,
    "weight": 1
   },
   {
    "source": 61,
    "target": 712,
    "weight": 1
   },
   {
    "source": 653,
    "target": 712,
    "weight": 1
   },
   {
    "source": 394,
    "target": 648,
    "weight": 1
   },
   {
    "source": 117,
    "target": 394,
    "weight": 1
   },
   {
    "source": 117,
    "target": 596,
    "weight": 1
   },
   {
    "source": 61,
    "target": 653,
    "weight": 1
   },
   {
    "source": 62,
    "target": 716,
    "weight": 1
   },
   {
    "source": 695,
    "target": 716,
    "weight": 1
   },
   {
    "source": 40,
    "target": 695,
    "weight": 1
   },
   {
    "source": 34,
    "target": 717,
    "weight": 1
   },
   {
    "source": 645,
    "target": 717,
    "weight": 1
   },
   {
    "source": 40,
    "target": 718,
    "weight": 1
   },
   {
    "source": 72,
    "target": 718,
    "weight": 1
   },
   {
    "source": 46,
    "target": 503,
    "weight": 3
   },
   {
    "source": 503,
    "target": 635,
    "weight": 1
   },
   {
    "source": 494,
    "target": 635,
    "weight": 1
   },
   {
    "source": 494,
    "target": 596,
    "weight": 1
   },
   {
    "source": 47,
    "target": 583,
    "weight": 1
   },
   {
    "source": 40,
    "target": 717,
    "weight": 1
   },
   {
    "source": 2,
    "target": 717,
    "weight": 1
   },
   {
    "source": 62,
    "target": 648,
    "weight": 1
   },
   {
    "source": 46,
    "target": 62,
    "weight": 2
   },
   {
    "source": 46,
    "target": 583,
    "weight": 1
   },
   {
    "source": 62,
    "target": 129,
    "weight": 3
   },
   {
    "source": 137,
    "target": 578,
    "weight": 1
   },
   {
    "source": 579,
    "target": 684,
    "weight": 1
   },
   {
    "source": 46,
    "target": 684,
    "weight": 1
   },
   {
    "source": 46,
    "target": 702,
    "weight": 1
   },
   {
    "source": 192,
    "target": 702,
    "weight": 1
   },
   {
    "source": 40,
    "target": 192,
    "weight": 2
   },
   {
    "source": 40,
    "target": 406,
    "weight": 1
   },
   {
    "source": 406,
    "target": 645,
    "weight": 1
   },
   {
    "source": 40,
    "target": 269,
    "weight": 2
   },
   {
    "source": 46,
    "target": 269,
    "weight": 1
   },
   {
    "source": 45,
    "target": 270,
    "weight": 1
   },
   {
    "source": 193,
    "target": 719,
    "weight": 1
   },
   {
    "source": 719,
    "target": 720,
    "weight": 1
   },
   {
    "source": 46,
    "target": 720,
    "weight": 2
   },
   {
    "source": 40,
    "target": 216,
    "weight": 1
   },
   {
    "source": 216,
    "target": 561,
    "weight": 1
   },
   {
    "source": 561,
    "target": 721,
    "weight": 1
   },
   {
    "source": 45,
    "target": 721,
    "weight": 1
   },
   {
    "source": 46,
    "target": 562,
    "weight": 4
   },
   {
    "source": 562,
    "target": 722,
    "weight": 1
   },
   {
    "source": 46,
    "target": 270,
    "weight": 2
   },
   {
    "source": 137,
    "target": 696,
    "weight": 1
   },
   {
    "source": 46,
    "target": 523,
    "weight": 1
   },
   {
    "source": 46,
    "target": 588,
    "weight": 3
   },
   {
    "source": 503,
    "target": 588,
    "weight": 1
   },
   {
    "source": 192,
    "target": 680,
    "weight": 1
   },
   {
    "source": 523,
    "target": 648,
    "weight": 1
   },
   {
    "source": 696,
    "target": 722,
    "weight": 1
   },
   {
    "source": 2,
    "target": 723,
    "weight": 2
   },
   {
    "source": 69,
    "target": 723,
    "weight": 1
   },
   {
    "source": 69,
    "target": 169,
    "weight": 1
   },
   {
    "source": 72,
    "target": 169,
    "weight": 4
   },
   {
    "source": 72,
    "target": 724,
    "weight": 2
   },
   {
    "source": 72,
    "target": 448,
    "weight": 1
   },
   {
    "source": 40,
    "target": 448,
    "weight": 2
   },
   {
    "source": 69,
    "target": 72,
    "weight": 1
   },
   {
    "source": 332,
    "target": 723,
    "weight": 1
   },
   {
    "source": 33,
    "target": 332,
    "weight": 3
   },
   {
    "source": 33,
    "target": 261,
    "weight": 1
   },
   {
    "source": 248,
    "target": 261,
    "weight": 1
   },
   {
    "source": 248,
    "target": 381,
    "weight": 1
   },
   {
    "source": 40,
    "target": 381,
    "weight": 1
   },
   {
    "source": 40,
    "target": 725,
    "weight": 1
   },
   {
    "source": 725,
    "target": 726,
    "weight": 1
   },
   {
    "source": 726,
    "target": 727,
    "weight": 1
   },
   {
    "source": 727,
    "target": 728,
    "weight": 1
   },
   {
    "source": 728,
    "target": 729,
    "weight": 1
   },
   {
    "source": 40,
    "target": 729,
    "weight": 1
   },
   {
    "source": 40,
    "target": 202,
    "weight": 1
   },
   {
    "source": 202,
    "target": 370,
    "weight": 1
   },
   {
    "source": 40,
    "target": 370,
    "weight": 2
   },
   {
    "source": 72,
    "target": 723,
    "weight": 1
   },
   {
    "source": 192,
    "target": 717,
    "weight": 1
   },
   {
    "source": 599,
    "target": 717,
    "weight": 1
   },
   {
    "source": 2,
    "target": 599,
    "weight": 3
   },
   {
    "source": 2,
    "target": 628,
    "weight": 1
   },
   {
    "source": 628,
    "target": 730,
    "weight": 1
   },
   {
    "source": 0,
    "target": 40,
    "weight": 1
   },
   {
    "source": 124,
    "target": 129,
    "weight": 3
   },
   {
    "source": 137,
    "target": 167,
    "weight": 1
   },
   {
    "source": 167,
    "target": 169,
    "weight": 1
   },
   {
    "source": 2,
    "target": 558,
    "weight": 1
   },
   {
    "source": 558,
    "target": 731,
    "weight": 2
   },
   {
    "source": 454,
    "target": 731,
    "weight": 1
   },
   {
    "source": 137,
    "target": 454,
    "weight": 1
   },
   {
    "source": 2,
    "target": 169,
    "weight": 1
   },
   {
    "source": 4,
    "target": 730,
    "weight": 1
   },
   {
    "source": 34,
    "target": 518,
    "weight": 1
   },
   {
    "source": 72,
    "target": 518,
    "weight": 1
   },
   {
    "source": 2,
    "target": 47,
    "weight": 12
   },
   {
    "source": 5,
    "target": 602,
    "weight": 1
   },
   {
    "source": 40,
    "target": 732,
    "weight": 1
   },
   {
    "source": 46,
    "target": 732,
    "weight": 1
   },
   {
    "source": 46,
    "target": 733,
    "weight": 3
   },
   {
    "source": 660,
    "target": 733,
    "weight": 1
   },
   {
    "source": 46,
    "target": 660,
    "weight": 2
   },
   {
    "source": 46,
    "target": 266,
    "weight": 4
   },
   {
    "source": 266,
    "target": 660,
    "weight": 1
   },
   {
    "source": 47,
    "target": 62,
    "weight": 3
   },
   {
    "source": 26,
    "target": 72,
    "weight": 1
   },
   {
    "source": 47,
    "target": 672,
    "weight": 2
   },
   {
    "source": 672,
    "target": 674,
    "weight": 1
   },
   {
    "source": 269,
    "target": 674,
    "weight": 1
   },
   {
    "source": 269,
    "target": 734,
    "weight": 1
   },
   {
    "source": 298,
    "target": 734,
    "weight": 1
   },
   {
    "source": 298,
    "target": 735,
    "weight": 1
   },
   {
    "source": 735,
    "target": 736,
    "weight": 1
   },
   {
    "source": 64,
    "target": 736,
    "weight": 1
   },
   {
    "source": 64,
    "target": 292,
    "weight": 1
   },
   {
    "source": 292,
    "target": 737,
    "weight": 1
   },
   {
    "source": 737,
    "target": 738,
    "weight": 1
   },
   {
    "source": 104,
    "target": 738,
    "weight": 1
   },
   {
    "source": 45,
    "target": 59,
    "weight": 1
   },
   {
    "source": 45,
    "target": 349,
    "weight": 1
   },
   {
    "source": 69,
    "target": 349,
    "weight": 1
   },
   {
    "source": 69,
    "target": 623,
    "weight": 1
   },
   {
    "source": 34,
    "target": 623,
    "weight": 1
   },
   {
    "source": 34,
    "target": 503,
    "weight": 1
   },
   {
    "source": 503,
    "target": 739,
    "weight": 1
   },
   {
    "source": 739,
    "target": 740,
    "weight": 1
   },
   {
    "source": 740,
    "target": 741,
    "weight": 2
   },
   {
    "source": 30,
    "target": 741,
    "weight": 1
   },
   {
    "source": 30,
    "target": 170,
    "weight": 1
   },
   {
    "source": 59,
    "target": 104,
    "weight": 1
   },
   {
    "source": 61,
    "target": 623,
    "weight": 1
   },
   {
    "source": 623,
    "target": 742,
    "weight": 1
   },
   {
    "source": 40,
    "target": 742,
    "weight": 1
   },
   {
    "source": 61,
    "target": 170,
    "weight": 1
   },
   {
    "source": 34,
    "target": 62,
    "weight": 4
   },
   {
    "source": 34,
    "target": 742,
    "weight": 1
   },
   {
    "source": 254,
    "target": 742,
    "weight": 1
   },
   {
    "source": 90,
    "target": 254,
    "weight": 1
   },
   {
    "source": 90,
    "target": 740,
    "weight": 7
   },
   {
    "source": 740,
    "target": 743,
    "weight": 1
   },
   {
    "source": 40,
    "target": 743,
    "weight": 1
   },
   {
    "source": 96,
    "target": 744,
    "weight": 1
   },
   {
    "source": 152,
    "target": 744,
    "weight": 1
   },
   {
    "source": 90,
    "target": 152,
    "weight": 1
   },
   {
    "source": 90,
    "target": 745,
    "weight": 2
   },
   {
    "source": 46,
    "target": 745,
    "weight": 4
   },
   {
    "source": 96,
    "target": 152,
    "weight": 1
   },
   {
    "source": 40,
    "target": 96,
    "weight": 2
   },
   {
    "source": 271,
    "target": 746,
    "weight": 1
   },
   {
    "source": 4,
    "target": 746,
    "weight": 5
   },
   {
    "source": 116,
    "target": 747,
    "weight": 1
   },
   {
    "source": 493,
    "target": 747,
    "weight": 1
   },
   {
    "source": 46,
    "target": 271,
    "weight": 1
   },
   {
    "source": 61,
    "target": 748,
    "weight": 1
   },
   {
    "source": 61,
    "target": 742,
    "weight": 1
   },
   {
    "source": 460,
    "target": 742,
    "weight": 1
   },
   {
    "source": 460,
    "target": 623,
    "weight": 4
   },
   {
    "source": 623,
    "target": 749,
    "weight": 1
   },
   {
    "source": 122,
    "target": 749,
    "weight": 1
   },
   {
    "source": 380,
    "target": 748,
    "weight": 1
   },
   {
    "source": 45,
    "target": 623,
    "weight": 2
   },
   {
    "source": 45,
    "target": 745,
    "weight": 1
   },
   {
    "source": 122,
    "target": 623,
    "weight": 1
   },
   {
    "source": 26,
    "target": 623,
    "weight": 1
   },
   {
    "source": 26,
    "target": 729,
    "weight": 1
   },
   {
    "source": 380,
    "target": 729,
    "weight": 1
   },
   {
    "source": 380,
    "target": 404,
    "weight": 1
   },
   {
    "source": 382,
    "target": 404,
    "weight": 1
   },
   {
    "source": 382,
    "target": 750,
    "weight": 1
   },
   {
    "source": 141,
    "target": 750,
    "weight": 1
   },
   {
    "source": 141,
    "target": 745,
    "weight": 1
   },
   {
    "source": 10,
    "target": 46,
    "weight": 2
   },
   {
    "source": 90,
    "target": 623,
    "weight": 1
   },
   {
    "source": 424,
    "target": 460,
    "weight": 1
   },
   {
    "source": 424,
    "target": 751,
    "weight": 1
   },
   {
    "source": 478,
    "target": 751,
    "weight": 1
   },
   {
    "source": 40,
    "target": 360,
    "weight": 2
   },
   {
    "source": 360,
    "target": 623,
    "weight": 2
   },
   {
    "source": 460,
    "target": 738,
    "weight": 2
   },
   {
    "source": 360,
    "target": 460,
    "weight": 2
   },
   {
    "source": 360,
    "target": 403,
    "weight": 1
   },
   {
    "source": 40,
    "target": 403,
    "weight": 1
   },
   {
    "source": 360,
    "target": 478,
    "weight": 1
   },
   {
    "source": 54,
    "target": 106,
    "weight": 1
   },
   {
    "source": 54,
    "target": 460,
    "weight": 1
   },
   {
    "source": 40,
    "target": 106,
    "weight": 1
   },
   {
    "source": 374,
    "target": 642,
    "weight": 1
   },
   {
    "source": 374,
    "target": 558,
    "weight": 1
   },
   {
    "source": 45,
    "target": 731,
    "weight": 1
   },
   {
    "source": 45,
    "target": 752,
    "weight": 1
   },
   {
    "source": 40,
    "target": 752,
    "weight": 2
   },
   {
    "source": 360,
    "target": 642,
    "weight": 1
   },
   {
    "source": 34,
    "target": 47,
    "weight": 1
   },
   {
    "source": 47,
    "target": 753,
    "weight": 1
   },
   {
    "source": 46,
    "target": 753,
    "weight": 1
   },
   {
    "source": 46,
    "target": 754,
    "weight": 1
   },
   {
    "source": 192,
    "target": 754,
    "weight": 1
   },
   {
    "source": 47,
    "target": 650,
    "weight": 2
   },
   {
    "source": 47,
    "target": 127,
    "weight": 1
   },
   {
    "source": 111,
    "target": 127,
    "weight": 1
   },
   {
    "source": 27,
    "target": 755,
    "weight": 6
   },
   {
    "source": 40,
    "target": 650,
    "weight": 2
   },
   {
    "source": 47,
    "target": 608,
    "weight": 2
   },
   {
    "source": 558,
    "target": 608,
    "weight": 1
   },
   {
    "source": 47,
    "target": 558,
    "weight": 3
   },
   {
    "source": 47,
    "target": 68,
    "weight": 1
   },
   {
    "source": 582,
    "target": 635,
    "weight": 2
   },
   {
    "source": 193,
    "target": 635,
    "weight": 3
   },
   {
    "source": 193,
    "target": 251,
    "weight": 1
   },
   {
    "source": 523,
    "target": 755,
    "weight": 1
   },
   {
    "source": 47,
    "target": 413,
    "weight": 1
   },
   {
    "source": 262,
    "target": 413,
    "weight": 1
   },
   {
    "source": 262,
    "target": 394,
    "weight": 1
   },
   {
    "source": 110,
    "target": 394,
    "weight": 1
   },
   {
    "source": 47,
    "target": 251,
    "weight": 1
   },
   {
    "source": 47,
    "target": 756,
    "weight": 1
   },
   {
    "source": 287,
    "target": 756,
    "weight": 1
   },
   {
    "source": 26,
    "target": 287,
    "weight": 3
   },
   {
    "source": 26,
    "target": 269,
    "weight": 2
   },
   {
    "source": 40,
    "target": 561,
    "weight": 1
   },
   {
    "source": 46,
    "target": 561,
    "weight": 1
   },
   {
    "source": 562,
    "target": 757,
    "weight": 1
   },
   {
    "source": 26,
    "target": 756,
    "weight": 1
   },
   {
    "source": 46,
    "target": 757,
    "weight": 1
   },
   {
    "source": 137,
    "target": 575,
    "weight": 1
   },
   {
    "source": 30,
    "target": 575,
    "weight": 2
   },
   {
    "source": 30,
    "target": 40,
    "weight": 2
   },
   {
    "source": 40,
    "target": 120,
    "weight": 1
   },
   {
    "source": 103,
    "target": 120,
    "weight": 1
   },
   {
    "source": 103,
    "target": 758,
    "weight": 1
   },
   {
    "source": 52,
    "target": 758,
    "weight": 1
   },
   {
    "source": 52,
    "target": 759,
    "weight": 2
   },
   {
    "source": 623,
    "target": 759,
    "weight": 1
   },
   {
    "source": 40,
    "target": 66,
    "weight": 1
   },
   {
    "source": 62,
    "target": 757,
    "weight": 1
   },
   {
    "source": 59,
    "target": 62,
    "weight": 2
   },
   {
    "source": 59,
    "target": 565,
    "weight": 1
   },
   {
    "source": 5,
    "target": 565,
    "weight": 1
   },
   {
    "source": 5,
    "target": 40,
    "weight": 3
   },
   {
    "source": 2,
    "target": 161,
    "weight": 1
   },
   {
    "source": 156,
    "target": 161,
    "weight": 1
   },
   {
    "source": 138,
    "target": 156,
    "weight": 1
   },
   {
    "source": 138,
    "target": 636,
    "weight": 1
   },
   {
    "source": 2,
    "target": 636,
    "weight": 1
   },
   {
    "source": 62,
    "target": 66,
    "weight": 1
   },
   {
    "source": 760,
    "target": 761,
    "weight": 1
   },
   {
    "source": 265,
    "target": 761,
    "weight": 1
   },
   {
    "source": 265,
    "target": 580,
    "weight": 1
   },
   {
    "source": 40,
    "target": 762,
    "weight": 1
   },
   {
    "source": 442,
    "target": 762,
    "weight": 1
   },
   {
    "source": 442,
    "target": 763,
    "weight": 1
   },
   {
    "source": 152,
    "target": 763,
    "weight": 1
   },
   {
    "source": 152,
    "target": 764,
    "weight": 1
   },
   {
    "source": 87,
    "target": 764,
    "weight": 1
   },
   {
    "source": 87,
    "target": 640,
    "weight": 1
   },
   {
    "source": 640,
    "target": 662,
    "weight": 1
   },
   {
    "source": 2,
    "target": 760,
    "weight": 1
   },
   {
    "source": 5,
    "target": 765,
    "weight": 1
   },
   {
    "source": 5,
    "target": 766,
    "weight": 1
   },
   {
    "source": 80,
    "target": 766,
    "weight": 1
   },
   {
    "source": 80,
    "target": 767,
    "weight": 1
   },
   {
    "source": 464,
    "target": 767,
    "weight": 1
   },
   {
    "source": 464,
    "target": 768,
    "weight": 1
   },
   {
    "source": 662,
    "target": 765,
    "weight": 1
   },
   {
    "source": 137,
    "target": 769,
    "weight": 1
   },
   {
    "source": 2,
    "target": 672,
    "weight": 1
   },
   {
    "source": 150,
    "target": 672,
    "weight": 1
   },
   {
    "source": 52,
    "target": 150,
    "weight": 1
   },
   {
    "source": 768,
    "target": 769,
    "weight": 1
   },
   {
    "source": 287,
    "target": 717,
    "weight": 1
   },
   {
    "source": 25,
    "target": 31,
    "weight": 1
   },
   {
    "source": 31,
    "target": 34,
    "weight": 1
   },
   {
    "source": 717,
    "target": 759,
    "weight": 2
   },
   {
    "source": 34,
    "target": 719,
    "weight": 1
   },
   {
    "source": 47,
    "target": 385,
    "weight": 1
   },
   {
    "source": 46,
    "target": 57,
    "weight": 1
   },
   {
    "source": 9,
    "target": 57,
    "weight": 1
   },
   {
    "source": 9,
    "target": 287,
    "weight": 1
   },
   {
    "source": 26,
    "target": 141,
    "weight": 1
   },
   {
    "source": 9,
    "target": 26,
    "weight": 2
   },
   {
    "source": 385,
    "target": 719,
    "weight": 1
   },
   {
    "source": 10,
    "target": 604,
    "weight": 1
   },
   {
    "source": 10,
    "target": 770,
    "weight": 2
   },
   {
    "source": 415,
    "target": 770,
    "weight": 1
   },
   {
    "source": 90,
    "target": 415,
    "weight": 2
   },
   {
    "source": 2,
    "target": 582,
    "weight": 1
   },
   {
    "source": 46,
    "target": 582,
    "weight": 1
   },
   {
    "source": 599,
    "target": 740,
    "weight": 1
   },
   {
    "source": 68,
    "target": 771,
    "weight": 1
   },
   {
    "source": 770,
    "target": 771,
    "weight": 1
   },
   {
    "source": 62,
    "target": 772,
    "weight": 1
   },
   {
    "source": 610,
    "target": 772,
    "weight": 1
   },
   {
    "source": 610,
    "target": 773,
    "weight": 1
   },
   {
    "source": 28,
    "target": 773,
    "weight": 1
   },
   {
    "source": 5,
    "target": 774,
    "weight": 1
   },
   {
    "source": 191,
    "target": 774,
    "weight": 1
   },
   {
    "source": 140,
    "target": 191,
    "weight": 1
   },
   {
    "source": 140,
    "target": 436,
    "weight": 2
   },
   {
    "source": 68,
    "target": 321,
    "weight": 1
   },
   {
    "source": 40,
    "target": 772,
    "weight": 1
   },
   {
    "source": 5,
    "target": 191,
    "weight": 1
   },
   {
    "source": 40,
    "target": 68,
    "weight": 1
   },
   {
    "source": 39,
    "target": 775,
    "weight": 1
   },
   {
    "source": 47,
    "target": 775,
    "weight": 1
   },
   {
    "source": 40,
    "target": 47,
    "weight": 10
   },
   {
    "source": 2,
    "target": 719,
    "weight": 1
   },
   {
    "source": 1,
    "target": 68,
    "weight": 1
   },
   {
    "source": 386,
    "target": 776,
    "weight": 1
   },
   {
    "source": 206,
    "target": 776,
    "weight": 1
   },
   {
    "source": 34,
    "target": 206,
    "weight": 1
   },
   {
    "source": 34,
    "target": 56,
    "weight": 1
   },
   {
    "source": 386,
    "target": 719,
    "weight": 1
   },
   {
    "source": 38,
    "target": 575,
    "weight": 1
   },
   {
    "source": 2,
    "target": 575,
    "weight": 1
   },
   {
    "source": 2,
    "target": 45,
    "weight": 1
   },
   {
    "source": 46,
    "target": 380,
    "weight": 4
   },
   {
    "source": 47,
    "target": 380,
    "weight": 2
   },
   {
    "source": 47,
    "target": 777,
    "weight": 1
   },
   {
    "source": 2,
    "target": 778,
    "weight": 1
   },
   {
    "source": 46,
    "target": 778,
    "weight": 1
   },
   {
    "source": 46,
    "target": 779,
    "weight": 1
   },
   {
    "source": 619,
    "target": 779,
    "weight": 1
   },
   {
    "source": 619,
    "target": 780,
    "weight": 29
   },
   {
    "source": 780,
    "target": 781,
    "weight": 3
   },
   {
    "source": 380,
    "target": 781,
    "weight": 4
   },
   {
    "source": 0,
    "target": 777,
    "weight": 1
   },
   {
    "source": 266,
    "target": 380,
    "weight": 2
   },
   {
    "source": 40,
    "target": 380,
    "weight": 4
   },
   {
    "source": 40,
    "target": 782,
    "weight": 1
   },
   {
    "source": 44,
    "target": 782,
    "weight": 1
   },
   {
    "source": 44,
    "target": 783,
    "weight": 1
   },
   {
    "source": 47,
    "target": 783,
    "weight": 1
   },
   {
    "source": 47,
    "target": 739,
    "weight": 1
   },
   {
    "source": 739,
    "target": 770,
    "weight": 2
   },
   {
    "source": 90,
    "target": 770,
    "weight": 1
   },
   {
    "source": 46,
    "target": 740,
    "weight": 1
   },
   {
    "source": 47,
    "target": 784,
    "weight": 1
   },
   {
    "source": 26,
    "target": 784,
    "weight": 1
   },
   {
    "source": 46,
    "target": 493,
    "weight": 1
   },
   {
    "source": 26,
    "target": 45,
    "weight": 1
   },
   {
    "source": 40,
    "target": 503,
    "weight": 1
   },
   {
    "source": 40,
    "target": 773,
    "weight": 2
   },
   {
    "source": 582,
    "target": 773,
    "weight": 1
   },
   {
    "source": 193,
    "target": 582,
    "weight": 2
   },
   {
    "source": 287,
    "target": 635,
    "weight": 2
   },
   {
    "source": 26,
    "target": 38,
    "weight": 2
   },
   {
    "source": 38,
    "target": 493,
    "weight": 1
   },
   {
    "source": 30,
    "target": 38,
    "weight": 2
   },
   {
    "source": 30,
    "target": 746,
    "weight": 1
   },
   {
    "source": 380,
    "target": 740,
    "weight": 1
   },
   {
    "source": 370,
    "target": 380,
    "weight": 1
   },
   {
    "source": 370,
    "target": 781,
    "weight": 1
   },
   {
    "source": 30,
    "target": 415,
    "weight": 1
   },
   {
    "source": 46,
    "target": 781,
    "weight": 7
   },
   {
    "source": 46,
    "target": 619,
    "weight": 5
   },
   {
    "source": 675,
    "target": 780,
    "weight": 1
   },
   {
    "source": 675,
    "target": 726,
    "weight": 1
   },
   {
    "source": 380,
    "target": 726,
    "weight": 1
   },
   {
    "source": 380,
    "target": 605,
    "weight": 1
   },
   {
    "source": 605,
    "target": 726,
    "weight": 1
   },
   {
    "source": 237,
    "target": 726,
    "weight": 1
   },
   {
    "source": 145,
    "target": 237,
    "weight": 1
   },
   {
    "source": 40,
    "target": 785,
    "weight": 1
   },
   {
    "source": 129,
    "target": 786,
    "weight": 1
   },
   {
    "source": 781,
    "target": 786,
    "weight": 1
   },
   {
    "source": 781,
    "target": 787,
    "weight": 1
   },
   {
    "source": 380,
    "target": 787,
    "weight": 1
   },
   {
    "source": 145,
    "target": 785,
    "weight": 1
   },
   {
    "source": 740,
    "target": 781,
    "weight": 1
   },
   {
    "source": 210,
    "target": 781,
    "weight": 1
   },
   {
    "source": 210,
    "target": 380,
    "weight": 1
   },
   {
    "source": 90,
    "target": 380,
    "weight": 1
   },
   {
    "source": 380,
    "target": 638,
    "weight": 2
   },
   {
    "source": 781,
    "target": 788,
    "weight": 1
   },
   {
    "source": 254,
    "target": 788,
    "weight": 1
   },
   {
    "source": 254,
    "target": 781,
    "weight": 1
   },
   {
    "source": 30,
    "target": 150,
    "weight": 2
   },
   {
    "source": 4,
    "target": 380,
    "weight": 1
   },
   {
    "source": 380,
    "target": 789,
    "weight": 2
   },
   {
    "source": 46,
    "target": 789,
    "weight": 1
   },
   {
    "source": 619,
    "target": 781,
    "weight": 1
   },
   {
    "source": 780,
    "target": 790,
    "weight": 1
   },
   {
    "source": 254,
    "target": 790,
    "weight": 1
   },
   {
    "source": 254,
    "target": 596,
    "weight": 1
   },
   {
    "source": 26,
    "target": 596,
    "weight": 2
   },
   {
    "source": 150,
    "target": 781,
    "weight": 1
   },
   {
    "source": 746,
    "target": 791,
    "weight": 1
   },
   {
    "source": 791,
    "target": 792,
    "weight": 1
   },
   {
    "source": 674,
    "target": 792,
    "weight": 1
   },
   {
    "source": 4,
    "target": 674,
    "weight": 2
   },
   {
    "source": 46,
    "target": 746,
    "weight": 2
   },
   {
    "source": 54,
    "target": 793,
    "weight": 1
   },
   {
    "source": 54,
    "target": 554,
    "weight": 1
   },
   {
    "source": 554,
    "target": 794,
    "weight": 1
   },
   {
    "source": 628,
    "target": 794,
    "weight": 1
   },
   {
    "source": 11,
    "target": 628,
    "weight": 1
   },
   {
    "source": 11,
    "target": 72,
    "weight": 1
   },
   {
    "source": 4,
    "target": 72,
    "weight": 1
   },
   {
    "source": 30,
    "target": 795,
    "weight": 1
   },
   {
    "source": 623,
    "target": 795,
    "weight": 1
   },
   {
    "source": 47,
    "target": 623,
    "weight": 1
   },
   {
    "source": 554,
    "target": 628,
    "weight": 1
   },
   {
    "source": 11,
    "target": 554,
    "weight": 1
   },
   {
    "source": 11,
    "target": 794,
    "weight": 1
   },
   {
    "source": 4,
    "target": 793,
    "weight": 1
   },
   {
    "source": 122,
    "target": 796,
    "weight": 1
   },
   {
    "source": 122,
    "target": 628,
    "weight": 1
   },
   {
    "source": 628,
    "target": 789,
    "weight": 1
   },
   {
    "source": 4,
    "target": 789,
    "weight": 1
   },
   {
    "source": 4,
    "target": 797,
    "weight": 1
   },
   {
    "source": 599,
    "target": 797,
    "weight": 1
   },
   {
    "source": 137,
    "target": 796,
    "weight": 1
   },
   {
    "source": 4,
    "target": 713,
    "weight": 2
   },
   {
    "source": 46,
    "target": 713,
    "weight": 2
   },
   {
    "source": 380,
    "target": 780,
    "weight": 2
   },
   {
    "source": 38,
    "target": 599,
    "weight": 3
   },
   {
    "source": 44,
    "target": 401,
    "weight": 1
   },
   {
    "source": 401,
    "target": 798,
    "weight": 1
   },
   {
    "source": 140,
    "target": 798,
    "weight": 1
   },
   {
    "source": 140,
    "target": 781,
    "weight": 1
   },
   {
    "source": 4,
    "target": 781,
    "weight": 1
   },
   {
    "source": 746,
    "target": 789,
    "weight": 1
   },
   {
    "source": 380,
    "target": 619,
    "weight": 2
   },
   {
    "source": 2,
    "target": 799,
    "weight": 1
   },
   {
    "source": 6,
    "target": 152,
    "weight": 1
   },
   {
    "source": 3,
    "target": 799,
    "weight": 1
   },
   {
    "source": 380,
    "target": 745,
    "weight": 2
   },
   {
    "source": 152,
    "target": 745,
    "weight": 1
   },
   {
    "source": 38,
    "target": 152,
    "weight": 1
   },
   {
    "source": 152,
    "target": 800,
    "weight": 1
   },
   {
    "source": 789,
    "target": 800,
    "weight": 1
   },
   {
    "source": 781,
    "target": 789,
    "weight": 1
   },
   {
    "source": 38,
    "target": 380,
    "weight": 6
   },
   {
    "source": 38,
    "target": 138,
    "weight": 1
   },
   {
    "source": 46,
    "target": 138,
    "weight": 1
   },
   {
    "source": 380,
    "target": 739,
    "weight": 1
   },
   {
    "source": 739,
    "target": 801,
    "weight": 1
   },
   {
    "source": 72,
    "target": 801,
    "weight": 1
   },
   {
    "source": 72,
    "target": 104,
    "weight": 2
   },
   {
    "source": 104,
    "target": 352,
    "weight": 1
   },
   {
    "source": 239,
    "target": 352,
    "weight": 1
   },
   {
    "source": 154,
    "target": 202,
    "weight": 1
   },
   {
    "source": 177,
    "target": 202,
    "weight": 1
   },
   {
    "source": 177,
    "target": 746,
    "weight": 1
   },
   {
    "source": 746,
    "target": 802,
    "weight": 1
   },
   {
    "source": 521,
    "target": 802,
    "weight": 1
   },
   {
    "source": 521,
    "target": 803,
    "weight": 1
   },
   {
    "source": 4,
    "target": 415,
    "weight": 1
   },
   {
    "source": 415,
    "target": 741,
    "weight": 1
   },
   {
    "source": 717,
    "target": 740,
    "weight": 1
   },
   {
    "source": 26,
    "target": 717,
    "weight": 1
   },
   {
    "source": 746,
    "target": 803,
    "weight": 1
   },
   {
    "source": 34,
    "target": 804,
    "weight": 1
   },
   {
    "source": 804,
    "target": 805,
    "weight": 1
   },
   {
    "source": 733,
    "target": 805,
    "weight": 1
   },
   {
    "source": 733,
    "target": 806,
    "weight": 1
   },
   {
    "source": 404,
    "target": 806,
    "weight": 1
   },
   {
    "source": 38,
    "target": 404,
    "weight": 1
   },
   {
    "source": 38,
    "target": 62,
    "weight": 7
   },
   {
    "source": 26,
    "target": 34,
    "weight": 1
   },
   {
    "source": 38,
    "target": 270,
    "weight": 1
   },
   {
    "source": 40,
    "target": 713,
    "weight": 3
   },
   {
    "source": 267,
    "target": 713,
    "weight": 1
   },
   {
    "source": 267,
    "target": 745,
    "weight": 1
   },
   {
    "source": 46,
    "target": 152,
    "weight": 2
   },
   {
    "source": 40,
    "target": 270,
    "weight": 1
   },
   {
    "source": 40,
    "target": 783,
    "weight": 1
   },
   {
    "source": 38,
    "target": 783,
    "weight": 2
   },
   {
    "source": 307,
    "target": 723,
    "weight": 1
   },
   {
    "source": 40,
    "target": 307,
    "weight": 1
   },
   {
    "source": 34,
    "target": 141,
    "weight": 1
   },
   {
    "source": 111,
    "target": 141,
    "weight": 1
   },
   {
    "source": 10,
    "target": 111,
    "weight": 1
   },
   {
    "source": 10,
    "target": 26,
    "weight": 4
   },
   {
    "source": 26,
    "target": 380,
    "weight": 1
   },
   {
    "source": 40,
    "target": 723,
    "weight": 1
   },
   {
    "source": 270,
    "target": 380,
    "weight": 1
   },
   {
    "source": 46,
    "target": 807,
    "weight": 1
   },
   {
    "source": 623,
    "target": 807,
    "weight": 1
   },
   {
    "source": 380,
    "target": 808,
    "weight": 3
   },
   {
    "source": 619,
    "target": 808,
    "weight": 2
   },
   {
    "source": 780,
    "target": 808,
    "weight": 1
   },
   {
    "source": 381,
    "target": 619,
    "weight": 2
   },
   {
    "source": 620,
    "target": 726,
    "weight": 1
   },
   {
    "source": 726,
    "target": 786,
    "weight": 1
   },
   {
    "source": 619,
    "target": 809,
    "weight": 1
   },
   {
    "source": 38,
    "target": 780,
    "weight": 2
   },
   {
    "source": 786,
    "target": 809,
    "weight": 1
   },
   {
    "source": 46,
    "target": 780,
    "weight": 4
   },
   {
    "source": 46,
    "target": 786,
    "weight": 2
   },
   {
    "source": 619,
    "target": 786,
    "weight": 1
   },
   {
    "source": 38,
    "target": 619,
    "weight": 1
   },
   {
    "source": 152,
    "target": 781,
    "weight": 1
   },
   {
    "source": 152,
    "target": 619,
    "weight": 1
   },
   {
    "source": 733,
    "target": 780,
    "weight": 1
   },
   {
    "source": 733,
    "target": 810,
    "weight": 1
   },
   {
    "source": 786,
    "target": 810,
    "weight": 1
   },
   {
    "source": 193,
    "target": 786,
    "weight": 1
   },
   {
    "source": 210,
    "target": 733,
    "weight": 1
   },
   {
    "source": 38,
    "target": 733,
    "weight": 3
   },
   {
    "source": 34,
    "target": 45,
    "weight": 1
   },
   {
    "source": 210,
    "target": 780,
    "weight": 1
   },
   {
    "source": 38,
    "target": 385,
    "weight": 3
   },
   {
    "source": 38,
    "target": 811,
    "weight": 1
   },
   {
    "source": 808,
    "target": 811,
    "weight": 1
   },
   {
    "source": 380,
    "target": 618,
    "weight": 1
   },
   {
    "source": 618,
    "target": 780,
    "weight": 5
   },
   {
    "source": 122,
    "target": 385,
    "weight": 1
   },
   {
    "source": 75,
    "target": 575,
    "weight": 1
   },
   {
    "source": 38,
    "target": 75,
    "weight": 1
   },
   {
    "source": 38,
    "target": 618,
    "weight": 1
   },
   {
    "source": 258,
    "target": 780,
    "weight": 1
   },
   {
    "source": 258,
    "target": 808,
    "weight": 1
   },
   {
    "source": 575,
    "target": 780,
    "weight": 2
   },
   {
    "source": 360,
    "target": 775,
    "weight": 1
   },
   {
    "source": 269,
    "target": 775,
    "weight": 1
   },
   {
    "source": 68,
    "target": 269,
    "weight": 2
   },
   {
    "source": 68,
    "target": 258,
    "weight": 2
   },
   {
    "source": 258,
    "target": 266,
    "weight": 1
   },
   {
    "source": 266,
    "target": 781,
    "weight": 1
   },
   {
    "source": 360,
    "target": 380,
    "weight": 1
   },
   {
    "source": 147,
    "target": 169,
    "weight": 1
   },
   {
    "source": 345,
    "target": 523,
    "weight": 1
   },
   {
    "source": 161,
    "target": 345,
    "weight": 1
   },
   {
    "source": 161,
    "target": 380,
    "weight": 1
   },
   {
    "source": 177,
    "target": 380,
    "weight": 1
   },
   {
    "source": 177,
    "target": 812,
    "weight": 1
   },
   {
    "source": 618,
    "target": 812,
    "weight": 2
   },
   {
    "source": 147,
    "target": 781,
    "weight": 1
   },
   {
    "source": 575,
    "target": 813,
    "weight": 1
   },
   {
    "source": 156,
    "target": 813,
    "weight": 1
   },
   {
    "source": 156,
    "target": 605,
    "weight": 1
   },
   {
    "source": 112,
    "target": 605,
    "weight": 1
   },
   {
    "source": 619,
    "target": 680,
    "weight": 1
   },
   {
    "source": 680,
    "target": 730,
    "weight": 1
   },
   {
    "source": 730,
    "target": 814,
    "weight": 1
   },
   {
    "source": 112,
    "target": 814,
    "weight": 1
   },
   {
    "source": 112,
    "target": 269,
    "weight": 1
   },
   {
    "source": 269,
    "target": 618,
    "weight": 1
   },
   {
    "source": 69,
    "target": 618,
    "weight": 1
   },
   {
    "source": 69,
    "target": 815,
    "weight": 1
   },
   {
    "source": 112,
    "target": 619,
    "weight": 1
   },
   {
    "source": 2,
    "target": 618,
    "weight": 1
   },
   {
    "source": 0,
    "target": 815,
    "weight": 1
   },
   {
    "source": 605,
    "target": 618,
    "weight": 1
   },
   {
    "source": 605,
    "target": 650,
    "weight": 1
   },
   {
    "source": 112,
    "target": 650,
    "weight": 1
   },
   {
    "source": 47,
    "target": 619,
    "weight": 1
   },
   {
    "source": 780,
    "target": 816,
    "weight": 1
   },
   {
    "source": 812,
    "target": 816,
    "weight": 1
   },
   {
    "source": 618,
    "target": 817,
    "weight": 1
   },
   {
    "source": 184,
    "target": 817,
    "weight": 1
   },
   {
    "source": 75,
    "target": 184,
    "weight": 1
   },
   {
    "source": 75,
    "target": 112,
    "weight": 1
   },
   {
    "source": 112,
    "target": 746,
    "weight": 4
   },
   {
    "source": 746,
    "target": 818,
    "weight": 1
   },
   {
    "source": 169,
    "target": 818,
    "weight": 1
   },
   {
    "source": 40,
    "target": 112,
    "weight": 1
   },
   {
    "source": 406,
    "target": 604,
    "weight": 1
   },
   {
    "source": 406,
    "target": 609,
    "weight": 1
   },
   {
    "source": 2,
    "target": 609,
    "weight": 3
   },
   {
    "source": 40,
    "target": 604,
    "weight": 2
   },
   {
    "source": 345,
    "target": 819,
    "weight": 1
   },
   {
    "source": 5,
    "target": 819,
    "weight": 1
   },
   {
    "source": 5,
    "target": 575,
    "weight": 1
   },
   {
    "source": 503,
    "target": 575,
    "weight": 1
   },
   {
    "source": 503,
    "target": 609,
    "weight": 2
   },
   {
    "source": 112,
    "target": 609,
    "weight": 1
   },
   {
    "source": 112,
    "target": 137,
    "weight": 1
   },
   {
    "source": 137,
    "target": 820,
    "weight": 1
   },
   {
    "source": 812,
    "target": 820,
    "weight": 1
   },
   {
    "source": 609,
    "target": 812,
    "weight": 1
   },
   {
    "source": 609,
    "target": 821,
    "weight": 1
   },
   {
    "source": 427,
    "target": 821,
    "weight": 1
   },
   {
    "source": 427,
    "target": 484,
    "weight": 1
   },
   {
    "source": 42,
    "target": 484,
    "weight": 1
   },
   {
    "source": 40,
    "target": 806,
    "weight": 1
   },
   {
    "source": 2,
    "target": 345,
    "weight": 1
   },
   {
    "source": 663,
    "target": 822,
    "weight": 1
   },
   {
    "source": 563,
    "target": 822,
    "weight": 1
   },
   {
    "source": 124,
    "target": 558,
    "weight": 1
   },
   {
    "source": 124,
    "target": 165,
    "weight": 1
   },
   {
    "source": 165,
    "target": 823,
    "weight": 1
   },
   {
    "source": 198,
    "target": 823,
    "weight": 1
   },
   {
    "source": 198,
    "target": 507,
    "weight": 3
   },
   {
    "source": 663,
    "target": 806,
    "weight": 1
   },
   {
    "source": 609,
    "target": 824,
    "weight": 1
   },
   {
    "source": 147,
    "target": 824,
    "weight": 1
   },
   {
    "source": 147,
    "target": 596,
    "weight": 1
   },
   {
    "source": 26,
    "target": 695,
    "weight": 1
   },
   {
    "source": 695,
    "target": 825,
    "weight": 1
   },
   {
    "source": 165,
    "target": 825,
    "weight": 1
   },
   {
    "source": 165,
    "target": 425,
    "weight": 1
   },
   {
    "source": 507,
    "target": 609,
    "weight": 1
   },
   {
    "source": 317,
    "target": 663,
    "weight": 1
   },
   {
    "source": 38,
    "target": 317,
    "weight": 4
   },
   {
    "source": 38,
    "target": 826,
    "weight": 1
   },
   {
    "source": 609,
    "target": 826,
    "weight": 3
   },
   {
    "source": 425,
    "target": 663,
    "weight": 1
   },
   {
    "source": 40,
    "target": 827,
    "weight": 1
   },
   {
    "source": 619,
    "target": 827,
    "weight": 2
   },
   {
    "source": 503,
    "target": 619,
    "weight": 1
   },
   {
    "source": 609,
    "target": 615,
    "weight": 1
   },
   {
    "source": 312,
    "target": 615,
    "weight": 1
   },
   {
    "source": 265,
    "target": 312,
    "weight": 1
   },
   {
    "source": 265,
    "target": 619,
    "weight": 2
   },
   {
    "source": 203,
    "target": 619,
    "weight": 1
   },
   {
    "source": 203,
    "target": 269,
    "weight": 1
   },
   {
    "source": 269,
    "target": 609,
    "weight": 1
   },
   {
    "source": 609,
    "target": 781,
    "weight": 1
   },
   {
    "source": 317,
    "target": 337,
    "weight": 1
   },
   {
    "source": 337,
    "target": 641,
    "weight": 1
   },
   {
    "source": 641,
    "target": 828,
    "weight": 1
   },
   {
    "source": 46,
    "target": 828,
    "weight": 1
   },
   {
    "source": 2,
    "target": 46,
    "weight": 1
   },
   {
    "source": 2,
    "target": 829,
    "weight": 1
   },
   {
    "source": 430,
    "target": 829,
    "weight": 1
   },
   {
    "source": 430,
    "target": 619,
    "weight": 1
   },
   {
    "source": 609,
    "target": 619,
    "weight": 1
   },
   {
    "source": 317,
    "target": 781,
    "weight": 1
   },
   {
    "source": 406,
    "target": 771,
    "weight": 1
   },
   {
    "source": 46,
    "target": 406,
    "weight": 1
   },
   {
    "source": 46,
    "target": 748,
    "weight": 1
   },
   {
    "source": 579,
    "target": 748,
    "weight": 1
   },
   {
    "source": 141,
    "target": 579,
    "weight": 1
   },
   {
    "source": 141,
    "target": 748,
    "weight": 1
   },
   {
    "source": 609,
    "target": 771,
    "weight": 1
   },
   {
    "source": 59,
    "target": 141,
    "weight": 1
   },
   {
    "source": 45,
    "target": 317,
    "weight": 2
   },
   {
    "source": 45,
    "target": 830,
    "weight": 1
   },
   {
    "source": 59,
    "target": 317,
    "weight": 1
   },
   {
    "source": 370,
    "target": 831,
    "weight": 1
   },
   {
    "source": 122,
    "target": 831,
    "weight": 2
   },
   {
    "source": 122,
    "target": 832,
    "weight": 1
   },
   {
    "source": 831,
    "target": 832,
    "weight": 1
   },
   {
    "source": 122,
    "target": 193,
    "weight": 1
   },
   {
    "source": 193,
    "target": 726,
    "weight": 2
   },
   {
    "source": 726,
    "target": 833,
    "weight": 1
   },
   {
    "source": 192,
    "target": 833,
    "weight": 1
   },
   {
    "source": 370,
    "target": 830,
    "weight": 1
   },
   {
    "source": 272,
    "target": 758,
    "weight": 1
   },
   {
    "source": 406,
    "target": 758,
    "weight": 1
   },
   {
    "source": 141,
    "target": 406,
    "weight": 1
   },
   {
    "source": 141,
    "target": 708,
    "weight": 1
   },
   {
    "source": 635,
    "target": 708,
    "weight": 1
   },
   {
    "source": 59,
    "target": 287,
    "weight": 1
   },
   {
    "source": 192,
    "target": 272,
    "weight": 1
   },
   {
    "source": 834,
    "target": 835,
    "weight": 1
   },
   {
    "source": 835,
    "target": 836,
    "weight": 1
   },
   {
    "source": 693,
    "target": 836,
    "weight": 1
   },
   {
    "source": 141,
    "target": 693,
    "weight": 1
   },
   {
    "source": 141,
    "target": 837,
    "weight": 1
   },
   {
    "source": 837,
    "target": 838,
    "weight": 1
   },
   {
    "source": 59,
    "target": 834,
    "weight": 1
   },
   {
    "source": 604,
    "target": 733,
    "weight": 1
   },
   {
    "source": 46,
    "target": 379,
    "weight": 1
   },
   {
    "source": 47,
    "target": 379,
    "weight": 1
   },
   {
    "source": 47,
    "target": 110,
    "weight": 1
   },
   {
    "source": 604,
    "target": 838,
    "weight": 1
   },
   {
    "source": 90,
    "target": 839,
    "weight": 1
   },
   {
    "source": 40,
    "target": 740,
    "weight": 1
   },
   {
    "source": 46,
    "target": 839,
    "weight": 1
   },
   {
    "source": 780,
    "target": 840,
    "weight": 2
   },
   {
    "source": 609,
    "target": 618,
    "weight": 1
   },
   {
    "source": 609,
    "target": 809,
    "weight": 1
   },
   {
    "source": 380,
    "target": 809,
    "weight": 1
   },
   {
    "source": 3,
    "target": 38,
    "weight": 1
   },
   {
    "source": 38,
    "target": 582,
    "weight": 1
   },
   {
    "source": 582,
    "target": 717,
    "weight": 1
   },
   {
    "source": 46,
    "target": 759,
    "weight": 1
   },
   {
    "source": 278,
    "target": 317,
    "weight": 1
   },
   {
    "source": 317,
    "target": 619,
    "weight": 1
   },
   {
    "source": 46,
    "target": 841,
    "weight": 1
   },
   {
    "source": 745,
    "target": 841,
    "weight": 1
   },
   {
    "source": 745,
    "target": 842,
    "weight": 1
   },
   {
    "source": 90,
    "target": 842,
    "weight": 1
   },
   {
    "source": 90,
    "target": 843,
    "weight": 1
   },
   {
    "source": 745,
    "target": 843,
    "weight": 1
   },
   {
    "source": 745,
    "target": 844,
    "weight": 1
   },
   {
    "source": 619,
    "target": 844,
    "weight": 1
   },
   {
    "source": 278,
    "target": 380,
    "weight": 1
   },
   {
    "source": 46,
    "target": 463,
    "weight": 1
   },
   {
    "source": 463,
    "target": 619,
    "weight": 1
   },
   {
    "source": 463,
    "target": 780,
    "weight": 1
   },
   {
    "source": 317,
    "target": 841,
    "weight": 1
   },
   {
    "source": 266,
    "target": 841,
    "weight": 1
   },
   {
    "source": 266,
    "target": 845,
    "weight": 1
   },
   {
    "source": 845,
    "target": 846,
    "weight": 1
   },
   {
    "source": 442,
    "target": 846,
    "weight": 1
   },
   {
    "source": 193,
    "target": 442,
    "weight": 1
   },
   {
    "source": 90,
    "target": 193,
    "weight": 1
   },
   {
    "source": 317,
    "target": 780,
    "weight": 1
   },
   {
    "source": 442,
    "target": 657,
    "weight": 2
   },
   {
    "source": 90,
    "target": 442,
    "weight": 1
   },
   {
    "source": 129,
    "target": 780,
    "weight": 2
   },
   {
    "source": 9,
    "target": 780,
    "weight": 1
   },
   {
    "source": 11,
    "target": 266,
    "weight": 3
   },
   {
    "source": 193,
    "target": 266,
    "weight": 1
   },
   {
    "source": 193,
    "target": 380,
    "weight": 1
   },
   {
    "source": 40,
    "target": 53,
    "weight": 2
   },
   {
    "source": 28,
    "target": 53,
    "weight": 2
   },
   {
    "source": 43,
    "target": 53,
    "weight": 1
   },
   {
    "source": 43,
    "target": 847,
    "weight": 1
   },
   {
    "source": 783,
    "target": 847,
    "weight": 1
   },
   {
    "source": 783,
    "target": 848,
    "weight": 1
   },
   {
    "source": 47,
    "target": 848,
    "weight": 1
   },
   {
    "source": 47,
    "target": 849,
    "weight": 6
   },
   {
    "source": 781,
    "target": 849,
    "weight": 2
   },
   {
    "source": 47,
    "target": 266,
    "weight": 1
   },
   {
    "source": 266,
    "target": 478,
    "weight": 1
   },
   {
    "source": 49,
    "target": 478,
    "weight": 1
   },
   {
    "source": 49,
    "target": 155,
    "weight": 2
   },
   {
    "source": 46,
    "target": 155,
    "weight": 2
   },
   {
    "source": 40,
    "target": 582,
    "weight": 1
   },
   {
    "source": 38,
    "target": 46,
    "weight": 9
   },
   {
    "source": 47,
    "target": 210,
    "weight": 1
   },
   {
    "source": 211,
    "target": 791,
    "weight": 1
   },
   {
    "source": 62,
    "target": 791,
    "weight": 1
   },
   {
    "source": 40,
    "target": 141,
    "weight": 1
   },
   {
    "source": 54,
    "target": 141,
    "weight": 2
   },
   {
    "source": 54,
    "target": 67,
    "weight": 1
   },
   {
    "source": 47,
    "target": 582,
    "weight": 1
   },
   {
    "source": 721,
    "target": 771,
    "weight": 1
   },
   {
    "source": 733,
    "target": 771,
    "weight": 1
   },
   {
    "source": 38,
    "target": 721,
    "weight": 1
   },
   {
    "source": 8,
    "target": 46,
    "weight": 3
   },
   {
    "source": 8,
    "target": 58,
    "weight": 1
   },
   {
    "source": 58,
    "target": 148,
    "weight": 1
   },
   {
    "source": 148,
    "target": 849,
    "weight": 3
   },
   {
    "source": 646,
    "target": 733,
    "weight": 1
   },
   {
    "source": 46,
    "target": 292,
    "weight": 1
   },
   {
    "source": 646,
    "target": 849,
    "weight": 1
   },
   {
    "source": 577,
    "target": 608,
    "weight": 1
   },
   {
    "source": 577,
    "target": 793,
    "weight": 1
   },
   {
    "source": 793,
    "target": 850,
    "weight": 1
   },
   {
    "source": 47,
    "target": 292,
    "weight": 1
   },
   {
    "source": 47,
    "target": 850,
    "weight": 3
   },
   {
    "source": 317,
    "target": 850,
    "weight": 1
   },
   {
    "source": 38,
    "target": 851,
    "weight": 1
   },
   {
    "source": 46,
    "target": 850,
    "weight": 1
   },
   {
    "source": 850,
    "target": 851,
    "weight": 1
   },
   {
    "source": 192,
    "target": 850,
    "weight": 1
   },
   {
    "source": 26,
    "target": 148,
    "weight": 1
   },
   {
    "source": 46,
    "target": 148,
    "weight": 14
   },
   {
    "source": 46,
    "target": 48,
    "weight": 1
   },
   {
    "source": 126,
    "target": 852,
    "weight": 1
   },
   {
    "source": 126,
    "target": 148,
    "weight": 1
   },
   {
    "source": 148,
    "target": 853,
    "weight": 2
   },
   {
    "source": 638,
    "target": 853,
    "weight": 1
   },
   {
    "source": 46,
    "target": 638,
    "weight": 2
   },
   {
    "source": 48,
    "target": 852,
    "weight": 1
   },
   {
    "source": 672,
    "target": 728,
    "weight": 1
   },
   {
    "source": 30,
    "target": 728,
    "weight": 1
   },
   {
    "source": 30,
    "target": 166,
    "weight": 1
   },
   {
    "source": 166,
    "target": 854,
    "weight": 1
   },
   {
    "source": 853,
    "target": 854,
    "weight": 8
   },
   {
    "source": 65,
    "target": 650,
    "weight": 2
   },
   {
    "source": 650,
    "target": 855,
    "weight": 1
   },
   {
    "source": 855,
    "target": 856,
    "weight": 2
   },
   {
    "source": 856,
    "target": 857,
    "weight": 2
   },
   {
    "source": 156,
    "target": 856,
    "weight": 1
   },
   {
    "source": 156,
    "target": 858,
    "weight": 1
   },
   {
    "source": 850,
    "target": 858,
    "weight": 1
   },
   {
    "source": 156,
    "target": 850,
    "weight": 2
   },
   {
    "source": 657,
    "target": 850,
    "weight": 1
   },
   {
    "source": 657,
    "target": 859,
    "weight": 1
   },
   {
    "source": 65,
    "target": 853,
    "weight": 1
   },
   {
    "source": 854,
    "target": 860,
    "weight": 1
   },
   {
    "source": 853,
    "target": 861,
    "weight": 1
   },
   {
    "source": 728,
    "target": 861,
    "weight": 1
   },
   {
    "source": 254,
    "target": 728,
    "weight": 1
   },
   {
    "source": 859,
    "target": 860,
    "weight": 1
   },
   {
    "source": 47,
    "target": 862,
    "weight": 1
   },
   {
    "source": 849,
    "target": 862,
    "weight": 1
   },
   {
    "source": 463,
    "target": 849,
    "weight": 2
   },
   {
    "source": 849,
    "target": 863,
    "weight": 5
   },
   {
    "source": 47,
    "target": 254,
    "weight": 2
   },
   {
    "source": 300,
    "target": 849,
    "weight": 2
   },
   {
    "source": 300,
    "target": 863,
    "weight": 1
   },
   {
    "source": 2,
    "target": 793,
    "weight": 1
   },
   {
    "source": 793,
    "target": 864,
    "weight": 1
   },
   {
    "source": 853,
    "target": 864,
    "weight": 2
   },
   {
    "source": 0,
    "target": 849,
    "weight": 1
   },
   {
    "source": 733,
    "target": 849,
    "weight": 2
   },
   {
    "source": 849,
    "target": 853,
    "weight": 1
   },
   {
    "source": 793,
    "target": 865,
    "weight": 1
   },
   {
    "source": 853,
    "target": 865,
    "weight": 2
   },
   {
    "source": 853,
    "target": 866,
    "weight": 1
   },
   {
    "source": 49,
    "target": 866,
    "weight": 1
   },
   {
    "source": 49,
    "target": 733,
    "weight": 1
   },
   {
    "source": 47,
    "target": 654,
    "weight": 1
   },
   {
    "source": 654,
    "target": 849,
    "weight": 1
   },
   {
    "source": 733,
    "target": 793,
    "weight": 1
   },
   {
    "source": 300,
    "target": 775,
    "weight": 1
   },
   {
    "source": 308,
    "target": 775,
    "weight": 1
   },
   {
    "source": 47,
    "target": 308,
    "weight": 1
   },
   {
    "source": 47,
    "target": 317,
    "weight": 1
   },
   {
    "source": 126,
    "target": 856,
    "weight": 1
   },
   {
    "source": 854,
    "target": 856,
    "weight": 1
   },
   {
    "source": 47,
    "target": 126,
    "weight": 1
   },
   {
    "source": 47,
    "target": 728,
    "weight": 4
   },
   {
    "source": 47,
    "target": 165,
    "weight": 2
   },
   {
    "source": 165,
    "target": 849,
    "weight": 1
   },
   {
    "source": 728,
    "target": 853,
    "weight": 4
   },
   {
    "source": 775,
    "target": 854,
    "weight": 1
   },
   {
    "source": 775,
    "target": 849,
    "weight": 1
   },
   {
    "source": 40,
    "target": 728,
    "weight": 1
   },
   {
    "source": 2,
    "target": 573,
    "weight": 1
   },
   {
    "source": 413,
    "target": 573,
    "weight": 1
   },
   {
    "source": 413,
    "target": 745,
    "weight": 1
   },
   {
    "source": 745,
    "target": 849,
    "weight": 1
   },
   {
    "source": 111,
    "target": 849,
    "weight": 1
   },
   {
    "source": 40,
    "target": 573,
    "weight": 1
   },
   {
    "source": 38,
    "target": 864,
    "weight": 1
   },
   {
    "source": 286,
    "target": 853,
    "weight": 1
   },
   {
    "source": 47,
    "target": 286,
    "weight": 1
   },
   {
    "source": 111,
    "target": 865,
    "weight": 1
   },
   {
    "source": 38,
    "target": 857,
    "weight": 1
   },
   {
    "source": 38,
    "target": 746,
    "weight": 2
   },
   {
    "source": 40,
    "target": 746,
    "weight": 4
   },
   {
    "source": 26,
    "target": 857,
    "weight": 1
   },
   {
    "source": 148,
    "target": 865,
    "weight": 1
   },
   {
    "source": 849,
    "target": 867,
    "weight": 2
   },
   {
    "source": 867,
    "target": 868,
    "weight": 1
   },
   {
    "source": 868,
    "target": 869,
    "weight": 1
   },
   {
    "source": 47,
    "target": 869,
    "weight": 2
   },
   {
    "source": 660,
    "target": 781,
    "weight": 1
   },
   {
    "source": 660,
    "target": 870,
    "weight": 1
   },
   {
    "source": 865,
    "target": 870,
    "weight": 1
   },
   {
    "source": 40,
    "target": 865,
    "weight": 1
   },
   {
    "source": 746,
    "target": 871,
    "weight": 1
   },
   {
    "source": 26,
    "target": 746,
    "weight": 1
   },
   {
    "source": 865,
    "target": 871,
    "weight": 1
   },
   {
    "source": 851,
    "target": 853,
    "weight": 1
   },
   {
    "source": 161,
    "target": 851,
    "weight": 1
   },
   {
    "source": 161,
    "target": 781,
    "weight": 1
   },
   {
    "source": 849,
    "target": 872,
    "weight": 1
   },
   {
    "source": 8,
    "target": 872,
    "weight": 2
   },
   {
    "source": 8,
    "target": 38,
    "weight": 3
   },
   {
    "source": 720,
    "target": 854,
    "weight": 1
   },
   {
    "source": 638,
    "target": 728,
    "weight": 1
   },
   {
    "source": 638,
    "target": 849,
    "weight": 2
   },
   {
    "source": 849,
    "target": 873,
    "weight": 1
   },
   {
    "source": 856,
    "target": 873,
    "weight": 1
   },
   {
    "source": 47,
    "target": 856,
    "weight": 1
   },
   {
    "source": 40,
    "target": 874,
    "weight": 1
   },
   {
    "source": 49,
    "target": 874,
    "weight": 2
   },
   {
    "source": 49,
    "target": 875,
    "weight": 1
   },
   {
    "source": 867,
    "target": 875,
    "weight": 2
   },
   {
    "source": 867,
    "target": 876,
    "weight": 1
   },
   {
    "source": 46,
    "target": 876,
    "weight": 1
   },
   {
    "source": 46,
    "target": 874,
    "weight": 1
   },
   {
    "source": 49,
    "target": 867,
    "weight": 1
   },
   {
    "source": 46,
    "target": 867,
    "weight": 1
   },
   {
    "source": 46,
    "target": 49,
    "weight": 5
   },
   {
    "source": 1,
    "target": 724,
    "weight": 1
   },
   {
    "source": 48,
    "target": 724,
    "weight": 1
   },
   {
    "source": 1,
    "target": 48,
    "weight": 1
   },
   {
    "source": 48,
    "target": 463,
    "weight": 1
   },
   {
    "source": 47,
    "target": 463,
    "weight": 2
   },
   {
    "source": 47,
    "target": 877,
    "weight": 1
   },
   {
    "source": 877,
    "target": 878,
    "weight": 1
   },
   {
    "source": 878,
    "target": 879,
    "weight": 1
   },
   {
    "source": 47,
    "target": 879,
    "weight": 1
   },
   {
    "source": 47,
    "target": 880,
    "weight": 1
   },
   {
    "source": 248,
    "target": 880,
    "weight": 1
   },
   {
    "source": 248,
    "target": 881,
    "weight": 1
   },
   {
    "source": 881,
    "target": 882,
    "weight": 1
   },
   {
    "source": 40,
    "target": 851,
    "weight": 1
   },
   {
    "source": 46,
    "target": 254,
    "weight": 3
   },
   {
    "source": 254,
    "target": 638,
    "weight": 1
   },
   {
    "source": 47,
    "target": 638,
    "weight": 1
   },
   {
    "source": 851,
    "target": 882,
    "weight": 1
   },
   {
    "source": 1,
    "target": 40,
    "weight": 4
   },
   {
    "source": 38,
    "target": 883,
    "weight": 1
   },
   {
    "source": 874,
    "target": 883,
    "weight": 1
   },
   {
    "source": 3,
    "target": 874,
    "weight": 1
   },
   {
    "source": 40,
    "target": 663,
    "weight": 2
   },
   {
    "source": 392,
    "target": 663,
    "weight": 1
   },
   {
    "source": 392,
    "target": 884,
    "weight": 1
   },
   {
    "source": 40,
    "target": 884,
    "weight": 2
   },
   {
    "source": 6,
    "target": 40,
    "weight": 2
   },
   {
    "source": 1,
    "target": 254,
    "weight": 1
   },
   {
    "source": 1,
    "target": 46,
    "weight": 13
   },
   {
    "source": 588,
    "target": 657,
    "weight": 1
   },
   {
    "source": 251,
    "target": 588,
    "weight": 1
   },
   {
    "source": 254,
    "target": 884,
    "weight": 1
   },
   {
    "source": 1,
    "target": 148,
    "weight": 1
   },
   {
    "source": 148,
    "target": 678,
    "weight": 3
   },
   {
    "source": 46,
    "target": 678,
    "weight": 1
   },
   {
    "source": 40,
    "target": 780,
    "weight": 1
   },
   {
    "source": 96,
    "target": 148,
    "weight": 1
   },
   {
    "source": 49,
    "target": 678,
    "weight": 1
   },
   {
    "source": 96,
    "target": 678,
    "weight": 1
   },
   {
    "source": 459,
    "target": 720,
    "weight": 3
   },
   {
    "source": 720,
    "target": 885,
    "weight": 1
   },
   {
    "source": 885,
    "target": 886,
    "weight": 6
   },
   {
    "source": 46,
    "target": 886,
    "weight": 2
   },
   {
    "source": 459,
    "target": 678,
    "weight": 1
   },
   {
    "source": 40,
    "target": 887,
    "weight": 2
   },
   {
    "source": 886,
    "target": 887,
    "weight": 4
   },
   {
    "source": 40,
    "target": 886,
    "weight": 1
   },
   {
    "source": 46,
    "target": 128,
    "weight": 2
   },
   {
    "source": 128,
    "target": 539,
    "weight": 1
   },
   {
    "source": 46,
    "target": 539,
    "weight": 2
   },
   {
    "source": 1,
    "target": 4,
    "weight": 1
   },
   {
    "source": 4,
    "target": 46,
    "weight": 1
   },
   {
    "source": 1,
    "target": 188,
    "weight": 1
   },
   {
    "source": 188,
    "target": 728,
    "weight": 1
   },
   {
    "source": 728,
    "target": 888,
    "weight": 3
   },
   {
    "source": 674,
    "target": 888,
    "weight": 3
   },
   {
    "source": 40,
    "target": 674,
    "weight": 3
   },
   {
    "source": 40,
    "target": 67,
    "weight": 2
   },
   {
    "source": 67,
    "target": 75,
    "weight": 1
   },
   {
    "source": 35,
    "target": 75,
    "weight": 1
   },
   {
    "source": 35,
    "target": 773,
    "weight": 1
   },
   {
    "source": 300,
    "target": 728,
    "weight": 1
   },
   {
    "source": 1,
    "target": 300,
    "weight": 1
   },
   {
    "source": 40,
    "target": 889,
    "weight": 1
   },
   {
    "source": 588,
    "target": 889,
    "weight": 1
   },
   {
    "source": 728,
    "target": 773,
    "weight": 1
   },
   {
    "source": 46,
    "target": 728,
    "weight": 1
   },
   {
    "source": 129,
    "target": 539,
    "weight": 1
   },
   {
    "source": 251,
    "target": 539,
    "weight": 1
   },
   {
    "source": 58,
    "target": 251,
    "weight": 1
   },
   {
    "source": 58,
    "target": 360,
    "weight": 1
   },
   {
    "source": 251,
    "target": 360,
    "weight": 1
   },
   {
    "source": 251,
    "target": 889,
    "weight": 1
   },
   {
    "source": 49,
    "target": 889,
    "weight": 1
   },
   {
    "source": 129,
    "target": 728,
    "weight": 1
   },
   {
    "source": 317,
    "target": 829,
    "weight": 1
   },
   {
    "source": 230,
    "target": 829,
    "weight": 1
   },
   {
    "source": 230,
    "target": 728,
    "weight": 2
   },
   {
    "source": 1,
    "target": 728,
    "weight": 2
   },
   {
    "source": 1,
    "target": 401,
    "weight": 1
   },
   {
    "source": 401,
    "target": 890,
    "weight": 2
   },
   {
    "source": 890,
    "target": 891,
    "weight": 1
   },
   {
    "source": 891,
    "target": 892,
    "weight": 1
   },
   {
    "source": 151,
    "target": 892,
    "weight": 1
   },
   {
    "source": 151,
    "target": 728,
    "weight": 1
   },
   {
    "source": 728,
    "target": 893,
    "weight": 1
   },
   {
    "source": 728,
    "target": 829,
    "weight": 1
   },
   {
    "source": 46,
    "target": 317,
    "weight": 3
   },
   {
    "source": 1,
    "target": 657,
    "weight": 6
   },
   {
    "source": 657,
    "target": 893,
    "weight": 1
   },
   {
    "source": 562,
    "target": 894,
    "weight": 2
   },
   {
    "source": 657,
    "target": 894,
    "weight": 2
   },
   {
    "source": 148,
    "target": 657,
    "weight": 2
   },
   {
    "source": 562,
    "target": 657,
    "weight": 1
   },
   {
    "source": 148,
    "target": 562,
    "weight": 1
   },
   {
    "source": 148,
    "target": 894,
    "weight": 2
   },
   {
    "source": 2,
    "target": 148,
    "weight": 1
   },
   {
    "source": 148,
    "target": 885,
    "weight": 1
   },
   {
    "source": 49,
    "target": 885,
    "weight": 1
   },
   {
    "source": 155,
    "target": 658,
    "weight": 1
   },
   {
    "source": 96,
    "target": 658,
    "weight": 1
   },
   {
    "source": 96,
    "target": 849,
    "weight": 1
   },
   {
    "source": 514,
    "target": 849,
    "weight": 1
   },
   {
    "source": 40,
    "target": 514,
    "weight": 1
   },
   {
    "source": 657,
    "target": 713,
    "weight": 1
   },
   {
    "source": 478,
    "target": 657,
    "weight": 2
   },
   {
    "source": 478,
    "target": 885,
    "weight": 1
   },
   {
    "source": 745,
    "target": 885,
    "weight": 1
   },
   {
    "source": 713,
    "target": 745,
    "weight": 1
   },
   {
    "source": 0,
    "target": 886,
    "weight": 1
   },
   {
    "source": 720,
    "target": 895,
    "weight": 2
   },
   {
    "source": 886,
    "target": 895,
    "weight": 3
   },
   {
    "source": 193,
    "target": 401,
    "weight": 1
   },
   {
    "source": 193,
    "target": 890,
    "weight": 1
   },
   {
    "source": 156,
    "target": 193,
    "weight": 1
   },
   {
    "source": 156,
    "target": 885,
    "weight": 1
   },
   {
    "source": 885,
    "target": 896,
    "weight": 3
   },
   {
    "source": 193,
    "target": 896,
    "weight": 1
   },
   {
    "source": 193,
    "target": 849,
    "weight": 1
   },
   {
    "source": 459,
    "target": 849,
    "weight": 1
   },
   {
    "source": 459,
    "target": 713,
    "weight": 1
   },
   {
    "source": 46,
    "target": 459,
    "weight": 2
   },
   {
    "source": 96,
    "target": 886,
    "weight": 1
   },
   {
    "source": 96,
    "target": 657,
    "weight": 1
   },
   {
    "source": 1,
    "target": 897,
    "weight": 1
   },
   {
    "source": 886,
    "target": 897,
    "weight": 4
   },
   {
    "source": 657,
    "target": 886,
    "weight": 2
   },
   {
    "source": 46,
    "target": 90,
    "weight": 2
   },
   {
    "source": 4,
    "target": 311,
    "weight": 1
   },
   {
    "source": 657,
    "target": 897,
    "weight": 1
   },
   {
    "source": 1,
    "target": 886,
    "weight": 1
   },
   {
    "source": 40,
    "target": 657,
    "weight": 2
   },
   {
    "source": 1,
    "target": 898,
    "weight": 1
   },
   {
    "source": 728,
    "target": 898,
    "weight": 1
   },
   {
    "source": 1,
    "target": 111,
    "weight": 1
   },
   {
    "source": 46,
    "target": 111,
    "weight": 1
   },
   {
    "source": 47,
    "target": 539,
    "weight": 2
   },
   {
    "source": 4,
    "target": 657,
    "weight": 1
   },
   {
    "source": 1,
    "target": 67,
    "weight": 2
   },
   {
    "source": 67,
    "target": 640,
    "weight": 1
   },
   {
    "source": 269,
    "target": 640,
    "weight": 1
   },
   {
    "source": 269,
    "target": 761,
    "weight": 9
   },
   {
    "source": 214,
    "target": 761,
    "weight": 1
   },
   {
    "source": 640,
    "target": 761,
    "weight": 1
   },
   {
    "source": 214,
    "target": 640,
    "weight": 1
   },
   {
    "source": 380,
    "target": 657,
    "weight": 1
   },
   {
    "source": 230,
    "target": 899,
    "weight": 1
   },
   {
    "source": 657,
    "target": 728,
    "weight": 1
   },
   {
    "source": 1,
    "target": 520,
    "weight": 1
   },
   {
    "source": 38,
    "target": 520,
    "weight": 1
   },
   {
    "source": 59,
    "target": 851,
    "weight": 1
   },
   {
    "source": 46,
    "target": 851,
    "weight": 1
   },
   {
    "source": 26,
    "target": 267,
    "weight": 1
   },
   {
    "source": 267,
    "target": 746,
    "weight": 1
   },
   {
    "source": 214,
    "target": 899,
    "weight": 1
   },
   {
    "source": 166,
    "target": 448,
    "weight": 1
   },
   {
    "source": 38,
    "target": 166,
    "weight": 1
   },
   {
    "source": 38,
    "target": 593,
    "weight": 1
   },
   {
    "source": 57,
    "target": 593,
    "weight": 1
   },
   {
    "source": 40,
    "target": 57,
    "weight": 1
   },
   {
    "source": 635,
    "target": 773,
    "weight": 1
   },
   {
    "source": 148,
    "target": 478,
    "weight": 4
   },
   {
    "source": 46,
    "target": 478,
    "weight": 4
   },
   {
    "source": 40,
    "target": 463,
    "weight": 1
   },
   {
    "source": 40,
    "target": 869,
    "weight": 2
   },
   {
    "source": 40,
    "target": 900,
    "weight": 1
   },
   {
    "source": 173,
    "target": 900,
    "weight": 1
   },
   {
    "source": 40,
    "target": 173,
    "weight": 1
   },
   {
    "source": 148,
    "target": 193,
    "weight": 1
   },
   {
    "source": 604,
    "target": 635,
    "weight": 1
   },
   {
    "source": 38,
    "target": 193,
    "weight": 1
   },
   {
    "source": 38,
    "target": 901,
    "weight": 1
   },
   {
    "source": 885,
    "target": 901,
    "weight": 1
   },
   {
    "source": 885,
    "target": 897,
    "weight": 1
   },
   {
    "source": 895,
    "target": 896,
    "weight": 1
   },
   {
    "source": 6,
    "target": 206,
    "weight": 1
   },
   {
    "source": 206,
    "target": 902,
    "weight": 3
   },
   {
    "source": 902,
    "target": 903,
    "weight": 1
   },
   {
    "source": 787,
    "target": 903,
    "weight": 1
   },
   {
    "source": 292,
    "target": 787,
    "weight": 1
   },
   {
    "source": 292,
    "target": 904,
    "weight": 1
   },
   {
    "source": 904,
    "target": 905,
    "weight": 1
   },
   {
    "source": 165,
    "target": 905,
    "weight": 1
   },
   {
    "source": 165,
    "target": 166,
    "weight": 1
   },
   {
    "source": 166,
    "target": 726,
    "weight": 1
   },
   {
    "source": 195,
    "target": 726,
    "weight": 1
   },
   {
    "source": 3,
    "target": 896,
    "weight": 1
   },
   {
    "source": 115,
    "target": 713,
    "weight": 1
   },
   {
    "source": 713,
    "target": 906,
    "weight": 1
   },
   {
    "source": 539,
    "target": 906,
    "weight": 1
   },
   {
    "source": 115,
    "target": 539,
    "weight": 1
   },
   {
    "source": 115,
    "target": 166,
    "weight": 1
   },
   {
    "source": 166,
    "target": 907,
    "weight": 1
   },
   {
    "source": 115,
    "target": 195,
    "weight": 1
   },
   {
    "source": 122,
    "target": 907,
    "weight": 1
   },
   {
    "source": 143,
    "target": 908,
    "weight": 1
   },
   {
    "source": 122,
    "target": 908,
    "weight": 1
   },
   {
    "source": 904,
    "target": 909,
    "weight": 2
   },
   {
    "source": 904,
    "target": 910,
    "weight": 1
   },
   {
    "source": 910,
    "target": 911,
    "weight": 1
   },
   {
    "source": 238,
    "target": 911,
    "weight": 2
   },
   {
    "source": 238,
    "target": 912,
    "weight": 1
   },
   {
    "source": 912,
    "target": 913,
    "weight": 1
   },
   {
    "source": 143,
    "target": 909,
    "weight": 1
   },
   {
    "source": 913,
    "target": 914,
    "weight": 2
   },
   {
    "source": 913,
    "target": 915,
    "weight": 1
   },
   {
    "source": 915,
    "target": 916,
    "weight": 1
   },
   {
    "source": 238,
    "target": 916,
    "weight": 1
   },
   {
    "source": 165,
    "target": 904,
    "weight": 1
   },
   {
    "source": 165,
    "target": 917,
    "weight": 1
   },
   {
    "source": 238,
    "target": 904,
    "weight": 1
   },
   {
    "source": 904,
    "target": 918,
    "weight": 2
   },
   {
    "source": 140,
    "target": 918,
    "weight": 1
   },
   {
    "source": 140,
    "target": 775,
    "weight": 1
   },
   {
    "source": 775,
    "target": 919,
    "weight": 1
   },
   {
    "source": 919,
    "target": 920,
    "weight": 1
   },
   {
    "source": 254,
    "target": 920,
    "weight": 1
   },
   {
    "source": 254,
    "target": 904,
    "weight": 2
   },
   {
    "source": 904,
    "target": 919,
    "weight": 3
   },
   {
    "source": 919,
    "target": 921,
    "weight": 4
   },
   {
    "source": 308,
    "target": 921,
    "weight": 3
   },
   {
    "source": 218,
    "target": 308,
    "weight": 2
   },
   {
    "source": 218,
    "target": 427,
    "weight": 2
   },
   {
    "source": 909,
    "target": 917,
    "weight": 1
   },
   {
    "source": 206,
    "target": 922,
    "weight": 3
   },
   {
    "source": 922,
    "target": 923,
    "weight": 1
   },
   {
    "source": 285,
    "target": 923,
    "weight": 1
   },
   {
    "source": 285,
    "target": 924,
    "weight": 1
   },
   {
    "source": 924,
    "target": 925,
    "weight": 1
   },
   {
    "source": 302,
    "target": 925,
    "weight": 1
   },
   {
    "source": 302,
    "target": 904,
    "weight": 1
   },
   {
    "source": 904,
    "target": 926,
    "weight": 1
   },
   {
    "source": 292,
    "target": 926,
    "weight": 3
   },
   {
    "source": 206,
    "target": 427,
    "weight": 1
   },
   {
    "source": 444,
    "target": 493,
    "weight": 1
   },
   {
    "source": 444,
    "target": 569,
    "weight": 1
   },
   {
    "source": 569,
    "target": 927,
    "weight": 1
   },
   {
    "source": 155,
    "target": 927,
    "weight": 1
   },
   {
    "source": 110,
    "target": 155,
    "weight": 1
   },
   {
    "source": 110,
    "target": 928,
    "weight": 1
   },
   {
    "source": 913,
    "target": 928,
    "weight": 4
   },
   {
    "source": 411,
    "target": 913,
    "weight": 4
   },
   {
    "source": 292,
    "target": 493,
    "weight": 1
   },
   {
    "source": 929,
    "target": 930,
    "weight": 1
   },
   {
    "source": 930,
    "target": 931,
    "weight": 1
   },
   {
    "source": 931,
    "target": 932,
    "weight": 1
   },
   {
    "source": 88,
    "target": 932,
    "weight": 1
   },
   {
    "source": 88,
    "target": 777,
    "weight": 1
   },
   {
    "source": 777,
    "target": 913,
    "weight": 1
   },
   {
    "source": 254,
    "target": 913,
    "weight": 2
   },
   {
    "source": 129,
    "target": 254,
    "weight": 1
   },
   {
    "source": 129,
    "target": 775,
    "weight": 1
   },
   {
    "source": 26,
    "target": 775,
    "weight": 1
   },
   {
    "source": 26,
    "target": 311,
    "weight": 1
   },
   {
    "source": 311,
    "target": 818,
    "weight": 1
   },
   {
    "source": 521,
    "target": 818,
    "weight": 1
   },
   {
    "source": 88,
    "target": 931,
    "weight": 1
   },
   {
    "source": 411,
    "target": 929,
    "weight": 1
   },
   {
    "source": 904,
    "target": 913,
    "weight": 2
   },
   {
    "source": 521,
    "target": 904,
    "weight": 1
   },
   {
    "source": 913,
    "target": 923,
    "weight": 1
   },
   {
    "source": 599,
    "target": 913,
    "weight": 1
   },
   {
    "source": 14,
    "target": 599,
    "weight": 1
   },
   {
    "source": 14,
    "target": 933,
    "weight": 1
   },
   {
    "source": 933,
    "target": 934,
    "weight": 1
   },
   {
    "source": 934,
    "target": 935,
    "weight": 1
   },
   {
    "source": 11,
    "target": 935,
    "weight": 1
   },
   {
    "source": 11,
    "target": 936,
    "weight": 1
   },
   {
    "source": 869,
    "target": 936,
    "weight": 1
   },
   {
    "source": 759,
    "target": 869,
    "weight": 1
   },
   {
    "source": 759,
    "target": 936,
    "weight": 1
   },
   {
    "source": 414,
    "target": 936,
    "weight": 1
   },
   {
    "source": 254,
    "target": 923,
    "weight": 1
   },
   {
    "source": 916,
    "target": 937,
    "weight": 1
   },
   {
    "source": 916,
    "target": 938,
    "weight": 1
   },
   {
    "source": 14,
    "target": 938,
    "weight": 3
   },
   {
    "source": 14,
    "target": 411,
    "weight": 1
   },
   {
    "source": 414,
    "target": 937,
    "weight": 1
   },
   {
    "source": 411,
    "target": 759,
    "weight": 2
   },
   {
    "source": 759,
    "target": 939,
    "weight": 1
   },
   {
    "source": 140,
    "target": 940,
    "weight": 1
   },
   {
    "source": 140,
    "target": 941,
    "weight": 1
   },
   {
    "source": 928,
    "target": 941,
    "weight": 1
   },
   {
    "source": 939,
    "target": 940,
    "weight": 1
   },
   {
    "source": 140,
    "target": 627,
    "weight": 1
   },
   {
    "source": 140,
    "target": 913,
    "weight": 1
   },
   {
    "source": 49,
    "target": 392,
    "weight": 1
   },
   {
    "source": 140,
    "target": 392,
    "weight": 3
   },
   {
    "source": 140,
    "target": 942,
    "weight": 1
   },
   {
    "source": 942,
    "target": 943,
    "weight": 1
   },
   {
    "source": 49,
    "target": 943,
    "weight": 1
   },
   {
    "source": 49,
    "target": 415,
    "weight": 1
   },
   {
    "source": 415,
    "target": 436,
    "weight": 1
   },
   {
    "source": 436,
    "target": 944,
    "weight": 1
   },
   {
    "source": 944,
    "target": 945,
    "weight": 1
   },
   {
    "source": 928,
    "target": 945,
    "weight": 1
   },
   {
    "source": 392,
    "target": 942,
    "weight": 1
   },
   {
    "source": 392,
    "target": 943,
    "weight": 1
   },
   {
    "source": 140,
    "target": 943,
    "weight": 1
   },
   {
    "source": 49,
    "target": 627,
    "weight": 1
   },
   {
    "source": 140,
    "target": 864,
    "weight": 1
   },
   {
    "source": 864,
    "target": 913,
    "weight": 1
   },
   {
    "source": 111,
    "target": 436,
    "weight": 1
   },
   {
    "source": 111,
    "target": 457,
    "weight": 1
   },
   {
    "source": 457,
    "target": 904,
    "weight": 1
   },
   {
    "source": 436,
    "target": 904,
    "weight": 1
   },
   {
    "source": 436,
    "target": 946,
    "weight": 1
   },
   {
    "source": 441,
    "target": 946,
    "weight": 1
   },
   {
    "source": 441,
    "target": 495,
    "weight": 1
   },
   {
    "source": 495,
    "target": 904,
    "weight": 1
   },
   {
    "source": 166,
    "target": 904,
    "weight": 1
   },
   {
    "source": 206,
    "target": 519,
    "weight": 1
   },
   {
    "source": 902,
    "target": 922,
    "weight": 3
   },
   {
    "source": 256,
    "target": 922,
    "weight": 2
   },
   {
    "source": 256,
    "target": 370,
    "weight": 1
   },
   {
    "source": 370,
    "target": 378,
    "weight": 3
   },
   {
    "source": 166,
    "target": 519,
    "weight": 1
   },
   {
    "source": 370,
    "target": 947,
    "weight": 1
   },
   {
    "source": 210,
    "target": 947,
    "weight": 1
   },
   {
    "source": 210,
    "target": 913,
    "weight": 2
   },
   {
    "source": 26,
    "target": 913,
    "weight": 1
   },
   {
    "source": 26,
    "target": 370,
    "weight": 1
   },
   {
    "source": 2,
    "target": 948,
    "weight": 1
   },
   {
    "source": 164,
    "target": 948,
    "weight": 1
   },
   {
    "source": 39,
    "target": 164,
    "weight": 1
   },
   {
    "source": 39,
    "target": 713,
    "weight": 1
   },
   {
    "source": 312,
    "target": 713,
    "weight": 1
   },
   {
    "source": 110,
    "target": 312,
    "weight": 1
   },
   {
    "source": 65,
    "target": 107,
    "weight": 1
   },
   {
    "source": 107,
    "target": 141,
    "weight": 1
   },
   {
    "source": 141,
    "target": 752,
    "weight": 1
   },
   {
    "source": 0,
    "target": 378,
    "weight": 1
   },
   {
    "source": 59,
    "target": 771,
    "weight": 1
   },
   {
    "source": 38,
    "target": 59,
    "weight": 3
   },
   {
    "source": 38,
    "target": 872,
    "weight": 1
   },
   {
    "source": 40,
    "target": 44,
    "weight": 2
   },
   {
    "source": 752,
    "target": 771,
    "weight": 1
   },
   {
    "source": 9,
    "target": 59,
    "weight": 1
   },
   {
    "source": 8,
    "target": 40,
    "weight": 2
   },
   {
    "source": 40,
    "target": 757,
    "weight": 1
   },
   {
    "source": 34,
    "target": 757,
    "weight": 3
   },
   {
    "source": 34,
    "target": 46,
    "weight": 2
   },
   {
    "source": 562,
    "target": 602,
    "weight": 1
   },
   {
    "source": 44,
    "target": 59,
    "weight": 1
   },
   {
    "source": 38,
    "target": 949,
    "weight": 1
   },
   {
    "source": 746,
    "target": 950,
    "weight": 1
   },
   {
    "source": 623,
    "target": 950,
    "weight": 1
   },
   {
    "source": 602,
    "target": 949,
    "weight": 1
   },
   {
    "source": 67,
    "target": 716,
    "weight": 1
   },
   {
    "source": 716,
    "target": 733,
    "weight": 1
   },
   {
    "source": 47,
    "target": 193,
    "weight": 2
   },
   {
    "source": 2,
    "target": 193,
    "weight": 2
   },
   {
    "source": 2,
    "target": 214,
    "weight": 1
   },
   {
    "source": 67,
    "target": 602,
    "weight": 1
   },
   {
    "source": 47,
    "target": 332,
    "weight": 1
   },
   {
    "source": 332,
    "target": 672,
    "weight": 1
   },
   {
    "source": 214,
    "target": 672,
    "weight": 1
   },
   {
    "source": 38,
    "target": 214,
    "weight": 1
   },
   {
    "source": 38,
    "target": 951,
    "weight": 3
   },
   {
    "source": 227,
    "target": 427,
    "weight": 1
   },
   {
    "source": 214,
    "target": 951,
    "weight": 1
   },
   {
    "source": 47,
    "target": 300,
    "weight": 2
   },
   {
    "source": 72,
    "target": 300,
    "weight": 1
   },
   {
    "source": 72,
    "target": 952,
    "weight": 1
   },
   {
    "source": 40,
    "target": 952,
    "weight": 1
   },
   {
    "source": 38,
    "target": 427,
    "weight": 2
   },
   {
    "source": 67,
    "target": 211,
    "weight": 1
   },
   {
    "source": 67,
    "target": 646,
    "weight": 1
   },
   {
    "source": 646,
    "target": 953,
    "weight": 1
   },
   {
    "source": 951,
    "target": 953,
    "weight": 1
   },
   {
    "source": 40,
    "target": 210,
    "weight": 1
   },
   {
    "source": 67,
    "target": 771,
    "weight": 1
   },
   {
    "source": 1,
    "target": 678,
    "weight": 4
   },
   {
    "source": 38,
    "target": 678,
    "weight": 1
   },
   {
    "source": 47,
    "target": 954,
    "weight": 1
   },
   {
    "source": 115,
    "target": 954,
    "weight": 1
   },
   {
    "source": 115,
    "target": 193,
    "weight": 1
   },
   {
    "source": 24,
    "target": 193,
    "weight": 1
   },
   {
    "source": 771,
    "target": 951,
    "weight": 1
   },
   {
    "source": 31,
    "target": 824,
    "weight": 1
   },
   {
    "source": 31,
    "target": 648,
    "weight": 1
   },
   {
    "source": 648,
    "target": 955,
    "weight": 1
   },
   {
    "source": 67,
    "target": 955,
    "weight": 1
   },
   {
    "source": 47,
    "target": 269,
    "weight": 2
   },
   {
    "source": 761,
    "target": 956,
    "weight": 1
   },
   {
    "source": 2,
    "target": 956,
    "weight": 1
   },
   {
    "source": 2,
    "target": 28,
    "weight": 1
   },
   {
    "source": 24,
    "target": 824,
    "weight": 1
   },
   {
    "source": 67,
    "target": 140,
    "weight": 1
   },
   {
    "source": 60,
    "target": 177,
    "weight": 1
   },
   {
    "source": 38,
    "target": 61,
    "weight": 6
   },
   {
    "source": 47,
    "target": 951,
    "weight": 1
   },
   {
    "source": 2,
    "target": 951,
    "weight": 1
   },
   {
    "source": 2,
    "target": 43,
    "weight": 1
   },
   {
    "source": 43,
    "target": 957,
    "weight": 1
   },
   {
    "source": 64,
    "target": 957,
    "weight": 1
   },
   {
    "source": 64,
    "target": 297,
    "weight": 1
   },
   {
    "source": 28,
    "target": 38,
    "weight": 1
   },
   {
    "source": 914,
    "target": 929,
    "weight": 4
   },
   {
    "source": 929,
    "target": 958,
    "weight": 1
   },
   {
    "source": 958,
    "target": 959,
    "weight": 1
   },
   {
    "source": 320,
    "target": 959,
    "weight": 1
   },
   {
    "source": 292,
    "target": 320,
    "weight": 1
   },
   {
    "source": 292,
    "target": 960,
    "weight": 1
   },
   {
    "source": 905,
    "target": 960,
    "weight": 1
   },
   {
    "source": 81,
    "target": 905,
    "weight": 1
   },
   {
    "source": 81,
    "target": 961,
    "weight": 1
   },
   {
    "source": 31,
    "target": 961,
    "weight": 1
   },
   {
    "source": 31,
    "target": 962,
    "weight": 1
   },
   {
    "source": 962,
    "target": 963,
    "weight": 1
   },
   {
    "source": 872,
    "target": 963,
    "weight": 1
   },
   {
    "source": 872,
    "target": 962,
    "weight": 1
   },
   {
    "source": 297,
    "target": 914,
    "weight": 1
   },
   {
    "source": 218,
    "target": 423,
    "weight": 1
   },
   {
    "source": 301,
    "target": 423,
    "weight": 1
   },
   {
    "source": 301,
    "target": 964,
    "weight": 1
   },
   {
    "source": 964,
    "target": 965,
    "weight": 1
   },
   {
    "source": 965,
    "target": 966,
    "weight": 1
   },
   {
    "source": 929,
    "target": 966,
    "weight": 1
   },
   {
    "source": 929,
    "target": 961,
    "weight": 2
   },
   {
    "source": 961,
    "target": 967,
    "weight": 2
   },
   {
    "source": 218,
    "target": 872,
    "weight": 1
   },
   {
    "source": 301,
    "target": 782,
    "weight": 1
   },
   {
    "source": 292,
    "target": 782,
    "weight": 1
   },
   {
    "source": 81,
    "target": 292,
    "weight": 1
   },
   {
    "source": 26,
    "target": 81,
    "weight": 1
   },
   {
    "source": 26,
    "target": 256,
    "weight": 3
   },
   {
    "source": 238,
    "target": 256,
    "weight": 1
   },
   {
    "source": 238,
    "target": 914,
    "weight": 1
   },
   {
    "source": 914,
    "target": 961,
    "weight": 1
   },
   {
    "source": 26,
    "target": 967,
    "weight": 1
   },
   {
    "source": 301,
    "target": 967,
    "weight": 1
   },
   {
    "source": 45,
    "target": 519,
    "weight": 1
   },
   {
    "source": 45,
    "target": 370,
    "weight": 1
   },
   {
    "source": 204,
    "target": 370,
    "weight": 1
   },
   {
    "source": 204,
    "target": 256,
    "weight": 1
   },
   {
    "source": 140,
    "target": 256,
    "weight": 3
   },
   {
    "source": 140,
    "target": 902,
    "weight": 1
   },
   {
    "source": 256,
    "target": 519,
    "weight": 1
   },
   {
    "source": 6,
    "target": 968,
    "weight": 1
   },
   {
    "source": 141,
    "target": 968,
    "weight": 1
   },
   {
    "source": 3,
    "target": 922,
    "weight": 1
   },
   {
    "source": 969,
    "target": 970,
    "weight": 1
   },
   {
    "source": 38,
    "target": 970,
    "weight": 1
   },
   {
    "source": 193,
    "target": 370,
    "weight": 1
   },
   {
    "source": 141,
    "target": 969,
    "weight": 1
   },
   {
    "source": 510,
    "target": 969,
    "weight": 1
   },
   {
    "source": 38,
    "target": 510,
    "weight": 1
   },
   {
    "source": 47,
    "target": 674,
    "weight": 1
   },
   {
    "source": 211,
    "target": 674,
    "weight": 1
   },
   {
    "source": 211,
    "target": 378,
    "weight": 1
   },
   {
    "source": 206,
    "target": 378,
    "weight": 1
   },
   {
    "source": 206,
    "target": 971,
    "weight": 1
   },
   {
    "source": 140,
    "target": 971,
    "weight": 1
   },
   {
    "source": 690,
    "target": 969,
    "weight": 1
   },
   {
    "source": 47,
    "target": 188,
    "weight": 2
   },
   {
    "source": 188,
    "target": 723,
    "weight": 1
   },
   {
    "source": 38,
    "target": 140,
    "weight": 2
   },
   {
    "source": 317,
    "target": 826,
    "weight": 2
   },
   {
    "source": 54,
    "target": 317,
    "weight": 1
   },
   {
    "source": 609,
    "target": 723,
    "weight": 1
   },
   {
    "source": 46,
    "target": 826,
    "weight": 1
   },
   {
    "source": 46,
    "target": 904,
    "weight": 3
   },
   {
    "source": 609,
    "target": 904,
    "weight": 1
   },
   {
    "source": 317,
    "target": 740,
    "weight": 1
   },
   {
    "source": 740,
    "target": 972,
    "weight": 1
   },
   {
    "source": 81,
    "target": 972,
    "weight": 1
   },
   {
    "source": 81,
    "target": 973,
    "weight": 1
   },
   {
    "source": 973,
    "target": 974,
    "weight": 1
   },
   {
    "source": 140,
    "target": 974,
    "weight": 1
   },
   {
    "source": 2,
    "target": 54,
    "weight": 1
   },
   {
    "source": 292,
    "target": 317,
    "weight": 1
   },
   {
    "source": 122,
    "target": 292,
    "weight": 1
   },
   {
    "source": 122,
    "target": 904,
    "weight": 1
   },
   {
    "source": 140,
    "target": 904,
    "weight": 2
   },
   {
    "source": 39,
    "target": 140,
    "weight": 1
   },
   {
    "source": 39,
    "target": 913,
    "weight": 1
   },
   {
    "source": 646,
    "target": 913,
    "weight": 1
   },
   {
    "source": 646,
    "target": 975,
    "weight": 1
   },
   {
    "source": 297,
    "target": 975,
    "weight": 1
   },
   {
    "source": 297,
    "target": 646,
    "weight": 1
   },
   {
    "source": 140,
    "target": 826,
    "weight": 1
   },
   {
    "source": 969,
    "target": 976,
    "weight": 1
   },
   {
    "source": 650,
    "target": 969,
    "weight": 1
   },
   {
    "source": 650,
    "target": 904,
    "weight": 1
   },
   {
    "source": 47,
    "target": 977,
    "weight": 1
   },
   {
    "source": 297,
    "target": 976,
    "weight": 1
   },
   {
    "source": 650,
    "target": 910,
    "weight": 1
   },
   {
    "source": 910,
    "target": 919,
    "weight": 1
   },
   {
    "source": 919,
    "target": 978,
    "weight": 1
   },
   {
    "source": 128,
    "target": 978,
    "weight": 1
   },
   {
    "source": 46,
    "target": 978,
    "weight": 1
   },
   {
    "source": 650,
    "target": 977,
    "weight": 1
   },
   {
    "source": 46,
    "target": 857,
    "weight": 2
   },
   {
    "source": 46,
    "target": 166,
    "weight": 1
   },
   {
    "source": 166,
    "target": 911,
    "weight": 1
   },
   {
    "source": 238,
    "target": 921,
    "weight": 1
   },
   {
    "source": 519,
    "target": 979,
    "weight": 1
   },
   {
    "source": 510,
    "target": 519,
    "weight": 2
   },
   {
    "source": 510,
    "target": 904,
    "weight": 1
   },
   {
    "source": 49,
    "target": 904,
    "weight": 1
   },
   {
    "source": 46,
    "target": 498,
    "weight": 1
   },
   {
    "source": 498,
    "target": 786,
    "weight": 1
   },
   {
    "source": 148,
    "target": 904,
    "weight": 1
   },
   {
    "source": 921,
    "target": 979,
    "weight": 1
   },
   {
    "source": 267,
    "target": 969,
    "weight": 1
   },
   {
    "source": 179,
    "target": 969,
    "weight": 1
   },
   {
    "source": 179,
    "target": 902,
    "weight": 1
   },
   {
    "source": 206,
    "target": 904,
    "weight": 2
   },
   {
    "source": 904,
    "target": 980,
    "weight": 1
   },
   {
    "source": 218,
    "target": 980,
    "weight": 1
   },
   {
    "source": 256,
    "target": 919,
    "weight": 2
   },
   {
    "source": 911,
    "target": 919,
    "weight": 1
   },
   {
    "source": 214,
    "target": 911,
    "weight": 1
   },
   {
    "source": 214,
    "target": 921,
    "weight": 1
   },
   {
    "source": 254,
    "target": 921,
    "weight": 1
   },
   {
    "source": 267,
    "target": 904,
    "weight": 1
   },
   {
    "source": 206,
    "target": 969,
    "weight": 1
   },
   {
    "source": 217,
    "target": 922,
    "weight": 1
   },
   {
    "source": 217,
    "target": 256,
    "weight": 1
   },
   {
    "source": 217,
    "target": 919,
    "weight": 1
   },
   {
    "source": 254,
    "target": 969,
    "weight": 1
   },
   {
    "source": 210,
    "target": 941,
    "weight": 1
   },
   {
    "source": 913,
    "target": 981,
    "weight": 1
   },
   {
    "source": 390,
    "target": 981,
    "weight": 1
   },
   {
    "source": 390,
    "target": 920,
    "weight": 1
   },
   {
    "source": 920,
    "target": 928,
    "weight": 1
   },
   {
    "source": 928,
    "target": 929,
    "weight": 1
   },
   {
    "source": 256,
    "target": 961,
    "weight": 1
   },
   {
    "source": 390,
    "target": 928,
    "weight": 1
   },
   {
    "source": 390,
    "target": 929,
    "weight": 1
   },
   {
    "source": 920,
    "target": 929,
    "weight": 1
   },
   {
    "source": 919,
    "target": 941,
    "weight": 1
   },
   {
    "source": 759,
    "target": 982,
    "weight": 1
   },
   {
    "source": 759,
    "target": 913,
    "weight": 1
   },
   {
    "source": 913,
    "target": 936,
    "weight": 1
   },
   {
    "source": 936,
    "target": 983,
    "weight": 1
   },
   {
    "source": 256,
    "target": 982,
    "weight": 1
   },
   {
    "source": 904,
    "target": 922,
    "weight": 1
   },
   {
    "source": 47,
    "target": 922,
    "weight": 2
   },
   {
    "source": 47,
    "target": 148,
    "weight": 1
   },
   {
    "source": 148,
    "target": 423,
    "weight": 1
   },
   {
    "source": 206,
    "target": 423,
    "weight": 1
   },
   {
    "source": 904,
    "target": 984,
    "weight": 1
   },
   {
    "source": 984,
    "target": 985,
    "weight": 1
   },
   {
    "source": 759,
    "target": 985,
    "weight": 1
   },
   {
    "source": 759,
    "target": 984,
    "weight": 1
   },
   {
    "source": 46,
    "target": 983,
    "weight": 1
   },
   {
    "source": 348,
    "target": 969,
    "weight": 1
   },
   {
    "source": 348,
    "target": 857,
    "weight": 1
   },
   {
    "source": 515,
    "target": 857,
    "weight": 1
   },
   {
    "source": 40,
    "target": 515,
    "weight": 1
   },
   {
    "source": 40,
    "target": 971,
    "weight": 3
   },
   {
    "source": 472,
    "target": 971,
    "weight": 1
   },
   {
    "source": 378,
    "target": 902,
    "weight": 1
   },
   {
    "source": 515,
    "target": 971,
    "weight": 1
   },
   {
    "source": 969,
    "target": 984,
    "weight": 1
   },
   {
    "source": 47,
    "target": 972,
    "weight": 1
   },
   {
    "source": 46,
    "target": 972,
    "weight": 1
   },
   {
    "source": 46,
    "target": 140,
    "weight": 3
   },
   {
    "source": 593,
    "target": 913,
    "weight": 1
   },
   {
    "source": 593,
    "target": 986,
    "weight": 1
   },
   {
    "source": 986,
    "target": 987,
    "weight": 1
   },
   {
    "source": 47,
    "target": 206,
    "weight": 1
   },
   {
    "source": 403,
    "target": 988,
    "weight": 1
   },
   {
    "source": 403,
    "target": 904,
    "weight": 1
   },
   {
    "source": 904,
    "target": 989,
    "weight": 1
   },
   {
    "source": 416,
    "target": 989,
    "weight": 1
   },
   {
    "source": 148,
    "target": 416,
    "weight": 1
   },
   {
    "source": 46,
    "target": 919,
    "weight": 3
   },
   {
    "source": 436,
    "target": 919,
    "weight": 1
   },
   {
    "source": 904,
    "target": 988,
    "weight": 1
   },
   {
    "source": 46,
    "target": 416,
    "weight": 1
   },
   {
    "source": 987,
    "target": 988,
    "weight": 1
   },
   {
    "source": 403,
    "target": 990,
    "weight": 1
   },
   {
    "source": 403,
    "target": 913,
    "weight": 1
   },
   {
    "source": 436,
    "target": 990,
    "weight": 1
   },
   {
    "source": 2,
    "target": 969,
    "weight": 5
   },
   {
    "source": 0,
    "target": 913,
    "weight": 1
   },
   {
    "source": 47,
    "target": 902,
    "weight": 2
   },
   {
    "source": 303,
    "target": 902,
    "weight": 1
   },
   {
    "source": 303,
    "target": 991,
    "weight": 3
   },
   {
    "source": 148,
    "target": 991,
    "weight": 3
   },
   {
    "source": 46,
    "target": 991,
    "weight": 3
   },
   {
    "source": 38,
    "target": 969,
    "weight": 4
   },
   {
    "source": 46,
    "target": 990,
    "weight": 3
   },
   {
    "source": 148,
    "target": 990,
    "weight": 3
   },
   {
    "source": 6,
    "target": 969,
    "weight": 1
   },
   {
    "source": 3,
    "target": 148,
    "weight": 2
   },
   {
    "source": 303,
    "target": 922,
    "weight": 1
   },
   {
    "source": 0,
    "target": 148,
    "weight": 1
   },
   {
    "source": 47,
    "target": 515,
    "weight": 1
   },
   {
    "source": 378,
    "target": 515,
    "weight": 2
   },
   {
    "source": 378,
    "target": 782,
    "weight": 1
   },
   {
    "source": 303,
    "target": 782,
    "weight": 1
   },
   {
    "source": 515,
    "target": 782,
    "weight": 1
   },
   {
    "source": 6,
    "target": 238,
    "weight": 1
   },
   {
    "source": 238,
    "target": 928,
    "weight": 1
   },
   {
    "source": 759,
    "target": 928,
    "weight": 1
   },
   {
    "source": 46,
    "target": 992,
    "weight": 1
   },
   {
    "source": 922,
    "target": 992,
    "weight": 1
   },
   {
    "source": 922,
    "target": 993,
    "weight": 1
   },
   {
    "source": 129,
    "target": 993,
    "weight": 1
   },
   {
    "source": 129,
    "target": 872,
    "weight": 1
   },
   {
    "source": 872,
    "target": 913,
    "weight": 1
   },
   {
    "source": 238,
    "target": 913,
    "weight": 1
   },
   {
    "source": 238,
    "target": 902,
    "weight": 1
   },
   {
    "source": 47,
    "target": 969,
    "weight": 1
   },
   {
    "source": 317,
    "target": 759,
    "weight": 1
   },
   {
    "source": 140,
    "target": 919,
    "weight": 1
   },
   {
    "source": 140,
    "target": 254,
    "weight": 1
   },
   {
    "source": 254,
    "target": 498,
    "weight": 1
   },
   {
    "source": 128,
    "target": 498,
    "weight": 1
   },
   {
    "source": 128,
    "target": 650,
    "weight": 1
   },
   {
    "source": 360,
    "target": 650,
    "weight": 1
   },
   {
    "source": 141,
    "target": 360,
    "weight": 1
   },
   {
    "source": 141,
    "target": 919,
    "weight": 1
   },
   {
    "source": 498,
    "target": 650,
    "weight": 1
   },
   {
    "source": 46,
    "target": 969,
    "weight": 1
   },
   {
    "source": 46,
    "target": 869,
    "weight": 1
   },
   {
    "source": 47,
    "target": 994,
    "weight": 1
   },
   {
    "source": 992,
    "target": 994,
    "weight": 1
   },
   {
    "source": 869,
    "target": 992,
    "weight": 1
   },
   {
    "source": 857,
    "target": 869,
    "weight": 1
   },
   {
    "source": 206,
    "target": 857,
    "weight": 1
   },
   {
    "source": 206,
    "target": 994,
    "weight": 1
   },
   {
    "source": 902,
    "target": 904,
    "weight": 1
   },
   {
    "source": 918,
    "target": 919,
    "weight": 1
   },
   {
    "source": 152,
    "target": 921,
    "weight": 1
   },
   {
    "source": 902,
    "target": 994,
    "weight": 1
   },
   {
    "source": 913,
    "target": 922,
    "weight": 1
   },
   {
    "source": 913,
    "target": 941,
    "weight": 1
   },
   {
    "source": 759,
    "target": 941,
    "weight": 1
   },
   {
    "source": 646,
    "target": 759,
    "weight": 1
   },
   {
    "source": 411,
    "target": 646,
    "weight": 1
   },
   {
    "source": 702,
    "target": 857,
    "weight": 1
   },
   {
    "source": 10,
    "target": 857,
    "weight": 1
   },
   {
    "source": 10,
    "target": 715,
    "weight": 1
   },
   {
    "source": 715,
    "target": 919,
    "weight": 1
   },
   {
    "source": 357,
    "target": 919,
    "weight": 1
   },
   {
    "source": 357,
    "target": 904,
    "weight": 1
   },
   {
    "source": 904,
    "target": 995,
    "weight": 1
   },
   {
    "source": 759,
    "target": 995,
    "weight": 1
   },
   {
    "source": 411,
    "target": 702,
    "weight": 1
   },
   {
    "source": 310,
    "target": 747,
    "weight": 1
   },
   {
    "source": 129,
    "target": 747,
    "weight": 1
   },
   {
    "source": 31,
    "target": 129,
    "weight": 1
   },
   {
    "source": 31,
    "target": 971,
    "weight": 1
   },
   {
    "source": 310,
    "target": 928,
    "weight": 1
   },
   {
    "source": 69,
    "target": 946,
    "weight": 1
   },
   {
    "source": 38,
    "target": 69,
    "weight": 3
   },
   {
    "source": 38,
    "target": 515,
    "weight": 1
   },
   {
    "source": 186,
    "target": 515,
    "weight": 1
   },
   {
    "source": 40,
    "target": 45,
    "weight": 1
   },
   {
    "source": 650,
    "target": 842,
    "weight": 1
   },
   {
    "source": 45,
    "target": 842,
    "weight": 1
   },
   {
    "source": 40,
    "target": 946,
    "weight": 1
   },
   {
    "source": 28,
    "target": 67,
    "weight": 1
   },
   {
    "source": 40,
    "target": 273,
    "weight": 1
   },
   {
    "source": 40,
    "target": 996,
    "weight": 2
   },
   {
    "source": 996,
    "target": 997,
    "weight": 1
   },
   {
    "source": 129,
    "target": 997,
    "weight": 1
   },
   {
    "source": 60,
    "target": 129,
    "weight": 1
   },
   {
    "source": 67,
    "target": 842,
    "weight": 1
   },
   {
    "source": 38,
    "target": 406,
    "weight": 1
   },
   {
    "source": 38,
    "target": 998,
    "weight": 2
   },
   {
    "source": 193,
    "target": 998,
    "weight": 1
   },
   {
    "source": 3,
    "target": 254,
    "weight": 3
   },
   {
    "source": 3,
    "target": 996,
    "weight": 2
   },
   {
    "source": 254,
    "target": 996,
    "weight": 1
   },
   {
    "source": 406,
    "target": 951,
    "weight": 1
   },
   {
    "source": 62,
    "target": 122,
    "weight": 1
   },
   {
    "source": 122,
    "target": 996,
    "weight": 1
   },
   {
    "source": 61,
    "target": 137,
    "weight": 1
   },
   {
    "source": 38,
    "target": 137,
    "weight": 2
   },
   {
    "source": 141,
    "target": 663,
    "weight": 1
   },
   {
    "source": 62,
    "target": 141,
    "weight": 1
   },
   {
    "source": 3,
    "target": 62,
    "weight": 2
   },
   {
    "source": 999,
    "target": 1000,
    "weight": 1
   },
   {
    "source": 1000,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 1001,
    "target": 1002,
    "weight": 1
   },
   {
    "source": 354,
    "target": 1002,
    "weight": 1
   },
   {
    "source": 354,
    "target": 918,
    "weight": 1
   },
   {
    "source": 918,
    "target": 1003,
    "weight": 1
   },
   {
    "source": 221,
    "target": 1003,
    "weight": 1
   },
   {
    "source": 221,
    "target": 406,
    "weight": 4
   },
   {
    "source": 406,
    "target": 1003,
    "weight": 1
   },
   {
    "source": 996,
    "target": 999,
    "weight": 1
   },
   {
    "source": 221,
    "target": 869,
    "weight": 1
   },
   {
    "source": 515,
    "target": 869,
    "weight": 1
   },
   {
    "source": 124,
    "target": 515,
    "weight": 1
   },
   {
    "source": 124,
    "target": 256,
    "weight": 1
   },
   {
    "source": 256,
    "target": 715,
    "weight": 1
   },
   {
    "source": 715,
    "target": 1004,
    "weight": 1
   },
   {
    "source": 1004,
    "target": 1005,
    "weight": 1
   },
   {
    "source": 1005,
    "target": 1006,
    "weight": 1
   },
   {
    "source": 215,
    "target": 432,
    "weight": 1
   },
   {
    "source": 96,
    "target": 432,
    "weight": 1
   },
   {
    "source": 96,
    "target": 221,
    "weight": 1
   },
   {
    "source": 40,
    "target": 281,
    "weight": 3
   },
   {
    "source": 40,
    "target": 354,
    "weight": 4
   },
   {
    "source": 220,
    "target": 354,
    "weight": 1
   },
   {
    "source": 221,
    "target": 354,
    "weight": 4
   },
   {
    "source": 40,
    "target": 1007,
    "weight": 1
   },
   {
    "source": 378,
    "target": 1007,
    "weight": 1
   },
   {
    "source": 221,
    "target": 378,
    "weight": 1
   },
   {
    "source": 406,
    "target": 733,
    "weight": 1
   },
   {
    "source": 733,
    "target": 918,
    "weight": 1
   },
   {
    "source": 327,
    "target": 918,
    "weight": 1
   },
   {
    "source": 327,
    "target": 996,
    "weight": 1
   },
   {
    "source": 46,
    "target": 996,
    "weight": 1
   },
   {
    "source": 46,
    "target": 221,
    "weight": 3
   },
   {
    "source": 221,
    "target": 1008,
    "weight": 1
   },
   {
    "source": 215,
    "target": 1006,
    "weight": 1
   },
   {
    "source": 394,
    "target": 733,
    "weight": 1
   },
   {
    "source": 281,
    "target": 394,
    "weight": 1
   },
   {
    "source": 281,
    "target": 1009,
    "weight": 1
   },
   {
    "source": 733,
    "target": 1008,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1010,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1009,
    "weight": 1
   },
   {
    "source": 662,
    "target": 760,
    "weight": 1
   },
   {
    "source": 214,
    "target": 662,
    "weight": 1
   },
   {
    "source": 214,
    "target": 281,
    "weight": 2
   },
   {
    "source": 281,
    "target": 1011,
    "weight": 1
   },
   {
    "source": 129,
    "target": 1011,
    "weight": 1
   },
   {
    "source": 90,
    "target": 129,
    "weight": 2
   },
   {
    "source": 760,
    "target": 1010,
    "weight": 1
   },
   {
    "source": 227,
    "target": 281,
    "weight": 1
   },
   {
    "source": 68,
    "target": 227,
    "weight": 1
   },
   {
    "source": 68,
    "target": 221,
    "weight": 1
   },
   {
    "source": 221,
    "target": 439,
    "weight": 1
   },
   {
    "source": 115,
    "target": 439,
    "weight": 1
   },
   {
    "source": 115,
    "target": 256,
    "weight": 3
   },
   {
    "source": 281,
    "target": 1012,
    "weight": 1
   },
   {
    "source": 281,
    "target": 1013,
    "weight": 1
   },
   {
    "source": 569,
    "target": 1013,
    "weight": 1
   },
   {
    "source": 214,
    "target": 569,
    "weight": 1
   },
   {
    "source": 256,
    "target": 1012,
    "weight": 1
   },
   {
    "source": 5,
    "target": 214,
    "weight": 2
   },
   {
    "source": 221,
    "target": 281,
    "weight": 1
   },
   {
    "source": 479,
    "target": 656,
    "weight": 3
   },
   {
    "source": 40,
    "target": 479,
    "weight": 1
   },
   {
    "source": 46,
    "target": 442,
    "weight": 1
   },
   {
    "source": 442,
    "target": 706,
    "weight": 1
   },
   {
    "source": 46,
    "target": 691,
    "weight": 3
   },
   {
    "source": 479,
    "target": 691,
    "weight": 1
   },
   {
    "source": 281,
    "target": 423,
    "weight": 1
   },
   {
    "source": 250,
    "target": 423,
    "weight": 1
   },
   {
    "source": 250,
    "target": 1014,
    "weight": 1
   },
   {
    "source": 97,
    "target": 1014,
    "weight": 1
   },
   {
    "source": 97,
    "target": 1008,
    "weight": 1
   },
   {
    "source": 1008,
    "target": 1015,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1015,
    "weight": 1
   },
   {
    "source": 46,
    "target": 743,
    "weight": 1
   },
   {
    "source": 281,
    "target": 656,
    "weight": 1
   },
   {
    "source": 272,
    "target": 281,
    "weight": 2
   },
   {
    "source": 281,
    "target": 655,
    "weight": 1
   },
   {
    "source": 272,
    "target": 743,
    "weight": 1
   },
   {
    "source": 38,
    "target": 219,
    "weight": 3
   },
   {
    "source": 47,
    "target": 221,
    "weight": 1
   },
   {
    "source": 40,
    "target": 987,
    "weight": 1
   },
   {
    "source": 849,
    "target": 987,
    "weight": 1
   },
   {
    "source": 46,
    "target": 849,
    "weight": 1
   },
   {
    "source": 46,
    "target": 281,
    "weight": 1
   },
   {
    "source": 478,
    "target": 1016,
    "weight": 1
   },
   {
    "source": 442,
    "target": 1016,
    "weight": 1
   },
   {
    "source": 478,
    "target": 894,
    "weight": 1
   },
   {
    "source": 281,
    "target": 479,
    "weight": 1
   },
   {
    "source": 40,
    "target": 478,
    "weight": 1
   },
   {
    "source": 478,
    "target": 691,
    "weight": 2
   },
   {
    "source": 112,
    "target": 781,
    "weight": 1
   },
   {
    "source": 112,
    "target": 150,
    "weight": 1
   },
   {
    "source": 38,
    "target": 150,
    "weight": 3
   },
   {
    "source": 38,
    "target": 281,
    "weight": 1
   },
   {
    "source": 266,
    "target": 281,
    "weight": 2
   },
   {
    "source": 266,
    "target": 657,
    "weight": 1
   },
   {
    "source": 656,
    "target": 691,
    "weight": 2
   },
   {
    "source": 656,
    "target": 781,
    "weight": 1
   },
   {
    "source": 224,
    "target": 691,
    "weight": 1
   },
   {
    "source": 224,
    "target": 281,
    "weight": 1
   },
   {
    "source": 478,
    "target": 656,
    "weight": 1
   },
   {
    "source": 281,
    "target": 1017,
    "weight": 3
   },
   {
    "source": 38,
    "target": 1017,
    "weight": 3
   },
   {
    "source": 59,
    "target": 1018,
    "weight": 1
   },
   {
    "source": 1018,
    "target": 1019,
    "weight": 2
   },
   {
    "source": 723,
    "target": 1019,
    "weight": 1
   },
   {
    "source": 723,
    "target": 1020,
    "weight": 1
   },
   {
    "source": 723,
    "target": 1018,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 59,
    "target": 1021,
    "weight": 1
   },
   {
    "source": 59,
    "target": 864,
    "weight": 1
   },
   {
    "source": 663,
    "target": 864,
    "weight": 1
   },
   {
    "source": 663,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 460,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 246,
    "target": 460,
    "weight": 1
   },
   {
    "source": 1020,
    "target": 1021,
    "weight": 1
   },
   {
    "source": 59,
    "target": 689,
    "weight": 1
   },
   {
    "source": 689,
    "target": 690,
    "weight": 1
   },
   {
    "source": 656,
    "target": 690,
    "weight": 1
   },
   {
    "source": 656,
    "target": 1022,
    "weight": 1
   },
   {
    "source": 1022,
    "target": 1023,
    "weight": 1
   },
   {
    "source": 1023,
    "target": 1024,
    "weight": 1
   },
   {
    "source": 442,
    "target": 1024,
    "weight": 1
   },
   {
    "source": 442,
    "target": 893,
    "weight": 1
   },
   {
    "source": 893,
    "target": 952,
    "weight": 1
   },
   {
    "source": 656,
    "target": 952,
    "weight": 1
   },
   {
    "source": 59,
    "target": 246,
    "weight": 1
   },
   {
    "source": 215,
    "target": 345,
    "weight": 1
   },
   {
    "source": 345,
    "target": 1025,
    "weight": 1
   },
   {
    "source": 120,
    "target": 1025,
    "weight": 1
   },
   {
    "source": 120,
    "target": 1026,
    "weight": 1
   },
   {
    "source": 893,
    "target": 1026,
    "weight": 1
   },
   {
    "source": 215,
    "target": 656,
    "weight": 1
   },
   {
    "source": 656,
    "target": 1020,
    "weight": 1
   },
   {
    "source": 46,
    "target": 829,
    "weight": 1
   },
   {
    "source": 38,
    "target": 829,
    "weight": 1
   },
   {
    "source": 38,
    "target": 656,
    "weight": 2
   },
   {
    "source": 656,
    "target": 792,
    "weight": 1
   },
   {
    "source": 656,
    "target": 829,
    "weight": 1
   },
   {
    "source": 893,
    "target": 1020,
    "weight": 1
   },
   {
    "source": 432,
    "target": 893,
    "weight": 1
   },
   {
    "source": 281,
    "target": 893,
    "weight": 1
   },
   {
    "source": 432,
    "target": 792,
    "weight": 1
   },
   {
    "source": 354,
    "target": 866,
    "weight": 1
   },
   {
    "source": 110,
    "target": 866,
    "weight": 1
   },
   {
    "source": 656,
    "target": 996,
    "weight": 1
   },
   {
    "source": 6,
    "target": 996,
    "weight": 1
   },
   {
    "source": 354,
    "target": 996,
    "weight": 1
   },
   {
    "source": 40,
    "target": 108,
    "weight": 1
   },
   {
    "source": 8,
    "target": 108,
    "weight": 1
   },
   {
    "source": 3,
    "target": 110,
    "weight": 1
   },
   {
    "source": 165,
    "target": 764,
    "weight": 1
   },
   {
    "source": 165,
    "target": 1027,
    "weight": 1
   },
   {
    "source": 996,
    "target": 1027,
    "weight": 1
   },
   {
    "source": 267,
    "target": 996,
    "weight": 1
   },
   {
    "source": 8,
    "target": 267,
    "weight": 1
   },
   {
    "source": 38,
    "target": 916,
    "weight": 1
   },
   {
    "source": 165,
    "target": 996,
    "weight": 1
   },
   {
    "source": 8,
    "target": 764,
    "weight": 1
   },
   {
    "source": 385,
    "target": 1028,
    "weight": 1
   },
   {
    "source": 108,
    "target": 1028,
    "weight": 1
   },
   {
    "source": 108,
    "target": 899,
    "weight": 1
   },
   {
    "source": 38,
    "target": 899,
    "weight": 1
   },
   {
    "source": 62,
    "target": 103,
    "weight": 1
   },
   {
    "source": 385,
    "target": 916,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 27,
    "target": 47,
    "weight": 9
   },
   {
    "source": 165,
    "target": 273,
    "weight": 1
   },
   {
    "source": 93,
    "target": 116,
    "weight": 1
   },
   {
    "source": 65,
    "target": 93,
    "weight": 1
   },
   {
    "source": 281,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 286,
    "target": 822,
    "weight": 1
   },
   {
    "source": 193,
    "target": 286,
    "weight": 1
   },
   {
    "source": 193,
    "target": 918,
    "weight": 1
   },
   {
    "source": 432,
    "target": 918,
    "weight": 2
   },
   {
    "source": 432,
    "target": 441,
    "weight": 1
   },
   {
    "source": 441,
    "target": 764,
    "weight": 1
   },
   {
    "source": 65,
    "target": 822,
    "weight": 1
   },
   {
    "source": 2,
    "target": 281,
    "weight": 1
   },
   {
    "source": 281,
    "target": 918,
    "weight": 2
   },
   {
    "source": 432,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 764,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 691,
    "target": 764,
    "weight": 1
   },
   {
    "source": 2,
    "target": 764,
    "weight": 3
   },
   {
    "source": 691,
    "target": 969,
    "weight": 1
   },
   {
    "source": 692,
    "target": 1029,
    "weight": 1
   },
   {
    "source": 996,
    "target": 1029,
    "weight": 1
   },
   {
    "source": 432,
    "target": 996,
    "weight": 1
   },
   {
    "source": 46,
    "target": 432,
    "weight": 1
   },
   {
    "source": 46,
    "target": 354,
    "weight": 1
   },
   {
    "source": 656,
    "target": 969,
    "weight": 1
   },
   {
    "source": 96,
    "target": 1017,
    "weight": 2
   },
   {
    "source": 38,
    "target": 96,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 317,
    "target": 893,
    "weight": 1
   },
   {
    "source": 893,
    "target": 1030,
    "weight": 1
   },
   {
    "source": 696,
    "target": 1030,
    "weight": 1
   },
   {
    "source": 696,
    "target": 1031,
    "weight": 1
   },
   {
    "source": 764,
    "target": 1031,
    "weight": 1
   },
   {
    "source": 764,
    "target": 893,
    "weight": 1
   },
   {
    "source": 317,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 110,
    "target": 996,
    "weight": 1
   },
   {
    "source": 173,
    "target": 996,
    "weight": 2
   },
   {
    "source": 173,
    "target": 918,
    "weight": 2
   },
   {
    "source": 38,
    "target": 918,
    "weight": 1
   },
   {
    "source": 62,
    "target": 432,
    "weight": 1
   },
   {
    "source": 110,
    "target": 893,
    "weight": 1
   },
   {
    "source": 364,
    "target": 764,
    "weight": 1
   },
   {
    "source": 364,
    "target": 718,
    "weight": 1
   },
   {
    "source": 8,
    "target": 718,
    "weight": 1
   },
   {
    "source": 8,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 173,
    "target": 1017,
    "weight": 1
   },
   {
    "source": 281,
    "target": 995,
    "weight": 1
   },
   {
    "source": 38,
    "target": 995,
    "weight": 1
   },
   {
    "source": 432,
    "target": 764,
    "weight": 1
   },
   {
    "source": 364,
    "target": 1032,
    "weight": 1
   },
   {
    "source": 62,
    "target": 1032,
    "weight": 1
   },
   {
    "source": 62,
    "target": 364,
    "weight": 1
   },
   {
    "source": 460,
    "target": 893,
    "weight": 1
   },
   {
    "source": 332,
    "target": 893,
    "weight": 1
   },
   {
    "source": 33,
    "target": 151,
    "weight": 1
   },
   {
    "source": 151,
    "target": 408,
    "weight": 1
   },
   {
    "source": 124,
    "target": 408,
    "weight": 1
   },
   {
    "source": 38,
    "target": 460,
    "weight": 1
   },
   {
    "source": 129,
    "target": 220,
    "weight": 1
   },
   {
    "source": 220,
    "target": 662,
    "weight": 1
   },
   {
    "source": 414,
    "target": 662,
    "weight": 1
   },
   {
    "source": 414,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 1001,
    "target": 1033,
    "weight": 1
   },
   {
    "source": 215,
    "target": 1033,
    "weight": 1
   },
   {
    "source": 220,
    "target": 414,
    "weight": 1
   },
   {
    "source": 29,
    "target": 111,
    "weight": 1
   },
   {
    "source": 111,
    "target": 1034,
    "weight": 1
   },
   {
    "source": 8,
    "target": 1034,
    "weight": 1
   },
   {
    "source": 2,
    "target": 173,
    "weight": 1
   },
   {
    "source": 173,
    "target": 281,
    "weight": 1
   },
   {
    "source": 281,
    "target": 287,
    "weight": 1
   },
   {
    "source": 173,
    "target": 287,
    "weight": 1
   },
   {
    "source": 29,
    "target": 215,
    "weight": 1
   },
   {
    "source": 38,
    "target": 764,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1035,
    "weight": 1
   },
   {
    "source": 164,
    "target": 1035,
    "weight": 1
   },
   {
    "source": 40,
    "target": 48,
    "weight": 1
   },
   {
    "source": 287,
    "target": 764,
    "weight": 1
   },
   {
    "source": 62,
    "target": 996,
    "weight": 1
   },
   {
    "source": 173,
    "target": 1036,
    "weight": 1
   },
   {
    "source": 746,
    "target": 1036,
    "weight": 1
   },
   {
    "source": 173,
    "target": 746,
    "weight": 1
   },
   {
    "source": 38,
    "target": 220,
    "weight": 1
   },
   {
    "source": 793,
    "target": 1037,
    "weight": 1
   },
   {
    "source": 61,
    "target": 793,
    "weight": 1
   },
   {
    "source": 61,
    "target": 792,
    "weight": 1
   },
   {
    "source": 792,
    "target": 1038,
    "weight": 1
   },
   {
    "source": 62,
    "target": 1038,
    "weight": 1
   },
   {
    "source": 62,
    "target": 165,
    "weight": 1
   },
   {
    "source": 165,
    "target": 1039,
    "weight": 1
   },
   {
    "source": 746,
    "target": 1037,
    "weight": 1
   },
   {
    "source": 206,
    "target": 279,
    "weight": 1
   },
   {
    "source": 279,
    "target": 671,
    "weight": 1
   },
   {
    "source": 671,
    "target": 1040,
    "weight": 2
   },
   {
    "source": 206,
    "target": 1039,
    "weight": 1
   },
   {
    "source": 124,
    "target": 680,
    "weight": 1
   },
   {
    "source": 58,
    "target": 680,
    "weight": 1
   },
   {
    "source": 58,
    "target": 1041,
    "weight": 1
   },
   {
    "source": 677,
    "target": 1041,
    "weight": 1
   },
   {
    "source": 677,
    "target": 1042,
    "weight": 1
   },
   {
    "source": 1042,
    "target": 1043,
    "weight": 1
   },
   {
    "source": 93,
    "target": 1043,
    "weight": 1
   },
   {
    "source": 93,
    "target": 269,
    "weight": 1
   },
   {
    "source": 124,
    "target": 1040,
    "weight": 1
   },
   {
    "source": 2,
    "target": 49,
    "weight": 1
   },
   {
    "source": 49,
    "target": 425,
    "weight": 1
   },
   {
    "source": 0,
    "target": 26,
    "weight": 1
   },
   {
    "source": 28,
    "target": 326,
    "weight": 1
   },
   {
    "source": 26,
    "target": 326,
    "weight": 1
   },
   {
    "source": 152,
    "target": 750,
    "weight": 1
   },
   {
    "source": 728,
    "target": 750,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1044,
    "weight": 1
   },
   {
    "source": 360,
    "target": 1044,
    "weight": 1
   },
   {
    "source": 58,
    "target": 425,
    "weight": 1
   },
   {
    "source": 3,
    "target": 40,
    "weight": 2
   },
   {
    "source": 38,
    "target": 360,
    "weight": 1
   },
   {
    "source": 215,
    "target": 424,
    "weight": 1
   },
   {
    "source": 62,
    "target": 215,
    "weight": 1
   },
   {
    "source": 38,
    "target": 322,
    "weight": 1
   },
   {
    "source": 40,
    "target": 322,
    "weight": 1
   },
   {
    "source": 36,
    "target": 40,
    "weight": 2
   },
   {
    "source": 36,
    "target": 515,
    "weight": 1
   },
   {
    "source": 40,
    "target": 424,
    "weight": 1
   },
   {
    "source": 38,
    "target": 211,
    "weight": 1
   },
   {
    "source": 38,
    "target": 120,
    "weight": 1
   },
   {
    "source": 120,
    "target": 515,
    "weight": 1
   },
   {
    "source": 515,
    "target": 1045,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1045,
    "weight": 1
   },
   {
    "source": 24,
    "target": 140,
    "weight": 1
   },
   {
    "source": 24,
    "target": 69,
    "weight": 1
   },
   {
    "source": 26,
    "target": 69,
    "weight": 1
   },
   {
    "source": 140,
    "target": 515,
    "weight": 2
   },
   {
    "source": 210,
    "target": 472,
    "weight": 1
   },
   {
    "source": 67,
    "target": 539,
    "weight": 1
   },
   {
    "source": 90,
    "target": 539,
    "weight": 1
   },
   {
    "source": 1,
    "target": 90,
    "weight": 1
   },
   {
    "source": 26,
    "target": 67,
    "weight": 2
   },
   {
    "source": 73,
    "target": 678,
    "weight": 1
   },
   {
    "source": 657,
    "target": 678,
    "weight": 1
   },
   {
    "source": 193,
    "target": 783,
    "weight": 1
   },
   {
    "source": 663,
    "target": 783,
    "weight": 1
   },
   {
    "source": 656,
    "target": 663,
    "weight": 2
   },
   {
    "source": 47,
    "target": 73,
    "weight": 2
   },
   {
    "source": 663,
    "target": 726,
    "weight": 1
   },
   {
    "source": 49,
    "target": 663,
    "weight": 1
   },
   {
    "source": 49,
    "target": 69,
    "weight": 1
   },
   {
    "source": 50,
    "target": 69,
    "weight": 1
   },
   {
    "source": 50,
    "target": 75,
    "weight": 3
   },
   {
    "source": 59,
    "target": 75,
    "weight": 1
   },
   {
    "source": 59,
    "target": 726,
    "weight": 1
   },
   {
    "source": 45,
    "target": 726,
    "weight": 1
   },
   {
    "source": 45,
    "target": 663,
    "weight": 1
   },
   {
    "source": 360,
    "target": 663,
    "weight": 1
   },
   {
    "source": 69,
    "target": 75,
    "weight": 2
   },
   {
    "source": 59,
    "target": 69,
    "weight": 1
   },
   {
    "source": 50,
    "target": 59,
    "weight": 1
   },
   {
    "source": 193,
    "target": 656,
    "weight": 1
   },
   {
    "source": 40,
    "target": 126,
    "weight": 1
   },
   {
    "source": 40,
    "target": 680,
    "weight": 1
   },
   {
    "source": 26,
    "target": 680,
    "weight": 3
   },
   {
    "source": 26,
    "target": 708,
    "weight": 1
   },
   {
    "source": 40,
    "target": 708,
    "weight": 1
   },
   {
    "source": 126,
    "target": 360,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1046,
    "weight": 1
   },
   {
    "source": 443,
    "target": 1046,
    "weight": 1
   },
   {
    "source": 138,
    "target": 443,
    "weight": 1
   },
   {
    "source": 4,
    "target": 138,
    "weight": 1
   },
   {
    "source": 337,
    "target": 680,
    "weight": 1
   },
   {
    "source": 7,
    "target": 26,
    "weight": 1
   },
   {
    "source": 8,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 650,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 281,
    "target": 650,
    "weight": 1
   },
   {
    "source": 281,
    "target": 1048,
    "weight": 1
   },
   {
    "source": 81,
    "target": 1048,
    "weight": 2
   },
   {
    "source": 81,
    "target": 825,
    "weight": 1
   },
   {
    "source": 103,
    "target": 825,
    "weight": 1
   },
   {
    "source": 103,
    "target": 198,
    "weight": 1
   },
   {
    "source": 11,
    "target": 507,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1049,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1049,
    "weight": 1
   },
   {
    "source": 85,
    "target": 140,
    "weight": 1
   },
   {
    "source": 85,
    "target": 1050,
    "weight": 1
   },
   {
    "source": 709,
    "target": 1050,
    "weight": 1
   },
   {
    "source": 5,
    "target": 124,
    "weight": 3
   },
   {
    "source": 5,
    "target": 139,
    "weight": 1
   },
   {
    "source": 182,
    "target": 337,
    "weight": 1
   },
   {
    "source": 50,
    "target": 1051,
    "weight": 1
   },
   {
    "source": 723,
    "target": 1051,
    "weight": 1
   },
   {
    "source": 4,
    "target": 723,
    "weight": 1
   },
   {
    "source": 110,
    "target": 124,
    "weight": 1
   },
   {
    "source": 40,
    "target": 110,
    "weight": 1
   },
   {
    "source": 50,
    "target": 139,
    "weight": 1
   },
   {
    "source": 38,
    "target": 50,
    "weight": 1
   },
   {
    "source": 69,
    "target": 660,
    "weight": 1
   },
   {
    "source": 15,
    "target": 660,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1052,
    "weight": 4
   },
   {
    "source": 5,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 5,
    "target": 143,
    "weight": 2
   },
   {
    "source": 660,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 942,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 436,
    "target": 942,
    "weight": 1
   },
   {
    "source": 272,
    "target": 436,
    "weight": 1
   },
   {
    "source": 65,
    "target": 272,
    "weight": 1
   },
   {
    "source": 65,
    "target": 1053,
    "weight": 1
   },
   {
    "source": 844,
    "target": 1053,
    "weight": 1
   },
   {
    "source": 522,
    "target": 844,
    "weight": 1
   },
   {
    "source": 26,
    "target": 522,
    "weight": 1
   },
   {
    "source": 272,
    "target": 1053,
    "weight": 1
   },
   {
    "source": 15,
    "target": 143,
    "weight": 1
   },
   {
    "source": 539,
    "target": 1054,
    "weight": 1
   },
   {
    "source": 411,
    "target": 539,
    "weight": 1
   },
   {
    "source": 411,
    "target": 448,
    "weight": 1
   },
   {
    "source": 64,
    "target": 448,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1055,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1054,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1056,
    "weight": 1
   },
   {
    "source": 5,
    "target": 844,
    "weight": 1
   },
   {
    "source": 375,
    "target": 844,
    "weight": 1
   },
   {
    "source": 85,
    "target": 375,
    "weight": 1
   },
   {
    "source": 85,
    "target": 182,
    "weight": 1
   },
   {
    "source": 182,
    "target": 278,
    "weight": 1
   },
   {
    "source": 278,
    "target": 1057,
    "weight": 1
   },
   {
    "source": 167,
    "target": 1057,
    "weight": 1
   },
   {
    "source": 45,
    "target": 167,
    "weight": 1
   },
   {
    "source": 45,
    "target": 1058,
    "weight": 1
   },
   {
    "source": 1055,
    "target": 1056,
    "weight": 1
   },
   {
    "source": 1052,
    "target": 1059,
    "weight": 1
   },
   {
    "source": 442,
    "target": 1059,
    "weight": 1
   },
   {
    "source": 442,
    "target": 1060,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1058,
    "weight": 1
   },
   {
    "source": 6,
    "target": 1061,
    "weight": 1
   },
   {
    "source": 844,
    "target": 1061,
    "weight": 1
   },
   {
    "source": 192,
    "target": 844,
    "weight": 1
   },
   {
    "source": 192,
    "target": 312,
    "weight": 1
   },
   {
    "source": 312,
    "target": 1062,
    "weight": 1
   },
   {
    "source": 570,
    "target": 1062,
    "weight": 1
   },
   {
    "source": 312,
    "target": 570,
    "weight": 1
   },
   {
    "source": 3,
    "target": 1060,
    "weight": 1
   },
   {
    "source": 324,
    "target": 1063,
    "weight": 3
   },
   {
    "source": 129,
    "target": 1063,
    "weight": 1
   },
   {
    "source": 129,
    "target": 223,
    "weight": 1
   },
   {
    "source": 143,
    "target": 223,
    "weight": 1
   },
   {
    "source": 324,
    "target": 570,
    "weight": 1
   },
   {
    "source": 122,
    "target": 1054,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1054,
    "weight": 1
   },
   {
    "source": 323,
    "target": 755,
    "weight": 1
   },
   {
    "source": 323,
    "target": 409,
    "weight": 1
   },
   {
    "source": 409,
    "target": 844,
    "weight": 1
   },
   {
    "source": 323,
    "target": 844,
    "weight": 1
   },
   {
    "source": 122,
    "target": 143,
    "weight": 1
   },
   {
    "source": 88,
    "target": 993,
    "weight": 1
   },
   {
    "source": 993,
    "target": 1064,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1064,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 35,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 15,
    "target": 35,
    "weight": 1
   },
   {
    "source": 15,
    "target": 269,
    "weight": 1
   },
   {
    "source": 269,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 1054,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 324,
    "target": 1054,
    "weight": 1
   },
   {
    "source": 88,
    "target": 844,
    "weight": 1
   },
   {
    "source": 360,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 360,
    "target": 375,
    "weight": 2
   },
   {
    "source": 85,
    "target": 360,
    "weight": 1
   },
   {
    "source": 1052,
    "target": 1063,
    "weight": 1
   },
   {
    "source": 1065,
    "target": 1066,
    "weight": 1
   },
   {
    "source": 177,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 165,
    "target": 177,
    "weight": 1
   },
   {
    "source": 165,
    "target": 375,
    "weight": 1
   },
   {
    "source": 375,
    "target": 441,
    "weight": 1
   },
   {
    "source": 85,
    "target": 1066,
    "weight": 1
   },
   {
    "source": 499,
    "target": 1065,
    "weight": 2
   },
   {
    "source": 145,
    "target": 499,
    "weight": 2
   },
   {
    "source": 145,
    "target": 370,
    "weight": 2
   },
   {
    "source": 5,
    "target": 370,
    "weight": 1
   },
   {
    "source": 5,
    "target": 441,
    "weight": 3
   },
   {
    "source": 441,
    "target": 1067,
    "weight": 1
   },
   {
    "source": 520,
    "target": 1067,
    "weight": 1
   },
   {
    "source": 520,
    "target": 577,
    "weight": 1
   },
   {
    "source": 5,
    "target": 577,
    "weight": 1
   },
   {
    "source": 441,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 187,
    "target": 499,
    "weight": 1
   },
   {
    "source": 187,
    "target": 1068,
    "weight": 3
   },
   {
    "source": 187,
    "target": 577,
    "weight": 1
   },
   {
    "source": 145,
    "target": 577,
    "weight": 1
   },
   {
    "source": 370,
    "target": 577,
    "weight": 1
   },
   {
    "source": 577,
    "target": 1062,
    "weight": 1
   },
   {
    "source": 1062,
    "target": 1067,
    "weight": 1
   },
   {
    "source": 364,
    "target": 1067,
    "weight": 1
   },
   {
    "source": 169,
    "target": 364,
    "weight": 1
   },
   {
    "source": 65,
    "target": 169,
    "weight": 1
   },
   {
    "source": 5,
    "target": 499,
    "weight": 1
   },
   {
    "source": 374,
    "target": 499,
    "weight": 1
   },
   {
    "source": 499,
    "target": 948,
    "weight": 1
   },
   {
    "source": 86,
    "target": 948,
    "weight": 1
   },
   {
    "source": 86,
    "target": 1069,
    "weight": 1
   },
   {
    "source": 539,
    "target": 1069,
    "weight": 1
   },
   {
    "source": 539,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 249,
    "target": 1052,
    "weight": 2
   },
   {
    "source": 65,
    "target": 374,
    "weight": 1
   },
   {
    "source": 5,
    "target": 65,
    "weight": 1
   },
   {
    "source": 65,
    "target": 72,
    "weight": 1
   },
   {
    "source": 72,
    "target": 143,
    "weight": 1
   },
   {
    "source": 143,
    "target": 706,
    "weight": 1
   },
   {
    "source": 706,
    "target": 944,
    "weight": 1
   },
   {
    "source": 86,
    "target": 944,
    "weight": 1
   },
   {
    "source": 86,
    "target": 251,
    "weight": 1
   },
   {
    "source": 251,
    "target": 1070,
    "weight": 1
   },
   {
    "source": 708,
    "target": 1070,
    "weight": 1
   },
   {
    "source": 708,
    "target": 1054,
    "weight": 1
   },
   {
    "source": 165,
    "target": 1054,
    "weight": 1
   },
   {
    "source": 5,
    "target": 165,
    "weight": 1
   },
   {
    "source": 251,
    "target": 944,
    "weight": 1
   },
   {
    "source": 108,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 108,
    "target": 269,
    "weight": 1
   },
   {
    "source": 5,
    "target": 269,
    "weight": 1
   },
   {
    "source": 5,
    "target": 471,
    "weight": 1
   },
   {
    "source": 5,
    "target": 145,
    "weight": 1
   },
   {
    "source": 187,
    "target": 317,
    "weight": 1
   },
   {
    "source": 577,
    "target": 1068,
    "weight": 1
   },
   {
    "source": 317,
    "target": 577,
    "weight": 1
   },
   {
    "source": 317,
    "target": 692,
    "weight": 1
   },
   {
    "source": 317,
    "target": 471,
    "weight": 1
   },
   {
    "source": 193,
    "target": 716,
    "weight": 1
   },
   {
    "source": 5,
    "target": 193,
    "weight": 1
   },
   {
    "source": 692,
    "target": 716,
    "weight": 1
   },
   {
    "source": 59,
    "target": 230,
    "weight": 1
   },
   {
    "source": 46,
    "target": 230,
    "weight": 1
   },
   {
    "source": 678,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 5,
    "target": 59,
    "weight": 1
   },
   {
    "source": 5,
    "target": 663,
    "weight": 2
   },
   {
    "source": 5,
    "target": 1071,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1071,
    "weight": 3
   },
   {
    "source": 2,
    "target": 660,
    "weight": 4
   },
   {
    "source": 34,
    "target": 1072,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1071,
    "weight": 2
   },
   {
    "source": 249,
    "target": 656,
    "weight": 1
   },
   {
    "source": 764,
    "target": 1072,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1073,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1074,
    "weight": 1
   },
   {
    "source": 402,
    "target": 1074,
    "weight": 1
   },
   {
    "source": 402,
    "target": 1075,
    "weight": 1
   },
   {
    "source": 969,
    "target": 1073,
    "weight": 1
   },
   {
    "source": 311,
    "target": 660,
    "weight": 1
   },
   {
    "source": 660,
    "target": 842,
    "weight": 1
   },
   {
    "source": 677,
    "target": 842,
    "weight": 3
   },
   {
    "source": 663,
    "target": 677,
    "weight": 1
   },
   {
    "source": 663,
    "target": 792,
    "weight": 1
   },
   {
    "source": 35,
    "target": 792,
    "weight": 1
   },
   {
    "source": 35,
    "target": 660,
    "weight": 1
   },
   {
    "source": 311,
    "target": 1075,
    "weight": 1
   },
   {
    "source": 979,
    "target": 1076,
    "weight": 1
   },
   {
    "source": 979,
    "target": 1077,
    "weight": 1
   },
   {
    "source": 1077,
    "target": 1078,
    "weight": 1
   },
   {
    "source": 81,
    "target": 1078,
    "weight": 1
   },
   {
    "source": 49,
    "target": 81,
    "weight": 1
   },
   {
    "source": 49,
    "target": 593,
    "weight": 1
   },
   {
    "source": 593,
    "target": 660,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1076,
    "weight": 1
   },
   {
    "source": 593,
    "target": 969,
    "weight": 1
   },
   {
    "source": 140,
    "target": 593,
    "weight": 1
   },
   {
    "source": 660,
    "target": 969,
    "weight": 2
   },
   {
    "source": 660,
    "target": 1079,
    "weight": 1
   },
   {
    "source": 1079,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 842,
    "target": 1080,
    "weight": 2
   },
   {
    "source": 140,
    "target": 660,
    "weight": 2
   },
   {
    "source": 811,
    "target": 992,
    "weight": 1
   },
   {
    "source": 660,
    "target": 811,
    "weight": 5
   },
   {
    "source": 660,
    "target": 1080,
    "weight": 2
   },
   {
    "source": 660,
    "target": 992,
    "weight": 1
   },
   {
    "source": 677,
    "target": 992,
    "weight": 1
   },
   {
    "source": 760,
    "target": 951,
    "weight": 1
   },
   {
    "source": 660,
    "target": 951,
    "weight": 1
   },
   {
    "source": 677,
    "target": 760,
    "weight": 1
   },
   {
    "source": 0,
    "target": 660,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1081,
    "weight": 1
   },
   {
    "source": 1065,
    "target": 1081,
    "weight": 1
   },
   {
    "source": 287,
    "target": 1065,
    "weight": 2
   },
   {
    "source": 287,
    "target": 303,
    "weight": 2
   },
   {
    "source": 303,
    "target": 677,
    "weight": 2
   },
   {
    "source": 46,
    "target": 677,
    "weight": 2
   },
   {
    "source": 969,
    "target": 1071,
    "weight": 2
   },
   {
    "source": 1082,
    "target": 1083,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1083,
    "weight": 1
   },
   {
    "source": 140,
    "target": 969,
    "weight": 1
   },
   {
    "source": 1,
    "target": 1082,
    "weight": 1
   },
   {
    "source": 6,
    "target": 172,
    "weight": 1
   },
   {
    "source": 172,
    "target": 679,
    "weight": 1
   },
   {
    "source": 663,
    "target": 679,
    "weight": 1
   },
   {
    "source": 287,
    "target": 663,
    "weight": 1
   },
   {
    "source": 3,
    "target": 969,
    "weight": 1
   },
   {
    "source": 448,
    "target": 679,
    "weight": 1
   },
   {
    "source": 59,
    "target": 448,
    "weight": 1
   },
   {
    "source": 193,
    "target": 677,
    "weight": 1
   },
   {
    "source": 677,
    "target": 726,
    "weight": 1
   },
   {
    "source": 723,
    "target": 1084,
    "weight": 1
   },
   {
    "source": 723,
    "target": 1011,
    "weight": 1
   },
   {
    "source": 1011,
    "target": 1085,
    "weight": 1
   },
   {
    "source": 648,
    "target": 1085,
    "weight": 3
   },
   {
    "source": 648,
    "target": 952,
    "weight": 1
   },
   {
    "source": 677,
    "target": 952,
    "weight": 1
   },
   {
    "source": 648,
    "target": 1011,
    "weight": 1
   },
   {
    "source": 726,
    "target": 1084,
    "weight": 1
   },
   {
    "source": 67,
    "target": 1086,
    "weight": 1
   },
   {
    "source": 661,
    "target": 1086,
    "weight": 1
   },
   {
    "source": 172,
    "target": 1087,
    "weight": 1
   },
   {
    "source": 103,
    "target": 1087,
    "weight": 1
   },
   {
    "source": 103,
    "target": 648,
    "weight": 1
   },
   {
    "source": 172,
    "target": 1086,
    "weight": 1
   },
   {
    "source": 67,
    "target": 677,
    "weight": 1
   },
   {
    "source": 87,
    "target": 1088,
    "weight": 1
   },
   {
    "source": 677,
    "target": 1088,
    "weight": 1
   },
   {
    "source": 87,
    "target": 648,
    "weight": 1
   },
   {
    "source": 62,
    "target": 1085,
    "weight": 1
   },
   {
    "source": 62,
    "target": 1089,
    "weight": 1
   },
   {
    "source": 485,
    "target": 1089,
    "weight": 1
   },
   {
    "source": 287,
    "target": 485,
    "weight": 1
   },
   {
    "source": 287,
    "target": 1090,
    "weight": 1
   },
   {
    "source": 677,
    "target": 1085,
    "weight": 1
   },
   {
    "source": 193,
    "target": 679,
    "weight": 1
   },
   {
    "source": 166,
    "target": 193,
    "weight": 1
   },
   {
    "source": 166,
    "target": 1085,
    "weight": 1
   },
   {
    "source": 648,
    "target": 1091,
    "weight": 1
   },
   {
    "source": 679,
    "target": 1090,
    "weight": 1
   },
   {
    "source": 140,
    "target": 172,
    "weight": 1
   },
   {
    "source": 172,
    "target": 726,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1091,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1092,
    "weight": 1
   },
   {
    "source": 1076,
    "target": 1092,
    "weight": 1
   },
   {
    "source": 679,
    "target": 1076,
    "weight": 1
   },
   {
    "source": 679,
    "target": 764,
    "weight": 2
   },
   {
    "source": 726,
    "target": 969,
    "weight": 1
   },
   {
    "source": 764,
    "target": 969,
    "weight": 2
   },
   {
    "source": 660,
    "target": 679,
    "weight": 1
   },
   {
    "source": 660,
    "target": 723,
    "weight": 1
   },
   {
    "source": 648,
    "target": 660,
    "weight": 1
   },
   {
    "source": 648,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 723,
    "target": 811,
    "weight": 1
   },
   {
    "source": 59,
    "target": 1093,
    "weight": 1
   },
   {
    "source": 1080,
    "target": 1093,
    "weight": 1
   },
   {
    "source": 811,
    "target": 1094,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1075,
    "weight": 4
   },
   {
    "source": 811,
    "target": 1075,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1095,
    "weight": 2
   },
   {
    "source": 651,
    "target": 1095,
    "weight": 2
   },
   {
    "source": 59,
    "target": 1094,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1094,
    "weight": 2
   },
   {
    "source": 249,
    "target": 660,
    "weight": 5
   },
   {
    "source": 249,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 37,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 37,
    "target": 1096,
    "weight": 1
   },
   {
    "source": 1096,
    "target": 1097,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1097,
    "weight": 1
   },
   {
    "source": 651,
    "target": 1094,
    "weight": 1
   },
   {
    "source": 702,
    "target": 1098,
    "weight": 1
   },
   {
    "source": 59,
    "target": 1098,
    "weight": 1
   },
   {
    "source": 140,
    "target": 702,
    "weight": 2
   },
   {
    "source": 660,
    "target": 1099,
    "weight": 1
   },
   {
    "source": 1099,
    "target": 1100,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1100,
    "weight": 1
   },
   {
    "source": 5,
    "target": 998,
    "weight": 1
   },
   {
    "source": 249,
    "target": 663,
    "weight": 1
   },
   {
    "source": 593,
    "target": 811,
    "weight": 1
   },
   {
    "source": 593,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 651,
    "target": 755,
    "weight": 1
   },
   {
    "source": 713,
    "target": 755,
    "weight": 1
   },
   {
    "source": 5,
    "target": 713,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1075,
    "weight": 1
   },
   {
    "source": 660,
    "target": 880,
    "weight": 1
   },
   {
    "source": 755,
    "target": 880,
    "weight": 1
   },
   {
    "source": 172,
    "target": 755,
    "weight": 1
   },
   {
    "source": 172,
    "target": 1101,
    "weight": 1
   },
   {
    "source": 1101,
    "target": 1102,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1102,
    "weight": 2
   },
   {
    "source": 515,
    "target": 1094,
    "weight": 1
   },
   {
    "source": 149,
    "target": 172,
    "weight": 1
   },
   {
    "source": 3,
    "target": 149,
    "weight": 1
   },
   {
    "source": 3,
    "target": 1033,
    "weight": 2
   },
   {
    "source": 149,
    "target": 515,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1094,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1103,
    "weight": 1
   },
   {
    "source": 1075,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 3,
    "target": 1103,
    "weight": 1
   },
   {
    "source": 5,
    "target": 140,
    "weight": 2
   },
   {
    "source": 140,
    "target": 691,
    "weight": 1
   },
   {
    "source": 116,
    "target": 691,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1104,
    "weight": 1
   },
   {
    "source": 1104,
    "target": 1105,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1105,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1106,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1080,
    "weight": 3
   },
   {
    "source": 660,
    "target": 1107,
    "weight": 1
   },
   {
    "source": 1107,
    "target": 1108,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1106,
    "weight": 1
   },
   {
    "source": 604,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 5,
    "target": 728,
    "weight": 1
   },
   {
    "source": 122,
    "target": 728,
    "weight": 2
   },
   {
    "source": 122,
    "target": 1109,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1109,
    "weight": 1
   },
   {
    "source": 604,
    "target": 1108,
    "weight": 1
   },
   {
    "source": 660,
    "target": 728,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1102,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1102,
    "weight": 1
   },
   {
    "source": 11,
    "target": 660,
    "weight": 2
   },
   {
    "source": 1080,
    "target": 1094,
    "weight": 1
   },
   {
    "source": 124,
    "target": 748,
    "weight": 1
   },
   {
    "source": 748,
    "target": 1102,
    "weight": 1
   },
   {
    "source": 124,
    "target": 1102,
    "weight": 1
   },
   {
    "source": 124,
    "target": 152,
    "weight": 1
   },
   {
    "source": 152,
    "target": 748,
    "weight": 1
   },
   {
    "source": 124,
    "target": 1110,
    "weight": 1
   },
   {
    "source": 3,
    "target": 124,
    "weight": 1
   },
   {
    "source": 3,
    "target": 1111,
    "weight": 1
   },
   {
    "source": 75,
    "target": 1111,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1110,
    "weight": 1
   },
   {
    "source": 1080,
    "target": 1110,
    "weight": 1
   },
   {
    "source": 1102,
    "target": 1110,
    "weight": 1
   },
   {
    "source": 1102,
    "target": 1112,
    "weight": 1
   },
   {
    "source": 1080,
    "target": 1102,
    "weight": 1
   },
   {
    "source": 75,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 441,
    "target": 1113,
    "weight": 1
   },
   {
    "source": 1113,
    "target": 1114,
    "weight": 1
   },
   {
    "source": 1114,
    "target": 1115,
    "weight": 1
   },
   {
    "source": 267,
    "target": 1115,
    "weight": 1
   },
   {
    "source": 267,
    "target": 1116,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1112,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1113,
    "weight": 1
   },
   {
    "source": 1106,
    "target": 1113,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1116,
    "weight": 1
   },
   {
    "source": 35,
    "target": 140,
    "weight": 1
   },
   {
    "source": 124,
    "target": 676,
    "weight": 1
   },
   {
    "source": 676,
    "target": 1117,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1117,
    "weight": 1
   },
   {
    "source": 165,
    "target": 1118,
    "weight": 1
   },
   {
    "source": 515,
    "target": 1118,
    "weight": 1
   },
   {
    "source": 27,
    "target": 515,
    "weight": 1
   },
   {
    "source": 27,
    "target": 140,
    "weight": 2
   },
   {
    "source": 35,
    "target": 1106,
    "weight": 1
   },
   {
    "source": 0,
    "target": 755,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1085,
    "weight": 1
   },
   {
    "source": 172,
    "target": 1085,
    "weight": 1
   },
   {
    "source": 172,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 829,
    "target": 1119,
    "weight": 1
   },
   {
    "source": 1080,
    "target": 1119,
    "weight": 1
   },
   {
    "source": 1,
    "target": 829,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 374,
    "target": 1052,
    "weight": 1
   },
   {
    "source": 86,
    "target": 374,
    "weight": 1
   },
   {
    "source": 86,
    "target": 1063,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1080,
    "weight": 1
   },
   {
    "source": 998,
    "target": 1120,
    "weight": 1
   },
   {
    "source": 478,
    "target": 1120,
    "weight": 1
   },
   {
    "source": 300,
    "target": 478,
    "weight": 1
   },
   {
    "source": 140,
    "target": 300,
    "weight": 2
   },
   {
    "source": 90,
    "target": 140,
    "weight": 1
   },
   {
    "source": 90,
    "target": 572,
    "weight": 1
   },
   {
    "source": 572,
    "target": 588,
    "weight": 1
   },
   {
    "source": 139,
    "target": 588,
    "weight": 1
   },
   {
    "source": 65,
    "target": 139,
    "weight": 1
   },
   {
    "source": 65,
    "target": 154,
    "weight": 2
   },
   {
    "source": 154,
    "target": 606,
    "weight": 1
   },
   {
    "source": 998,
    "target": 1063,
    "weight": 1
   },
   {
    "source": 284,
    "target": 998,
    "weight": 1
   },
   {
    "source": 67,
    "target": 284,
    "weight": 1
   },
   {
    "source": 67,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 998,
    "target": 1065,
    "weight": 1
   },
   {
    "source": 969,
    "target": 998,
    "weight": 1
   },
   {
    "source": 284,
    "target": 969,
    "weight": 1
   },
   {
    "source": 284,
    "target": 427,
    "weight": 1
   },
   {
    "source": 606,
    "target": 998,
    "weight": 1
   },
   {
    "source": 223,
    "target": 255,
    "weight": 1
   },
   {
    "source": 84,
    "target": 255,
    "weight": 1
   },
   {
    "source": 84,
    "target": 324,
    "weight": 1
   },
   {
    "source": 223,
    "target": 427,
    "weight": 1
   },
   {
    "source": 369,
    "target": 1121,
    "weight": 1
   },
   {
    "source": 249,
    "target": 369,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1122,
    "weight": 1
   },
   {
    "source": 65,
    "target": 1122,
    "weight": 1
   },
   {
    "source": 65,
    "target": 308,
    "weight": 2
   },
   {
    "source": 115,
    "target": 308,
    "weight": 1
   },
   {
    "source": 308,
    "target": 1122,
    "weight": 1
   },
   {
    "source": 1063,
    "target": 1121,
    "weight": 1
   },
   {
    "source": 369,
    "target": 805,
    "weight": 1
   },
   {
    "source": 369,
    "target": 573,
    "weight": 1
   },
   {
    "source": 255,
    "target": 573,
    "weight": 1
   },
   {
    "source": 161,
    "target": 255,
    "weight": 1
   },
   {
    "source": 161,
    "target": 660,
    "weight": 1
   },
   {
    "source": 115,
    "target": 805,
    "weight": 1
   },
   {
    "source": 67,
    "target": 188,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1123,
    "weight": 3
   },
   {
    "source": 64,
    "target": 1123,
    "weight": 1
   },
   {
    "source": 47,
    "target": 64,
    "weight": 2
   },
   {
    "source": 47,
    "target": 249,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1124,
    "weight": 2
   },
   {
    "source": 660,
    "target": 1125,
    "weight": 2
   },
   {
    "source": 188,
    "target": 660,
    "weight": 1
   },
   {
    "source": 660,
    "target": 998,
    "weight": 1
   },
   {
    "source": 26,
    "target": 998,
    "weight": 1
   },
   {
    "source": 354,
    "target": 1123,
    "weight": 1
   },
   {
    "source": 354,
    "target": 414,
    "weight": 1
   },
   {
    "source": 6,
    "target": 67,
    "weight": 1
   },
   {
    "source": 4,
    "target": 67,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1126,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1126,
    "weight": 1
   },
   {
    "source": 3,
    "target": 414,
    "weight": 1
   },
   {
    "source": 34,
    "target": 1127,
    "weight": 1
   },
   {
    "source": 1127,
    "target": 1128,
    "weight": 1
   },
   {
    "source": 35,
    "target": 1128,
    "weight": 1
   },
   {
    "source": 42,
    "target": 203,
    "weight": 1
   },
   {
    "source": 203,
    "target": 287,
    "weight": 2
   },
   {
    "source": 38,
    "target": 1129,
    "weight": 1
   },
   {
    "source": 427,
    "target": 1129,
    "weight": 1
   },
   {
    "source": 34,
    "target": 427,
    "weight": 1
   },
   {
    "source": 39,
    "target": 264,
    "weight": 1
   },
   {
    "source": 264,
    "target": 1130,
    "weight": 1
   },
   {
    "source": 167,
    "target": 1130,
    "weight": 1
   },
   {
    "source": 167,
    "target": 345,
    "weight": 1
   },
   {
    "source": 341,
    "target": 345,
    "weight": 1
   },
   {
    "source": 11,
    "target": 177,
    "weight": 1
   },
   {
    "source": 129,
    "target": 161,
    "weight": 1
   },
   {
    "source": 124,
    "target": 737,
    "weight": 1
   },
   {
    "source": 38,
    "target": 737,
    "weight": 1
   },
   {
    "source": 34,
    "target": 1046,
    "weight": 1
   },
   {
    "source": 272,
    "target": 1046,
    "weight": 1
   },
   {
    "source": 161,
    "target": 177,
    "weight": 1
   },
   {
    "source": 228,
    "target": 272,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1131,
    "weight": 1
   },
   {
    "source": 275,
    "target": 1131,
    "weight": 1
   },
   {
    "source": 38,
    "target": 277,
    "weight": 1
   },
   {
    "source": 330,
    "target": 1132,
    "weight": 1
   },
   {
    "source": 177,
    "target": 330,
    "weight": 1
   },
   {
    "source": 38,
    "target": 177,
    "weight": 2
   },
   {
    "source": 38,
    "target": 1133,
    "weight": 1
   },
   {
    "source": 300,
    "target": 1133,
    "weight": 1
   },
   {
    "source": 275,
    "target": 1132,
    "weight": 1
   },
   {
    "source": 129,
    "target": 301,
    "weight": 1
   },
   {
    "source": 306,
    "target": 781,
    "weight": 1
   },
   {
    "source": 46,
    "target": 249,
    "weight": 1
   },
   {
    "source": 112,
    "target": 129,
    "weight": 1
   },
   {
    "source": 46,
    "target": 231,
    "weight": 1
   },
   {
    "source": 231,
    "target": 1134,
    "weight": 1
   },
   {
    "source": 148,
    "target": 1134,
    "weight": 1
   },
   {
    "source": 46,
    "target": 238,
    "weight": 2
   },
   {
    "source": 282,
    "target": 1135,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1135,
    "weight": 1
   },
   {
    "source": 161,
    "target": 238,
    "weight": 2
   },
   {
    "source": 46,
    "target": 200,
    "weight": 1
   },
   {
    "source": 112,
    "target": 281,
    "weight": 1
   },
   {
    "source": 256,
    "target": 842,
    "weight": 1
   },
   {
    "source": 148,
    "target": 842,
    "weight": 1
   },
   {
    "source": 44,
    "target": 140,
    "weight": 1
   },
   {
    "source": 44,
    "target": 115,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1136,
    "weight": 1
   },
   {
    "source": 1136,
    "target": 1137,
    "weight": 1
   },
   {
    "source": 1137,
    "target": 1138,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1138,
    "weight": 1
   },
   {
    "source": 26,
    "target": 335,
    "weight": 1
   },
   {
    "source": 46,
    "target": 335,
    "weight": 1
   },
   {
    "source": 238,
    "target": 1139,
    "weight": 1
   },
   {
    "source": 148,
    "target": 1139,
    "weight": 2
   },
   {
    "source": 148,
    "target": 1032,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1032,
    "weight": 1
   },
   {
    "source": 46,
    "target": 289,
    "weight": 1
   },
   {
    "source": 240,
    "target": 289,
    "weight": 1
   },
   {
    "source": 231,
    "target": 240,
    "weight": 1
   },
   {
    "source": 10,
    "target": 335,
    "weight": 1
   },
   {
    "source": 161,
    "target": 1139,
    "weight": 1
   },
   {
    "source": 10,
    "target": 152,
    "weight": 2
   },
   {
    "source": 279,
    "target": 281,
    "weight": 1
   },
   {
    "source": 281,
    "target": 294,
    "weight": 1
   },
   {
    "source": 164,
    "target": 294,
    "weight": 1
   },
   {
    "source": 164,
    "target": 1003,
    "weight": 1
   },
   {
    "source": 308,
    "target": 1003,
    "weight": 1
   },
   {
    "source": 281,
    "target": 308,
    "weight": 1
   },
   {
    "source": 169,
    "target": 281,
    "weight": 1
   },
   {
    "source": 169,
    "target": 770,
    "weight": 1
   },
   {
    "source": 641,
    "target": 770,
    "weight": 1
   },
   {
    "source": 231,
    "target": 641,
    "weight": 1
   },
   {
    "source": 231,
    "target": 279,
    "weight": 1
   },
   {
    "source": 256,
    "target": 1140,
    "weight": 1
   },
   {
    "source": 312,
    "target": 1140,
    "weight": 1
   },
   {
    "source": 69,
    "target": 312,
    "weight": 1
   },
   {
    "source": 69,
    "target": 503,
    "weight": 1
   },
   {
    "source": 165,
    "target": 503,
    "weight": 1
   },
   {
    "source": 165,
    "target": 238,
    "weight": 1
   },
   {
    "source": 232,
    "target": 238,
    "weight": 1
   },
   {
    "source": 231,
    "target": 256,
    "weight": 1
   },
   {
    "source": 129,
    "target": 604,
    "weight": 1
   },
   {
    "source": 38,
    "target": 129,
    "weight": 2
   },
   {
    "source": 38,
    "target": 64,
    "weight": 1
   },
   {
    "source": 26,
    "target": 124,
    "weight": 1
   },
   {
    "source": 256,
    "target": 351,
    "weight": 1
   },
   {
    "source": 232,
    "target": 604,
    "weight": 1
   },
   {
    "source": 38,
    "target": 484,
    "weight": 1
   },
   {
    "source": 2,
    "target": 112,
    "weight": 4
   },
   {
    "source": 112,
    "target": 695,
    "weight": 1
   },
   {
    "source": 163,
    "target": 695,
    "weight": 1
   },
   {
    "source": 163,
    "target": 367,
    "weight": 1
   },
   {
    "source": 367,
    "target": 471,
    "weight": 1
   },
   {
    "source": 177,
    "target": 471,
    "weight": 1
   },
   {
    "source": 177,
    "target": 1141,
    "weight": 1
   },
   {
    "source": 362,
    "target": 1141,
    "weight": 1
   },
   {
    "source": 362,
    "target": 1142,
    "weight": 2
   },
   {
    "source": 351,
    "target": 484,
    "weight": 1
   },
   {
    "source": 351,
    "target": 1143,
    "weight": 1
   },
   {
    "source": 303,
    "target": 351,
    "weight": 1
   },
   {
    "source": 44,
    "target": 303,
    "weight": 1
   },
   {
    "source": 44,
    "target": 1144,
    "weight": 1
   },
   {
    "source": 471,
    "target": 1144,
    "weight": 1
   },
   {
    "source": 471,
    "target": 1145,
    "weight": 1
   },
   {
    "source": 1142,
    "target": 1143,
    "weight": 1
   },
   {
    "source": 2,
    "target": 221,
    "weight": 1
   },
   {
    "source": 38,
    "target": 221,
    "weight": 1
   },
   {
    "source": 38,
    "target": 365,
    "weight": 1
   },
   {
    "source": 256,
    "target": 365,
    "weight": 1
   },
   {
    "source": 177,
    "target": 256,
    "weight": 2
   },
   {
    "source": 177,
    "target": 267,
    "weight": 2
   },
   {
    "source": 267,
    "target": 824,
    "weight": 1
   },
   {
    "source": 202,
    "target": 824,
    "weight": 1
   },
   {
    "source": 202,
    "target": 266,
    "weight": 1
   },
   {
    "source": 46,
    "target": 332,
    "weight": 1
   },
   {
    "source": 33,
    "target": 40,
    "weight": 1
   },
   {
    "source": 177,
    "target": 824,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1145,
    "weight": 1
   },
   {
    "source": 206,
    "target": 351,
    "weight": 1
   },
   {
    "source": 206,
    "target": 828,
    "weight": 1
   },
   {
    "source": 828,
    "target": 1146,
    "weight": 1
   },
   {
    "source": 1146,
    "target": 1147,
    "weight": 1
   },
   {
    "source": 1147,
    "target": 1148,
    "weight": 1
   },
   {
    "source": 1148,
    "target": 1149,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1149,
    "weight": 1
   },
   {
    "source": 38,
    "target": 496,
    "weight": 1
   },
   {
    "source": 496,
    "target": 713,
    "weight": 1
   },
   {
    "source": 216,
    "target": 256,
    "weight": 1
   },
   {
    "source": 311,
    "target": 364,
    "weight": 1
   },
   {
    "source": 364,
    "target": 1150,
    "weight": 1
   },
   {
    "source": 249,
    "target": 1150,
    "weight": 1
   },
   {
    "source": 10,
    "target": 249,
    "weight": 1
   },
   {
    "source": 155,
    "target": 400,
    "weight": 1
   },
   {
    "source": 253,
    "target": 400,
    "weight": 1
   },
   {
    "source": 38,
    "target": 253,
    "weight": 1
   },
   {
    "source": 46,
    "target": 216,
    "weight": 1
   },
   {
    "source": 4,
    "target": 117,
    "weight": 1
   },
   {
    "source": 117,
    "target": 140,
    "weight": 1
   },
   {
    "source": 107,
    "target": 140,
    "weight": 2
   },
   {
    "source": 107,
    "target": 372,
    "weight": 1
   },
   {
    "source": 155,
    "target": 393,
    "weight": 2
   },
   {
    "source": 374,
    "target": 393,
    "weight": 2
   },
   {
    "source": 140,
    "target": 374,
    "weight": 1
   },
   {
    "source": 38,
    "target": 124,
    "weight": 2
   },
   {
    "source": 193,
    "target": 1151,
    "weight": 1
   },
   {
    "source": 193,
    "target": 203,
    "weight": 1
   },
   {
    "source": 43,
    "target": 372,
    "weight": 1
   },
   {
    "source": 43,
    "target": 255,
    "weight": 1
   },
   {
    "source": 218,
    "target": 255,
    "weight": 1
   },
   {
    "source": 2,
    "target": 218,
    "weight": 1
   },
   {
    "source": 2,
    "target": 383,
    "weight": 1
   },
   {
    "source": 383,
    "target": 1152,
    "weight": 1
   },
   {
    "source": 379,
    "target": 1152,
    "weight": 1
   },
   {
    "source": 203,
    "target": 372,
    "weight": 1
   },
   {
    "source": 43,
    "target": 218,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1151,
    "weight": 1
   },
   {
    "source": 376,
    "target": 644,
    "weight": 1
   },
   {
    "source": 69,
    "target": 644,
    "weight": 1
   },
   {
    "source": 40,
    "target": 287,
    "weight": 1
   },
   {
    "source": 287,
    "target": 1153,
    "weight": 1
   },
   {
    "source": 372,
    "target": 1153,
    "weight": 1
   },
   {
    "source": 38,
    "target": 644,
    "weight": 1
   },
   {
    "source": 376,
    "target": 380,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1154,
    "weight": 1
   },
   {
    "source": 300,
    "target": 1155,
    "weight": 1
   },
   {
    "source": 28,
    "target": 1155,
    "weight": 1
   },
   {
    "source": 28,
    "target": 44,
    "weight": 2
   },
   {
    "source": 44,
    "target": 292,
    "weight": 1
   },
   {
    "source": 140,
    "target": 292,
    "weight": 1
   },
   {
    "source": 214,
    "target": 702,
    "weight": 1
   },
   {
    "source": 124,
    "target": 1154,
    "weight": 1
   },
   {
    "source": 287,
    "target": 400,
    "weight": 1
   },
   {
    "source": 26,
    "target": 177,
    "weight": 1
   },
   {
    "source": 155,
    "target": 254,
    "weight": 1
   },
   {
    "source": 281,
    "target": 1156,
    "weight": 1
   },
   {
    "source": 177,
    "target": 1156,
    "weight": 1
   },
   {
    "source": 9,
    "target": 256,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 804,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 264,
    "target": 804,
    "weight": 1
   },
   {
    "source": 254,
    "target": 264,
    "weight": 1
   },
   {
    "source": 4,
    "target": 254,
    "weight": 1
   },
   {
    "source": 4,
    "target": 297,
    "weight": 1
   },
   {
    "source": 267,
    "target": 1156,
    "weight": 1
   },
   {
    "source": 214,
    "target": 287,
    "weight": 1
   },
   {
    "source": 67,
    "target": 372,
    "weight": 1
   },
   {
    "source": 67,
    "target": 373,
    "weight": 1
   },
   {
    "source": 75,
    "target": 373,
    "weight": 1
   },
   {
    "source": 75,
    "target": 255,
    "weight": 2
   },
   {
    "source": 199,
    "target": 256,
    "weight": 1
   },
   {
    "source": 155,
    "target": 199,
    "weight": 1
   },
   {
    "source": 28,
    "target": 399,
    "weight": 1
   },
   {
    "source": 44,
    "target": 46,
    "weight": 2
   },
   {
    "source": 44,
    "target": 517,
    "weight": 1
   },
   {
    "source": 9,
    "target": 44,
    "weight": 1
   },
   {
    "source": 26,
    "target": 372,
    "weight": 1
   },
   {
    "source": 38,
    "target": 53,
    "weight": 2
   },
   {
    "source": 38,
    "target": 348,
    "weight": 1
   },
   {
    "source": 348,
    "target": 517,
    "weight": 1
   },
   {
    "source": 30,
    "target": 53,
    "weight": 1
   },
   {
    "source": 53,
    "target": 713,
    "weight": 1
   },
   {
    "source": 38,
    "target": 713,
    "weight": 2
   },
   {
    "source": 64,
    "target": 124,
    "weight": 2
   },
   {
    "source": 40,
    "target": 64,
    "weight": 1
   },
   {
    "source": 40,
    "target": 332,
    "weight": 1
   },
   {
    "source": 67,
    "target": 332,
    "weight": 1
   },
   {
    "source": 3,
    "target": 67,
    "weight": 1
   },
   {
    "source": 70,
    "target": 517,
    "weight": 1
   },
   {
    "source": 143,
    "target": 208,
    "weight": 1
   },
   {
    "source": 4,
    "target": 207,
    "weight": 2
   },
   {
    "source": 207,
    "target": 1158,
    "weight": 1
   },
   {
    "source": 441,
    "target": 1158,
    "weight": 1
   },
   {
    "source": 72,
    "target": 441,
    "weight": 1
   },
   {
    "source": 137,
    "target": 1159,
    "weight": 2
   },
   {
    "source": 137,
    "target": 727,
    "weight": 1
   },
   {
    "source": 72,
    "target": 727,
    "weight": 2
   },
   {
    "source": 2,
    "target": 1160,
    "weight": 1
   },
   {
    "source": 208,
    "target": 1160,
    "weight": 1
   },
   {
    "source": 2,
    "target": 727,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1159,
    "weight": 1
   },
   {
    "source": 36,
    "target": 207,
    "weight": 2
   },
   {
    "source": 5,
    "target": 35,
    "weight": 1
   },
   {
    "source": 40,
    "target": 727,
    "weight": 1
   },
   {
    "source": 59,
    "target": 727,
    "weight": 1
   },
   {
    "source": 59,
    "target": 73,
    "weight": 1
   },
   {
    "source": 5,
    "target": 208,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1046,
    "weight": 1
   },
   {
    "source": 1046,
    "target": 1161,
    "weight": 1
   },
   {
    "source": 718,
    "target": 1161,
    "weight": 1
   },
   {
    "source": 577,
    "target": 718,
    "weight": 1
   },
   {
    "source": 577,
    "target": 1162,
    "weight": 1
   },
   {
    "source": 1162,
    "target": 1163,
    "weight": 1
   },
   {
    "source": 207,
    "target": 1163,
    "weight": 1
   },
   {
    "source": 207,
    "target": 770,
    "weight": 1
   },
   {
    "source": 770,
    "target": 811,
    "weight": 1
   },
   {
    "source": 650,
    "target": 811,
    "weight": 2
   },
   {
    "source": 650,
    "target": 1164,
    "weight": 1
   },
   {
    "source": 38,
    "target": 73,
    "weight": 1
   },
   {
    "source": 155,
    "target": 256,
    "weight": 2
   },
   {
    "source": 256,
    "target": 1164,
    "weight": 1
   },
   {
    "source": 129,
    "target": 147,
    "weight": 1
   },
   {
    "source": 71,
    "target": 147,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1165,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1165,
    "weight": 1
   },
   {
    "source": 5,
    "target": 254,
    "weight": 1
   },
   {
    "source": 39,
    "target": 254,
    "weight": 2
   },
   {
    "source": 39,
    "target": 1166,
    "weight": 1
   },
   {
    "source": 1166,
    "target": 1167,
    "weight": 1
   },
   {
    "source": 1167,
    "target": 1168,
    "weight": 1
   },
   {
    "source": 869,
    "target": 1168,
    "weight": 1
   },
   {
    "source": 869,
    "target": 1169,
    "weight": 1
   },
   {
    "source": 311,
    "target": 1169,
    "weight": 1
   },
   {
    "source": 311,
    "target": 1170,
    "weight": 1
   },
   {
    "source": 1170,
    "target": 1171,
    "weight": 1
   },
   {
    "source": 1171,
    "target": 1172,
    "weight": 1
   },
   {
    "source": 129,
    "target": 155,
    "weight": 1
   },
   {
    "source": 1173,
    "target": 1174,
    "weight": 1
   },
   {
    "source": 1174,
    "target": 1175,
    "weight": 1
   },
   {
    "source": 1165,
    "target": 1175,
    "weight": 1
   },
   {
    "source": 1172,
    "target": 1173,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1165,
    "weight": 2
   },
   {
    "source": 1165,
    "target": 1174,
    "weight": 1
   },
   {
    "source": 1174,
    "target": 1176,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1176,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1177,
    "weight": 2
   },
   {
    "source": 71,
    "target": 378,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1178,
    "weight": 1
   },
   {
    "source": 71,
    "target": 465,
    "weight": 1
   },
   {
    "source": 465,
    "target": 1165,
    "weight": 1
   },
   {
    "source": 378,
    "target": 1178,
    "weight": 1
   },
   {
    "source": 39,
    "target": 851,
    "weight": 1
   },
   {
    "source": 5,
    "target": 39,
    "weight": 2
   },
   {
    "source": 5,
    "target": 279,
    "weight": 1
   },
   {
    "source": 71,
    "target": 279,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1179,
    "weight": 1
   },
   {
    "source": 1179,
    "target": 1180,
    "weight": 1
   },
   {
    "source": 1180,
    "target": 1181,
    "weight": 1
   },
   {
    "source": 1181,
    "target": 1182,
    "weight": 1
   },
   {
    "source": 1182,
    "target": 1183,
    "weight": 1
   },
   {
    "source": 264,
    "target": 1183,
    "weight": 1
   },
   {
    "source": 264,
    "target": 1184,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1184,
    "weight": 1
   },
   {
    "source": 39,
    "target": 279,
    "weight": 1
   },
   {
    "source": 851,
    "target": 1165,
    "weight": 1
   },
   {
    "source": 38,
    "target": 660,
    "weight": 1
   },
   {
    "source": 660,
    "target": 1163,
    "weight": 1
   },
   {
    "source": 708,
    "target": 1163,
    "weight": 2
   },
   {
    "source": 38,
    "target": 71,
    "weight": 1
   },
   {
    "source": 137,
    "target": 352,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1185,
    "weight": 1
   },
   {
    "source": 680,
    "target": 1185,
    "weight": 1
   },
   {
    "source": 26,
    "target": 71,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1163,
    "weight": 1
   },
   {
    "source": 137,
    "target": 1163,
    "weight": 1
   },
   {
    "source": 47,
    "target": 360,
    "weight": 2
   },
   {
    "source": 360,
    "target": 708,
    "weight": 1
   },
   {
    "source": 71,
    "target": 708,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1186,
    "weight": 1
   },
   {
    "source": 588,
    "target": 1186,
    "weight": 1
   },
   {
    "source": 38,
    "target": 588,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1163,
    "weight": 1
   },
   {
    "source": 172,
    "target": 999,
    "weight": 1
   },
   {
    "source": 49,
    "target": 172,
    "weight": 1
   },
   {
    "source": 49,
    "target": 67,
    "weight": 1
   },
   {
    "source": 47,
    "target": 999,
    "weight": 1
   },
   {
    "source": 129,
    "target": 929,
    "weight": 1
   },
   {
    "source": 129,
    "target": 173,
    "weight": 1
   },
   {
    "source": 173,
    "target": 380,
    "weight": 1
   },
   {
    "source": 140,
    "target": 380,
    "weight": 1
   },
   {
    "source": 44,
    "target": 914,
    "weight": 1
   },
   {
    "source": 141,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 38,
    "target": 141,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1187,
    "weight": 1
   },
   {
    "source": 177,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 246,
    "target": 599,
    "weight": 1
   },
   {
    "source": 38,
    "target": 246,
    "weight": 1
   },
   {
    "source": 380,
    "target": 1188,
    "weight": 3
   },
   {
    "source": 380,
    "target": 1189,
    "weight": 1
   },
   {
    "source": 1189,
    "target": 1190,
    "weight": 1
   },
   {
    "source": 569,
    "target": 1190,
    "weight": 1
   },
   {
    "source": 38,
    "target": 569,
    "weight": 1
   },
   {
    "source": 47,
    "target": 129,
    "weight": 2
   },
   {
    "source": 129,
    "target": 403,
    "weight": 1
   },
   {
    "source": 44,
    "target": 403,
    "weight": 1
   },
   {
    "source": 47,
    "target": 569,
    "weight": 1
   },
   {
    "source": 599,
    "target": 1187,
    "weight": 1
   },
   {
    "source": 1188,
    "target": 1190,
    "weight": 1
   },
   {
    "source": 380,
    "target": 783,
    "weight": 1
   },
   {
    "source": 44,
    "target": 1190,
    "weight": 1
   },
   {
    "source": 47,
    "target": 256,
    "weight": 1
   },
   {
    "source": 256,
    "target": 380,
    "weight": 1
   },
   {
    "source": 380,
    "target": 849,
    "weight": 2
   },
   {
    "source": 266,
    "target": 849,
    "weight": 2
   },
   {
    "source": 266,
    "target": 1191,
    "weight": 1
   },
   {
    "source": 807,
    "target": 1191,
    "weight": 1
   },
   {
    "source": 47,
    "target": 807,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1157,
    "weight": 4
   },
   {
    "source": 45,
    "target": 47,
    "weight": 1
   },
   {
    "source": 44,
    "target": 1192,
    "weight": 1
   },
   {
    "source": 256,
    "target": 1192,
    "weight": 1
   },
   {
    "source": 155,
    "target": 1188,
    "weight": 1
   },
   {
    "source": 1157,
    "target": 1188,
    "weight": 1
   },
   {
    "source": 49,
    "target": 381,
    "weight": 1
   },
   {
    "source": 381,
    "target": 1159,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1159,
    "weight": 1
   },
   {
    "source": 2,
    "target": 381,
    "weight": 1
   },
   {
    "source": 126,
    "target": 380,
    "weight": 1
   },
   {
    "source": 47,
    "target": 67,
    "weight": 1
   },
   {
    "source": 67,
    "target": 74,
    "weight": 1
   },
   {
    "source": 126,
    "target": 137,
    "weight": 1
   },
   {
    "source": 51,
    "target": 211,
    "weight": 1
   },
   {
    "source": 74,
    "target": 211,
    "weight": 1
   },
   {
    "source": 102,
    "target": 451,
    "weight": 1
   },
   {
    "source": 102,
    "target": 269,
    "weight": 1
   },
   {
    "source": 11,
    "target": 51,
    "weight": 1
   },
   {
    "source": 5,
    "target": 74,
    "weight": 2
   },
   {
    "source": 5,
    "target": 108,
    "weight": 1
   },
   {
    "source": 108,
    "target": 759,
    "weight": 1
   },
   {
    "source": 759,
    "target": 1193,
    "weight": 1
   },
   {
    "source": 707,
    "target": 1193,
    "weight": 1
   },
   {
    "source": 75,
    "target": 707,
    "weight": 1
   },
   {
    "source": 75,
    "target": 742,
    "weight": 1
   },
   {
    "source": 4,
    "target": 742,
    "weight": 1
   },
   {
    "source": 4,
    "target": 102,
    "weight": 1
   },
   {
    "source": 707,
    "target": 742,
    "weight": 1
   },
   {
    "source": 150,
    "target": 453,
    "weight": 1
   },
   {
    "source": 23,
    "target": 75,
    "weight": 1
   },
   {
    "source": 0,
    "target": 23,
    "weight": 3
   },
   {
    "source": 0,
    "target": 21,
    "weight": 5
   },
   {
    "source": 17,
    "target": 21,
    "weight": 2
   },
   {
    "source": 17,
    "target": 1194,
    "weight": 2
   },
   {
    "source": 74,
    "target": 1194,
    "weight": 2
   },
   {
    "source": 74,
    "target": 453,
    "weight": 1
   },
   {
    "source": 38,
    "target": 453,
    "weight": 1
   },
   {
    "source": 48,
    "target": 102,
    "weight": 1
   },
   {
    "source": 102,
    "target": 1190,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1190,
    "weight": 2
   },
   {
    "source": 75,
    "target": 102,
    "weight": 1
   },
   {
    "source": 453,
    "target": 1195,
    "weight": 1
   },
   {
    "source": 1190,
    "target": 1195,
    "weight": 1
   },
   {
    "source": 47,
    "target": 453,
    "weight": 1
   },
   {
    "source": 62,
    "target": 849,
    "weight": 1
   },
   {
    "source": 62,
    "target": 1196,
    "weight": 1
   },
   {
    "source": 227,
    "target": 1196,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1190,
    "weight": 1
   },
   {
    "source": 1190,
    "target": 1197,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1197,
    "weight": 1
   },
   {
    "source": 254,
    "target": 1139,
    "weight": 1
   },
   {
    "source": 849,
    "target": 1198,
    "weight": 1
   },
   {
    "source": 39,
    "target": 227,
    "weight": 1
   },
   {
    "source": 185,
    "target": 1190,
    "weight": 1
   },
   {
    "source": 26,
    "target": 185,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1199,
    "weight": 1
   },
   {
    "source": 108,
    "target": 1199,
    "weight": 1
   },
   {
    "source": 108,
    "target": 352,
    "weight": 1
   },
   {
    "source": 1190,
    "target": 1198,
    "weight": 1
   },
   {
    "source": 69,
    "target": 1200,
    "weight": 1
   },
   {
    "source": 352,
    "target": 1200,
    "weight": 1
   },
   {
    "source": 1157,
    "target": 1201,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1202,
    "weight": 1
   },
   {
    "source": 1202,
    "target": 1203,
    "weight": 1
   },
   {
    "source": 1203,
    "target": 1204,
    "weight": 1
   },
   {
    "source": 200,
    "target": 1204,
    "weight": 1
   },
   {
    "source": 200,
    "target": 1203,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1201,
    "weight": 1
   },
   {
    "source": 172,
    "target": 1205,
    "weight": 1
   },
   {
    "source": 172,
    "target": 1206,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1206,
    "weight": 1
   },
   {
    "source": 969,
    "target": 975,
    "weight": 1
   },
   {
    "source": 200,
    "target": 1205,
    "weight": 1
   },
   {
    "source": 200,
    "target": 1207,
    "weight": 1
   },
   {
    "source": 200,
    "target": 1208,
    "weight": 1
   },
   {
    "source": 539,
    "target": 1208,
    "weight": 1
   },
   {
    "source": 539,
    "target": 1209,
    "weight": 1
   },
   {
    "source": 1209,
    "target": 1210,
    "weight": 1
   },
   {
    "source": 165,
    "target": 1210,
    "weight": 1
   },
   {
    "source": 165,
    "target": 995,
    "weight": 1
   },
   {
    "source": 995,
    "target": 1211,
    "weight": 1
   },
   {
    "source": 285,
    "target": 1211,
    "weight": 1
   },
   {
    "source": 975,
    "target": 1207,
    "weight": 1
   },
   {
    "source": 200,
    "target": 1212,
    "weight": 1
   },
   {
    "source": 38,
    "target": 200,
    "weight": 1
   },
   {
    "source": 285,
    "target": 1212,
    "weight": 1
   },
   {
    "source": 66,
    "target": 1213,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1213,
    "weight": 1
   },
   {
    "source": 30,
    "target": 246,
    "weight": 1
   },
   {
    "source": 34,
    "target": 271,
    "weight": 1
   },
   {
    "source": 167,
    "target": 1214,
    "weight": 1
   },
   {
    "source": 38,
    "target": 167,
    "weight": 1
   },
   {
    "source": 44,
    "target": 47,
    "weight": 1
   },
   {
    "source": 34,
    "target": 1214,
    "weight": 1
   },
   {
    "source": 90,
    "target": 780,
    "weight": 1
   },
   {
    "source": 254,
    "target": 740,
    "weight": 1
   },
   {
    "source": 254,
    "target": 380,
    "weight": 1
   },
   {
    "source": 380,
    "target": 746,
    "weight": 1
   },
   {
    "source": 46,
    "target": 808,
    "weight": 1
   },
   {
    "source": 40,
    "target": 811,
    "weight": 1
   },
   {
    "source": 148,
    "target": 650,
    "weight": 1
   },
   {
    "source": 148,
    "target": 1164,
    "weight": 1
   },
   {
    "source": 47,
    "target": 141,
    "weight": 1
   },
   {
    "source": 49,
    "target": 54,
    "weight": 1
   },
   {
    "source": 49,
    "target": 951,
    "weight": 1
   },
   {
    "source": 59,
    "target": 951,
    "weight": 1
   },
   {
    "source": 59,
    "target": 253,
    "weight": 1
   },
   {
    "source": 253,
    "target": 332,
    "weight": 1
   },
   {
    "source": 332,
    "target": 1215,
    "weight": 1
   },
   {
    "source": 67,
    "target": 1215,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1164,
    "weight": 1
   },
   {
    "source": 53,
    "target": 254,
    "weight": 1
   },
   {
    "source": 60,
    "target": 254,
    "weight": 1
   },
   {
    "source": 60,
    "target": 62,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1216,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1216,
    "weight": 1
   },
   {
    "source": 297,
    "target": 1217,
    "weight": 1
   },
   {
    "source": 641,
    "target": 1217,
    "weight": 1
   },
   {
    "source": 140,
    "target": 641,
    "weight": 1
   },
   {
    "source": 140,
    "target": 220,
    "weight": 1
   },
   {
    "source": 53,
    "target": 67,
    "weight": 1
   },
   {
    "source": 6,
    "target": 893,
    "weight": 1
   },
   {
    "source": 38,
    "target": 893,
    "weight": 1
   },
   {
    "source": 47,
    "target": 660,
    "weight": 1
   },
   {
    "source": 223,
    "target": 249,
    "weight": 1
   },
   {
    "source": 38,
    "target": 202,
    "weight": 1
   },
   {
    "source": 202,
    "target": 646,
    "weight": 1
   },
   {
    "source": 642,
    "target": 646,
    "weight": 1
   },
   {
    "source": 34,
    "target": 642,
    "weight": 1
   },
   {
    "source": 34,
    "target": 64,
    "weight": 1
   },
   {
    "source": 3,
    "target": 143,
    "weight": 1
   },
   {
    "source": 5,
    "target": 303,
    "weight": 1
   },
   {
    "source": 312,
    "target": 1014,
    "weight": 1
   },
   {
    "source": 312,
    "target": 1218,
    "weight": 1
   },
   {
    "source": 301,
    "target": 1218,
    "weight": 1
   },
   {
    "source": 301,
    "target": 1219,
    "weight": 1
   },
   {
    "source": 1219,
    "target": 1220,
    "weight": 1
   },
   {
    "source": 298,
    "target": 1220,
    "weight": 1
   },
   {
    "source": 64,
    "target": 298,
    "weight": 1
   },
   {
    "source": 58,
    "target": 144,
    "weight": 1
   },
   {
    "source": 58,
    "target": 68,
    "weight": 1
   },
   {
    "source": 303,
    "target": 1014,
    "weight": 1
   },
   {
    "source": 59,
    "target": 734,
    "weight": 1
   },
   {
    "source": 5,
    "target": 734,
    "weight": 1
   },
   {
    "source": 5,
    "target": 717,
    "weight": 1
   },
   {
    "source": 59,
    "target": 68,
    "weight": 1
   },
   {
    "source": 432,
    "target": 1221,
    "weight": 1
   },
   {
    "source": 717,
    "target": 1221,
    "weight": 1
   },
   {
    "source": 280,
    "target": 1222,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1222,
    "weight": 1
   },
   {
    "source": 30,
    "target": 213,
    "weight": 1
   },
   {
    "source": 213,
    "target": 350,
    "weight": 1
   },
   {
    "source": 246,
    "target": 350,
    "weight": 1
   },
   {
    "source": 4,
    "target": 246,
    "weight": 2
   },
   {
    "source": 4,
    "target": 68,
    "weight": 1
   },
   {
    "source": 68,
    "target": 154,
    "weight": 1
   },
   {
    "source": 280,
    "target": 432,
    "weight": 1
   },
   {
    "source": 150,
    "target": 918,
    "weight": 1
   },
   {
    "source": 149,
    "target": 606,
    "weight": 1
   },
   {
    "source": 154,
    "target": 918,
    "weight": 1
   },
   {
    "source": 137,
    "target": 669,
    "weight": 1
   },
   {
    "source": 49,
    "target": 137,
    "weight": 1
   },
   {
    "source": 49,
    "target": 680,
    "weight": 1
   },
   {
    "source": 264,
    "target": 680,
    "weight": 1
   },
   {
    "source": 264,
    "target": 441,
    "weight": 1
   },
   {
    "source": 114,
    "target": 441,
    "weight": 1
   },
   {
    "source": 114,
    "target": 279,
    "weight": 1
   },
   {
    "source": 279,
    "target": 521,
    "weight": 1
   },
   {
    "source": 279,
    "target": 441,
    "weight": 1
   },
   {
    "source": 606,
    "target": 669,
    "weight": 1
   },
   {
    "source": 385,
    "target": 641,
    "weight": 1
   },
   {
    "source": 641,
    "target": 650,
    "weight": 1
   },
   {
    "source": 193,
    "target": 650,
    "weight": 1
   },
   {
    "source": 193,
    "target": 584,
    "weight": 1
   },
   {
    "source": 584,
    "target": 1223,
    "weight": 1
   },
   {
    "source": 214,
    "target": 1223,
    "weight": 1
   },
   {
    "source": 214,
    "target": 669,
    "weight": 1
   },
   {
    "source": 5,
    "target": 669,
    "weight": 3
   },
   {
    "source": 5,
    "target": 853,
    "weight": 1
   },
   {
    "source": 214,
    "target": 853,
    "weight": 1
   },
   {
    "source": 214,
    "target": 278,
    "weight": 1
   },
   {
    "source": 278,
    "target": 427,
    "weight": 1
   },
   {
    "source": 38,
    "target": 374,
    "weight": 1
   },
   {
    "source": 214,
    "target": 584,
    "weight": 1
   },
   {
    "source": 604,
    "target": 669,
    "weight": 1
   },
   {
    "source": 5,
    "target": 213,
    "weight": 1
   },
   {
    "source": 213,
    "target": 677,
    "weight": 1
   },
   {
    "source": 374,
    "target": 604,
    "weight": 1
   },
   {
    "source": 38,
    "target": 696,
    "weight": 1
   },
   {
    "source": 38,
    "target": 110,
    "weight": 1
   },
   {
    "source": 110,
    "target": 169,
    "weight": 1
   },
   {
    "source": 169,
    "target": 267,
    "weight": 1
   },
   {
    "source": 40,
    "target": 267,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1224,
    "weight": 1
   },
   {
    "source": 677,
    "target": 696,
    "weight": 1
   },
   {
    "source": 5,
    "target": 188,
    "weight": 1
   },
   {
    "source": 188,
    "target": 648,
    "weight": 1
   },
   {
    "source": 376,
    "target": 650,
    "weight": 1
   },
   {
    "source": 38,
    "target": 376,
    "weight": 1
   },
   {
    "source": 150,
    "target": 650,
    "weight": 1
   },
   {
    "source": 47,
    "target": 265,
    "weight": 1
   },
   {
    "source": 58,
    "target": 265,
    "weight": 1
   },
   {
    "source": 50,
    "target": 58,
    "weight": 1
   },
   {
    "source": 50,
    "target": 62,
    "weight": 1
   },
   {
    "source": 62,
    "target": 520,
    "weight": 1
   },
   {
    "source": 520,
    "target": 951,
    "weight": 1
   },
   {
    "source": 662,
    "target": 951,
    "weight": 1
   },
   {
    "source": 669,
    "target": 1224,
    "weight": 1
   },
   {
    "source": 147,
    "target": 912,
    "weight": 1
   },
   {
    "source": 147,
    "target": 1225,
    "weight": 1
   },
   {
    "source": 688,
    "target": 1225,
    "weight": 1
   },
   {
    "source": 40,
    "target": 688,
    "weight": 1
   },
   {
    "source": 30,
    "target": 688,
    "weight": 1
   },
   {
    "source": 663,
    "target": 688,
    "weight": 1
   },
   {
    "source": 619,
    "target": 663,
    "weight": 1
   },
   {
    "source": 267,
    "target": 618,
    "weight": 1
   },
   {
    "source": 267,
    "target": 1226,
    "weight": 1
   },
   {
    "source": 1226,
    "target": 1227,
    "weight": 1
   },
   {
    "source": 1227,
    "target": 1228,
    "weight": 1
   },
   {
    "source": 618,
    "target": 663,
    "weight": 1
   },
   {
    "source": 267,
    "target": 663,
    "weight": 1
   },
   {
    "source": 267,
    "target": 619,
    "weight": 1
   },
   {
    "source": 662,
    "target": 912,
    "weight": 1
   },
   {
    "source": 303,
    "target": 1229,
    "weight": 1
   },
   {
    "source": 303,
    "target": 619,
    "weight": 1
   },
   {
    "source": 145,
    "target": 619,
    "weight": 1
   },
   {
    "source": 145,
    "target": 423,
    "weight": 2
   },
   {
    "source": 423,
    "target": 444,
    "weight": 2
   },
   {
    "source": 145,
    "target": 444,
    "weight": 1
   },
   {
    "source": 444,
    "target": 619,
    "weight": 1
   },
   {
    "source": 1228,
    "target": 1229,
    "weight": 1
   },
   {
    "source": 45,
    "target": 618,
    "weight": 1
   },
   {
    "source": 258,
    "target": 619,
    "weight": 1
   },
   {
    "source": 148,
    "target": 618,
    "weight": 1
   },
   {
    "source": 360,
    "target": 742,
    "weight": 1
   },
   {
    "source": 360,
    "target": 1230,
    "weight": 1
   },
   {
    "source": 1230,
    "target": 1231,
    "weight": 1
   },
   {
    "source": 618,
    "target": 1231,
    "weight": 1
   },
   {
    "source": 618,
    "target": 742,
    "weight": 1
   },
   {
    "source": 30,
    "target": 618,
    "weight": 2
   },
   {
    "source": 49,
    "target": 618,
    "weight": 1
   },
   {
    "source": 49,
    "target": 730,
    "weight": 1
   },
   {
    "source": 441,
    "target": 695,
    "weight": 1
   },
   {
    "source": 269,
    "target": 695,
    "weight": 1
   },
   {
    "source": 269,
    "target": 827,
    "weight": 1
   },
   {
    "source": 350,
    "target": 619,
    "weight": 1
   },
   {
    "source": 350,
    "target": 609,
    "weight": 1
   },
   {
    "source": 400,
    "target": 609,
    "weight": 1
   },
   {
    "source": 400,
    "target": 596,
    "weight": 1
   },
   {
    "source": 596,
    "target": 1232,
    "weight": 1
   },
   {
    "source": 392,
    "target": 1232,
    "weight": 1
   },
   {
    "source": 392,
    "target": 688,
    "weight": 3
   },
   {
    "source": 152,
    "target": 688,
    "weight": 9
   },
   {
    "source": 152,
    "target": 392,
    "weight": 2
   },
   {
    "source": 5,
    "target": 730,
    "weight": 1
   },
   {
    "source": 59,
    "target": 112,
    "weight": 1
   },
   {
    "source": 112,
    "target": 127,
    "weight": 1
   },
   {
    "source": 127,
    "target": 673,
    "weight": 1
   },
   {
    "source": 44,
    "target": 673,
    "weight": 1
   },
   {
    "source": 44,
    "target": 221,
    "weight": 1
   },
   {
    "source": 221,
    "target": 740,
    "weight": 1
   },
   {
    "source": 298,
    "target": 740,
    "weight": 1
   },
   {
    "source": 65,
    "target": 298,
    "weight": 1
   },
   {
    "source": 65,
    "target": 1140,
    "weight": 1
   },
   {
    "source": 156,
    "target": 1140,
    "weight": 1
   },
   {
    "source": 156,
    "target": 221,
    "weight": 1
   },
   {
    "source": 406,
    "target": 918,
    "weight": 1
   },
   {
    "source": 59,
    "target": 152,
    "weight": 1
   },
   {
    "source": 284,
    "target": 317,
    "weight": 1
   },
   {
    "source": 266,
    "target": 284,
    "weight": 1
   },
   {
    "source": 90,
    "target": 266,
    "weight": 1
   },
   {
    "source": 317,
    "target": 918,
    "weight": 1
   },
   {
    "source": 129,
    "target": 1233,
    "weight": 1
   },
   {
    "source": 53,
    "target": 1233,
    "weight": 2
   },
   {
    "source": 53,
    "target": 577,
    "weight": 2
   },
   {
    "source": 577,
    "target": 657,
    "weight": 1
   },
   {
    "source": 577,
    "target": 1233,
    "weight": 2
   },
   {
    "source": 38,
    "target": 1130,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1130,
    "weight": 1
   },
   {
    "source": 38,
    "target": 106,
    "weight": 1
   },
   {
    "source": 106,
    "target": 839,
    "weight": 1
   },
   {
    "source": 619,
    "target": 839,
    "weight": 1
   },
   {
    "source": 156,
    "target": 780,
    "weight": 1
   },
   {
    "source": 38,
    "target": 156,
    "weight": 1
   },
   {
    "source": 38,
    "target": 311,
    "weight": 1
   },
   {
    "source": 311,
    "target": 619,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1130,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1130,
    "weight": 1
   },
   {
    "source": 317,
    "target": 657,
    "weight": 1
   },
   {
    "source": 2,
    "target": 442,
    "weight": 1
   },
   {
    "source": 442,
    "target": 1234,
    "weight": 1
   },
   {
    "source": 266,
    "target": 1234,
    "weight": 2
   },
   {
    "source": 266,
    "target": 269,
    "weight": 1
   },
   {
    "source": 246,
    "target": 317,
    "weight": 1
   },
   {
    "source": 317,
    "target": 1233,
    "weight": 1
   },
   {
    "source": 577,
    "target": 1234,
    "weight": 1
   },
   {
    "source": 38,
    "target": 266,
    "weight": 2
   },
   {
    "source": 0,
    "target": 780,
    "weight": 1
   },
   {
    "source": 130,
    "target": 406,
    "weight": 1
   },
   {
    "source": 406,
    "target": 850,
    "weight": 1
   },
   {
    "source": 608,
    "target": 850,
    "weight": 1
   },
   {
    "source": 608,
    "target": 728,
    "weight": 1
   },
   {
    "source": 728,
    "target": 850,
    "weight": 3
   },
   {
    "source": 850,
    "target": 854,
    "weight": 2
   },
   {
    "source": 47,
    "target": 130,
    "weight": 1
   },
   {
    "source": 728,
    "target": 851,
    "weight": 2
   },
   {
    "source": 638,
    "target": 851,
    "weight": 1
   },
   {
    "source": 849,
    "target": 875,
    "weight": 1
   },
   {
    "source": 47,
    "target": 867,
    "weight": 2
   },
   {
    "source": 728,
    "target": 854,
    "weight": 5
   },
   {
    "source": 849,
    "target": 851,
    "weight": 1
   },
   {
    "source": 269,
    "target": 300,
    "weight": 1
   },
   {
    "source": 269,
    "target": 853,
    "weight": 1
   },
   {
    "source": 853,
    "target": 1235,
    "weight": 1
   },
   {
    "source": 1235,
    "target": 1236,
    "weight": 2
   },
   {
    "source": 728,
    "target": 839,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1237,
    "weight": 1
   },
   {
    "source": 1237,
    "target": 1238,
    "weight": 2
   },
   {
    "source": 915,
    "target": 1238,
    "weight": 1
   },
   {
    "source": 47,
    "target": 915,
    "weight": 1
   },
   {
    "source": 4,
    "target": 47,
    "weight": 8
   },
   {
    "source": 269,
    "target": 1239,
    "weight": 1
   },
   {
    "source": 867,
    "target": 1239,
    "weight": 1
   },
   {
    "source": 839,
    "target": 1236,
    "weight": 1
   },
   {
    "source": 54,
    "target": 150,
    "weight": 1
   },
   {
    "source": 54,
    "target": 867,
    "weight": 1
   },
   {
    "source": 4,
    "target": 554,
    "weight": 1
   },
   {
    "source": 554,
    "target": 792,
    "weight": 1
   },
   {
    "source": 792,
    "target": 1240,
    "weight": 1
   },
   {
    "source": 854,
    "target": 1240,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1240,
    "weight": 1
   },
   {
    "source": 105,
    "target": 1241,
    "weight": 1
   },
   {
    "source": 107,
    "target": 1241,
    "weight": 1
   },
   {
    "source": 73,
    "target": 107,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1242,
    "weight": 1
   },
   {
    "source": 854,
    "target": 1242,
    "weight": 1
   },
   {
    "source": 849,
    "target": 850,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1242,
    "weight": 1
   },
   {
    "source": 105,
    "target": 728,
    "weight": 1
   },
   {
    "source": 122,
    "target": 478,
    "weight": 1
   },
   {
    "source": 478,
    "target": 853,
    "weight": 1
   },
   {
    "source": 728,
    "target": 864,
    "weight": 1
   },
   {
    "source": 864,
    "target": 865,
    "weight": 1
   },
   {
    "source": 424,
    "target": 865,
    "weight": 1
   },
   {
    "source": 5,
    "target": 424,
    "weight": 1
   },
   {
    "source": 179,
    "target": 957,
    "weight": 1
   },
   {
    "source": 179,
    "target": 1082,
    "weight": 1
   },
   {
    "source": 1082,
    "target": 1243,
    "weight": 1
   },
   {
    "source": 7,
    "target": 1243,
    "weight": 1
   },
   {
    "source": 8,
    "target": 177,
    "weight": 1
   },
   {
    "source": 177,
    "target": 1244,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1244,
    "weight": 1
   },
   {
    "source": 4,
    "target": 688,
    "weight": 1
   },
   {
    "source": 27,
    "target": 688,
    "weight": 1
   },
   {
    "source": 27,
    "target": 177,
    "weight": 4
   },
   {
    "source": 24,
    "target": 177,
    "weight": 1
   },
   {
    "source": 24,
    "target": 1245,
    "weight": 1
   },
   {
    "source": 1245,
    "target": 1246,
    "weight": 3
   },
   {
    "source": 1246,
    "target": 1247,
    "weight": 1
   },
   {
    "source": 1247,
    "target": 1248,
    "weight": 1
   },
   {
    "source": 1248,
    "target": 1249,
    "weight": 1
   },
   {
    "source": 1249,
    "target": 1250,
    "weight": 1
   },
   {
    "source": 24,
    "target": 27,
    "weight": 1
   },
   {
    "source": 5,
    "target": 957,
    "weight": 1
   },
   {
    "source": 764,
    "target": 1243,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1250,
    "weight": 1
   },
   {
    "source": 2,
    "target": 378,
    "weight": 1
   },
   {
    "source": 76,
    "target": 378,
    "weight": 1
   },
   {
    "source": 76,
    "target": 1248,
    "weight": 1
   },
   {
    "source": 8,
    "target": 1248,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1243,
    "weight": 1
   },
   {
    "source": 49,
    "target": 472,
    "weight": 1
   },
   {
    "source": 8,
    "target": 472,
    "weight": 1
   },
   {
    "source": 510,
    "target": 872,
    "weight": 1
   },
   {
    "source": 650,
    "target": 872,
    "weight": 1
   },
   {
    "source": 265,
    "target": 650,
    "weight": 1
   },
   {
    "source": 265,
    "target": 872,
    "weight": 1
   },
   {
    "source": 619,
    "target": 872,
    "weight": 1
   },
   {
    "source": 265,
    "target": 786,
    "weight": 1
   },
   {
    "source": 378,
    "target": 519,
    "weight": 1
   },
   {
    "source": 350,
    "target": 872,
    "weight": 1
   },
   {
    "source": 872,
    "target": 904,
    "weight": 1
   },
   {
    "source": 308,
    "target": 786,
    "weight": 1
   },
   {
    "source": 782,
    "target": 786,
    "weight": 1
   },
   {
    "source": 254,
    "target": 782,
    "weight": 1
   },
   {
    "source": 350,
    "target": 786,
    "weight": 1
   },
   {
    "source": 463,
    "target": 786,
    "weight": 1
   },
   {
    "source": 786,
    "target": 857,
    "weight": 1
   },
   {
    "source": 112,
    "target": 857,
    "weight": 1
   },
   {
    "source": 112,
    "target": 971,
    "weight": 1
   },
   {
    "source": 899,
    "target": 971,
    "weight": 1
   },
   {
    "source": 266,
    "target": 899,
    "weight": 1
   },
   {
    "source": 266,
    "target": 857,
    "weight": 1
   },
   {
    "source": 148,
    "target": 857,
    "weight": 1
   },
   {
    "source": 427,
    "target": 463,
    "weight": 1
   },
   {
    "source": 38,
    "target": 478,
    "weight": 1
   },
   {
    "source": 38,
    "target": 539,
    "weight": 2
   },
   {
    "source": 309,
    "target": 539,
    "weight": 1
   },
   {
    "source": 309,
    "target": 406,
    "weight": 1
   },
   {
    "source": 62,
    "target": 899,
    "weight": 1
   },
   {
    "source": 62,
    "target": 406,
    "weight": 1
   },
   {
    "source": 1024,
    "target": 1251,
    "weight": 1
   },
   {
    "source": 281,
    "target": 1024,
    "weight": 1
   },
   {
    "source": 272,
    "target": 971,
    "weight": 1
   },
   {
    "source": 971,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 15,
    "target": 310,
    "weight": 1
   },
   {
    "source": 899,
    "target": 1251,
    "weight": 1
   },
   {
    "source": 49,
    "target": 401,
    "weight": 1
   },
   {
    "source": 378,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 116,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 116,
    "target": 1252,
    "weight": 1
   },
   {
    "source": 253,
    "target": 1252,
    "weight": 1
   },
   {
    "source": 253,
    "target": 1001,
    "weight": 1
   },
   {
    "source": 1001,
    "target": 1253,
    "weight": 1
   },
   {
    "source": 1253,
    "target": 1254,
    "weight": 1
   },
   {
    "source": 971,
    "target": 1254,
    "weight": 1
   },
   {
    "source": 460,
    "target": 971,
    "weight": 2
   },
   {
    "source": 460,
    "target": 1254,
    "weight": 1
   },
   {
    "source": 310,
    "target": 401,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1255,
    "weight": 1
   },
   {
    "source": 187,
    "target": 1255,
    "weight": 1
   },
   {
    "source": 187,
    "target": 1256,
    "weight": 1
   },
   {
    "source": 1256,
    "target": 1257,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1258,
    "weight": 1
   },
   {
    "source": 281,
    "target": 1258,
    "weight": 1
   },
   {
    "source": 281,
    "target": 619,
    "weight": 1
   },
   {
    "source": 40,
    "target": 620,
    "weight": 1
   },
   {
    "source": 26,
    "target": 40,
    "weight": 2
   },
   {
    "source": 713,
    "target": 786,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1257,
    "weight": 1
   },
   {
    "source": 128,
    "target": 656,
    "weight": 1
   },
   {
    "source": 128,
    "target": 713,
    "weight": 1
   },
   {
    "source": 266,
    "target": 713,
    "weight": 1
   },
   {
    "source": 674,
    "target": 713,
    "weight": 1
   },
   {
    "source": 674,
    "target": 691,
    "weight": 1
   },
   {
    "source": 656,
    "target": 786,
    "weight": 1
   },
   {
    "source": 45,
    "target": 427,
    "weight": 1
   },
   {
    "source": 215,
    "target": 427,
    "weight": 1
   },
   {
    "source": 38,
    "target": 215,
    "weight": 1
   },
   {
    "source": 219,
    "target": 996,
    "weight": 1
   },
   {
    "source": 38,
    "target": 996,
    "weight": 1
   },
   {
    "source": 8,
    "target": 539,
    "weight": 1
   },
   {
    "source": 8,
    "target": 713,
    "weight": 1
   },
   {
    "source": 713,
    "target": 996,
    "weight": 1
   },
   {
    "source": 202,
    "target": 996,
    "weight": 1
   },
   {
    "source": 148,
    "target": 202,
    "weight": 1
   },
   {
    "source": 45,
    "target": 691,
    "weight": 1
   },
   {
    "source": 215,
    "target": 1259,
    "weight": 1
   },
   {
    "source": 215,
    "target": 736,
    "weight": 1
   },
   {
    "source": 38,
    "target": 736,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1259,
    "weight": 1
   },
   {
    "source": 106,
    "target": 205,
    "weight": 1
   },
   {
    "source": 1,
    "target": 205,
    "weight": 1
   },
   {
    "source": 678,
    "target": 1260,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1260,
    "weight": 1
   },
   {
    "source": 8,
    "target": 728,
    "weight": 1
   },
   {
    "source": 59,
    "target": 106,
    "weight": 1
   },
   {
    "source": 522,
    "target": 746,
    "weight": 1
   },
   {
    "source": 522,
    "target": 739,
    "weight": 1
   },
   {
    "source": 4,
    "target": 770,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1261,
    "weight": 1
   },
   {
    "source": 718,
    "target": 728,
    "weight": 1
   },
   {
    "source": 156,
    "target": 718,
    "weight": 1
   },
   {
    "source": 40,
    "target": 156,
    "weight": 1
   },
   {
    "source": 40,
    "target": 148,
    "weight": 1
   },
   {
    "source": 148,
    "target": 854,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1261,
    "weight": 1
   },
   {
    "source": 317,
    "target": 853,
    "weight": 1
   },
   {
    "source": 6,
    "target": 317,
    "weight": 1
   },
   {
    "source": 3,
    "target": 46,
    "weight": 1
   },
   {
    "source": 678,
    "target": 1262,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1262,
    "weight": 1
   },
   {
    "source": 680,
    "target": 728,
    "weight": 1
   },
   {
    "source": 8,
    "target": 680,
    "weight": 1
   },
   {
    "source": 32,
    "target": 53,
    "weight": 1
   },
   {
    "source": 32,
    "target": 34,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 38,
    "target": 1188,
    "weight": 1
   },
   {
    "source": 148,
    "target": 1188,
    "weight": 1
   },
   {
    "source": 155,
    "target": 1263,
    "weight": 1
   },
   {
    "source": 59,
    "target": 1263,
    "weight": 1
   },
   {
    "source": 59,
    "target": 352,
    "weight": 1
   },
   {
    "source": 44,
    "target": 352,
    "weight": 1
   },
   {
    "source": 44,
    "target": 237,
    "weight": 2
   },
   {
    "source": 237,
    "target": 1264,
    "weight": 1
   },
   {
    "source": 148,
    "target": 1264,
    "weight": 1
   },
   {
    "source": 53,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1265,
    "weight": 1
   },
   {
    "source": 857,
    "target": 1265,
    "weight": 1
   },
   {
    "source": 853,
    "target": 857,
    "weight": 2
   },
   {
    "source": 165,
    "target": 853,
    "weight": 1
   },
   {
    "source": 165,
    "target": 732,
    "weight": 1
   },
   {
    "source": 44,
    "target": 732,
    "weight": 1
   },
   {
    "source": 49,
    "target": 148,
    "weight": 1
   },
   {
    "source": 503,
    "target": 1266,
    "weight": 1
   },
   {
    "source": 237,
    "target": 503,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1267,
    "weight": 1
   },
   {
    "source": 794,
    "target": 1267,
    "weight": 1
   },
   {
    "source": 794,
    "target": 1268,
    "weight": 1
   },
   {
    "source": 1202,
    "target": 1268,
    "weight": 1
   },
   {
    "source": 1202,
    "target": 1269,
    "weight": 1
   },
   {
    "source": 251,
    "target": 1269,
    "weight": 1
   },
   {
    "source": 251,
    "target": 1270,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1270,
    "weight": 1
   },
   {
    "source": 46,
    "target": 65,
    "weight": 1
   },
   {
    "source": 794,
    "target": 1202,
    "weight": 1
   },
   {
    "source": 46,
    "target": 1266,
    "weight": 1
   },
   {
    "source": 591,
    "target": 1271,
    "weight": 1
   },
   {
    "source": 308,
    "target": 591,
    "weight": 1
   },
   {
    "source": 1266,
    "target": 1272,
    "weight": 1
   },
   {
    "source": 1266,
    "target": 1273,
    "weight": 1
   },
   {
    "source": 1271,
    "target": 1272,
    "weight": 1
   },
   {
    "source": 68,
    "target": 1274,
    "weight": 1
   },
   {
    "source": 1273,
    "target": 1274,
    "weight": 1
   },
   {
    "source": 1275,
    "target": 1276,
    "weight": 5
   },
   {
    "source": 15,
    "target": 1275,
    "weight": 3
   },
   {
    "source": 15,
    "target": 1194,
    "weight": 8
   },
   {
    "source": 1194,
    "target": 1275,
    "weight": 3
   },
   {
    "source": 68,
    "target": 1275,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1277,
    "weight": 1
   },
   {
    "source": 122,
    "target": 1278,
    "weight": 1
   },
   {
    "source": 122,
    "target": 506,
    "weight": 1
   },
   {
    "source": 506,
    "target": 736,
    "weight": 1
   },
   {
    "source": 736,
    "target": 1279,
    "weight": 1
   },
   {
    "source": 457,
    "target": 1279,
    "weight": 1
   },
   {
    "source": 457,
    "target": 1280,
    "weight": 1
   },
   {
    "source": 1280,
    "target": 1281,
    "weight": 1
   },
   {
    "source": 162,
    "target": 1281,
    "weight": 1
   },
   {
    "source": 162,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 942,
    "target": 1047,
    "weight": 2
   },
   {
    "source": 942,
    "target": 1278,
    "weight": 1
   },
   {
    "source": 506,
    "target": 1279,
    "weight": 1
   },
   {
    "source": 1277,
    "target": 1278,
    "weight": 1
   },
   {
    "source": 1273,
    "target": 1282,
    "weight": 1
   },
   {
    "source": 1282,
    "target": 1283,
    "weight": 1
   },
   {
    "source": 1273,
    "target": 1278,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1284,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 187,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 1283,
    "target": 1284,
    "weight": 1
   },
   {
    "source": 187,
    "target": 1285,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1286,
    "weight": 7
   },
   {
    "source": 4,
    "target": 1285,
    "weight": 1
   },
   {
    "source": 1287,
    "target": 1288,
    "weight": 4
   },
   {
    "source": 1288,
    "target": 1289,
    "weight": 4
   },
   {
    "source": 1286,
    "target": 1287,
    "weight": 3
   },
   {
    "source": 555,
    "target": 1289,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1148,
    "weight": 1
   },
   {
    "source": 1148,
    "target": 1290,
    "weight": 1
   },
   {
    "source": 73,
    "target": 556,
    "weight": 1
   },
   {
    "source": 112,
    "target": 152,
    "weight": 3
   },
   {
    "source": 112,
    "target": 1290,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1291,
    "weight": 1
   },
   {
    "source": 9,
    "target": 30,
    "weight": 1
   },
   {
    "source": 30,
    "target": 115,
    "weight": 4
   },
   {
    "source": 115,
    "target": 755,
    "weight": 4
   },
   {
    "source": 9,
    "target": 1291,
    "weight": 1
   },
   {
    "source": 755,
    "target": 855,
    "weight": 1
   },
   {
    "source": 856,
    "target": 1292,
    "weight": 1
   },
   {
    "source": 857,
    "target": 1292,
    "weight": 1
   },
   {
    "source": 1293,
    "target": 1294,
    "weight": 1
   },
   {
    "source": 1294,
    "target": 1295,
    "weight": 1
   },
   {
    "source": 1295,
    "target": 1296,
    "weight": 1
   },
   {
    "source": 857,
    "target": 1293,
    "weight": 1
   },
   {
    "source": 1233,
    "target": 1297,
    "weight": 1
   },
   {
    "source": 1296,
    "target": 1297,
    "weight": 1
   },
   {
    "source": 221,
    "target": 582,
    "weight": 1
   },
   {
    "source": 221,
    "target": 786,
    "weight": 1
   },
   {
    "source": 582,
    "target": 1233,
    "weight": 1
   },
   {
    "source": 676,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 786,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 676,
    "target": 1298,
    "weight": 1
   },
   {
    "source": 26,
    "target": 297,
    "weight": 1
   },
   {
    "source": 297,
    "target": 326,
    "weight": 1
   },
   {
    "source": 326,
    "target": 998,
    "weight": 1
   },
   {
    "source": 329,
    "target": 998,
    "weight": 1
   },
   {
    "source": 329,
    "target": 1299,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1298,
    "weight": 1
   },
   {
    "source": 1300,
    "target": 1301,
    "weight": 2
   },
   {
    "source": 15,
    "target": 1300,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1300,
    "weight": 1
   },
   {
    "source": 1299,
    "target": 1300,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1302,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1303,
    "weight": 1
   },
   {
    "source": 713,
    "target": 1304,
    "weight": 1
   },
   {
    "source": 608,
    "target": 1304,
    "weight": 1
   },
   {
    "source": 1302,
    "target": 1303,
    "weight": 1
   },
   {
    "source": 81,
    "target": 1305,
    "weight": 3
   },
   {
    "source": 81,
    "target": 130,
    "weight": 2
   },
   {
    "source": 608,
    "target": 1305,
    "weight": 1
   },
   {
    "source": 1306,
    "target": 1307,
    "weight": 1
   },
   {
    "source": 1307,
    "target": 1308,
    "weight": 1
   },
   {
    "source": 1308,
    "target": 1309,
    "weight": 1
   },
   {
    "source": 130,
    "target": 1306,
    "weight": 1
   },
   {
    "source": 269,
    "target": 1310,
    "weight": 1
   },
   {
    "source": 761,
    "target": 1310,
    "weight": 1
   },
   {
    "source": 1309,
    "target": 1310,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1311,
    "weight": 13
   },
   {
    "source": 1311,
    "target": 1312,
    "weight": 1
   },
   {
    "source": 1312,
    "target": 1313,
    "weight": 1
   },
   {
    "source": 39,
    "target": 761,
    "weight": 1
   },
   {
    "source": 1314,
    "target": 1315,
    "weight": 1
   },
   {
    "source": 1313,
    "target": 1314,
    "weight": 1
   },
   {
    "source": 123,
    "target": 426,
    "weight": 2
   },
   {
    "source": 426,
    "target": 1315,
    "weight": 1
   },
   {
    "source": 1316,
    "target": 1317,
    "weight": 1
   },
   {
    "source": 123,
    "target": 1316,
    "weight": 1
   },
   {
    "source": 1318,
    "target": 1319,
    "weight": 1
   },
   {
    "source": 1317,
    "target": 1318,
    "weight": 1
   },
   {
    "source": 27,
    "target": 246,
    "weight": 1
   },
   {
    "source": 177,
    "target": 737,
    "weight": 1
   },
   {
    "source": 737,
    "target": 841,
    "weight": 1
   },
   {
    "source": 2,
    "target": 841,
    "weight": 1
   },
   {
    "source": 177,
    "target": 246,
    "weight": 1
   },
   {
    "source": 246,
    "target": 1319,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1275,
    "weight": 1
   },
   {
    "source": 1320,
    "target": 1321,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1320,
    "weight": 1
   },
   {
    "source": 2,
    "target": 27,
    "weight": 5
   },
   {
    "source": 177,
    "target": 287,
    "weight": 1
   },
   {
    "source": 27,
    "target": 287,
    "weight": 2
   },
   {
    "source": 2,
    "target": 1321,
    "weight": 1
   },
   {
    "source": 34,
    "target": 1117,
    "weight": 1
   },
   {
    "source": 287,
    "target": 1117,
    "weight": 1
   },
   {
    "source": 200,
    "target": 1322,
    "weight": 1
   },
   {
    "source": 364,
    "target": 1322,
    "weight": 1
   },
   {
    "source": 246,
    "target": 364,
    "weight": 1
   },
   {
    "source": 246,
    "target": 362,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1142,
    "weight": 1
   },
   {
    "source": 27,
    "target": 311,
    "weight": 1
   },
   {
    "source": 311,
    "target": 1323,
    "weight": 1
   },
   {
    "source": 375,
    "target": 1323,
    "weight": 1
   },
   {
    "source": 200,
    "target": 351,
    "weight": 1
   },
   {
    "source": 755,
    "target": 1324,
    "weight": 3
   },
   {
    "source": 755,
    "target": 1325,
    "weight": 3
   },
   {
    "source": 375,
    "target": 1324,
    "weight": 1
   },
   {
    "source": 543,
    "target": 558,
    "weight": 1
   },
   {
    "source": 543,
    "target": 1325,
    "weight": 1
   },
   {
    "source": 2,
    "target": 7,
    "weight": 2
   },
   {
    "source": 26,
    "target": 558,
    "weight": 1
   },
   {
    "source": 3,
    "target": 8,
    "weight": 2
   },
   {
    "source": 540,
    "target": 1326,
    "weight": 1
   },
   {
    "source": 1326,
    "target": 1327,
    "weight": 1
   },
   {
    "source": 5,
    "target": 540,
    "weight": 1
   },
   {
    "source": 596,
    "target": 724,
    "weight": 3
   },
   {
    "source": 596,
    "target": 721,
    "weight": 1
   },
   {
    "source": 317,
    "target": 721,
    "weight": 1
   },
   {
    "source": 317,
    "target": 661,
    "weight": 1
   },
   {
    "source": 721,
    "target": 724,
    "weight": 1
   },
   {
    "source": 724,
    "target": 1327,
    "weight": 1
   },
   {
    "source": 53,
    "target": 1328,
    "weight": 1
   },
   {
    "source": 1328,
    "target": 1329,
    "weight": 1
   },
   {
    "source": 1329,
    "target": 1330,
    "weight": 1
   },
   {
    "source": 1330,
    "target": 1331,
    "weight": 1
   },
   {
    "source": 1328,
    "target": 1330,
    "weight": 1
   },
   {
    "source": 53,
    "target": 172,
    "weight": 1
   },
   {
    "source": 1331,
    "target": 1332,
    "weight": 1
   },
   {
    "source": 465,
    "target": 942,
    "weight": 1
   },
   {
    "source": 115,
    "target": 465,
    "weight": 1
   },
   {
    "source": 115,
    "target": 258,
    "weight": 2
   },
   {
    "source": 942,
    "target": 1332,
    "weight": 1
   },
   {
    "source": 1276,
    "target": 1333,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1333,
    "weight": 1
   },
   {
    "source": 258,
    "target": 1275,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1334,
    "weight": 1
   },
   {
    "source": 4,
    "target": 374,
    "weight": 1
   },
   {
    "source": 374,
    "target": 506,
    "weight": 1
   },
   {
    "source": 506,
    "target": 1335,
    "weight": 1
   },
   {
    "source": 75,
    "target": 1335,
    "weight": 1
   },
   {
    "source": 75,
    "target": 1336,
    "weight": 1
   },
   {
    "source": 272,
    "target": 1336,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1334,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1337,
    "weight": 7
   },
   {
    "source": 4,
    "target": 272,
    "weight": 1
   },
   {
    "source": 92,
    "target": 1337,
    "weight": 1
   },
   {
    "source": 854,
    "target": 1241,
    "weight": 1
   },
   {
    "source": 92,
    "target": 1241,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1338,
    "weight": 1
   },
   {
    "source": 1117,
    "target": 1338,
    "weight": 1
   },
   {
    "source": 853,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 2,
    "target": 228,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1117,
    "weight": 1
   },
   {
    "source": 230,
    "target": 1339,
    "weight": 1
   },
   {
    "source": 230,
    "target": 235,
    "weight": 1
   },
   {
    "source": 4,
    "target": 82,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1098,
    "weight": 2
   },
   {
    "source": 228,
    "target": 1339,
    "weight": 1
   },
   {
    "source": 1337,
    "target": 1340,
    "weight": 1
   },
   {
    "source": 227,
    "target": 426,
    "weight": 1
   },
   {
    "source": 123,
    "target": 757,
    "weight": 1
   },
   {
    "source": 152,
    "target": 757,
    "weight": 1
   },
   {
    "source": 227,
    "target": 1340,
    "weight": 1
   },
   {
    "source": 9,
    "target": 1341,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1123,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1342,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1341,
    "weight": 1
   },
   {
    "source": 1275,
    "target": 1343,
    "weight": 2
   },
   {
    "source": 1343,
    "target": 1344,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1344,
    "weight": 1
   },
   {
    "source": 1275,
    "target": 1342,
    "weight": 1
   },
   {
    "source": 557,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 30,
    "target": 140,
    "weight": 1
   },
   {
    "source": 140,
    "target": 1043,
    "weight": 1
   },
   {
    "source": 30,
    "target": 557,
    "weight": 2
   },
   {
    "source": 1117,
    "target": 1317,
    "weight": 2
   },
   {
    "source": 130,
    "target": 1117,
    "weight": 2
   },
   {
    "source": 130,
    "target": 1317,
    "weight": 1
   },
   {
    "source": 1043,
    "target": 1317,
    "weight": 1
   },
   {
    "source": 130,
    "target": 557,
    "weight": 1
   },
   {
    "source": 255,
    "target": 744,
    "weight": 1
   },
   {
    "source": 75,
    "target": 744,
    "weight": 1
   },
   {
    "source": 75,
    "target": 203,
    "weight": 1
   },
   {
    "source": 255,
    "target": 557,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1047,
    "weight": 2
   },
   {
    "source": 64,
    "target": 170,
    "weight": 3
   },
   {
    "source": 2,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 170,
    "target": 557,
    "weight": 1
   },
   {
    "source": 539,
    "target": 650,
    "weight": 1
   },
   {
    "source": 47,
    "target": 557,
    "weight": 1
   },
   {
    "source": 20,
    "target": 650,
    "weight": 1
   },
   {
    "source": 34,
    "target": 755,
    "weight": 3
   },
   {
    "source": 523,
    "target": 757,
    "weight": 2
   },
   {
    "source": 40,
    "target": 378,
    "weight": 3
   },
   {
    "source": 20,
    "target": 40,
    "weight": 3
   },
   {
    "source": 1301,
    "target": 1345,
    "weight": 6
   },
   {
    "source": 1301,
    "target": 1346,
    "weight": 10
   },
   {
    "source": 378,
    "target": 1345,
    "weight": 3
   },
   {
    "source": 557,
    "target": 1347,
    "weight": 1
   },
   {
    "source": 557,
    "target": 1346,
    "weight": 1
   },
   {
    "source": 596,
    "target": 745,
    "weight": 1
   },
   {
    "source": 137,
    "target": 745,
    "weight": 1
   },
   {
    "source": 137,
    "target": 261,
    "weight": 1
   },
   {
    "source": 261,
    "target": 596,
    "weight": 1
   },
   {
    "source": 596,
    "target": 1347,
    "weight": 1
   },
   {
    "source": 557,
    "target": 1348,
    "weight": 2
   },
   {
    "source": 73,
    "target": 115,
    "weight": 1
   },
   {
    "source": 30,
    "target": 737,
    "weight": 1
   },
   {
    "source": 30,
    "target": 73,
    "weight": 2
   },
   {
    "source": 73,
    "target": 1348,
    "weight": 2
   },
   {
    "source": 557,
    "target": 737,
    "weight": 1
   },
   {
    "source": 64,
    "target": 73,
    "weight": 2
   },
   {
    "source": 30,
    "target": 1349,
    "weight": 1
   },
   {
    "source": 1349,
    "target": 1350,
    "weight": 1
   },
   {
    "source": 1301,
    "target": 1351,
    "weight": 4
   },
   {
    "source": 1350,
    "target": 1351,
    "weight": 1
   },
   {
    "source": 1352,
    "target": 1353,
    "weight": 1
   },
   {
    "source": 1346,
    "target": 1352,
    "weight": 1
   },
   {
    "source": 575,
    "target": 1354,
    "weight": 1
   },
   {
    "source": 116,
    "target": 1354,
    "weight": 1
   },
   {
    "source": 62,
    "target": 116,
    "weight": 1
   },
   {
    "source": 62,
    "target": 112,
    "weight": 1
   },
   {
    "source": 575,
    "target": 1353,
    "weight": 2
   },
   {
    "source": 326,
    "target": 688,
    "weight": 1
   },
   {
    "source": 152,
    "target": 326,
    "weight": 2
   },
   {
    "source": 112,
    "target": 688,
    "weight": 1
   },
   {
    "source": 524,
    "target": 1355,
    "weight": 1
   },
   {
    "source": 302,
    "target": 1355,
    "weight": 1
   },
   {
    "source": 152,
    "target": 524,
    "weight": 1
   },
   {
    "source": 137,
    "target": 356,
    "weight": 1
   },
   {
    "source": 137,
    "target": 503,
    "weight": 1
   },
   {
    "source": 302,
    "target": 356,
    "weight": 1
   },
   {
    "source": 1356,
    "target": 1357,
    "weight": 4
   },
   {
    "source": 503,
    "target": 1356,
    "weight": 1
   },
   {
    "source": 34,
    "target": 688,
    "weight": 4
   },
   {
    "source": 39,
    "target": 1357,
    "weight": 4
   },
   {
    "source": 1358,
    "target": 1359,
    "weight": 4
   },
   {
    "source": 1194,
    "target": 1359,
    "weight": 4
   },
   {
    "source": 152,
    "target": 1358,
    "weight": 4
   },
   {
    "source": 1360,
    "target": 1361,
    "weight": 1
   },
   {
    "source": 1361,
    "target": 1362,
    "weight": 1
   },
   {
    "source": 1362,
    "target": 1363,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1360,
    "weight": 1
   },
   {
    "source": 65,
    "target": 1364,
    "weight": 1
   },
   {
    "source": 47,
    "target": 65,
    "weight": 1
   },
   {
    "source": 47,
    "target": 86,
    "weight": 1
   },
   {
    "source": 86,
    "target": 1046,
    "weight": 1
   },
   {
    "source": 1046,
    "target": 1365,
    "weight": 1
   },
   {
    "source": 1365,
    "target": 1366,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1366,
    "weight": 1
   },
   {
    "source": 11,
    "target": 106,
    "weight": 1
   },
   {
    "source": 106,
    "target": 1367,
    "weight": 1
   },
   {
    "source": 1367,
    "target": 1368,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1365,
    "weight": 1
   },
   {
    "source": 1363,
    "target": 1364,
    "weight": 1
   },
   {
    "source": 53,
    "target": 1329,
    "weight": 4
   },
   {
    "source": 1329,
    "target": 1369,
    "weight": 5
   },
   {
    "source": 7,
    "target": 1369,
    "weight": 4
   },
   {
    "source": 8,
    "target": 1245,
    "weight": 2
   },
   {
    "source": 53,
    "target": 1368,
    "weight": 1
   },
   {
    "source": 1246,
    "target": 1360,
    "weight": 1
   },
   {
    "source": 103,
    "target": 164,
    "weight": 1
   },
   {
    "source": 103,
    "target": 115,
    "weight": 1
   },
   {
    "source": 164,
    "target": 1360,
    "weight": 1
   },
   {
    "source": 1370,
    "target": 1371,
    "weight": 2
   },
   {
    "source": 115,
    "target": 1370,
    "weight": 1
   },
   {
    "source": 267,
    "target": 1157,
    "weight": 2
   },
   {
    "source": 1157,
    "target": 1371,
    "weight": 2
   },
   {
    "source": 1289,
    "target": 1372,
    "weight": 8
   },
   {
    "source": 152,
    "target": 1372,
    "weight": 2
   },
   {
    "source": 0,
    "target": 1289,
    "weight": 2
   },
   {
    "source": 1107,
    "target": 1373,
    "weight": 1
   },
   {
    "source": 75,
    "target": 1373,
    "weight": 1
   },
   {
    "source": 75,
    "target": 433,
    "weight": 1
   },
   {
    "source": 64,
    "target": 434,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1107,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1370,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 426,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 4,
    "target": 426,
    "weight": 1
   },
   {
    "source": 11,
    "target": 154,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 543,
    "target": 1374,
    "weight": 1
   },
   {
    "source": 11,
    "target": 543,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1170,
    "weight": 6
   },
   {
    "source": 4,
    "target": 755,
    "weight": 6
   },
   {
    "source": 755,
    "target": 1375,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1375,
    "weight": 1
   },
   {
    "source": 1170,
    "target": 1374,
    "weight": 1
   },
   {
    "source": 362,
    "target": 1376,
    "weight": 2
   },
   {
    "source": 362,
    "target": 1377,
    "weight": 2
   },
   {
    "source": 11,
    "target": 1376,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1378,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1377,
    "weight": 1
   },
   {
    "source": 272,
    "target": 417,
    "weight": 1
   },
   {
    "source": 272,
    "target": 640,
    "weight": 1
   },
   {
    "source": 426,
    "target": 640,
    "weight": 1
   },
   {
    "source": 64,
    "target": 426,
    "weight": 1
   },
   {
    "source": 417,
    "target": 1378,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1379,
    "weight": 2
   },
   {
    "source": 0,
    "target": 5,
    "weight": 1
   },
   {
    "source": 110,
    "target": 154,
    "weight": 1
   },
   {
    "source": 154,
    "target": 986,
    "weight": 1
   },
   {
    "source": 246,
    "target": 986,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1379,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1380,
    "weight": 1
   },
   {
    "source": 32,
    "target": 50,
    "weight": 1
   },
   {
    "source": 75,
    "target": 104,
    "weight": 1
   },
   {
    "source": 104,
    "target": 272,
    "weight": 1
   },
   {
    "source": 32,
    "target": 1380,
    "weight": 1
   },
   {
    "source": 3,
    "target": 272,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1381,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1382,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1381,
    "weight": 1
   },
   {
    "source": 1383,
    "target": 1384,
    "weight": 1
   },
   {
    "source": 1384,
    "target": 1385,
    "weight": 1
   },
   {
    "source": 1385,
    "target": 1386,
    "weight": 1
   },
   {
    "source": 1382,
    "target": 1383,
    "weight": 1
   },
   {
    "source": 558,
    "target": 1386,
    "weight": 1
   },
   {
    "source": 47,
    "target": 72,
    "weight": 1
   },
   {
    "source": 2,
    "target": 52,
    "weight": 1
   },
   {
    "source": 52,
    "target": 73,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1387,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1387,
    "weight": 1
   },
   {
    "source": 4,
    "target": 225,
    "weight": 1
   },
   {
    "source": 73,
    "target": 225,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1388,
    "weight": 1
   },
   {
    "source": 920,
    "target": 1388,
    "weight": 1
   },
   {
    "source": 52,
    "target": 72,
    "weight": 1
   },
   {
    "source": 73,
    "target": 920,
    "weight": 1
   },
   {
    "source": 4,
    "target": 920,
    "weight": 1
   },
   {
    "source": 558,
    "target": 1286,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1389,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1389,
    "weight": 1
   },
   {
    "source": 64,
    "target": 558,
    "weight": 1
   },
   {
    "source": 543,
    "target": 1390,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1390,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1391,
    "weight": 2
   },
   {
    "source": 543,
    "target": 1391,
    "weight": 1
   },
   {
    "source": 1301,
    "target": 1392,
    "weight": 4
   },
   {
    "source": 1301,
    "target": 1377,
    "weight": 4
   },
   {
    "source": 4,
    "target": 1392,
    "weight": 1
   },
   {
    "source": 558,
    "target": 1377,
    "weight": 1
   },
   {
    "source": 46,
    "target": 564,
    "weight": 1
   },
   {
    "source": 137,
    "target": 657,
    "weight": 1
   },
   {
    "source": 137,
    "target": 269,
    "weight": 1
   },
   {
    "source": 40,
    "target": 761,
    "weight": 4
   },
   {
    "source": 761,
    "target": 1369,
    "weight": 1
   },
   {
    "source": 1369,
    "target": 1393,
    "weight": 1
   },
   {
    "source": 1393,
    "target": 1394,
    "weight": 1
   },
   {
    "source": 1394,
    "target": 1395,
    "weight": 1
   },
   {
    "source": 558,
    "target": 1395,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1369,
    "weight": 1
   },
   {
    "source": 53,
    "target": 761,
    "weight": 1
   },
   {
    "source": 543,
    "target": 1396,
    "weight": 2
   },
   {
    "source": 72,
    "target": 1396,
    "weight": 1
   },
   {
    "source": 543,
    "target": 1170,
    "weight": 2
   },
   {
    "source": 755,
    "target": 1392,
    "weight": 3
   },
   {
    "source": 6,
    "target": 1397,
    "weight": 1
   },
   {
    "source": 1397,
    "target": 1398,
    "weight": 1
   },
   {
    "source": 3,
    "target": 1377,
    "weight": 1
   },
   {
    "source": 65,
    "target": 115,
    "weight": 1
   },
   {
    "source": 65,
    "target": 1398,
    "weight": 1
   },
   {
    "source": 1344,
    "target": 1399,
    "weight": 1
   },
   {
    "source": 942,
    "target": 1344,
    "weight": 1
   },
   {
    "source": 79,
    "target": 942,
    "weight": 1
   },
   {
    "source": 79,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 79,
    "target": 1344,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1344,
    "weight": 1
   },
   {
    "source": 942,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1399,
    "weight": 1
   },
   {
    "source": 1400,
    "target": 1401,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1400,
    "weight": 1
   },
   {
    "source": 737,
    "target": 1082,
    "weight": 1
   },
   {
    "source": 122,
    "target": 1082,
    "weight": 1
   },
   {
    "source": 4,
    "target": 122,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1402,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1402,
    "weight": 1
   },
   {
    "source": 737,
    "target": 1401,
    "weight": 1
   },
   {
    "source": 755,
    "target": 1403,
    "weight": 1
   },
   {
    "source": 585,
    "target": 1404,
    "weight": 1
   },
   {
    "source": 73,
    "target": 585,
    "weight": 1
   },
   {
    "source": 72,
    "target": 73,
    "weight": 3
   },
   {
    "source": 1403,
    "target": 1404,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1386,
    "weight": 1
   },
   {
    "source": 30,
    "target": 755,
    "weight": 2
   },
   {
    "source": 34,
    "target": 284,
    "weight": 2
   },
   {
    "source": 73,
    "target": 284,
    "weight": 2
   },
   {
    "source": 1170,
    "target": 1386,
    "weight": 2
   },
   {
    "source": 2,
    "target": 1376,
    "weight": 1
   },
   {
    "source": 1405,
    "target": 1406,
    "weight": 1
   },
   {
    "source": 1377,
    "target": 1405,
    "weight": 1
   },
   {
    "source": 1226,
    "target": 1406,
    "weight": 1
   },
   {
    "source": 1407,
    "target": 1408,
    "weight": 5
   },
   {
    "source": 1408,
    "target": 1409,
    "weight": 5
   },
   {
    "source": 1226,
    "target": 1407,
    "weight": 1
   },
   {
    "source": 30,
    "target": 112,
    "weight": 5
   },
   {
    "source": 30,
    "target": 1409,
    "weight": 5
   },
   {
    "source": 1276,
    "target": 1410,
    "weight": 6
   },
   {
    "source": 1276,
    "target": 1411,
    "weight": 4
   },
   {
    "source": 1194,
    "target": 1411,
    "weight": 2
   },
   {
    "source": 112,
    "target": 1410,
    "weight": 4
   },
   {
    "source": 542,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 543,
    "target": 596,
    "weight": 1
   },
   {
    "source": 5,
    "target": 525,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1382,
    "weight": 1
   },
   {
    "source": 62,
    "target": 1382,
    "weight": 1
   },
   {
    "source": 40,
    "target": 526,
    "weight": 1
   },
   {
    "source": 83,
    "target": 591,
    "weight": 1
   },
   {
    "source": 62,
    "target": 590,
    "weight": 1
   },
   {
    "source": 23,
    "target": 83,
    "weight": 1
   },
   {
    "source": 9,
    "target": 1412,
    "weight": 2
   },
   {
    "source": 11,
    "target": 1412,
    "weight": 2
   },
   {
    "source": 11,
    "target": 75,
    "weight": 1
   },
   {
    "source": 75,
    "target": 115,
    "weight": 1
   },
   {
    "source": 9,
    "target": 75,
    "weight": 1
   },
   {
    "source": 75,
    "target": 1412,
    "weight": 1
   },
   {
    "source": 9,
    "target": 23,
    "weight": 1
   },
   {
    "source": 1157,
    "target": 1413,
    "weight": 2
   },
   {
    "source": 676,
    "target": 1157,
    "weight": 2
   },
   {
    "source": 676,
    "target": 1179,
    "weight": 2
   },
   {
    "source": 755,
    "target": 1179,
    "weight": 2
   },
   {
    "source": 256,
    "target": 1413,
    "weight": 1
   },
   {
    "source": 23,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 23,
    "target": 755,
    "weight": 1
   },
   {
    "source": 34,
    "target": 1414,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1415,
    "weight": 1
   },
   {
    "source": 1414,
    "target": 1415,
    "weight": 1
   },
   {
    "source": 1276,
    "target": 1416,
    "weight": 2
   },
   {
    "source": 115,
    "target": 1410,
    "weight": 1
   },
   {
    "source": 23,
    "target": 1416,
    "weight": 1
   },
   {
    "source": 462,
    "target": 1417,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1417,
    "weight": 1
   },
   {
    "source": 112,
    "target": 462,
    "weight": 1
   },
   {
    "source": 462,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1413,
    "weight": 1
   },
   {
    "source": 1418,
    "target": 1419,
    "weight": 1
   },
   {
    "source": 755,
    "target": 1418,
    "weight": 1
   },
   {
    "source": 200,
    "target": 241,
    "weight": 1
   },
   {
    "source": 241,
    "target": 1419,
    "weight": 1
   },
   {
    "source": 124,
    "target": 200,
    "weight": 1
   },
   {
    "source": 124,
    "target": 1420,
    "weight": 1
   },
   {
    "source": 1421,
    "target": 1422,
    "weight": 1
   },
   {
    "source": 1420,
    "target": 1421,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1422,
    "weight": 1
   },
   {
    "source": 527,
    "target": 1423,
    "weight": 1
   },
   {
    "source": 1423,
    "target": 1424,
    "weight": 1
   },
   {
    "source": 5,
    "target": 527,
    "weight": 1
   },
   {
    "source": 137,
    "target": 595,
    "weight": 1
   },
   {
    "source": 595,
    "target": 826,
    "weight": 1
   },
   {
    "source": 589,
    "target": 1424,
    "weight": 1
   },
   {
    "source": 326,
    "target": 755,
    "weight": 5
   },
   {
    "source": 326,
    "target": 826,
    "weight": 1
   },
   {
    "source": 113,
    "target": 755,
    "weight": 1
   },
   {
    "source": 119,
    "target": 1425,
    "weight": 1
   },
   {
    "source": 118,
    "target": 1426,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1426,
    "weight": 1
   },
   {
    "source": 113,
    "target": 1425,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1345,
    "weight": 1
   },
   {
    "source": 1427,
    "target": 1428,
    "weight": 1
   },
   {
    "source": 1346,
    "target": 1427,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1429,
    "weight": 1
   },
   {
    "source": 249,
    "target": 1429,
    "weight": 1
   },
   {
    "source": 177,
    "target": 249,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1428,
    "weight": 1
   },
   {
    "source": 528,
    "target": 1430,
    "weight": 1
   },
   {
    "source": 528,
    "target": 1337,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1431,
    "weight": 1
   },
   {
    "source": 73,
    "target": 575,
    "weight": 4
   },
   {
    "source": 1430,
    "target": 1431,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1356,
    "weight": 1
   },
   {
    "source": 1037,
    "target": 1432,
    "weight": 1
   },
   {
    "source": 1432,
    "target": 1433,
    "weight": 1
   },
   {
    "source": 1037,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 27,
    "target": 628,
    "weight": 1
   },
   {
    "source": 177,
    "target": 628,
    "weight": 2
   },
   {
    "source": 628,
    "target": 1433,
    "weight": 1
   },
   {
    "source": 1434,
    "target": 1435,
    "weight": 1
   },
   {
    "source": 177,
    "target": 1434,
    "weight": 1
   },
   {
    "source": 1170,
    "target": 1435,
    "weight": 1
   },
   {
    "source": 1436,
    "target": 1437,
    "weight": 1
   },
   {
    "source": 685,
    "target": 1437,
    "weight": 1
   },
   {
    "source": 1377,
    "target": 1436,
    "weight": 1
   },
   {
    "source": 203,
    "target": 728,
    "weight": 1
   },
   {
    "source": 203,
    "target": 746,
    "weight": 1
   },
   {
    "source": 724,
    "target": 746,
    "weight": 1
   },
   {
    "source": 2,
    "target": 724,
    "weight": 2
   },
   {
    "source": 685,
    "target": 728,
    "weight": 1
   },
   {
    "source": 44,
    "target": 357,
    "weight": 1
   },
   {
    "source": 44,
    "target": 739,
    "weight": 1
   },
   {
    "source": 256,
    "target": 739,
    "weight": 1
   },
   {
    "source": 152,
    "target": 357,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1305,
    "weight": 1
   },
   {
    "source": 125,
    "target": 130,
    "weight": 1
   },
   {
    "source": 125,
    "target": 182,
    "weight": 1
   },
   {
    "source": 1311,
    "target": 1438,
    "weight": 1
   },
   {
    "source": 1438,
    "target": 1439,
    "weight": 1
   },
   {
    "source": 39,
    "target": 182,
    "weight": 1
   },
   {
    "source": 544,
    "target": 1439,
    "weight": 1
   },
   {
    "source": 269,
    "target": 545,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1317,
    "weight": 3
   },
   {
    "source": 1317,
    "target": 1425,
    "weight": 3
   },
   {
    "source": 269,
    "target": 1425,
    "weight": 3
   },
   {
    "source": 269,
    "target": 755,
    "weight": 3
   },
   {
    "source": 40,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 1440,
    "target": 1441,
    "weight": 1
   },
   {
    "source": 1307,
    "target": 1441,
    "weight": 1
   },
   {
    "source": 755,
    "target": 1440,
    "weight": 1
   },
   {
    "source": 287,
    "target": 761,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1241,
    "weight": 1
   },
   {
    "source": 269,
    "target": 1307,
    "weight": 1
   },
   {
    "source": 1442,
    "target": 1443,
    "weight": 1
   },
   {
    "source": 1301,
    "target": 1443,
    "weight": 1
   },
   {
    "source": 1301,
    "target": 1444,
    "weight": 2
   },
   {
    "source": 1444,
    "target": 1445,
    "weight": 2
   },
   {
    "source": 1241,
    "target": 1442,
    "weight": 1
   },
   {
    "source": 1229,
    "target": 1445,
    "weight": 1
   },
   {
    "source": 575,
    "target": 596,
    "weight": 1
   },
   {
    "source": 575,
    "target": 1229,
    "weight": 1
   },
   {
    "source": 596,
    "target": 1351,
    "weight": 1
   },
   {
    "source": 860,
    "target": 1346,
    "weight": 1
   },
   {
    "source": 27,
    "target": 853,
    "weight": 1
   },
   {
    "source": 47,
    "target": 680,
    "weight": 1
   },
   {
    "source": 680,
    "target": 1446,
    "weight": 1
   },
   {
    "source": 853,
    "target": 860,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1446,
    "weight": 1
   },
   {
    "source": 47,
    "target": 860,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1447,
    "weight": 1
   },
   {
    "source": 30,
    "target": 326,
    "weight": 1
   },
   {
    "source": 326,
    "target": 730,
    "weight": 1
   },
   {
    "source": 26,
    "target": 730,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1448,
    "weight": 2
   },
   {
    "source": 860,
    "target": 1447,
    "weight": 1
   },
   {
    "source": 27,
    "target": 676,
    "weight": 2
   },
   {
    "source": 676,
    "target": 1325,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1325,
    "weight": 1
   },
   {
    "source": 860,
    "target": 1325,
    "weight": 1
   },
   {
    "source": 27,
    "target": 860,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 860,
    "target": 1449,
    "weight": 1
   },
   {
    "source": 860,
    "target": 1450,
    "weight": 1
   },
   {
    "source": 1233,
    "target": 1450,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1449,
    "weight": 1
   },
   {
    "source": 728,
    "target": 857,
    "weight": 1
   },
   {
    "source": 47,
    "target": 854,
    "weight": 1
   },
   {
    "source": 853,
    "target": 1233,
    "weight": 1
   },
   {
    "source": 27,
    "target": 850,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1451,
    "weight": 1
   },
   {
    "source": 31,
    "target": 246,
    "weight": 1
   },
   {
    "source": 31,
    "target": 269,
    "weight": 1
   },
   {
    "source": 157,
    "target": 269,
    "weight": 1
   },
   {
    "source": 115,
    "target": 157,
    "weight": 1
   },
   {
    "source": 168,
    "target": 1451,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1452,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1453,
    "weight": 1
   },
   {
    "source": 1453,
    "target": 1454,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1452,
    "weight": 1
   },
   {
    "source": 5,
    "target": 371,
    "weight": 1
   },
   {
    "source": 371,
    "target": 1454,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1287,
    "weight": 1
   },
   {
    "source": 559,
    "target": 1455,
    "weight": 1
   },
   {
    "source": 559,
    "target": 1289,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1456,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1316,
    "weight": 1
   },
   {
    "source": 1316,
    "target": 1457,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1457,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1458,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1457,
    "weight": 1
   },
   {
    "source": 11,
    "target": 26,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1316,
    "weight": 1
   },
   {
    "source": 1455,
    "target": 1456,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1458,
    "weight": 1
   },
   {
    "source": 1353,
    "target": 1459,
    "weight": 1
   },
   {
    "source": 755,
    "target": 1459,
    "weight": 1
   },
   {
    "source": 575,
    "target": 1460,
    "weight": 1
   },
   {
    "source": 764,
    "target": 1460,
    "weight": 1
   },
   {
    "source": 177,
    "target": 764,
    "weight": 1
   },
   {
    "source": 177,
    "target": 1461,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1461,
    "weight": 1
   },
   {
    "source": 152,
    "target": 575,
    "weight": 1
   },
   {
    "source": 15,
    "target": 575,
    "weight": 1
   },
   {
    "source": 15,
    "target": 326,
    "weight": 1
   },
   {
    "source": 372,
    "target": 755,
    "weight": 1
   },
   {
    "source": 39,
    "target": 255,
    "weight": 1
   },
   {
    "source": 39,
    "target": 75,
    "weight": 1
   },
   {
    "source": 75,
    "target": 140,
    "weight": 1
   },
   {
    "source": 155,
    "target": 372,
    "weight": 1
   },
   {
    "source": 81,
    "target": 1047,
    "weight": 2
   },
   {
    "source": 107,
    "target": 1305,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1462,
    "weight": 1
   },
   {
    "source": 167,
    "target": 853,
    "weight": 1
   },
   {
    "source": 27,
    "target": 167,
    "weight": 1
   },
   {
    "source": 853,
    "target": 1462,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1463,
    "weight": 2
   },
   {
    "source": 15,
    "target": 1464,
    "weight": 2
   },
   {
    "source": 1194,
    "target": 1464,
    "weight": 2
   },
   {
    "source": 30,
    "target": 1463,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1462,
    "weight": 2
   },
   {
    "source": 1425,
    "target": 1465,
    "weight": 1
   },
   {
    "source": 1425,
    "target": 1466,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1466,
    "weight": 1
   },
   {
    "source": 1462,
    "target": 1465,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1463,
    "weight": 1
   },
   {
    "source": 434,
    "target": 1310,
    "weight": 1
   },
   {
    "source": 434,
    "target": 1462,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1467,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1467,
    "weight": 1
   },
   {
    "source": 1310,
    "target": 1467,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1468,
    "weight": 1
   },
   {
    "source": 594,
    "target": 1469,
    "weight": 1
   },
   {
    "source": 737,
    "target": 1469,
    "weight": 1
   },
   {
    "source": 594,
    "target": 1468,
    "weight": 1
   },
   {
    "source": 1293,
    "target": 1470,
    "weight": 2
   },
   {
    "source": 737,
    "target": 1293,
    "weight": 1
   },
   {
    "source": 1471,
    "target": 1472,
    "weight": 1
   },
   {
    "source": 1472,
    "target": 1473,
    "weight": 1
   },
   {
    "source": 1470,
    "target": 1471,
    "weight": 1
   },
   {
    "source": 609,
    "target": 1015,
    "weight": 1
   },
   {
    "source": 781,
    "target": 1015,
    "weight": 1
   },
   {
    "source": 138,
    "target": 781,
    "weight": 1
   },
   {
    "source": 112,
    "target": 138,
    "weight": 1
   },
   {
    "source": 609,
    "target": 1473,
    "weight": 1
   },
   {
    "source": 112,
    "target": 326,
    "weight": 2
   },
   {
    "source": 1471,
    "target": 1474,
    "weight": 1
   },
   {
    "source": 755,
    "target": 1471,
    "weight": 1
   },
   {
    "source": 62,
    "target": 152,
    "weight": 1
   },
   {
    "source": 152,
    "target": 746,
    "weight": 1
   },
   {
    "source": 62,
    "target": 1474,
    "weight": 1
   },
   {
    "source": 464,
    "target": 755,
    "weight": 1
   },
   {
    "source": 374,
    "target": 465,
    "weight": 1
   },
   {
    "source": 374,
    "target": 1475,
    "weight": 1
   },
   {
    "source": 79,
    "target": 1475,
    "weight": 1
   },
   {
    "source": 79,
    "target": 1324,
    "weight": 1
   },
   {
    "source": 1324,
    "target": 1325,
    "weight": 2
   },
   {
    "source": 1325,
    "target": 1476,
    "weight": 1
   },
   {
    "source": 245,
    "target": 1477,
    "weight": 1
   },
   {
    "source": 1165,
    "target": 1477,
    "weight": 1
   },
   {
    "source": 254,
    "target": 1165,
    "weight": 1
   },
   {
    "source": 245,
    "target": 1476,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1478,
    "weight": 1
   },
   {
    "source": 1472,
    "target": 1479,
    "weight": 1
   },
   {
    "source": 1408,
    "target": 1479,
    "weight": 1
   },
   {
    "source": 1472,
    "target": 1478,
    "weight": 1
   },
   {
    "source": 190,
    "target": 413,
    "weight": 1
   },
   {
    "source": 413,
    "target": 746,
    "weight": 1
   },
   {
    "source": 190,
    "target": 1408,
    "weight": 1
   },
   {
    "source": 73,
    "target": 112,
    "weight": 1
   },
   {
    "source": 530,
    "target": 1480,
    "weight": 1
   },
   {
    "source": 1480,
    "target": 1481,
    "weight": 1
   },
   {
    "source": 530,
    "target": 575,
    "weight": 1
   },
   {
    "source": 26,
    "target": 112,
    "weight": 2
   },
   {
    "source": 26,
    "target": 1482,
    "weight": 1
   },
   {
    "source": 195,
    "target": 1482,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1481,
    "weight": 1
   },
   {
    "source": 61,
    "target": 404,
    "weight": 1
   },
   {
    "source": 40,
    "target": 61,
    "weight": 1
   },
   {
    "source": 40,
    "target": 65,
    "weight": 1
   },
   {
    "source": 531,
    "target": 627,
    "weight": 1
   },
   {
    "source": 11,
    "target": 531,
    "weight": 1
   },
   {
    "source": 61,
    "target": 65,
    "weight": 1
   },
   {
    "source": 61,
    "target": 627,
    "weight": 1
   },
   {
    "source": 40,
    "target": 627,
    "weight": 2
   },
   {
    "source": 195,
    "target": 404,
    "weight": 1
   },
   {
    "source": 7,
    "target": 1047,
    "weight": 2
   },
   {
    "source": 1047,
    "target": 1482,
    "weight": 1
   },
   {
    "source": 1482,
    "target": 1483,
    "weight": 1
   },
   {
    "source": 1025,
    "target": 1484,
    "weight": 1
   },
   {
    "source": 1025,
    "target": 1485,
    "weight": 1
   },
   {
    "source": 1483,
    "target": 1484,
    "weight": 1
   },
   {
    "source": 683,
    "target": 929,
    "weight": 1
   },
   {
    "source": 683,
    "target": 1178,
    "weight": 1
   },
   {
    "source": 914,
    "target": 1485,
    "weight": 1
   },
   {
    "source": 944,
    "target": 1486,
    "weight": 1
   },
   {
    "source": 959,
    "target": 1486,
    "weight": 1
   },
   {
    "source": 920,
    "target": 959,
    "weight": 1
   },
   {
    "source": 920,
    "target": 1487,
    "weight": 1
   },
   {
    "source": 1487,
    "target": 1488,
    "weight": 1
   },
   {
    "source": 1488,
    "target": 1489,
    "weight": 1
   },
   {
    "source": 1489,
    "target": 1490,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1490,
    "weight": 1
   },
   {
    "source": 1311,
    "target": 1491,
    "weight": 1
   },
   {
    "source": 1491,
    "target": 1492,
    "weight": 1
   },
   {
    "source": 1492,
    "target": 1493,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1493,
    "weight": 1
   },
   {
    "source": 2,
    "target": 329,
    "weight": 1
   },
   {
    "source": 112,
    "target": 329,
    "weight": 1
   },
   {
    "source": 107,
    "target": 112,
    "weight": 1
   },
   {
    "source": 107,
    "target": 1494,
    "weight": 1
   },
   {
    "source": 920,
    "target": 1486,
    "weight": 1
   },
   {
    "source": 944,
    "target": 1178,
    "weight": 1
   },
   {
    "source": 1494,
    "target": 1495,
    "weight": 1
   },
   {
    "source": 4,
    "target": 329,
    "weight": 1
   },
   {
    "source": 329,
    "target": 1286,
    "weight": 1
   },
   {
    "source": 329,
    "target": 1495,
    "weight": 1
   },
   {
    "source": 1496,
    "target": 1497,
    "weight": 1
   },
   {
    "source": 1497,
    "target": 1498,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1498,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1498,
    "weight": 1
   },
   {
    "source": 1286,
    "target": 1496,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1492,
    "weight": 1
   },
   {
    "source": 106,
    "target": 1494,
    "weight": 1
   },
   {
    "source": 106,
    "target": 457,
    "weight": 1
   },
   {
    "source": 1492,
    "target": 1494,
    "weight": 1
   },
   {
    "source": 457,
    "target": 1386,
    "weight": 1
   },
   {
    "source": 1311,
    "target": 1377,
    "weight": 1
   },
   {
    "source": 1499,
    "target": 1500,
    "weight": 2
   },
   {
    "source": 1377,
    "target": 1499,
    "weight": 1
   },
   {
    "source": 54,
    "target": 112,
    "weight": 1
   },
   {
    "source": 54,
    "target": 595,
    "weight": 1
   },
   {
    "source": 595,
    "target": 730,
    "weight": 1
   },
   {
    "source": 597,
    "target": 730,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1500,
    "weight": 1
   },
   {
    "source": 597,
    "target": 688,
    "weight": 1
   },
   {
    "source": 688,
    "target": 1499,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1501,
    "weight": 1
   },
   {
    "source": 15,
    "target": 730,
    "weight": 1
   },
   {
    "source": 619,
    "target": 730,
    "weight": 1
   },
   {
    "source": 1500,
    "target": 1501,
    "weight": 1
   },
   {
    "source": 618,
    "target": 1502,
    "weight": 1
   },
   {
    "source": 594,
    "target": 1501,
    "weight": 1
   },
   {
    "source": 1501,
    "target": 1502,
    "weight": 1
   },
   {
    "source": 594,
    "target": 1293,
    "weight": 1
   },
   {
    "source": 1470,
    "target": 1503,
    "weight": 1
   },
   {
    "source": 444,
    "target": 1504,
    "weight": 1
   },
   {
    "source": 426,
    "target": 444,
    "weight": 1
   },
   {
    "source": 1503,
    "target": 1504,
    "weight": 1
   },
   {
    "source": 195,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 1321,
    "target": 1505,
    "weight": 1
   },
   {
    "source": 170,
    "target": 1321,
    "weight": 1
   },
   {
    "source": 188,
    "target": 1019,
    "weight": 1
   },
   {
    "source": 188,
    "target": 287,
    "weight": 1
   },
   {
    "source": 2,
    "target": 287,
    "weight": 1
   },
   {
    "source": 2,
    "target": 369,
    "weight": 1
   },
   {
    "source": 188,
    "target": 369,
    "weight": 1
   },
   {
    "source": 287,
    "target": 369,
    "weight": 1
   },
   {
    "source": 1018,
    "target": 1505,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1506,
    "weight": 1
   },
   {
    "source": 757,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 676,
    "target": 757,
    "weight": 1
   },
   {
    "source": 369,
    "target": 1506,
    "weight": 1
   },
   {
    "source": 560,
    "target": 676,
    "weight": 1
   },
   {
    "source": 721,
    "target": 794,
    "weight": 1
   },
   {
    "source": 251,
    "target": 721,
    "weight": 1
   },
   {
    "source": 251,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1507,
    "weight": 1
   },
   {
    "source": 1223,
    "target": 1507,
    "weight": 1
   },
   {
    "source": 484,
    "target": 1223,
    "weight": 1
   },
   {
    "source": 560,
    "target": 794,
    "weight": 1
   },
   {
    "source": 484,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 1360,
    "target": 1508,
    "weight": 1
   },
   {
    "source": 1356,
    "target": 1360,
    "weight": 1
   },
   {
    "source": 755,
    "target": 1508,
    "weight": 1
   },
   {
    "source": 47,
    "target": 369,
    "weight": 1
   },
   {
    "source": 129,
    "target": 369,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1356,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1338,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1338,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1338,
    "weight": 1
   },
   {
    "source": 73,
    "target": 129,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1509,
    "weight": 1
   },
   {
    "source": 746,
    "target": 781,
    "weight": 1
   },
   {
    "source": 781,
    "target": 1228,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1228,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1509,
    "weight": 1
   },
   {
    "source": 40,
    "target": 1407,
    "weight": 1
   },
   {
    "source": 532,
    "target": 1510,
    "weight": 1
   },
   {
    "source": 532,
    "target": 1511,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1510,
    "weight": 1
   },
   {
    "source": 44,
    "target": 674,
    "weight": 1
   },
   {
    "source": 674,
    "target": 1148,
    "weight": 1
   },
   {
    "source": 1148,
    "target": 1512,
    "weight": 1
   },
   {
    "source": 846,
    "target": 1512,
    "weight": 1
   },
   {
    "source": 44,
    "target": 846,
    "weight": 1
   },
   {
    "source": 44,
    "target": 1511,
    "weight": 1
   },
   {
    "source": 1513,
    "target": 1514,
    "weight": 1
   },
   {
    "source": 44,
    "target": 1513,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1514,
    "weight": 1
   },
   {
    "source": 532,
    "target": 1289,
    "weight": 1
   },
   {
    "source": 40,
    "target": 103,
    "weight": 1
   },
   {
    "source": 533,
    "target": 752,
    "weight": 1
   },
   {
    "source": 103,
    "target": 590,
    "weight": 1
   },
   {
    "source": 6,
    "target": 1515,
    "weight": 1
   },
   {
    "source": 1515,
    "target": 1516,
    "weight": 1
   },
   {
    "source": 3,
    "target": 591,
    "weight": 1
   },
   {
    "source": 688,
    "target": 1517,
    "weight": 1
   },
   {
    "source": 152,
    "target": 737,
    "weight": 1
   },
   {
    "source": 688,
    "target": 737,
    "weight": 1
   },
   {
    "source": 575,
    "target": 1517,
    "weight": 1
   },
   {
    "source": 199,
    "target": 1517,
    "weight": 1
   },
   {
    "source": 1516,
    "target": 1517,
    "weight": 1
   },
   {
    "source": 988,
    "target": 1518,
    "weight": 1
   },
   {
    "source": 1518,
    "target": 1519,
    "weight": 1
   },
   {
    "source": 1301,
    "target": 1519,
    "weight": 1
   },
   {
    "source": 988,
    "target": 1519,
    "weight": 1
   },
   {
    "source": 199,
    "target": 988,
    "weight": 1
   },
   {
    "source": 1520,
    "target": 1521,
    "weight": 1
   },
   {
    "source": 1445,
    "target": 1520,
    "weight": 1
   },
   {
    "source": 718,
    "target": 746,
    "weight": 1
   },
   {
    "source": 718,
    "target": 1522,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1522,
    "weight": 1
   },
   {
    "source": 746,
    "target": 1521,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1291,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1291,
    "weight": 1
   },
   {
    "source": 1289,
    "target": 1437,
    "weight": 1
   },
   {
    "source": 1437,
    "target": 1523,
    "weight": 1
   },
   {
    "source": 326,
    "target": 1523,
    "weight": 1
   },
   {
    "source": 755,
    "target": 1524,
    "weight": 1
   },
   {
    "source": 426,
    "target": 998,
    "weight": 1
   },
   {
    "source": 426,
    "target": 1524,
    "weight": 1
   },
   {
    "source": 1311,
    "target": 1525,
    "weight": 1
   },
   {
    "source": 1525,
    "target": 1526,
    "weight": 1
   },
   {
    "source": 39,
    "target": 998,
    "weight": 1
   },
   {
    "source": 1526,
    "target": 1527,
    "weight": 1
   },
   {
    "source": 215,
    "target": 1020,
    "weight": 1
   },
   {
    "source": 215,
    "target": 1528,
    "weight": 1
   },
   {
    "source": 1020,
    "target": 1527,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1528,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1527,
    "weight": 3
   },
   {
    "source": 47,
    "target": 1021,
    "weight": 1
   },
   {
    "source": 322,
    "target": 1021,
    "weight": 1
   },
   {
    "source": 322,
    "target": 1529,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1529,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1530,
    "weight": 1
   },
   {
    "source": 287,
    "target": 1530,
    "weight": 1
   },
   {
    "source": 1021,
    "target": 1529,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1021,
    "weight": 1
   },
   {
    "source": 2,
    "target": 322,
    "weight": 1
   },
   {
    "source": 1527,
    "target": 1531,
    "weight": 1
   },
   {
    "source": 267,
    "target": 1274,
    "weight": 1
   },
   {
    "source": 267,
    "target": 1050,
    "weight": 1
   },
   {
    "source": 157,
    "target": 1050,
    "weight": 1
   },
   {
    "source": 64,
    "target": 157,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1122,
    "weight": 1
   },
   {
    "source": 1274,
    "target": 1531,
    "weight": 1
   },
   {
    "source": 1317,
    "target": 1532,
    "weight": 1
   },
   {
    "source": 1122,
    "target": 1317,
    "weight": 1
   },
   {
    "source": 1532,
    "target": 1533,
    "weight": 1
   },
   {
    "source": 661,
    "target": 1533,
    "weight": 1
   },
   {
    "source": 1353,
    "target": 1534,
    "weight": 2
   },
   {
    "source": 1289,
    "target": 1534,
    "weight": 2
   },
   {
    "source": 172,
    "target": 1353,
    "weight": 1
   },
   {
    "source": 17,
    "target": 1289,
    "weight": 1
   },
   {
    "source": 64,
    "target": 256,
    "weight": 2
   },
   {
    "source": 75,
    "target": 256,
    "weight": 1
   },
   {
    "source": 65,
    "target": 75,
    "weight": 1
   },
   {
    "source": 9,
    "target": 17,
    "weight": 1
   },
   {
    "source": 1535,
    "target": 1536,
    "weight": 1
   },
   {
    "source": 1536,
    "target": 1537,
    "weight": 1
   },
   {
    "source": 13,
    "target": 1537,
    "weight": 1
   },
   {
    "source": 1535,
    "target": 1537,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1535,
    "weight": 1
   },
   {
    "source": 685,
    "target": 1436,
    "weight": 1
   },
   {
    "source": 1436,
    "target": 1538,
    "weight": 1
   },
   {
    "source": 98,
    "target": 685,
    "weight": 1
   },
   {
    "source": 724,
    "target": 737,
    "weight": 1
   },
   {
    "source": 737,
    "target": 1538,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1539,
    "weight": 1
   },
   {
    "source": 619,
    "target": 1539,
    "weight": 1
   },
   {
    "source": 618,
    "target": 688,
    "weight": 1
   },
   {
    "source": 688,
    "target": 1540,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 27,
    "target": 352,
    "weight": 1
   },
   {
    "source": 352,
    "target": 647,
    "weight": 1
   },
   {
    "source": 647,
    "target": 1050,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1050,
    "weight": 1
   },
   {
    "source": 352,
    "target": 1157,
    "weight": 1
   },
   {
    "source": 1157,
    "target": 1540,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1047,
    "weight": 2
   },
   {
    "source": 534,
    "target": 614,
    "weight": 1
   },
   {
    "source": 4,
    "target": 534,
    "weight": 1
   },
   {
    "source": 494,
    "target": 757,
    "weight": 1
   },
   {
    "source": 629,
    "target": 757,
    "weight": 1
   },
   {
    "source": 58,
    "target": 629,
    "weight": 1
   },
   {
    "source": 58,
    "target": 300,
    "weight": 1
   },
   {
    "source": 300,
    "target": 641,
    "weight": 1
   },
   {
    "source": 494,
    "target": 613,
    "weight": 1
   },
   {
    "source": 73,
    "target": 641,
    "weight": 1
   },
   {
    "source": 1541,
    "target": 1542,
    "weight": 1
   },
   {
    "source": 1542,
    "target": 1543,
    "weight": 1
   },
   {
    "source": 1543,
    "target": 1544,
    "weight": 1
   },
   {
    "source": 575,
    "target": 1541,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1244,
    "weight": 1
   },
   {
    "source": 81,
    "target": 1244,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1544,
    "weight": 1
   },
   {
    "source": 3,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 3,
    "target": 73,
    "weight": 1
   },
   {
    "source": 73,
    "target": 124,
    "weight": 1
   },
   {
    "source": 7,
    "target": 81,
    "weight": 1
   },
   {
    "source": 1356,
    "target": 1545,
    "weight": 1
   },
   {
    "source": 124,
    "target": 1545,
    "weight": 1
   },
   {
    "source": 152,
    "target": 269,
    "weight": 3
   },
   {
    "source": 392,
    "target": 1356,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1546,
    "weight": 2
   },
   {
    "source": 4,
    "target": 761,
    "weight": 1
   },
   {
    "source": 547,
    "target": 1546,
    "weight": 1
   },
   {
    "source": 596,
    "target": 1085,
    "weight": 1
   },
   {
    "source": 602,
    "target": 648,
    "weight": 1
   },
   {
    "source": 548,
    "target": 1085,
    "weight": 1
   },
   {
    "source": 34,
    "target": 1547,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1547,
    "weight": 1
   },
   {
    "source": 34,
    "target": 170,
    "weight": 1
   },
   {
    "source": 170,
    "target": 602,
    "weight": 1
   },
   {
    "source": 1548,
    "target": 1549,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1548,
    "weight": 1
   },
   {
    "source": 688,
    "target": 1366,
    "weight": 1
   },
   {
    "source": 152,
    "target": 1550,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1550,
    "weight": 2
   },
   {
    "source": 5,
    "target": 1551,
    "weight": 1
   },
   {
    "source": 1366,
    "target": 1549,
    "weight": 1
   },
   {
    "source": 130,
    "target": 1329,
    "weight": 1
   },
   {
    "source": 130,
    "target": 676,
    "weight": 1
   },
   {
    "source": 1329,
    "target": 1551,
    "weight": 1
   },
   {
    "source": 676,
    "target": 1552,
    "weight": 1
   },
   {
    "source": 376,
    "target": 1553,
    "weight": 1
   },
   {
    "source": 376,
    "target": 1554,
    "weight": 1
   },
   {
    "source": 475,
    "target": 1554,
    "weight": 1
   },
   {
    "source": 72,
    "target": 475,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1555,
    "weight": 1
   },
   {
    "source": 332,
    "target": 1555,
    "weight": 1
   },
   {
    "source": 332,
    "target": 496,
    "weight": 1
   },
   {
    "source": 496,
    "target": 1555,
    "weight": 1
   },
   {
    "source": 1552,
    "target": 1553,
    "weight": 1
   },
   {
    "source": 208,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1325,
    "weight": 3
   },
   {
    "source": 208,
    "target": 1325,
    "weight": 1
   },
   {
    "source": 496,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 21,
    "target": 1325,
    "weight": 2
   },
   {
    "source": 4,
    "target": 859,
    "weight": 1
   },
   {
    "source": 4,
    "target": 872,
    "weight": 1
   },
   {
    "source": 872,
    "target": 1367,
    "weight": 1
   },
   {
    "source": 137,
    "target": 1367,
    "weight": 1
   },
   {
    "source": 859,
    "target": 872,
    "weight": 1
   },
   {
    "source": 21,
    "target": 859,
    "weight": 1
   },
   {
    "source": 4,
    "target": 81,
    "weight": 3
   },
   {
    "source": 81,
    "target": 1325,
    "weight": 2
   },
   {
    "source": 81,
    "target": 137,
    "weight": 1
   },
   {
    "source": 162,
    "target": 326,
    "weight": 1
   },
   {
    "source": 4,
    "target": 162,
    "weight": 1
   },
   {
    "source": 103,
    "target": 918,
    "weight": 1
   },
   {
    "source": 21,
    "target": 326,
    "weight": 1
   },
   {
    "source": 918,
    "target": 1432,
    "weight": 1
   },
   {
    "source": 326,
    "target": 627,
    "weight": 1
   },
   {
    "source": 144,
    "target": 627,
    "weight": 1
   },
   {
    "source": 326,
    "target": 1432,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1351,
    "weight": 1
   },
   {
    "source": 21,
    "target": 1346,
    "weight": 1
   },
   {
    "source": 107,
    "target": 1335,
    "weight": 1
   },
   {
    "source": 107,
    "target": 1556,
    "weight": 1
   },
   {
    "source": 157,
    "target": 1556,
    "weight": 1
   },
   {
    "source": 126,
    "target": 157,
    "weight": 1
   },
   {
    "source": 4,
    "target": 126,
    "weight": 1
   },
   {
    "source": 21,
    "target": 1335,
    "weight": 1
   },
   {
    "source": 8,
    "target": 1557,
    "weight": 1
   },
   {
    "source": 1557,
    "target": 1558,
    "weight": 1
   },
   {
    "source": 53,
    "target": 115,
    "weight": 1
   },
   {
    "source": 21,
    "target": 1558,
    "weight": 1
   },
   {
    "source": 30,
    "target": 154,
    "weight": 1
   },
   {
    "source": 47,
    "target": 115,
    "weight": 1
   },
   {
    "source": 115,
    "target": 317,
    "weight": 1
   },
   {
    "source": 317,
    "target": 413,
    "weight": 1
   },
   {
    "source": 413,
    "target": 1559,
    "weight": 1
   },
   {
    "source": 0,
    "target": 154,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1559,
    "weight": 1
   },
   {
    "source": 21,
    "target": 1337,
    "weight": 1
   },
   {
    "source": 2,
    "target": 911,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1002,
    "weight": 1
   },
   {
    "source": 957,
    "target": 1002,
    "weight": 1
   },
   {
    "source": 914,
    "target": 957,
    "weight": 1
   },
   {
    "source": 0,
    "target": 911,
    "weight": 1
   },
   {
    "source": 53,
    "target": 1243,
    "weight": 1
   },
   {
    "source": 1243,
    "target": 1329,
    "weight": 1
   },
   {
    "source": 53,
    "target": 929,
    "weight": 1
   },
   {
    "source": 21,
    "target": 1246,
    "weight": 1
   },
   {
    "source": 152,
    "target": 262,
    "weight": 1
   },
   {
    "source": 10,
    "target": 34,
    "weight": 1
   },
   {
    "source": 23,
    "target": 262,
    "weight": 1
   },
   {
    "source": 8,
    "target": 1560,
    "weight": 1
   },
   {
    "source": 1560,
    "target": 1561,
    "weight": 1
   },
   {
    "source": 53,
    "target": 65,
    "weight": 1
   },
   {
    "source": 613,
    "target": 1561,
    "weight": 1
   },
   {
    "source": 499,
    "target": 1225,
    "weight": 1
   },
   {
    "source": 613,
    "target": 629,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1225,
    "weight": 1
   },
   {
    "source": 613,
    "target": 1562,
    "weight": 1
   },
   {
    "source": 1514,
    "target": 1562,
    "weight": 1
   },
   {
    "source": 613,
    "target": 1546,
    "weight": 1
   },
   {
    "source": 417,
    "target": 521,
    "weight": 1
   },
   {
    "source": 117,
    "target": 521,
    "weight": 1
   },
   {
    "source": 117,
    "target": 144,
    "weight": 1
   },
   {
    "source": 417,
    "target": 1514,
    "weight": 1
   },
   {
    "source": 613,
    "target": 1563,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1563,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1391,
    "weight": 1
   },
   {
    "source": 144,
    "target": 1391,
    "weight": 1
   },
   {
    "source": 0,
    "target": 613,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1372,
    "weight": 2
   },
   {
    "source": 535,
    "target": 1289,
    "weight": 1
   },
   {
    "source": 39,
    "target": 137,
    "weight": 1
   },
   {
    "source": 137,
    "target": 1564,
    "weight": 1
   },
   {
    "source": 39,
    "target": 535,
    "weight": 1
   },
   {
    "source": 1356,
    "target": 1564,
    "weight": 1
   },
   {
    "source": 549,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 112,
    "target": 700,
    "weight": 1
   },
   {
    "source": 550,
    "target": 700,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1356,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1565,
    "weight": 1
   },
   {
    "source": 112,
    "target": 177,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1261,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1261,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1354,
    "weight": 1
   },
   {
    "source": 619,
    "target": 1354,
    "weight": 1
   },
   {
    "source": 780,
    "target": 1354,
    "weight": 1
   },
   {
    "source": 177,
    "target": 1565,
    "weight": 1
   },
   {
    "source": 780,
    "target": 1407,
    "weight": 1
   },
   {
    "source": 536,
    "target": 1411,
    "weight": 1
   },
   {
    "source": 269,
    "target": 688,
    "weight": 1
   },
   {
    "source": 761,
    "target": 1170,
    "weight": 1
   },
   {
    "source": 195,
    "target": 1170,
    "weight": 1
   },
   {
    "source": 269,
    "target": 392,
    "weight": 1
   },
   {
    "source": 392,
    "target": 761,
    "weight": 1
   },
   {
    "source": 688,
    "target": 761,
    "weight": 1
   },
   {
    "source": 392,
    "target": 538,
    "weight": 1
   },
   {
    "source": 81,
    "target": 152,
    "weight": 2
   },
   {
    "source": 195,
    "target": 269,
    "weight": 1
   },
   {
    "source": 81,
    "target": 1566,
    "weight": 1
   },
   {
    "source": 190,
    "target": 1567,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1567,
    "weight": 1
   },
   {
    "source": 2,
    "target": 115,
    "weight": 2
   },
   {
    "source": 190,
    "target": 1566,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1317,
    "weight": 1
   },
   {
    "source": 130,
    "target": 1433,
    "weight": 1
   },
   {
    "source": 107,
    "target": 297,
    "weight": 3
   },
   {
    "source": 37,
    "target": 107,
    "weight": 2
   },
   {
    "source": 140,
    "target": 1568,
    "weight": 1
   },
   {
    "source": 379,
    "target": 1568,
    "weight": 1
   },
   {
    "source": 30,
    "target": 379,
    "weight": 1
   },
   {
    "source": 30,
    "target": 297,
    "weight": 1
   },
   {
    "source": 37,
    "target": 1568,
    "weight": 1
   },
   {
    "source": 297,
    "target": 1433,
    "weight": 1
   },
   {
    "source": 4,
    "target": 107,
    "weight": 1
   },
   {
    "source": 1037,
    "target": 1433,
    "weight": 1
   },
   {
    "source": 1337,
    "target": 1433,
    "weight": 1
   },
   {
    "source": 61,
    "target": 177,
    "weight": 1
   },
   {
    "source": 628,
    "target": 742,
    "weight": 1
   },
   {
    "source": 177,
    "target": 742,
    "weight": 1
   },
   {
    "source": 34,
    "target": 1037,
    "weight": 1
   },
   {
    "source": 3,
    "target": 742,
    "weight": 1
   },
   {
    "source": 1433,
    "target": 1569,
    "weight": 2
   },
   {
    "source": 5,
    "target": 1433,
    "weight": 2
   },
   {
    "source": 4,
    "target": 737,
    "weight": 1
   },
   {
    "source": 4,
    "target": 140,
    "weight": 3
   },
   {
    "source": 737,
    "target": 1569,
    "weight": 1
   },
   {
    "source": 297,
    "target": 1569,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1433,
    "weight": 1
   },
   {
    "source": 297,
    "target": 1372,
    "weight": 1
   },
   {
    "source": 1433,
    "target": 1570,
    "weight": 1
   },
   {
    "source": 1289,
    "target": 1433,
    "weight": 1
   },
   {
    "source": 140,
    "target": 215,
    "weight": 1
   },
   {
    "source": 215,
    "target": 821,
    "weight": 1
   },
   {
    "source": 75,
    "target": 821,
    "weight": 1
   },
   {
    "source": 297,
    "target": 1570,
    "weight": 1
   },
   {
    "source": 3,
    "target": 75,
    "weight": 1
   },
   {
    "source": 1433,
    "target": 1571,
    "weight": 1
   },
   {
    "source": 1571,
    "target": 1572,
    "weight": 1
   },
   {
    "source": 1572,
    "target": 1573,
    "weight": 1
   },
   {
    "source": 23,
    "target": 1573,
    "weight": 1
   },
   {
    "source": 23,
    "target": 1574,
    "weight": 1
   },
   {
    "source": 1571,
    "target": 1573,
    "weight": 1
   },
   {
    "source": 256,
    "target": 752,
    "weight": 1
   },
   {
    "source": 152,
    "target": 752,
    "weight": 1
   },
   {
    "source": 30,
    "target": 152,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1574,
    "weight": 1
   },
   {
    "source": 1311,
    "target": 1410,
    "weight": 2
   },
   {
    "source": 15,
    "target": 1410,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1410,
    "weight": 1
   },
   {
    "source": 40,
    "target": 73,
    "weight": 1
   },
   {
    "source": 73,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 2,
    "target": 1372,
    "weight": 1
   },
   {
    "source": 1427,
    "target": 1575,
    "weight": 1
   },
   {
    "source": 1289,
    "target": 1575,
    "weight": 1
   },
   {
    "source": 115,
    "target": 122,
    "weight": 1
   },
   {
    "source": 122,
    "target": 147,
    "weight": 1
   },
   {
    "source": 112,
    "target": 1427,
    "weight": 1
   },
   {
    "source": 1575,
    "target": 1576,
    "weight": 1
   },
   {
    "source": 147,
    "target": 1576,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1391,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1575,
    "weight": 1
   },
   {
    "source": 563,
    "target": 1289,
    "weight": 1
   },
   {
    "source": 309,
    "target": 1577,
    "weight": 1
   },
   {
    "source": 309,
    "target": 356,
    "weight": 1
   },
   {
    "source": 356,
    "target": 1577,
    "weight": 1
   },
   {
    "source": 558,
    "target": 1577,
    "weight": 1
   },
   {
    "source": 360,
    "target": 695,
    "weight": 1
   },
   {
    "source": 198,
    "target": 695,
    "weight": 1
   },
   {
    "source": 507,
    "target": 825,
    "weight": 1
   },
   {
    "source": 198,
    "target": 825,
    "weight": 1
   },
   {
    "source": 356,
    "target": 596,
    "weight": 1
   },
   {
    "source": 4,
    "target": 942,
    "weight": 1
   },
   {
    "source": 825,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1396,
    "weight": 1
   },
   {
    "source": 75,
    "target": 287,
    "weight": 1
   },
   {
    "source": 75,
    "target": 150,
    "weight": 1
   },
   {
    "source": 47,
    "target": 150,
    "weight": 1
   },
   {
    "source": 287,
    "target": 1396,
    "weight": 1
   },
   {
    "source": 21,
    "target": 1578,
    "weight": 1
   },
   {
    "source": 2,
    "target": 21,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1130,
    "weight": 1
   },
   {
    "source": 1130,
    "target": 1579,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1579,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1292,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1578,
    "weight": 1
   },
   {
    "source": 1292,
    "target": 1353,
    "weight": 1
   },
   {
    "source": 1580,
    "target": 1581,
    "weight": 1
   },
   {
    "source": 1581,
    "target": 1582,
    "weight": 1
   },
   {
    "source": 1289,
    "target": 1580,
    "weight": 1
   },
   {
    "source": 71,
    "target": 104,
    "weight": 1
   },
   {
    "source": 104,
    "target": 727,
    "weight": 1
   },
   {
    "source": 2,
    "target": 5,
    "weight": 1
   },
   {
    "source": 71,
    "target": 1582,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1345,
    "weight": 1
   },
   {
    "source": 20,
    "target": 1346,
    "weight": 1
   },
   {
    "source": 34,
    "target": 523,
    "weight": 1
   },
   {
    "source": 1583,
    "target": 1584,
    "weight": 1
   },
   {
    "source": 1346,
    "target": 1583,
    "weight": 1
   },
   {
    "source": 713,
    "target": 894,
    "weight": 1
   },
   {
    "source": 137,
    "target": 894,
    "weight": 1
   },
   {
    "source": 137,
    "target": 794,
    "weight": 1
   },
   {
    "source": 40,
    "target": 794,
    "weight": 1
   },
   {
    "source": 137,
    "target": 713,
    "weight": 1
   },
   {
    "source": 761,
    "target": 794,
    "weight": 1
   },
   {
    "source": 713,
    "target": 1584,
    "weight": 1
   },
   {
    "source": 1454,
    "target": 1585,
    "weight": 1
   },
   {
    "source": 81,
    "target": 1585,
    "weight": 1
   },
   {
    "source": 115,
    "target": 650,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1586,
    "weight": 2
   },
   {
    "source": 650,
    "target": 1454,
    "weight": 1
   },
   {
    "source": 1587,
    "target": 1588,
    "weight": 1
   },
   {
    "source": 1586,
    "target": 1587,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1117,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1117,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1588,
    "weight": 1
   },
   {
    "source": 362,
    "target": 1589,
    "weight": 1
   },
   {
    "source": 362,
    "target": 1590,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1590,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1589,
    "weight": 1
   },
   {
    "source": 1591,
    "target": 1592,
    "weight": 1
   },
   {
    "source": 1194,
    "target": 1591,
    "weight": 1
   },
   {
    "source": 355,
    "target": 1593,
    "weight": 1
   },
   {
    "source": 521,
    "target": 1593,
    "weight": 1
   },
   {
    "source": 227,
    "target": 521,
    "weight": 1
   },
   {
    "source": 227,
    "target": 1594,
    "weight": 1
   },
   {
    "source": 3,
    "target": 1594,
    "weight": 1
   },
   {
    "source": 3,
    "target": 65,
    "weight": 1
   },
   {
    "source": 26,
    "target": 65,
    "weight": 1
   },
   {
    "source": 3,
    "target": 26,
    "weight": 1
   },
   {
    "source": 355,
    "target": 1592,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1351,
    "weight": 1
   },
   {
    "source": 1346,
    "target": 1595,
    "weight": 1
   },
   {
    "source": 137,
    "target": 1595,
    "weight": 1
   },
   {
    "source": 137,
    "target": 1410,
    "weight": 1
   },
   {
    "source": 0,
    "target": 133,
    "weight": 1
   },
   {
    "source": 1379,
    "target": 1416,
    "weight": 1
   },
   {
    "source": 107,
    "target": 258,
    "weight": 1
   },
   {
    "source": 30,
    "target": 258,
    "weight": 1
   },
   {
    "source": 30,
    "target": 641,
    "weight": 1
   },
   {
    "source": 115,
    "target": 641,
    "weight": 1
   },
   {
    "source": 107,
    "target": 133,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1596,
    "weight": 1
   },
   {
    "source": 30,
    "target": 37,
    "weight": 1
   },
   {
    "source": 4,
    "target": 130,
    "weight": 1
   },
   {
    "source": 130,
    "target": 1597,
    "weight": 1
   },
   {
    "source": 390,
    "target": 1597,
    "weight": 1
   },
   {
    "source": 5,
    "target": 390,
    "weight": 1
   },
   {
    "source": 26,
    "target": 1596,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1598,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1598,
    "weight": 1
   },
   {
    "source": 1286,
    "target": 1372,
    "weight": 2
   },
   {
    "source": 1599,
    "target": 1600,
    "weight": 1
   },
   {
    "source": 1289,
    "target": 1599,
    "weight": 1
   },
   {
    "source": 217,
    "target": 424,
    "weight": 1
   },
   {
    "source": 424,
    "target": 1600,
    "weight": 1
   },
   {
    "source": 20,
    "target": 217,
    "weight": 1
   },
   {
    "source": 1346,
    "target": 1601,
    "weight": 1
   },
   {
    "source": 72,
    "target": 284,
    "weight": 1
   },
   {
    "source": 2,
    "target": 59,
    "weight": 1
   },
   {
    "source": 40,
    "target": 59,
    "weight": 1
   },
   {
    "source": 2,
    "target": 284,
    "weight": 1
   },
   {
    "source": 59,
    "target": 284,
    "weight": 1
   },
   {
    "source": 59,
    "target": 72,
    "weight": 1
   },
   {
    "source": 284,
    "target": 1601,
    "weight": 1
   },
   {
    "source": 3,
    "target": 761,
    "weight": 1
   },
   {
    "source": 1329,
    "target": 1546,
    "weight": 1
   },
   {
    "source": 1369,
    "target": 1546,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1369,
    "weight": 1
   },
   {
    "source": 11,
    "target": 251,
    "weight": 1
   },
   {
    "source": 251,
    "target": 1602,
    "weight": 1
   },
   {
    "source": 1487,
    "target": 1602,
    "weight": 1
   },
   {
    "source": 53,
    "target": 627,
    "weight": 1
   },
   {
    "source": 1603,
    "target": 1604,
    "weight": 1
   },
   {
    "source": 1487,
    "target": 1603,
    "weight": 1
   },
   {
    "source": 8,
    "target": 602,
    "weight": 1
   },
   {
    "source": 8,
    "target": 1605,
    "weight": 1
   },
   {
    "source": 595,
    "target": 1604,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1550,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1605,
    "weight": 1
   },
   {
    "source": 1606,
    "target": 1607,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1606,
    "weight": 1
   },
   {
    "source": 4,
    "target": 326,
    "weight": 1
   },
   {
    "source": 674,
    "target": 1607,
    "weight": 1
   },
   {
    "source": 1343,
    "target": 1416,
    "weight": 1
   },
   {
    "source": 326,
    "target": 1275,
    "weight": 1
   },
   {
    "source": 1608,
    "target": 1609,
    "weight": 1
   },
   {
    "source": 1609,
    "target": 1610,
    "weight": 1
   },
   {
    "source": 1416,
    "target": 1608,
    "weight": 1
   },
   {
    "source": 44,
    "target": 1366,
    "weight": 1
   },
   {
    "source": 272,
    "target": 1366,
    "weight": 1
   },
   {
    "source": 155,
    "target": 272,
    "weight": 1
   },
   {
    "source": 155,
    "target": 1611,
    "weight": 1
   },
   {
    "source": 1366,
    "target": 1611,
    "weight": 1
   },
   {
    "source": 1168,
    "target": 1366,
    "weight": 1
   },
   {
    "source": 1168,
    "target": 1612,
    "weight": 1
   },
   {
    "source": 392,
    "target": 1612,
    "weight": 1
   },
   {
    "source": 44,
    "target": 392,
    "weight": 1
   },
   {
    "source": 44,
    "target": 1610,
    "weight": 1
   },
   {
    "source": 3,
    "target": 44,
    "weight": 1
   },
   {
    "source": 5,
    "target": 551,
    "weight": 2
   },
   {
    "source": 73,
    "target": 650,
    "weight": 1
   },
   {
    "source": 2,
    "target": 650,
    "weight": 2
   },
   {
    "source": 2,
    "target": 1613,
    "weight": 1
   },
   {
    "source": 245,
    "target": 1613,
    "weight": 1
   },
   {
    "source": 73,
    "target": 551,
    "weight": 1
   },
   {
    "source": 3,
    "target": 245,
    "weight": 1
   },
   {
    "source": 2,
    "target": 709,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1614,
    "weight": 2
   },
   {
    "source": 551,
    "target": 650,
    "weight": 1
   },
   {
    "source": 1237,
    "target": 1337,
    "weight": 1
   },
   {
    "source": 34,
    "target": 853,
    "weight": 1
   },
   {
    "source": 34,
    "target": 67,
    "weight": 2
   },
   {
    "source": 853,
    "target": 1238,
    "weight": 1
   },
   {
    "source": 27,
    "target": 67,
    "weight": 1
   },
   {
    "source": 47,
    "target": 1615,
    "weight": 1
   },
   {
    "source": 81,
    "target": 103,
    "weight": 1
   },
   {
    "source": 281,
    "target": 596,
    "weight": 1
   },
   {
    "source": 1048,
    "target": 1615,
    "weight": 1
   },
   {
    "source": 5,
    "target": 646,
    "weight": 1
   },
   {
    "source": 646,
    "target": 1026,
    "weight": 1
   },
   {
    "source": 853,
    "target": 1026,
    "weight": 1
   },
   {
    "source": 147,
    "target": 853,
    "weight": 1
   },
   {
    "source": 147,
    "target": 390,
    "weight": 1
   },
   {
    "source": 390,
    "target": 475,
    "weight": 1
   },
   {
    "source": 64,
    "target": 134,
    "weight": 1
   },
   {
    "source": 475,
    "target": 1616,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1616,
    "weight": 1
   },
   {
    "source": 131,
    "target": 1571,
    "weight": 1
   },
   {
    "source": 131,
    "target": 1289,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1617,
    "weight": 1
   },
   {
    "source": 1617,
    "target": 1618,
    "weight": 1
   },
   {
    "source": 164,
    "target": 1571,
    "weight": 1
   },
   {
    "source": 1345,
    "target": 1618,
    "weight": 1
   },
   {
    "source": 5,
    "target": 1619,
    "weight": 1
   },
   {
    "source": 5,
    "target": 73,
    "weight": 1
   },
   {
    "source": 73,
    "target": 669,
    "weight": 2
   },
   {
    "source": 87,
    "target": 669,
    "weight": 1
   },
   {
    "source": 1346,
    "target": 1619,
    "weight": 1
   },
   {
    "source": 73,
    "target": 95,
    "weight": 1
   },
   {
    "source": 95,
    "target": 1620,
    "weight": 1
   },
   {
    "source": 1620,
    "target": 1621,
    "weight": 1
   },
   {
    "source": 1619,
    "target": 1621,
    "weight": 1
   },
   {
    "source": 1500,
    "target": 1619,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1500,
    "weight": 1
   },
   {
    "source": 1311,
    "target": 1622,
    "weight": 2
   },
   {
    "source": 1534,
    "target": 1622,
    "weight": 2
   },
   {
    "source": 39,
    "target": 258,
    "weight": 1
   },
   {
    "source": 552,
    "target": 1534,
    "weight": 1
   },
   {
    "source": 64,
    "target": 1049,
    "weight": 1
   },
   {
    "source": 75,
    "target": 1049,
    "weight": 2
   },
   {
    "source": 1049,
    "target": 1623,
    "weight": 1
   },
   {
    "source": 4,
    "target": 1623,
    "weight": 1
   },
   {
    "source": 64,
    "target": 553,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1624,
    "weight": 1
   },
   {
    "source": 1337,
    "target": 1624,
    "weight": 1
   },
   {
    "source": 1625,
    "target": 1626,
    "weight": 1
   },
   {
    "source": 65,
    "target": 1626,
    "weight": 1
   },
   {
    "source": 64,
    "target": 81,
    "weight": 1
   },
   {
    "source": 0,
    "target": 1625,
    "weight": 1
   },
   {
    "source": 1325,
    "target": 1627,
    "weight": 1
   },
   {
    "source": 1024,
    "target": 1628,
    "weight": 1
   },
   {
    "source": 65,
    "target": 1024,
    "weight": 1
   },
   {
    "source": 11,
    "target": 65,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1629,
    "weight": 1
   },
   {
    "source": 137,
    "target": 1629,
    "weight": 1
   },
   {
    "source": 11,
    "target": 1024,
    "weight": 1
   },
   {
    "source": 1627,
    "target": 1628,
    "weight": 1
   },
   {
    "source": 81,
    "target": 790,
    "weight": 1
   },
   {
    "source": 790,
    "target": 1047,
    "weight": 1
   },
   {
    "source": 137,
    "target": 790,
    "weight": 1
   },
   {
    "source": 1047,
    "target": 1630,
    "weight": 1
   },
   {
    "source": 781,
    "target": 1631,
    "weight": 1
   },
   {
    "source": 781,
    "target": 1227,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1227,
    "weight": 1
   },
   {
    "source": 15,
    "target": 1632,
    "weight": 1
   },
   {
    "source": 48,
    "target": 1632,
    "weight": 1
   },
   {
    "source": 1630,
    "target": 1631,
    "weight": 1
   },
   {
    "source": 48,
    "target": 1407,
    "weight": 1
   },
   {
    "source": 599,
    "target": 1486,
    "weight": 2
   },
   {
    "source": 1486,
    "target": 1555,
    "weight": 1
   },
   {
    "source": 1033,
    "target": 1555,
    "weight": 1
   },
   {
    "source": 1033,
    "target": 1633,
    "weight": 1
   },
   {
    "source": 1633,
    "target": 1634,
    "weight": 1
   },
   {
    "source": 1555,
    "target": 1633,
    "weight": 1
   },
   {
    "source": 599,
    "target": 1411,
    "weight": 1
   },
   {
    "source": 1033,
    "target": 1311,
    "weight": 1
   },
   {
    "source": 715,
    "target": 1033,
    "weight": 1
   },
   {
    "source": 375,
    "target": 715,
    "weight": 1
   },
   {
    "source": 375,
    "target": 1635,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1635,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1636,
    "weight": 1
   },
   {
    "source": 599,
    "target": 1636,
    "weight": 1
   },
   {
    "source": 39,
    "target": 1634,
    "weight": 1
   },
   {
    "source": 1637,
    "target": 1638,
    "weight": 1
   },
   {
    "source": 1486,
    "target": 1637,
    "weight": 1
   },
   {
    "source": 11,
    "target": 188,
    "weight": 1
   },
   {
    "source": 11,
    "target": 30,
    "weight": 1
   },
   {
    "source": 30,
    "target": 585,
    "weight": 1
   },
   {
    "source": 107,
    "target": 585,
    "weight": 1
   },
   {
    "source": 67,
    "target": 107,
    "weight": 1
   },
   {
    "source": 30,
    "target": 188,
    "weight": 2
   },
   {
    "source": 188,
    "target": 1638,
    "weight": 1
   },
   {
    "source": 1311,
    "target": 1639,
    "weight": 1
   },
   {
    "source": 1639,
    "target": 1640,
    "weight": 1
   },
   {
    "source": 39,
    "target": 67,
    "weight": 2
   },
   {
    "source": 1407,
    "target": 1640,
    "weight": 1
   },
   {
    "source": 39,
    "target": 112,
    "weight": 1
   },
   {
    "source": 1235,
    "target": 1410,
    "weight": 1
   },
   {
    "source": 27,
    "target": 1236,
    "weight": 1
   },
   {
    "source": 1275,
    "target": 1311,
    "weight": 1
   },
   {
    "source": 440,
    "target": 1194,
    "weight": 1
   },
   {
    "source": 27,
    "target": 440,
    "weight": 1
   },
   {
    "source": 39,
    "target": 676,
    "weight": 1
   },
   {
    "source": 20,
    "target": 440,
    "weight": 1
   },
   {
    "source": 440,
    "target": 1534,
    "weight": 1
   },
   {
    "source": 28,
    "target": 1586,
    "weight": 1
   },
   {
    "source": 115,
    "target": 1641,
    "weight": 1
   },
   {
    "source": 1641,
    "target": 1642,
    "weight": 1
   },
   {
    "source": 1642,
    "target": 1643,
    "weight": 1
   },
   {
    "source": 20,
    "target": 28,
    "weight": 1
   },
   {
    "source": 1324,
    "target": 1643,
    "weight": 1
   },
   {
    "source": 671,
    "target": 1325,
    "weight": 1
   },
   {
    "source": 326,
    "target": 671,
    "weight": 1
   },
   {
    "source": 30,
    "target": 1396,
    "weight": 1
   },
   {
    "source": 671,
    "target": 1377,
    "weight": 1
   },
   {
    "source": 4,
    "target": 728,
    "weight": 1
   },
   {
    "source": 152,
    "target": 669,
    "weight": 1
   },
   {
    "source": 30,
    "target": 669,
    "weight": 1
   },
   {
    "source": 728,
    "target": 1040,
    "weight": 1
   },
   {
    "source": 1056,
    "target": 1311,
    "weight": 1
   },
   {
    "source": 1056,
    "target": 1194,
    "weight": 1
   }
  ]
 },
 "summary": {
  "centralization": {
   "degree": 0.11468,
   "betweenness": 0.10402,
   "closeness": 0.3068,
   "eigenvector": 0.97602
  },
  "closenessNote": "",
  "meanInfluence": 0.0015,
  "nodeCount": 1644,
  "edgeCount": 6420
 }
}
```

---
*Please cite: Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002). Studying complex discursive systems: Centering Resonance Analysis of organizational communication. Human Communication Research, 28(2), 157-206.*
