/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M4 — Topic Modeler (Build Spec V2 §5.1; D-V2-5, D-V2-7, D-V2-8).
 *
 * NMF (Lee & Seung, 1999) on a document–term matrix, deterministic
 * end-to-end: NNDSVD initialization (Boutsidis & Gallopoulos, 2008),
 * multiplicative updates, fixed iteration cap (500) and tolerance (1e-6),
 * fixed update order. No LDA (D-V2-8).
 *
 * Ports are reference-faithful:
 *  - NNDSVD ports scikit-learn `_initialize_nmf(init='nndsvd')` including
 *    the 1e-6 truncation. NNDSVD is invariant to per-component SVD sign
 *    flips (flipping u_j, v_j swaps the ± parts and the larger product is
 *    chosen either way), so any exact SVD yields the same init. The SVD is
 *    computed exactly via Jacobi eigendecomposition of the document Gram
 *    matrix X·Xᵀ (documents ≤ a few hundred; vocabulary may be large).
 *  - The multiplicative-update loop ports scikit-learn
 *    `_fit_multiplicative_update` (beta=2/Frobenius): W *= XHᵀ/(WHHᵀ),
 *    H *= WᵀX/(WᵀWH), zero denominators replaced by EPSILON =
 *    1.1920929e-07 (float32 eps, as in sklearn), convergence checked every
 *    10 iterations on the Frobenius error against error-at-init.
 *    Oracle: sklearn NMF(solver='mu', init='custom' with our NNDSVD) —
 *    agreement 1e-6.
 *  - UMass coherence (Mimno et al., 2011) ports gensim's u_mass pipeline:
 *    s_one_pre segmentation over the top-N topic words, m = ln((D(wi,wj)/n
 *    + 1e-12)/(D(wj)/n)), arithmetic mean per topic, mean over topics.
 *    Oracle: gensim CoherenceModel(coherence='u_mass', topn=10).
 *
 * Input matrix (D-V2-5, both modes):
 *  - 'tfidf' (default): surface counts from each file's
 *    `surfaceFrequencies` block, keyphrase-stopword-filtered, tf·idf with
 *    sklearn's smooth idf  ln((1+n)/(1+df)) + 1  and L2 row normalization
 *    (variant recorded in the report).
 *  - 'influence': per-document node influence (stems) — a Crawdad-native
 *    variant, LABELED AS NOVEL in every output. L2 row normalization.
 *
 * K selection (topic-count analog of D-8): K₀ = round(√n documents),
 * accepted if UMass coherence(K₀) is within 10% of the coherence range of
 * the best K in [2, min(12, n−1)]; the full coherence-by-K table is always
 * reported and manual override is always available.
 */
(function (root) {
  'use strict';

  var EPSILON = 1.1920929e-07;  // sklearn nmf EPSILON (float32 eps)
  var UMASS_EPS = 1e-12;        // gensim direct_confirmation EPSILON

  function round5(x) { return Math.round(x * 1e5) / 1e5; }

  /* ------------------------------------------------------------------ *
   * Matrix construction (D-V2-5)
   * ------------------------------------------------------------------ */

  /**
   * Build the document–term matrix from loaded craData objects.
   * mode 'tfidf' needs surfaceFrequencies; mode 'influence' uses nodes.
   * deps: { isStopWord } (keyphrase closed-class list recommended)
   * Returns { X (n x V rows), vocab, names, excluded, mode, variant }
   */
  function buildMatrix(datas, names, opts, deps) {
    opts = opts || {};
    var mode = opts.mode || 'tfidf';
    var maxVocab = opts.maxVocab || 2000;
    var isStop = (deps && deps.isStopWord) || function () { return false; };

    var docs = [], used = [], excluded = [];
    datas.forEach(function (d, i) {
      if (mode === 'tfidf') {
        var sf = d.surfaceFrequencies;
        if (!sf || !sf.totalTokens || !sf.tokens) { excluded.push(names[i]); return; }
        var counts = Object.create(null);
        sf.tokens.forEach(function (t) {
          var w = t[0];
          if (w.length < 2 || isStop(w) || !/[a-z]/.test(w)) { return; }
          counts[w] = t[1];
        });
        docs.push(counts); used.push(names[i]);
      } else {
        var counts2 = Object.create(null);
        (d.network && d.network.nodes || []).forEach(function (nd) {
          if (nd.influence > 0) { counts2[nd.word] = nd.influence; }
        });
        docs.push(counts2); used.push(names[i]);
      }
    });
    var n = docs.length;

    // vocabulary: by document frequency, then summed value, then alpha
    var df = Object.create(null), sum = Object.create(null);
    docs.forEach(function (c) {
      Object.keys(c).forEach(function (w) {
        df[w] = (df[w] || 0) + 1;
        sum[w] = (sum[w] || 0) + c[w];
      });
    });
    var vocab = Object.keys(df)
      .filter(function (w) { return df[w] >= 2; }) // in ≥2 docs, else pure noise
      .sort(function (a, b) {
        return df[b] - df[a] || sum[b] - sum[a] || (a < b ? -1 : 1);
      })
      .slice(0, maxVocab);
    var wIdx = Object.create(null);
    vocab.forEach(function (w, j) { wIdx[w] = j; });

    var X = [];
    for (var i = 0; i < n; i++) {
      var row = new Array(vocab.length).fill(0);
      Object.keys(docs[i]).forEach(function (w) {
        if (wIdx[w] !== undefined) { row[wIdx[w]] = docs[i][w]; }
      });
      X.push(row);
    }
    if (mode === 'tfidf') {
      // sklearn smooth idf: ln((1+n)/(1+df)) + 1
      var idf = vocab.map(function (w) {
        return Math.log((1 + n) / (1 + df[w])) + 1;
      });
      X.forEach(function (row) {
        for (var j = 0; j < row.length; j++) { row[j] *= idf[j]; }
      });
    }
    // L2 row normalization (both modes; recorded)
    X.forEach(function (row) {
      var s = 0;
      for (var j = 0; j < row.length; j++) { s += row[j] * row[j]; }
      s = Math.sqrt(s);
      if (s > 0) { for (var j2 = 0; j2 < row.length; j2++) { row[j2] /= s; } }
    });
    return { X: X, vocab: vocab, names: used, excluded: excluded, mode: mode,
      variant: mode === 'tfidf'
        ? 'tf·idf, smooth idf ln((1+n)/(1+df))+1, L2 rows, keyphrase-stopword filter'
        : 'NOVEL influence-weighted matrix (per-document node influence), L2 rows' };
  }

  /* ------------------------------------------------------------------ *
   * Exact top-K SVD via the document Gram matrix (deps.jacobiEig)
   * ------------------------------------------------------------------ */

  function svdTopK(X, k, deps) {
    var n = X.length, V = X[0].length, i, j, l;
    var G = [];
    for (i = 0; i < n; i++) {
      G.push(new Array(n).fill(0));
      for (j = 0; j <= i; j++) {
        var s = 0;
        for (l = 0; l < V; l++) { s += X[i][l] * X[j][l]; }
        G[i][j] = s;
        if (j < i) { G[j] = G[j] || []; }
      }
    }
    for (i = 0; i < n; i++) { for (j = i + 1; j < n; j++) { G[i][j] = G[j][i]; } }
    var pairs = deps.jacobiEig(G); // [{value, vector}] sorted desc (themes.js)
    var U = [], S = [], Vt = [];
    for (var c = 0; c < k; c++) {
      var ev = Math.max(pairs[c].value, 0);
      var sv = Math.sqrt(ev);
      S.push(sv);
      var u = pairs[c].vector;
      U.push(u); // stored row-wise (component c across docs)
      var vrow = new Array(V).fill(0);
      if (sv > 0) {
        for (l = 0; l < V; l++) {
          var acc = 0;
          for (i = 0; i < n; i++) { acc += u[i] * X[i][l]; }
          vrow[l] = acc / sv;
        }
      }
      Vt.push(vrow);
    }
    return { U: U, S: S, Vt: Vt }; // U[c][i], S[c], Vt[c][l]
  }

  /* ------------------------------------------------------------------ *
   * NNDSVD (sklearn-faithful; sign-flip invariant)
   * ------------------------------------------------------------------ */

  function nndsvd(X, k, deps) {
    var n = X.length, V = X[0].length;
    var svd = svdTopK(X, k, deps);
    var W = [], H = [], i, j, l;
    for (i = 0; i < n; i++) { W.push(new Array(k).fill(0)); }
    for (j = 0; j < k; j++) { H.push(new Array(V).fill(0)); }

    for (i = 0; i < n; i++) { W[i][0] = Math.sqrt(svd.S[0]) * Math.abs(svd.U[0][i]); }
    for (l = 0; l < V; l++) { H[0][l] = Math.sqrt(svd.S[0]) * Math.abs(svd.Vt[0][l]); }

    for (j = 1; j < k; j++) {
      var x = svd.U[j], y = svd.Vt[j];
      var xpn = 0, xnn = 0, ypn = 0, ynn = 0;
      for (i = 0; i < n; i++) {
        if (x[i] > 0) { xpn += x[i] * x[i]; } else { xnn += x[i] * x[i]; }
      }
      for (l = 0; l < V; l++) {
        if (y[l] > 0) { ypn += y[l] * y[l]; } else { ynn += y[l] * y[l]; }
      }
      xpn = Math.sqrt(xpn); xnn = Math.sqrt(xnn);
      ypn = Math.sqrt(ypn); ynn = Math.sqrt(ynn);
      var mp = xpn * ypn, mn = xnn * ynn;
      var sigma = mp > mn ? mp : mn;
      var lbd = Math.sqrt(svd.S[j] * sigma);
      for (i = 0; i < n; i++) {
        var xv = mp > mn ? Math.max(x[i], 0) / xpn : Math.abs(Math.min(x[i], 0)) / xnn;
        W[i][j] = lbd * xv;
      }
      for (l = 0; l < V; l++) {
        var yv = mp > mn ? Math.max(y[l], 0) / ypn : Math.abs(Math.min(y[l], 0)) / ynn;
        H[j][l] = lbd * yv;
      }
    }
    // sklearn truncation: values < 1e-6 -> 0
    for (i = 0; i < n; i++) { for (j = 0; j < k; j++) { if (W[i][j] < 1e-6) { W[i][j] = 0; } } }
    for (j = 0; j < k; j++) { for (l = 0; l < V; l++) { if (H[j][l] < 1e-6) { H[j][l] = 0; } } }
    return { W: W, H: H };
  }

  /* ------------------------------------------------------------------ *
   * Multiplicative-update NMF (sklearn-faithful, Frobenius)
   * ------------------------------------------------------------------ */

  function frobError(X, W, H) {
    var n = X.length, V = X[0].length, k = H.length;
    var err = 0;
    for (var i = 0; i < n; i++) {
      for (var l = 0; l < V; l++) {
        var wh = 0;
        for (var c = 0; c < k; c++) { wh += W[i][c] * H[c][l]; }
        var d = X[i][l] - wh;
        err += d * d;
      }
    }
    return Math.sqrt(err);
  }

  function nmfMu(X, W0, H0, opts) {
    opts = opts || {};
    var maxIter = opts.maxIter || 500;
    var tol = opts.tol === undefined ? 1e-6 : opts.tol;
    var n = X.length, V = X[0].length, k = H0.length;
    var W = W0.map(function (r) { return r.slice(); });
    var H = H0.map(function (r) { return r.slice(); });
    var errInit = frobError(X, W, H);
    var prevErr = errInit;
    var nIter = 0, i, l, c, c2;

    for (var it = 1; it <= maxIter; it++) {
      nIter = it;
      // ---- W update: W *= (X Hᵀ) / (W (H Hᵀ)) ----
      var HHt = [];
      for (c = 0; c < k; c++) {
        HHt.push(new Array(k).fill(0));
        for (c2 = 0; c2 <= c; c2++) {
          var s = 0;
          for (l = 0; l < V; l++) { s += H[c][l] * H[c2][l]; }
          HHt[c][c2] = s;
        }
      }
      for (c = 0; c < k; c++) { for (c2 = c + 1; c2 < k; c2++) { HHt[c][c2] = HHt[c2][c]; } }
      for (i = 0; i < n; i++) {
        var num = new Array(k).fill(0), den = new Array(k).fill(0);
        for (c = 0; c < k; c++) {
          var a = 0;
          for (l = 0; l < V; l++) { a += X[i][l] * H[c][l]; }
          num[c] = a;
          var b = 0;
          for (c2 = 0; c2 < k; c2++) { b += W[i][c2] * HHt[c2][c]; }
          den[c] = b === 0 ? EPSILON : b;
        }
        for (c = 0; c < k; c++) { W[i][c] *= num[c] / den[c]; }
      }
      // ---- H update: H *= (Wᵀ X) / ((Wᵀ W) H) ----
      var WtW = [];
      for (c = 0; c < k; c++) {
        WtW.push(new Array(k).fill(0));
        for (c2 = 0; c2 <= c; c2++) {
          var s2 = 0;
          for (i = 0; i < n; i++) { s2 += W[i][c] * W[i][c2]; }
          WtW[c][c2] = s2;
        }
      }
      for (c = 0; c < k; c++) { for (c2 = c + 1; c2 < k; c2++) { WtW[c][c2] = WtW[c2][c]; } }
      for (l = 0; l < V; l++) {
        // all numerators/denominators for this column from the OLD H, then
        // write — sklearn's matrix update uses pre-update H throughout
        var newCol = new Array(k);
        for (c = 0; c < k; c++) {
          var a2 = 0;
          for (i = 0; i < n; i++) { a2 += W[i][c] * X[i][l]; }
          var b2 = 0;
          for (c2 = 0; c2 < k; c2++) { b2 += WtW[c][c2] * H[c2][l]; }
          if (b2 === 0) { b2 = EPSILON; }
          newCol[c] = H[c][l] * (a2 / b2);
        }
        for (c = 0; c < k; c++) { H[c][l] = newCol[c]; }
      }
      // convergence: every 10 iterations, sklearn criterion
      if (tol > 0 && it % 10 === 0) {
        var err = frobError(X, W, H);
        if ((prevErr - err) / errInit < tol) { break; }
        prevErr = err;
      }
    }
    return { W: W, H: H, nIter: nIter, error: frobError(X, W, H) };
  }

  /* ------------------------------------------------------------------ *
   * UMass coherence (gensim-faithful)
   * ------------------------------------------------------------------ */

  /**
   * topicsTop: per topic, ordered array of vocab indices (weight desc).
   * docBags: per document, a null-proto set of vocab indices present.
   */
  function umass(topicsTop, docBags) {
    var nDocs = docBags.length;
    var docFreq = Object.create(null);       // j -> count
    var pairFreq = Object.create(null);      // "a|b" -> count
    function dfOf(j) {
      if (docFreq[j] === undefined) {
        var c = 0;
        docBags.forEach(function (bag) { if (bag[j] === 1) { c++; } });
        docFreq[j] = c;
      }
      return docFreq[j];
    }
    function coOf(a, b) {
      var k = a < b ? a + '|' + b : b + '|' + a;
      if (pairFreq[k] === undefined) {
        var c = 0;
        docBags.forEach(function (bag) { if (bag[a] === 1 && bag[b] === 1) { c++; } });
        pairFreq[k] = c;
      }
      return pairFreq[k];
    }
    var perTopic = topicsTop.map(function (words) {
      var sims = [];
      // s_one_pre: (w_prime = w_i, w_star = w_j) for i > j
      for (var i2 = 1; i2 < words.length; i2++) {
        for (var j2 = 0; j2 < i2; j2++) {
          var wStarDf = dfOf(words[j2]);
          if (wStarDf === 0) { sims.push(0); continue; } // gensim ZeroDivision -> 0
          var co = coOf(words[i2], words[j2]);
          sims.push(Math.log((co / nDocs + UMASS_EPS) / (wStarDf / nDocs)));
        }
      }
      var s = 0;
      sims.forEach(function (x) { s += x; });
      return sims.length ? s / sims.length : 0;
    });
    var mean = 0;
    perTopic.forEach(function (x) { mean += x; });
    return { perTopic: perTopic, mean: perTopic.length ? mean / perTopic.length : 0 };
  }

  function topWordsOfH(H, topn) {
    return H.map(function (row) {
      return row.map(function (v, j) { return [j, v]; })
        .sort(function (a, b) { return b[1] - a[1] || a[0] - b[0]; })
        .slice(0, topn)
        .map(function (p) { return p[0]; });
    });
  }

  /* ------------------------------------------------------------------ *
   * K selection (analog of D-8) + full model
   * ------------------------------------------------------------------ */

  /**
   * Run the full Topic Modeler.
   * datas/names: loaded craData + display names
   * opts: { mode, k (manual override), maxVocab, coherenceTopN (10) }
   * deps: { isStopWord, jacobiEig }
   */
  function topicModel(datas, names, opts, deps) {
    opts = opts || {};
    var m = buildMatrix(datas, names, opts, deps);
    var n = m.names.length;
    if (n < 3) {
      throw new Error('Topic Modeler needs at least 3 files with the required data (have ' + n + ').');
    }
    var topN = opts.coherenceTopN || 10;

    // presence bags on the SAME matrix vocabulary (counts > 0)
    var docBags = m.X.map(function (row) {
      var bag = Object.create(null);
      row.forEach(function (v, j) { if (v > 0) { bag[j] = 1; } });
      return bag;
    });

    var k0 = Math.max(2, Math.round(Math.sqrt(n)));
    var kMax = Math.min(12, n - 1);
    var kMin = 2;
    if (k0 > kMax) { k0 = kMax; }

    var table = [], models = Object.create(null);
    for (var k = kMin; k <= kMax; k++) {
      var init = nndsvd(m.X, k, deps);
      var fit = nmfMu(m.X, init.W, init.H, { maxIter: 500, tol: 1e-6 });
      var coh = umass(topWordsOfH(fit.H, topN), docBags);
      table.push({ k: k, coherence: round5(coh.mean), nIter: fit.nIter,
        error: round5(fit.error) });
      models[k] = fit;
    }
    var best = table.reduce(function (a, b) { return b.coherence > a.coherence ? b : a; });
    var cohVals = table.map(function (r) { return r.coherence; });
    var range = Math.max.apply(null, cohVals) - Math.min.apply(null, cohVals);
    var k0Row = table.filter(function (r) { return r.k === k0; })[0];
    var accepted = range === 0 || (k0Row.coherence >= best.coherence - 0.1 * range);
    var kChosen = opts.k ? opts.k : (accepted ? k0 : best.k);
    if (opts.k && (opts.k < kMin || opts.k > kMax)) {
      throw new Error('K must be between ' + kMin + ' and ' + kMax + '.');
    }
    var chosen = models[kChosen];

    // topics: top-12 words with weights
    var topics = chosen.H.map(function (row, t) {
      var top = row.map(function (v, j) { return [j, v]; })
        .sort(function (a, b) { return b[1] - a[1] || a[0] - b[0]; })
        .slice(0, 12)
        .filter(function (p) { return p[1] > 0; })
        .map(function (p) { return { word: m.vocab[p[0]], weight: round5(p[1]) }; });
      return { topic: t + 1, words: top };
    });
    // per-doc loadings, share-normalized for readability (raw kept)
    var loadings = chosen.W.map(function (row, i) {
      var s = 0;
      row.forEach(function (v) { s += v; });
      var shares = row.map(function (v) { return s > 0 ? round5(v / s) : 0; });
      var dom = 0;
      row.forEach(function (v, t) { if (v > row[dom]) { dom = t; } });
      return { name: m.names[i], raw: row.map(round5), share: shares,
        dominant: dom + 1 };
    });
    var cohChosen = umass(topWordsOfH(chosen.H, topN), docBags);

    return {
      parameters: {
        mode: m.mode, variant: m.variant, vocabulary: m.vocab.length,
        maxIter: 500, tol: 1e-6, init: 'nndsvd',
        coherence: 'UMass (Mimno et al., 2011), top ' + topN + ' words, gensim convention',
        kRule: 'K0=round(sqrt(n))=' + k0 + (opts.k ? '; MANUAL OVERRIDE K=' + opts.k
          : (accepted ? ', accepted (within 10% of coherence range of best)'
                      : ', rejected; best K=' + best.k + ' used'))
      },
      names: m.names, excluded: m.excluded,
      k: kChosen, k0: k0, kAccepted: accepted,
      coherenceByK: table,
      coherencePerTopic: cohChosen.perTopic.map(round5),
      topics: topics, loadings: loadings,
      vocab: m.vocab, W: chosen.W, H: chosen.H
    };
  }

  /* ------------------------------------------------------------------ *
   * Report
   * ------------------------------------------------------------------ */

  function serializeReport(res, citationBlock) {
    var L = [];
    L.push('# Crawdad Topic Modeler: ' + res.names.length + ' texts, K = ' + res.k);
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- Method: NMF (Lee & Seung, 1999), NNDSVD init (Boutsidis & Gallopoulos,');
    L.push('  2008), multiplicative updates, max 500 iterations, tol 1e-6 — deterministic');
    L.push('  end-to-end. Matrix: ' + res.parameters.variant + '.');
    L.push('- K rule: ' + res.parameters.kRule + '. Coherence: ' + res.parameters.coherence + '.');
    if (res.parameters.mode === 'influence') {
      L.push('- NOTE: the influence-weighted matrix is a Crawdad-native NOVEL variant;');
      L.push('  the TF-IDF mode is the standard, comparable configuration.');
    }
    if (res.excluded.length) {
      L.push('- Excluded (no surface frequencies; regenerate with 2.0.0-M1+): ' +
        res.excluded.join(', '));
    }
    L.push('');
    L.push('## Coherence by K (higher = better; UMass values are negative)');
    L.push('');
    L.push('| K | UMass coherence | NMF iterations | Frobenius error |');
    L.push('|---|---|---|---|');
    res.coherenceByK.forEach(function (r) {
      L.push('| ' + r.k + (r.k === res.k ? ' ←' : '') + ' | ' + r.coherence +
        ' | ' + r.nIter + ' | ' + r.error + ' |');
    });
    L.push('');
    res.topics.forEach(function (t, ti) {
      L.push('## Topic ' + t.topic + ' (coherence ' + res.coherencePerTopic[ti] + ')');
      L.push('');
      L.push('| Word | Weight |');
      L.push('|---|---|');
      t.words.forEach(function (w) { L.push('| ' + w.word + ' | ' + w.weight + ' |'); });
      L.push('');
    });
    L.push('## Document–topic loadings (share of each document\'s weight)');
    L.push('');
    L.push('| Text | Dominant | ' + res.topics.map(function (t) {
      return 'T' + t.topic;
    }).join(' | ') + ' |');
    L.push('|---|---|' + res.topics.map(function () { return '---|'; }).join(''));
    res.loadings.forEach(function (d) {
      L.push('| ' + d.name + ' | T' + d.dominant + ' | ' + d.share.join(' | ') + ' |');
    });
    L.push('');
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-topics', schemaVersion: '1.0',
      parameters: res.parameters, names: res.names, excluded: res.excluded,
      k: res.k, k0: res.k0, kAccepted: res.kAccepted,
      coherenceByK: res.coherenceByK, coherencePerTopic: res.coherencePerTopic,
      topics: res.topics, loadings: res.loadings }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    String(citationBlock || '').split('\n\n').forEach(function (c) {
      if (c) { L.push('*' + c + '*'); L.push(''); }
    });
    return L.join('\n');
  }

  var api = {
    EPSILON: EPSILON,
    buildMatrix: buildMatrix,
    svdTopK: svdTopK,
    nndsvd: nndsvd,
    nmfMu: nmfMu,
    frobError: frobError,
    umass: umass,
    topWordsOfH: topWordsOfH,
    topicModel: topicModel,
    serializeReport: serializeReport
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadTopics = api; }
})(typeof self !== 'undefined' ? self : this);
