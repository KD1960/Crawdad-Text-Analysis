/*
 * Crawdad 2026 — M2: Generator pipeline orchestration (spec §6)
 * clean -> substitutions -> parse -> normalize/link/index -> _cra.md
 */
(function (root) {
  'use strict';

  var APP_VERSION = '1.4.7';
  var BUILD_DATE = '2026-08-09';

  /**
   * Run the full Generator pipeline on one text.
   * deps: { parser, porter2, isStopWord, schema, textclean }
   * options: { stemming, keepPronouns, interSentenceLinking, tokPairs, tokFileName }
   * Returns { craData, craMd, log: string[] }
   */
  function generate(filename, rawText, options, deps) {
    var log = [];
    options = options || {};

    // 1-2. clean
    var cleaned = deps.textclean.cleanText(rawText);
    cleaned.notes.forEach(function (n) { log.push('[clean] ' + n); });

    // 3. tokenization substitutions
    var text = cleaned.text;
    if (options.tokPairs && options.tokPairs.length) {
      var sub = deps.textclean.applySubstitutions(text, options.tokPairs);
      text = sub.text;
      Object.keys(sub.counts).forEach(function (k) {
        log.push('[tokenize] "' + k + '" -> replaced ' + sub.counts[k] + 'x');
      });
    }

    // 4. parse (sentence segmentation, POS, NP extraction); excluded words
    // break center runs at the parser level (D-14)
    var exclParse = null;
    if (options.excludeWords && options.excludeWords.length) {
      exclParse = {};
      options.excludeWords.forEach(function (w) { exclParse[w] = true; });
      log.push('[exclude] ' + options.excludeWords.join(', '));
    }
    var parsed = deps.parser.parse(text, { exclude: exclParse });
    log.push('[parse] ' + parsed.sentences.length + ' sentences');

    // 4a. tokenization suggestions (2026-08-09): adjacent co-occurrence of
    // center words within noun phrases → candidate multi-word tokens for a
    // future tokenization file. Advisory only; never applied automatically.
    var tokenSuggestions = deps.textclean.suggestTokenizations
      ? deps.textclean.suggestTokenizations(parsed.sentences, {
          isStopWord: deps.isStopWord,
          existingPairs: options.tokPairs || []
        })
      : null;
    if (tokenSuggestions && tokenSuggestions.length) {
      log.push('[tokenize] ' + tokenSuggestions.length + ' candidate multi-word token(s) suggested');
    }

    // 4b. text-level metrics (D-12) — computed on the full token stream
    var textMetrics = null;
    if (deps.textmetrics) {
      var stemMode = options.stemming || 'porter';
      var stemFn = stemMode === 'porter' ? deps.porter2
        : stemMode === 'minimal' ? deps.network.minimalStem
        : function (w) { return w; };
      textMetrics = deps.textmetrics.computeAll(parsed.sentences,
        { sentimentFn: deps.sentiment || null, stemFn: stemFn });
      log.push('[metrics] text-level metrics computed');
    }

    // 5-7. normalize, link, index
    var excludeSet = {};
    (options.excludeWords || []).forEach(function (w) { excludeSet[w] = true; });
    var isStopOrExcluded = function (w) {
      return deps.isStopWord(w) || excludeSet[w] === true;
    };
    var cra = deps.network.buildCra(parsed.sentences, {
      stemming: options.stemming || 'porter',
      interSentenceLinking: options.interSentenceLinking === true // default off (D-17)
    }, { porter2: deps.porter2, isStopWord: isStopOrExcluded });
    log.push('[network] ' + cra.nodes.length + ' nodes, ' + cra.edges.length + ' edges');

    if (cra.nodes.length === 0) {
      throw new Error('No noun phrases found in "' + filename + '" — is this prose?');
    }

    // 8. emit
    var data = deps.schema.newCraData(filename, {
      stemming: options.stemming || 'porter',
      pronouns: !!options.keepPronouns,
      interSentenceLinking: options.interSentenceLinking === true, // D-17
      excludeWords: options.excludeWords || [],
      tokenizationFile: options.tokFileName || null,
      stopWordList: 'default'
    }, APP_VERSION + ' (built ' + BUILD_DATE + ')');
    data.network.nodes = cra.nodes;
    data.network.edges = cra.edges;
    data.summary = cra.summary;
    if (textMetrics) { data.textMetrics = textMetrics; }
    if (tokenSuggestions && tokenSuggestions.length) {
      data.tokenSuggestions = tokenSuggestions;
    }
    if (cleaned.notes.length) { data.cleaningNotes = cleaned.notes; }

    var md = deps.schema.serializeCra(data);
    return { craData: data, craMd: md, log: log };
  }

  function craFileName(sourceName) {
    return sourceName.replace(/\.(txt|md|pdf|docx)$/i, '') + '_cra.md';
  }

  var api = { generate: generate, craFileName: craFileName,
    APP_VERSION: APP_VERSION, BUILD_DATE: BUILD_DATE };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadGenerator = api; }
})(typeof self !== 'undefined' ? self : this);
