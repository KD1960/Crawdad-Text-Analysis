/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M7 — inference layer (Build Spec V2 §7).
 *
 * Seeded, closed-loop uncertainty statements. Every output states METHOD,
 * COUNT, and SEED — nothing is silently asymptotic.
 *
 *  1. Influence stability: bootstrap over sentences (default B = 200,
 *     mulberry32 seed recorded) → percentile 95% CI on each word's
 *     influence. A word absent from a resample carries influence 0 in that
 *     replicate (its centrality genuinely is 0 there). Reported as a range
 *     column in the node table so "the #1 word" claims survive review.
 *  2. Resonance significance: permutation null for WR′ — word labels of
 *     text B are permuted (both texts' influence DISTRIBUTIONS are
 *     preserved; only the word–influence alignment is broken), default
 *     999 permutations, empirical p = (hits + 1)/(B + 1).
 *  3. Cluster stability: cluster-wise Jaccard bootstrap (Hennig, 2007) on
 *     the Classifier solution — objects resampled with replacement,
 *     re-clustered at the SAME k, each original cluster scored by its best
 *     Jaccard match among bootstrap clusters (computed on the sampled
 *     objects), averaged over B = 100. Hennig's reading: < 0.5 dissolved;
 *     0.5–0.75 doubtful; 0.75–0.85 valid with some pattern; ≥ 0.85 highly
 *     stable. Flags directly address the weak-silhouette regime documented
 *     in the Design Guide's example.
 *  4. Keyness permutation shipped in V2-M3 (js/keyness.js).
 */
(function (root) {
  'use strict';

  function mulberry32(seed) {
    var s = seed >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      var t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function round5(x) { return Math.round(x * 1e5) / 1e5; }

  /* ------------------------------------------------------------------ *
   * 1. Influence bootstrap (sentence resampling)
   * ------------------------------------------------------------------ */

  /**
   * parsedSentences: parser output (the Generator's step-4 result).
   * opts: { B (200), seed (42), ciLevel (0.95), stemming, interSentenceLinking }
   * deps: { network, porter2, isStopWord }
   * Returns { method, B, seed, ciLevel, ci: {word: [lo, hi]} }.
   */
  function bootstrapInfluence(parsedSentences, opts, deps) {
    opts = opts || {};
    var B = opts.B === undefined ? 200 : opts.B;
    var seed = opts.seed === undefined ? 42 : opts.seed;
    var ciLevel = opts.ciLevel === undefined ? 0.95 : opts.ciLevel;
    var rng = mulberry32(seed);
    var n = parsedSentences.length;
    var netOpts = { stemming: opts.stemming || 'porter',
      interSentenceLinking: opts.interSentenceLinking === true };
    var netDeps = { porter2: deps.porter2, isStopWord: deps.isStopWord };

    // original word set
    var base = deps.network.buildCra(parsedSentences, netOpts, netDeps);
    var words = base.nodes.map(function (nd) { return nd.word; });
    var samples = Object.create(null);
    words.forEach(function (w) { samples[w] = []; });

    for (var b = 0; b < B; b++) {
      var resample = [];
      for (var i = 0; i < n; i++) {
        resample.push(parsedSentences[Math.floor(rng() * n)]);
      }
      var rep;
      try {
        rep = deps.network.buildCra(resample, netOpts, netDeps);
      } catch (e) { rep = { nodes: [] }; } // degenerate resample -> all zeros
      var seen = Object.create(null);
      rep.nodes.forEach(function (nd) { seen[nd.word] = nd.influence; });
      words.forEach(function (w) {
        samples[w].push(seen[w] === undefined ? 0 : seen[w]);
      });
    }
    var alpha = (1 - ciLevel) / 2;
    var loIdx = Math.max(0, Math.ceil(alpha * B) - 1);
    var hiIdx = Math.min(B - 1, Math.floor((1 - alpha) * B));
    var ci = Object.create(null);
    words.forEach(function (w) {
      var s = samples[w].slice().sort(function (a, b2) { return a - b2; });
      ci[w] = [round5(s[loIdx]), round5(s[hiIdx])];
    });
    return { method: 'sentence bootstrap, percentile CI (nearest rank)',
      B: B, seed: seed, ciLevel: ciLevel, ci: ci };
  }

  /* ------------------------------------------------------------------ *
   * 2. WR′ permutation null
   * ------------------------------------------------------------------ */

  /**
   * dataA/dataB: craData objects. opts: { B (999), seed (42) }.
   * deps: { resonance }
   * Returns { method, B, seed, observed, permP, permMean }.
   */
  function wrPermutation(dataA, dataB, opts, deps) {
    opts = opts || {};
    var B = opts.B === undefined ? 999 : opts.B;
    var seed = opts.seed === undefined ? 42 : opts.seed;
    var rng = mulberry32(seed);
    var obs = deps.resonance.wordResonance(dataA, dataB).WRs;

    var wordsB = dataB.network.nodes.map(function (nd) { return nd.word; });
    var hits = 0, sum = 0;
    for (var b = 0; b < B; b++) {
      // Fisher–Yates permutation of B's word labels
      var perm = wordsB.slice();
      for (var i = perm.length - 1; i > 0; i--) {
        var j = Math.floor(rng() * (i + 1));
        var t = perm[i]; perm[i] = perm[j]; perm[j] = t;
      }
      var permB = { network: {
        nodes: dataB.network.nodes.map(function (nd, k) {
          return { id: nd.id, word: perm[k], display: perm[k],
            degree: nd.degree, influence: nd.influence };
        }),
        edges: dataB.network.edges
      } };
      var wr = deps.resonance.wordResonance(dataA, permB).WRs;
      sum += wr;
      if (wr >= obs - 1e-12) { hits++; }
    }
    return {
      method: 'word labels of text B permuted (both influence distributions preserved)',
      B: B, seed: seed,
      observed: round5(obs),
      permMean: round5(sum / B),
      permP: Math.round((hits + 1) / (B + 1) * 1e4) / 1e4
    };
  }

  /* ------------------------------------------------------------------ *
   * 3. Cluster-wise Jaccard bootstrap (Hennig, 2007)
   * ------------------------------------------------------------------ */

  function jaccard(setA, setB) {
    var inter = 0, uni = 0, k;
    var u = Object.create(null);
    for (k in setA) { u[k] = 1; }
    for (k in setB) { u[k] = 1; }
    for (k in u) {
      uni++;
      if (setA[k] === 1 && setB[k] === 1) { inter++; }
    }
    return uni > 0 ? inter / uni : 0;
  }

  /**
   * rows: feature rows used by the Classifier (one per text).
   * labels: the accepted solution's cluster labels.
   * opts: { B (100), seed (42) }
   * deps: { classifier } (kmeans)
   * Returns { method, B, seed, k, clusters: [{cluster, meanJaccard, verdict}] }.
   */
  function clusterStability(rows, labels, opts, deps) {
    opts = opts || {};
    var B = opts.B === undefined ? 100 : opts.B;
    var seed = opts.seed === undefined ? 42 : opts.seed;
    var rng = mulberry32(seed);
    var n = rows.length;
    var k = 0;
    labels.forEach(function (l) { if (l + 1 > k) { k = l + 1; } });

    var sums = new Array(k).fill(0);
    for (var b = 0; b < B; b++) {
      var idx = [];
      for (var i = 0; i < n; i++) { idx.push(Math.floor(rng() * n)); }
      var uniq = [];
      var seen = Object.create(null);
      idx.forEach(function (ix) {
        if (!seen[ix]) { seen[ix] = 1; uniq.push(ix); }
      });
      var bootRows = idx.map(function (ix) { return rows[ix]; });
      var km = deps.classifier.kmeans(bootRows, k, seed + 1 + b);
      // map bootstrap labels back: position p in idx -> original object idx[p]
      var bootClusters = [];
      for (var c = 0; c < k; c++) { bootClusters.push(Object.create(null)); }
      km.labels.forEach(function (l, p) { bootClusters[l][idx[p]] = 1; });
      for (c = 0; c < k; c++) {
        // original cluster restricted to sampled objects
        var orig = Object.create(null);
        uniq.forEach(function (ix) { if (labels[ix] === c) { orig[ix] = 1; } });
        var isEmpty = true;
        for (var kk in orig) { isEmpty = false; void kk; break; }
        if (isEmpty) { sums[c] += 0; continue; } // cluster unsampled: counts against
        var best = 0;
        for (var c2 = 0; c2 < k; c2++) {
          var jc = jaccard(orig, bootClusters[c2]);
          if (jc > best) { best = jc; }
        }
        sums[c] += best;
      }
    }
    function verdict(g) {
      if (g < 0.5) { return 'DISSOLVED (below 0.5): not a stable cluster'; }
      if (g < 0.75) { return 'doubtful (0.5–0.75)'; }
      if (g < 0.85) { return 'valid, some pattern (0.75–0.85)'; }
      return 'highly stable (≥ 0.85)';
    }
    return {
      method: 'cluster-wise Jaccard bootstrap (Hennig, 2007), objects resampled ' +
        'with replacement, re-clustered at the same k',
      B: B, seed: seed, k: k,
      clusters: sums.map(function (s, c) {
        var g = round5(s / B);
        return { cluster: c + 1, meanJaccard: g, verdict: verdict(g) };
      })
    };
  }

  var api = {
    mulberry32: mulberry32,
    bootstrapInfluence: bootstrapInfluence,
    wrPermutation: wrPermutation,
    clusterStability: clusterStability
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadInference = api; }
})(typeof self !== 'undefined' ? self : this);
