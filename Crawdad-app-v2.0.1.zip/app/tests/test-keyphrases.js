/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M2 tests — node stats (PageRank/strength), NPMI/log-Dice
 * collocations, TextRank + YAKE keyphrases (Build Spec V2 §3.3, §11).
 * Node:    NODE_PATH=... node tests/test-keyphrases.js
 * Browser: open tests/test-keyphrases.html
 * Oracles: networkx.pagerank (fixture-pagerank.json, tol 1e-9);
 *          reference YAKE (LIAAD yake 0.7.1, levs dedup, shared stopword
 *          list, identical segtok token streams — fixture-yake-ref.json);
 *          hand-worked NPMI / log-Dice.
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var KP = isNode ? require('../js/keyphrases.js') : root.CrawdadKeyphrases;
  var NET = isNode ? require('../js/network.js') : root.CrawdadNetwork;
  var TC = isNode ? require('../js/textclean.js') : root.CrawdadTextClean;
  var TH = isNode ? require('../js/themes.js') : root.CrawdadThemes;
  var S = isNode ? require('../js/craschema.js') : root.CrawdadSchema;
  var FIX_PR = isNode ? require('./fixture-pagerank.json') : root.CrawdadFixture_pagerank;
  var FIX_YAKE = isNode ? require('./fixture-yake-ref.json') : root.CrawdadFixture_yakeRef;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }
  function close(a, b, tol, m) {
    if (Math.abs(a - b) > tol) { throw new Error((m || '') + ' |' + a + ' - ' + b + '| > ' + tol); }
  }

  /* ---------------- node stats ---------------- */

  t('PageRank matches networkx on the weighted fixture graph (1e-9, incl. dangling node)', function () {
    var edges = FIX_PR.edges.map(function (e) {
      return { source: e[0], target: e[1], weight: e[2] };
    });
    var pr = NET.pageRank(FIX_PR.n, edges);
    for (var i = 0; i < FIX_PR.n; i++) {
      close(pr[i], FIX_PR.pagerank[i], 1e-9, 'node ' + i);
    }
  });

  t('strength = weighted degree, matches networkx', function () {
    var edges = FIX_PR.edges.map(function (e) {
      return { source: e[0], target: e[1], weight: e[2] };
    });
    var st = NET.strength(FIX_PR.n, edges);
    for (var i = 0; i < FIX_PR.n; i++) {
      assert(st[i] === FIX_PR.strength[i], 'node ' + i + ': ' + st[i] + ' vs ' + FIX_PR.strength[i]);
    }
  });

  t('PageRank sums to 1 and dangling node gets (1-alpha)-floor share', function () {
    var edges = FIX_PR.edges.map(function (e) {
      return { source: e[0], target: e[1], weight: e[2] };
    });
    var pr = NET.pageRank(FIX_PR.n, edges);
    var sum = pr.reduce(function (a, b) { return a + b; }, 0);
    close(sum, 1, 1e-12, 'sum');
    assert(pr[5] > 0, 'dangling node must not be zero');
  });

  /* ---------------- NPMI / log-Dice (hand-worked) ---------------- */

  function mkSentences(phrases) { // one sentence, given noun phrases
    return [{ text: 'x', phrases: phrases, tokens: [] }];
  }

  t('NPMI hand-worked: perfect association reaches +1', function () {
    // "alpha beta" 3x, nothing else: f(alpha)=f(beta)=f(pair)=3, N=6
    // NPMI = ln(p(xy)/(px*py)) / -ln p(xy); p=3/6=.5 -> ln(.5/.25)/ -ln .5 = 1
    var r = TC.suggestTokenizations(mkSentences(
      [['alpha', 'beta'], ['alpha', 'beta'], ['alpha', 'beta']]), {});
    assert(r.nTokens === 6, 'N=' + r.nTokens);
    assert(r.suggestions.length === 1, 'one suggestion');
    close(r.suggestions[0].npmi, 1, 1e-9, 'NPMI');
    // log-Dice = 14 + log2(2*3/(3+3)) = 14
    close(r.suggestions[0].logDice, 14, 1e-9, 'logDice');
    assert(r.suggestions[0].count === 3, 'count');
  });

  t('NPMI hand-worked: mixed usage scores below a pure pair', function () {
    // "gamma delta" 3x  +  gamma alone 3x -> f(gamma)=6, f(delta)=3, f(pair)=3, N=9
    // NPMI = ln((3/9)/((6/9)*(3/9))) / -ln(3/9) = ln(1.5)/ln(3)
    var phrases = [['gamma', 'delta'], ['gamma', 'delta'], ['gamma', 'delta'],
      ['gamma'], ['gamma'], ['gamma']];
    var r = TC.suggestTokenizations(mkSentences(phrases), {});
    var expect = Math.log(1.5) / Math.log(3);
    close(r.suggestions[0].npmi, Math.round(expect * 1e4) / 1e4, 1e-9, 'NPMI');
    // log-Dice = 14 + log2(2*3/(6+3))
    var ld = 14 + Math.log(2 * 3 / 9) / Math.LN2;
    close(r.suggestions[0].logDice, Math.round(ld * 1e4) / 1e4, 1e-9, 'logDice');
  });

  t('NPMI ranking beats raw count: rarer-but-exclusive pair ranks first', function () {
    var phrases = [];
    var i;
    for (i = 0; i < 8; i++) { phrases.push(['market', 'share']); } // frequent pair
    for (i = 0; i < 12; i++) { phrases.push(['market']); }         // …of promiscuous words
    for (i = 0; i < 12; i++) { phrases.push(['share']); }
    for (i = 0; i < 3; i++) { phrases.push(['iridium', 'venture']); } // rare, exclusive
    var r = TC.suggestTokenizations(mkSentences(phrases), {});
    assert(r.suggestions[0].phrase === 'iridium venture',
      'expected exclusive pair first, got ' + r.suggestions[0].phrase);
    assert(r.suggestions[0].count < r.suggestions[1].count, 'and it is the rarer one');
  });

  t('trigram NPMI uses the (n-1) normalization and stays in [-1, 1]', function () {
    var phrases = [];
    for (var i = 0; i < 4; i++) { phrases.push(['supply', 'chain', 'management']); }
    var r = TC.suggestTokenizations(mkSentences(phrases), {});
    var tri = r.suggestions.filter(function (s) { return s.words === 3; })[0];
    assert(tri, 'trigram suggested');
    close(tri.npmi, 1, 1e-9, 'pure trigram = +1'); // p(xyz)=p(x)=... -> exactly 1
    assert(tri.wordCounts.length === 3, 'wordCounts recorded');
  });

  t('suggestions ranked by NPMI desc; schema fields present', function () {
    var phrases = [];
    var i;
    for (i = 0; i < 5; i++) { phrases.push(['noise', 'floor']); }
    for (i = 0; i < 5; i++) { phrases.push(['noise']); }
    for (i = 0; i < 3; i++) { phrases.push(['clean', 'pair']); }
    var r = TC.suggestTokenizations(mkSentences(phrases), {});
    for (i = 1; i < r.suggestions.length; i++) {
      assert(r.suggestions[i - 1].npmi >= r.suggestions[i].npmi, 'sorted by NPMI');
    }
    r.suggestions.forEach(function (sg) {
      assert(typeof sg.npmi === 'number' && typeof sg.logDice === 'number' &&
        Array.isArray(sg.wordCounts), 'assoc fields');
    });
  });

  /* ---------------- YAKE core vs. reference ---------------- */

  t('YAKE core is output-identical to reference yake on identical token streams (1e-10, order up to FP ties)', function () {
    var canon = function (l) {
      return l.map(function (p) {
        return [Math.round(p[1] * 1e10) / 1e10, p[0]];
      }).sort(function (a, b) { return a[0] - b[0] || (a[1] < b[1] ? -1 : 1); });
    };
    Object.keys(FIX_YAKE).forEach(function (f) {
      var o = FIX_YAKE[f];
      var mine = KP.yake(o.sentences, {
        isStopWord: KP.isKpStopWord, n: 3, windowSize: 1, top: 20, dedupLim: 0.9
      }).map(function (p) { return [p.phrase, p.score]; });
      var a = JSON.stringify(canon(mine)), b = JSON.stringify(canon(o.keywords));
      assert(a === b, f + ': mismatch\nmine ' + a.slice(0, 200) + '\nref  ' + b.slice(0, 200));
    });
  });

  t('yakeTag matches reference tagging rules', function () {
    assert(KP.yakeTag('1999', 1) === 'd', 'digit');
    assert(KP.yakeTag('3.5', 1) === 'd', 'decimal');
    assert(KP.yakeTag('B2B', 1) === 'u', 'mixed alnum');
    assert(KP.yakeTag('NASA', 1) === 'a', 'acronym');
    assert(KP.yakeTag('Motorola', 3) === 'n', 'proper noun mid-sentence');
    assert(KP.yakeTag('Motorola', 0) === 'p', 'sentence-initial capital is plain');
    assert(KP.yakeTag('satellite', 4) === 'p', 'plain');
    assert(KP.yakeTag('U.S.', 2) === 'u', 'multi-punct token is unusual');
  });

  t('yakeTokenize: possessives dropped, hyphens kept, punctuation split', function () {
    var toks = KP.yakeTokenize("Motorola's hand-held phones, worth $5 billion.");
    assert(toks.indexOf('Motorola') !== -1 && toks.indexOf("'s") === -1, 'possessive');
    assert(toks.indexOf('hand-held') !== -1, 'hyphenated kept whole');
    assert(toks.indexOf(',') !== -1 && toks.indexOf('$') !== -1, 'punct separate');
    assert(toks.indexOf('5') !== -1 && toks.indexOf('billion') !== -1, 'number split from $');
  });

  t('levSimilarity: exact 1, disjoint low, near-duplicate above 0.9', function () {
    close(KP.levSimilarity('satellite', 'satellite'), 1, 1e-12);
    assert(KP.levSimilarity('satellite', 'iridium') < 0.5, 'disjoint');
    assert(KP.levSimilarity('satellite phone', 'satellite phones') > 0.9, 'near-dup');
  });

  /* ---------------- TextRank ---------------- */

  function tok(w, pos) { return { w: w, pos: pos }; }

  t('TextRank hand-worked: adjacent nouns form an edge; merged phrase reported', function () {
    // "supply chain" repeatedly adjacent; "risk" linked via "chain risk"
    var sents = [
      { tokens: [tok('supply', 'NOUN'), tok('chain', 'NOUN'), tok('is', 'AUX'),
                 tok('fragile', 'ADJ')] },
      { tokens: [tok('supply', 'NOUN'), tok('chain', 'NOUN'), tok('risk', 'NOUN')] },
      { tokens: [tok('the', 'DET'), tok('supply', 'NOUN'), tok('chain', 'NOUN')] }
    ];
    var r = KP.textRank(sents, { pageRank: NET.pageRank });
    assert(r.vertexCount === 4, 'vertices: supply, chain, fragile, risk (got ' + r.vertexCount + ')');
    var top = r.phrases[0];
    assert(top.phrase === 'supply chain' || top.phrase === 'supply chain risk',
      'merged multiword phrase on top, got "' + top.phrase + '"');
    var sc = r.phrases.filter(function (p) { return p.phrase === 'supply chain'; })[0];
    assert(sc && sc.count >= 2, '"supply chain" counted across occurrences');
    // regression (2026-08-11): "fragile" ends sentence 1, "supply" opens
    // sentence 2 — a phrase merged across that boundary never occurs in text
    r.phrases.forEach(function (p) {
      assert(p.phrase.indexOf('fragile supply') === -1,
        'phrase merged across sentence boundary: "' + p.phrase + '"');
    });
  });

  t('TextRank uses only nouns/adjectives as vertices', function () {
    var sents = [{ tokens: [tok('run', 'VERB'), tok('quickly', 'ADV'),
      tok('market', 'NOUN'), tok('green', 'ADJ'), tok('it', 'PRON')] }];
    var r = KP.textRank(sents, { pageRank: NET.pageRank });
    assert(r.vertexCount === 2, 'only market + green (got ' + r.vertexCount + ')');
  });

  t('TextRank is deterministic (identical output on identical input)', function () {
    var sents = [{ tokens: [tok('alpha', 'NOUN'), tok('beta', 'NOUN'),
      tok('gamma', 'NOUN'), tok('alpha', 'NOUN'), tok('beta', 'NOUN')] }];
    var a = JSON.stringify(KP.textRank(sents, { pageRank: NET.pageRank }));
    var b = JSON.stringify(KP.textRank(sents, { pageRank: NET.pageRank }));
    assert(a === b, 'nondeterminism');
  });

  /* ---------------- extract() + schema integration ---------------- */

  function miniParsed() {
    return [
      { text: 'The Iridium satellite venture cost Motorola five billion dollars.',
        tokens: [tok('the', 'DET'), tok('iridium', 'PROPN'), tok('satellite', 'NOUN'),
          tok('venture', 'NOUN'), tok('cost', 'VERB'), tok('motorola', 'PROPN'),
          tok('five', 'NUM'), tok('billion', 'NUM'), tok('dollars', 'NOUN')],
        phrases: [['iridium', 'satellite', 'venture'], ['motorola'], ['dollars']] },
      { text: 'The satellite venture failed after Motorola launched Iridium.',
        tokens: [tok('the', 'DET'), tok('satellite', 'NOUN'), tok('venture', 'NOUN'),
          tok('failed', 'VERB'), tok('after', 'ADP'), tok('motorola', 'PROPN'),
          tok('launched', 'VERB'), tok('iridium', 'PROPN')],
        phrases: [['satellite', 'venture'], ['motorola'], ['iridium']] }
    ];
  }

  t('extract() returns both methods with parameters recorded', function () {
    var kp = KP.extract(miniParsed(), { isStopWord: function () { return false; },
      pageRank: NET.pageRank });
    assert(kp.textRank && Array.isArray(kp.textRank.phrases) && kp.textRank.phrases.length > 0, 'textRank');
    assert(kp.yake && Array.isArray(kp.yake.phrases) && kp.yake.phrases.length > 0, 'yake');
    assert(kp.textRank.parameters.damping === 0.85, 'damping recorded');
    assert(kp.yake.parameters.dedupLim === 0.9, 'dedupLim recorded');
    assert(/lower/.test(kp.yake.parameters.note), 'lower-is-better note');
  });

  t('serialized _cra.md carries Keyphrases section + node-stat columns + NPMI columns', function () {
    var d = S.newCraData('kp.txt', null, '2.0.0-M2 (built 2026-08-11)');
    d.network.nodes = [
      { id: 0, word: 'venture', display: 'venture', degree: 1, strength: 3,
        influence: 0.4, pageRank: 0.31 },
      { id: 1, word: 'satellite', display: 'satellite', degree: 1, strength: 3,
        influence: 0.2, pageRank: 0.22 }
    ];
    d.network.edges = [{ source: 0, target: 1, weight: 3 }];
    d.summary = { nodeCount: 2, edgeCount: 1 };
    d.tokenSuggestions = [{ phrase: 'satellite venture', replacement: 'satellite_venture',
      count: 3, words: 2, npmi: 0.8123, logDice: 12.5, wordCounts: [4, 3] }];
    d.collocationTokens = 20;
    d.keyphrases = KP.extract(miniParsed(), { isStopWord: function () { return false; },
      pageRank: NET.pageRank });
    var md = S.serializeCra(d);
    assert(/## Keyphrases/.test(md), 'Keyphrases section');
    assert(/TextRank phrase/.test(md) && /YAKE phrase/.test(md), 'both tables');
    assert(/\| Word \| Degree \| Strength \| Influence \| PageRank \|/.test(md), 'node columns');
    assert(/\| Candidate phrase \| Count \| NPMI \| log-Dice \|/.test(md), 'NPMI columns');
    var back = S.parseCra(md);
    assert(back.ok, 'round-trip: ' + back.errors.join('; '));
    assert(back.data.keyphrases.yake.phrases.length ===
      d.keyphrases.yake.phrases.length, 'keyphrases survive round-trip');
    assert(back.data.network.nodes[0].pageRank === 0.31, 'pageRank survives');
  });

  t('validator rejects a malformed keyphrases block', function () {
    var d = S.newCraData('bad.txt', null, 'dev');
    d.network.nodes = [{ id: 0, word: 'x', display: 'x', degree: 0, influence: 0 }];
    d.network.edges = [];
    d.keyphrases = { textRank: { phrases: 'not-an-array' } };
    var v = S.validateCra(d);
    assert(!v.ok, 'should fail');
    assert(v.errors.some(function (e) { return /keyphrases/.test(e); }), 'names the block');
  });

  t('V1-era data (no node stats, no assoc fields) still serializes with old columns', function () {
    var d = S.newCraData('old.txt', null, '1.4.7');
    d.network.nodes = [{ id: 0, word: 'x', display: 'x', degree: 1, influence: 0.4 },
      { id: 1, word: 'y', display: 'y', degree: 1, influence: 0.2 }];
    d.network.edges = [{ source: 0, target: 1, weight: 1 }];
    d.summary = {};
    d.tokenSuggestions = [{ phrase: 'a b', replacement: 'a_b', count: 3, words: 2 }];
    var md = S.serializeCra(d);
    assert(/\| Word \| Degree \| Influence \| Connected to \|/.test(md), 'old node columns');
    assert(/\| Candidate phrase \| Count \| Suggested replacement \|/.test(md), 'old sugg columns');
    assert(!/## Keyphrases/.test(md), 'no keyphrases section');
  });

  /* ---------------- corpus collocations (Summarizer) ---------------- */

  t('corpusCollocations pools counts and recomputes NPMI from pooled counts', function () {
    function mk(count, wc, n) {
      return { tokenSuggestions: [{ phrase: 'space station', replacement: 'space_station',
        count: count, words: 2, npmi: 0.5, logDice: 10, wordCounts: wc }],
        collocationTokens: n };
    }
    var rows = TH.corpusCollocations([mk(3, [3, 3], 6), mk(3, [3, 3], 6)]);
    assert(rows.length === 1, 'pooled to one row');
    assert(rows[0].count === 6 && rows[0].files === 2, 'counts pooled');
    // pooled: f=6, fw=6/6, N=12 -> p=.5 each -> NPMI=1, logDice=14
    close(rows[0].npmi, 1, 1e-9, 'pooled NPMI');
    close(rows[0].logDice, 14, 1e-9, 'pooled logDice');
  });

  t('corpusCollocations ignores V1-era files without assoc fields', function () {
    var v1 = { tokenSuggestions: [{ phrase: 'a b', replacement: 'a_b', count: 5, words: 2 }] };
    var rows = TH.corpusCollocations([v1]);
    assert(rows.length === 0, 'nothing poolable');
  });

  /* ---------------- report ---------------- */

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M2 keyphrase/collocation/node-stat tests: ' + passed + '/' +
    results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadKeyphraseTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
