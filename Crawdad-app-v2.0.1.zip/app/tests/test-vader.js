/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M1 — VADER port tests.
 * Node:    node tests/test-vader.js
 * Browser: open tests/test-vader.html
 * The fixture (fixture-vader.json) carries reference outputs from the
 * Python vaderSentiment 3.3.2 implementation; the port must match the
 * rounded reference outputs EXACTLY (compound 4 dp; pos/neu/neg 3 dp).
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var V, FIXTURE;
  if (isNode) {
    V = require('../js/vader.js');
    FIXTURE = require('./fixture-vader.json');
  } else {
    V = root.CrawdadVader;
    FIXTURE = root.CrawdadVaderFixture; // loaded via fixture-vader.js wrapper
  }

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }

  t('fixture: every sentence matches the Python reference exactly', function () {
    var bad = [];
    FIXTURE.forEach(function (f) {
      var got = V.polarityScores(f.text);
      ['neg', 'neu', 'pos', 'compound'].forEach(function (k) {
        if (got[k] !== f.ref[k]) {
          bad.push(f.text.slice(0, 40) + ' [' + k + '] got ' + got[k] + ' ref ' + f.ref[k]);
        }
      });
    });
    assert(bad.length === 0, bad.length + ' mismatches: ' + bad.slice(0, 3).join('; '));
  });

  t('neutral text scores zero compound', function () {
    assert(V.polarityScores('The table has four legs.').compound === 0, 'expected 0');
  });

  t('negation flips valence', function () {
    var pos = V.polarityScores('The plan is good.').compound;
    var neg = V.polarityScores("The plan isn't good.").compound;
    assert(pos > 0 && neg < 0, 'got ' + pos + ' / ' + neg);
  });

  t('booster raises magnitude', function () {
    var base = V.polarityScores('The plan is good.').compound;
    var boosted = V.polarityScores('The plan is very good.').compound;
    assert(boosted > base, 'got ' + base + ' -> ' + boosted);
  });

  t('exclamation emphasis raises magnitude', function () {
    var base = V.polarityScores('The plan is good.').compound;
    var emph = V.polarityScores('The plan is good!!!').compound;
    assert(emph > base, 'got ' + base + ' -> ' + emph);
  });

  t('documentSentiment: mean compound + pos/neg shares at ±0.05', function () {
    var sents = [
      { text: 'This is wonderful.' },
      { text: 'This is terrible.' },
      { text: 'The table has four legs.' }
    ];
    var r = V.documentSentiment(sents);
    assert(r !== null && typeof r.meanCompound === 'number', 'meanCompound missing');
    assert(r.posShare > 0 && r.negShare > 0 && r.posShare < 1 && r.negShare < 1,
      'shares wrong: ' + JSON.stringify(r));
  });

  t('documentSentiment: empty input yields null', function () {
    assert(V.documentSentiment([]) === null, 'expected null');
    assert(V.documentSentiment([{ text: '   ' }]) === null, 'expected null for blank');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M1 VADER tests: ' + passed + '/' + results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadVaderTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
