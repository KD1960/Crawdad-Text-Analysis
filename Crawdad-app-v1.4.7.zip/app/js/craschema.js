/*
 * Crawdad 2026 — CRA file schema (spec §4.1)
 * Serializes/parses/validates `filename_cra.md` files.
 *
 * A _cra.md file has two sections:
 *   A. Human-readable summary (display threshold: influence > 0.005)
 *   B. Machine-readable fenced ```json block with the COMPLETE network.
 * Downstream modules parse ONLY the JSON block; the display threshold
 * never affects computation (decision 2026-07-09).
 *
 * Plain script (no ES modules) so the app runs from file:// with no
 * build step (spec §2, M8). Also loadable in Node for tests.
 */
(function (root) {
  'use strict';

  var SCHEMA_NAME = 'crawdad-cra';
  var SCHEMA_VERSION = '1.2'; // 1.1: optional textMetrics (D-12);
                              // 1.2: optional tokenSuggestions + cleaningNotes (2026-08-09)
  var DISPLAY_THRESHOLD = 0.005; // spec WF 2j-iii: display-only
  var CITATION =
    'Please cite: Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002). ' +
    'Studying complex discursive systems: Centering Resonance Analysis of ' +
    'organizational communication. Human Communication Research, 28(2), 157-206.';
  // Design Guide §06: two references travel with every artifact — the method
  // and the software that computed it. Method first, software second.
  function softwareCitation(appVersion) {
    var m = String(appVersion || '').match(/\d+\.\d+(\.\d+)?/);
    var v = m ? m[0] : 'unknown';
    return 'Dooley, K. (2026). Crawdad Text Analysis Software (Version ' + v +
      ') [Computer software].';
  }
  var DISCLAIMER =
    'Disclaimer: analyses are generated automatically and provided as-is, ' +
    'without warranty of any kind. We take no ' +
    'responsibility for interpretations, conclusions, or decisions based on ' +
    'these results; verifying fitness for any particular use is the ' +
    'responsibility of the user.';

  /* ------------------------------------------------------------------ *
   * Validation
   * ------------------------------------------------------------------ */

  /**
   * Validate a CRA data object. Returns { ok: boolean, errors: string[] }.
   * Structural integrity only; numeric plausibility checks are warnings-level
   * errors here because downstream math depends on them.
   */
  function validateCra(data) {
    var errors = [];
    function err(msg) { errors.push(msg); }

    if (!data || typeof data !== 'object') {
      return { ok: false, errors: ['Not an object.'] };
    }
    if (data.schema !== SCHEMA_NAME) {
      err('schema must be "' + SCHEMA_NAME + '" (got "' + data.schema + '").');
    }
    if (typeof data.schemaVersion !== 'string') {
      err('schemaVersion missing.');
    }
    if (!data.source || typeof data.source.filename !== 'string') {
      err('source.filename missing.');
    }
    if (!data.parameters || typeof data.parameters !== 'object') {
      err('parameters block missing.');
    }
    if (data.textMetrics !== undefined && data.textMetrics !== null &&
        typeof data.textMetrics !== 'object') {
      err('textMetrics must be an object when present.');
    }
    if (data.tokenSuggestions !== undefined && data.tokenSuggestions !== null &&
        !Array.isArray(data.tokenSuggestions)) {
      err('tokenSuggestions must be an array when present.');
    }
    if (data.cleaningNotes !== undefined && data.cleaningNotes !== null &&
        !Array.isArray(data.cleaningNotes)) {
      err('cleaningNotes must be an array when present.');
    }

    var net = data.network;
    if (!net || !Array.isArray(net.nodes) || !Array.isArray(net.edges)) {
      err('network.nodes / network.edges missing.');
      return { ok: errors.length === 0, errors: errors };
    }

    var ids = {};
    net.nodes.forEach(function (n, i) {
      if (typeof n.id !== 'number' && typeof n.id !== 'string') {
        err('node[' + i + ']: id missing.');
      } else if (ids.hasOwnProperty(n.id)) {
        err('node[' + i + ']: duplicate id "' + n.id + '".');
      } else {
        ids[n.id] = true;
      }
      if (typeof n.word !== 'string' || n.word.length === 0) {
        err('node[' + i + ']: word missing.');
      }
      if (typeof n.influence !== 'number' || isNaN(n.influence) ||
          n.influence < 0 || n.influence > 1) {
        err('node[' + i + '] ("' + n.word + '"): influence must be a number in [0,1].');
      }
      if (typeof n.degree !== 'number' || n.degree < 0 || n.degree % 1 !== 0) {
        err('node[' + i + '] ("' + n.word + '"): degree must be a non-negative integer.');
      }
    });

    var seenEdge = {};
    net.edges.forEach(function (e, i) {
      if (!ids.hasOwnProperty(e.source)) {
        err('edge[' + i + ']: source "' + e.source + '" is not a node id.');
      }
      if (!ids.hasOwnProperty(e.target)) {
        err('edge[' + i + ']: target "' + e.target + '" is not a node id.');
      }
      if (e.source === e.target) {
        err('edge[' + i + ']: self-loop not allowed.');
      }
      if (typeof e.weight !== 'number' || e.weight < 1 || e.weight % 1 !== 0) {
        err('edge[' + i + ']: weight (F_ij) must be an integer >= 1.');
      }
      // undirected: canonical key to catch duplicates in either order
      var k = e.source < e.target ? e.source + '|' + e.target : e.target + '|' + e.source;
      if (seenEdge[k]) { err('edge[' + i + ']: duplicate undirected edge ' + k + '.'); }
      seenEdge[k] = true;
    });

    return { ok: errors.length === 0, errors: errors };
  }

  /* ------------------------------------------------------------------ *
   * Serialization  (data object -> _cra.md text)
   * ------------------------------------------------------------------ */

  function fmt(x, places) {
    return Number(x).toFixed(places === undefined ? 5 : places);
  }

  /* ------------------------------------------------------------------ *
   * Metric interpretation (2026-08-09).
   * Descriptive guides for reading the numbers — NOT validated cutpoints.
   * Bands follow the cited source where one exists (Flesch bands: Flesch
   * 1948; density: Ure 1971; formality: Heylighen & Dewaele 1999) and are
   * otherwise rough conventions. Comparisons across texts processed with
   * identical settings are more defensible than absolute readings.
   * ------------------------------------------------------------------ */

  function band(x, cuts, labels) {
    // cuts ascending; labels.length === cuts.length + 1
    for (var i = 0; i < cuts.length; i++) { if (x < cuts[i]) { return labels[i]; } }
    return labels[cuts.length];
  }

  var INTERPRET = {
    sentiment: function (x) {
      if (Math.abs(x) <= 0.05) { return 'neutral on balance'; }
      var strength = Math.abs(x) <= 0.25 ? 'mildly ' : 'strongly ';
      return strength + (x > 0 ? 'positive' : 'negative') + ' valence';
    },
    gendered: function (g) {
      if (Math.abs(g.index) < 0.2) { return 'balanced coded vocabulary'; }
      return g.index > 0 ? 'leans masculine-coded (agentic) wording'
                         : 'leans feminine-coded (communal) wording';
    },
    abstractness: function (x) {
      return band(x, [0.15, 0.30],
        ['mostly concrete nouns', 'mixed concrete/abstract',
         'heavily abstract nominal style']);
    },
    agreeableness: function (a) {
      if (Math.abs(a.index) < 0.2) { return 'balanced agreement/disagreement markers'; }
      return a.index > 0 ? 'agreement markers dominate'
                         : 'disagreement/adversative markers dominate';
    },
    mtld: function (x) {
      if (x === null || x === undefined) { return '—'; }
      return band(x, [50, 90],
        ['low vocabulary diversity (repetitive)', 'typical range for running prose',
         'high vocabulary diversity']);
    },
    density: function (x) {
      return band(x, [0.40, 0.50],
        ['speech-like density', 'typical written prose',
         'dense, information-packed (academic register)']);
    },
    fre: function (x) {
      return band(x, [30, 50, 70],
        ['very difficult (postgraduate/technical)', 'difficult (college)',
         'fairly difficult (high school)', 'easy (general readership)']);
    },
    cohesion: function (x) {
      return band(x, [0.30, 0.60],
        ['low explicit cohesion (topic shifts or implicit links)',
         'moderate sentence-to-sentence continuity',
         'high sentence-to-sentence continuity']);
    },
    certainty: function (x) {
      if (x < -0.1) { return 'hedged, tentative stance'; }
      if (x > 0.1) { return 'assertive, boosted stance'; }
      return 'balanced hedging vs. assertion';
    },
    pronouns: function (p) {
      var rates = { 'first-person singular': p.firstSingularPer1000,
        'first-person plural': p.firstPluralPer1000,
        'second-person': p.secondPer1000, 'third-person': p.thirdPer1000 };
      var bestK = null, bestV = -1;
      Object.keys(rates).forEach(function (k) {
        if (rates[k] > bestV) { bestV = rates[k]; bestK = k; }
      });
      if (bestV < 5) { return 'impersonal register (sparse pronoun use)'; }
      return bestK + ' voice dominates';
    },
    wordLength: function (w) {
      return band(w.longWordShare, [0.15, 0.25],
        ['plain diction', 'moderately long-word diction',
         'long-word heavy (technical/sophisticated diction)']);
    },
    passive: function (x) {
      return band(x, [0.10, 0.25],
        ['active-voice dominant', 'moderate passive use',
         'passive-heavy (agent-obscuring)']);
    },
    formality: function (x) {
      return band(x, [45, 55],
        ['informal, involved style', 'mid-range formality',
         'formal, nominal style']);
    }
  };

  /** Short prose reading of the network summary (fragmentation + focus). */
  function interpretSummary(s) {
    if (!s || s.componentCount === undefined) { return []; }
    var out = [];
    if (s.componentCount === 1) {
      out.push('The network is a single connected component: every concept is ' +
        'reachable from every other, indicating a text whose noun phrases ' +
        'consistently interlink.');
    } else if (s.largestComponentShare >= 0.75) {
      out.push('One dominant component holds ' + fmt(s.largestComponentShare * 100, 0) +
        '% of concepts, with ' + (s.componentCount - 1) + ' small fragment(s) — a ' +
        'coherent core plus peripheral asides, the expected shape for most prose ' +
        '(Corman et al., 2002, p. 177).');
    } else {
      out.push('The largest component holds only ' + fmt(s.largestComponentShare * 100, 0) +
        '% of concepts across ' + s.componentCount + ' components — fragmented ' +
        'discourse whose parts are not tied together by shared noun phrases.');
    }
    var b = s.centralization && s.centralization.betweenness;
    if (b !== undefined && b !== null) {
      if (b >= 0.5) {
        out.push('Betweenness centralization is high (' + fmt(b) + '): coherence ' +
          'depends on a few hub words; the influence table shows which.');
      } else if (b >= 0.2) {
        out.push('Betweenness centralization is moderate (' + fmt(b) + '): a ' +
          'recognizable set of organizing words, with meaning spread beyond them.');
      } else {
        out.push('Betweenness centralization is low (' + fmt(b) + '): influence is ' +
          'spread across many words rather than concentrated in a few hubs.');
      }
    }
    return out;
  }

  function serializeCra(data) {
    var v = validateCra(data);
    if (!v.ok) {
      throw new Error('Refusing to serialize invalid CRA data:\n' + v.errors.join('\n'));
    }
    var net = data.network;
    var byId = {};
    net.nodes.forEach(function (n) { byId[n.id] = n; });

    // neighbor map for the human-readable table
    var nbrs = {};
    net.nodes.forEach(function (n) { nbrs[n.id] = []; });
    net.edges.forEach(function (e) {
      nbrs[e.source].push(byId[e.target].word);
      nbrs[e.target].push(byId[e.source].word);
    });

    var s = data.summary || {};
    var c = s.centralization || {};
    var lines = [];

    lines.push('# CRA Analysis: ' + data.source.filename);
    lines.push('');
    lines.push('- Processed: ' + (data.source.processedAt || 'unknown'));
    lines.push('- App version: ' + (data.source.appVersion || 'unknown'));
    lines.push('- Parameters: stemming=' + data.parameters.stemming +
      ', pronouns=' + (data.parameters.pronouns ? 'retained' : 'dropped') +
      ', inter-sentence linking=' + (data.parameters.interSentenceLinking ? 'on' : 'off (JHC 2002)') +
      ', tokenization file=' + (data.parameters.tokenizationFile || 'none'));
    if (data.cleaningNotes && data.cleaningNotes.length) {
      lines.push('');
      lines.push('## Text cleaning');
      lines.push('');
      lines.push('Applied before parsing (deterministic; citations and reference lists are');
      lines.push('removed so author names and years do not become network nodes):');
      lines.push('');
      data.cleaningNotes.forEach(function (n) { lines.push('- ' + n); });
    }
    lines.push('');
    lines.push('## Network summary');
    lines.push('');
    lines.push('| Measure | Value |');
    lines.push('|---|---|');
    lines.push('| Nodes | ' + net.nodes.length + ' |');
    lines.push('| Edges | ' + net.edges.length + ' |');
    ['degree', 'betweenness', 'closeness', 'eigenvector'].forEach(function (m) {
      var cap = m.charAt(0).toUpperCase() + m.slice(1);
      var note = (m === 'closeness' && s.closenessNote) ? s.closenessNote : '';
      lines.push('| ' + cap + ' centralization | ' +
        (c[m] === undefined || c[m] === null ? 'n/a' : fmt(c[m])) + note + ' |');
    });
    if (s.meanInfluence !== undefined) {
      lines.push('| Mean influence | ' + fmt(s.meanInfluence) + ' |');
    }
    if (s.componentCount !== undefined) {
      lines.push('| Network fragmentation | ' + s.componentCount + ' component(s); largest holds ' +
        fmt(s.largestComponentShare, 3) + ' of nodes |');
    }
    var sumInterp = interpretSummary(s);
    if (sumInterp.length) {
      lines.push('');
      sumInterp.forEach(function (p) { lines.push(p); });
    }
    // ---- text-level metrics (D-12) ----
    if (data.textMetrics) {
      var tm = data.textMetrics;
      lines.push('');
      lines.push('## Text metrics');
      lines.push('');
      lines.push('| Metric | Value | Interpretation | Method |');
      lines.push('|---|---|---|---|');
      if (tm.sentiment !== null && tm.sentiment !== undefined) {
        lines.push('| Sentiment (-1 to +1; mean/sentence) | ' + tm.sentiment +
          ' | ' + INTERPRET.sentiment(tm.sentiment) +
          ' | AFINN-165 (Nielsen, 2011), rescaled from ±5 |');
      }
      if (tm.genderedLanguage) {
        lines.push('| Gendered language index (+1 masc, -1 fem) | ' + tm.genderedLanguage.index +
          ' (M ' + tm.genderedLanguage.masculinePer1000 + '/1k, F ' +
          tm.genderedLanguage.femininePer1000 + '/1k) | ' +
          INTERPRET.gendered(tm.genderedLanguage) +
          ' | Gaucher, Friesen, & Kay (2011) stems |');
      }
      if (tm.abstractness !== null && tm.abstractness !== undefined) {
        lines.push('| Abstractness (0 concrete - 1 abstract) | ' + tm.abstractness +
          ' | ' + INTERPRET.abstractness(tm.abstractness) +
          ' | HEURISTIC: abstract-suffix nouns (see Brysbaert et al., 2014 for norms) |');
      }
      if (tm.agreeableness) {
        lines.push('| Agreeableness index (+1 agree, -1 disagree) | ' + tm.agreeableness.index +
          ' (A ' + tm.agreeableness.agreePer1000 + '/1k, D ' +
          tm.agreeableness.disagreePer1000 + '/1k) | ' +
          INTERPRET.agreeableness(tm.agreeableness) +
          ' | HEURISTIC marker counts |');
      }
      if (tm.lexicalDiversity) {
        lines.push('| Lexical diversity MTLD | ' + tm.lexicalDiversity.mtld +
          ' (TTR ' + tm.lexicalDiversity.ttr + ', ' + tm.lexicalDiversity.types + ' types / ' +
          tm.lexicalDiversity.tokens + ' tokens) | ' +
          INTERPRET.mtld(tm.lexicalDiversity.mtld) +
          ' | McCarthy & Jarvis (2010) |');
      }
      if (tm.lexicalDensity !== null && tm.lexicalDensity !== undefined) {
        lines.push('| Lexical density (content words / all words) | ' + tm.lexicalDensity +
          ' | ' + INTERPRET.density(tm.lexicalDensity) +
          ' | Ure (1971) |');
      }
      if (tm.readability) {
        lines.push('| Flesch Reading Ease | ' + tm.readability.fleschReadingEase +
          ' (FK grade ' + tm.readability.fleschKincaidGrade + '; ' +
          tm.readability.meanWordsPerSentence + ' words/sentence) | ' +
          INTERPRET.fre(tm.readability.fleschReadingEase) +
          ' | Kincaid et al. (1975) |');
      }
      if (tm.cohesion) {
        lines.push('| Cohesion: adjacent-sentence noun overlap | ' + tm.cohesion.adjacentNounOverlap +
          ' (global ' + tm.cohesion.globalNounOverlap + ') | ' +
          INTERPRET.cohesion(tm.cohesion.adjacentNounOverlap) +
          ' | Coh-Metrix-style (Graesser et al., 2004) |');
      }
      if (tm.hedging) {
        lines.push('| Certainty index (+1 boosted, -1 hedged) | ' + tm.hedging.certaintyIndex +
          ' (hedges ' + tm.hedging.hedgesPer1000 + '/1k, boosters ' +
          tm.hedging.boostersPer1000 + '/1k) | ' +
          INTERPRET.certainty(tm.hedging.certaintyIndex) +
          ' | Hyland (2005) hedges/boosters |');
      }
      if (tm.pronounRates) {
        lines.push('| Pronoun rates per 1k (I / we / you / third) | ' +
          tm.pronounRates.firstSingularPer1000 + ' / ' + tm.pronounRates.firstPluralPer1000 +
          ' / ' + tm.pronounRates.secondPer1000 + ' / ' + tm.pronounRates.thirdPer1000 +
          ' | ' + INTERPRET.pronouns(tm.pronounRates) +
          ' | counted before CRA pronoun drop |');
      }
      if (tm.wordLength) {
        lines.push('| Word length (mean chars; share >= 7 chars) | ' + tm.wordLength.meanChars +
          '; ' + tm.wordLength.longWordShare + ' | ' +
          INTERPRET.wordLength(tm.wordLength) +
          ' | sophistication proxy |');
      }
      if (tm.passiveRate !== null && tm.passiveRate !== undefined) {
        lines.push('| Passive voice (share of sentences) | ' + tm.passiveRate +
          ' | ' + INTERPRET.passive(tm.passiveRate) +
          ' | HEURISTIC: be-verb + participle pattern |');
      }
      if (tm.formality !== null && tm.formality !== undefined) {
        lines.push('| Formality F-score (~50 neutral; higher = formal) | ' + tm.formality +
          ' | ' + INTERPRET.formality(tm.formality) +
          ' | Heylighen & Dewaele (1999) |');
      }
      lines.push('');
      lines.push('Interpretations are descriptive guides, not validated cutpoints: bands ' +
        'follow the cited source where one exists and are otherwise rough conventions. ' +
        'Readability formulas run low on technical vocabulary (validation study V7), so ' +
        'comparisons across texts processed with identical settings are more defensible ' +
        'than absolute readings. Metrics marked HEURISTIC use unvalidated word lists.');
    }
    lines.push('');
    lines.push('## Influential words (influence > ' + DISPLAY_THRESHOLD + ')');
    lines.push('');
    lines.push('| Word | Degree | Influence | Connected to |');
    lines.push('|---|---|---|---|');
    net.nodes
      .filter(function (n) { return n.influence > DISPLAY_THRESHOLD; })
      .sort(function (a, b) { return b.influence - a.influence; })
      .forEach(function (n) {
        lines.push('| ' + (n.display || n.word) + ' | ' + n.degree + ' | ' +
          fmt(n.influence) + ' | ' + nbrs[n.id].sort().join(', ') + ' |');
      });
    if (data.tokenSuggestions && data.tokenSuggestions.length) {
      lines.push('');
      lines.push('## Tokenization suggestions (word–word adjacency)');
      lines.push('');
      lines.push('Word sequences that repeatedly occur adjacent within the same noun phrase.');
      lines.push('Each is a *candidate* multi-word concept — whether it is genuinely one');
      lines.push('concept is the analyst\'s judgment, not the software\'s. To merge one, add a');
      lines.push('row to a tokenization file (column 1 = phrase, column 2 = replacement) and');
      lines.push('re-run the Generator. The replacement must be a single token: join words');
      lines.push('with underscores (e.g., supply_chain) or use an acronym (SCM). Matching is');
      lines.push('whole-word and case-insensitive, so add inflected variants ("supply chains")');
      lines.push('as separate rows.');
      lines.push('');
      lines.push('| Candidate phrase | Count | Suggested replacement |');
      lines.push('|---|---|---|');
      data.tokenSuggestions.forEach(function (sug) {
        lines.push('| ' + sug.phrase + ' | ' + sug.count + ' | ' + sug.replacement + ' |');
      });
    }
    lines.push('');
    lines.push('## Data (machine-readable — do not edit)');
    lines.push('');
    lines.push('```json');
    lines.push(JSON.stringify(data, null, 1));
    lines.push('```');
    lines.push('');
    lines.push('---');
    lines.push('*' + CITATION + '*');
    lines.push('');
    lines.push('*' + softwareCitation(data.source.appVersion) + '*');
    lines.push('');
    lines.push('*' + DISCLAIMER + '*');
    lines.push('');
    return lines.join('\n');
  }

  /* ------------------------------------------------------------------ *
   * Parsing  (_cra.md text -> data object)
   * ------------------------------------------------------------------ */

  /**
   * Parse a _cra.md file. Returns { ok, data, errors }.
   * Only the fenced JSON block is authoritative (spec §4.1).
   */
  function parseCra(text) {
    if (typeof text !== 'string') {
      return { ok: false, data: null, errors: ['Input is not text.'] };
    }
    var m = text.match(/```json\s*\n([\s\S]*?)\n```/);
    if (!m) {
      return {
        ok: false, data: null,
        errors: ['No machine-readable JSON block found. This is not a valid Crawdad _cra.md file (spec §4.1).']
      };
    }
    var data;
    try {
      data = JSON.parse(m[1]);
    } catch (e) {
      return { ok: false, data: null, errors: ['JSON block is corrupt: ' + e.message] };
    }
    var v = validateCra(data);
    return { ok: v.ok, data: v.ok ? data : data, errors: v.errors };
  }

  /* ------------------------------------------------------------------ *
   * Helpers for building a fresh data object (used by Generator in M2)
   * ------------------------------------------------------------------ */

  function newCraData(filename, parameters, appVersion) {
    return {
      schema: SCHEMA_NAME,
      schemaVersion: SCHEMA_VERSION,
      source: {
        filename: filename,
        processedAt: new Date().toISOString(),
        appVersion: appVersion || 'dev'
      },
      parameters: parameters || {
        stemming: 'porter',            // D-2 default
        pronouns: false,               // JHC p. 175 default
        interSentenceLinking: false,   // D-17 default (off = JHC 2002)
        tokenizationFile: null,
        stopWordList: 'default'
      },
      network: { nodes: [], edges: [] },
      summary: {}
    };
  }

  var api = {
    SCHEMA_NAME: SCHEMA_NAME,
    SCHEMA_VERSION: SCHEMA_VERSION,
    DISPLAY_THRESHOLD: DISPLAY_THRESHOLD,
    CITATION: CITATION,
    softwareCitation: softwareCitation,
    DISCLAIMER: DISCLAIMER,
    validateCra: validateCra,
    serializeCra: serializeCra,
    parseCra: parseCra,
    newCraData: newCraData
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;           // Node (tests)
  } else {
    root.CrawdadSchema = api;       // Browser
  }
})(typeof self !== 'undefined' ? self : this);
