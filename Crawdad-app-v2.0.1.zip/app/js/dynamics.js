/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M6 — Dynamics module (Build Spec V2 §6.2; D-V2-9, D-V2-13,
 * D-V2-14).
 *
 * Normative foundation: Dooley & Corman (2004), NDPLS 8(3) — the published
 * windowed-CRA workflow, productized as one engine over three windowing
 * granularities:
 *   corpus mode        — each loaded _cra.md is one time window, in order;
 *   per-article bucket — CRA per document, theme influence averaged over
 *                        calendar buckets (D-V2-14; empty-bucket handling
 *                        is a REPORTED parameter);
 *   within-text mode   — windows are segments of one document (fixed word
 *                        count or TextTiling, Hearst 1997), yielding
 *                        influence trajectories (handled by the caller,
 *                        which builds per-window craData and runs this
 *                        same engine).
 *
 * Pipeline (2004 study; all closed-form / exact):
 *   1. word × window influence matrix, admission ≥ ½ of windows (config,
 *      recorded), capped at top `topWords` by summed influence;
 *   2. dynamic themes via the Theme Identifier machinery (PCA + Kaiser-
 *      normalized varimax); eigenvalue cut 1.0 default, the paper's 4.0 as
 *      a setting; |loading| ≥ 0.4, max-loading assignment;
 *   3. theme time series = mean influence of theme words per window;
 *   4. diagnostics per series: ACF + PACF (Durbin–Levinson) with Bartlett
 *      bands, DFT periodogram, Ljung–Box, Yule–Walker AR(p ≤ 3) and MA(1)
 *      by the innovations algorithm, model chosen by AICc (closed-form
 *      only — no iterative MLE in the determinism contract);
 *   5. PELT change points (Killick et al., 2012; normal mean-shift cost,
 *      min segment 2), penalty = mult × 2σ²ln n with BIC default mult = 1
 *      — a visible reported parameter (D-V2-14);
 *   6. stage transitions: ≥ k themes (default 2) with change points within
 *      ±1 window (Daneke & Dooley 2007 coincidence rule, D-V2-14);
 *   7. lagged cross-correlations (max lag ⌊n/4⌋, 2/√n bands), cyclic
 *      paths flagged (the 2004 production-process signature);
 *   8. sequential WR′ between consecutive windows (CRA resonance term,
 *      D-V2-9) — the turnover profile;
 *   9. Barron, Huang, Spang, & DeDeo (2018) novelty/transience/resonance:
 *      KL divergence over Laplace-smoothed (α = 0.01) unigram
 *      distributions from each window's surfaceFrequencies block (top
 *      2,000 types/window — stated). D-V2-9: Barron's published terms are
 *      used WITH a disambiguation note; the WR′ profile always carries the
 *      CRA term.
 *
 * The 2004 study's core methodological caution ships in every report:
 * when window size approaches the texts' production timescale, observed
 * dynamics mix production/institutional effects with environmental ones
 * (pp. 279–281).
 *
 * Oracles: the Iridium dynamics pilot (13 yearly windows) is the fixture;
 * statsmodels ACF/PACF/Yule–Walker at 1e-9; ruptures PELT breakpoint
 * equality; hand-worked KL.
 */
(function (root) {
  'use strict';

  function mean(a) {
    var s = 0;
    for (var i = 0; i < a.length; i++) { s += a[i]; }
    return a.length ? s / a.length : 0;
  }
  function round(x, p) { var m = Math.pow(10, p); return Math.round(x * m) / m; }

  /* ------------------------------------------------------------------ *
   * 1–3: influence matrix + dynamic themes + series
   * ------------------------------------------------------------------ */

  function influenceMatrix(windows, opts) {
    opts = opts || {};
    var minShare = opts.minWindowShare === undefined ? 0.5 : opts.minWindowShare;
    var topWords = opts.topWords === undefined ? 50 : opts.topWords;
    var nW = windows.length;
    var infl = windows.map(function (w) {
      var m = Object.create(null);
      (w.data.network && w.data.network.nodes || []).forEach(function (n) {
        m[n.word] = n.influence;
      });
      return m;
    });
    var disp = Object.create(null), present = Object.create(null);
    windows.forEach(function (w, i) {
      (w.data.network && w.data.network.nodes || []).forEach(function (n) {
        if (!(n.word in disp)) { disp[n.word] = n.display || n.word; }
      });
      Object.keys(infl[i]).forEach(function (k) { present[k] = (present[k] || 0) + 1; });
    });
    var minWindows = Math.ceil(nW * minShare);
    var eligible = Object.keys(present).filter(function (k) {
      return present[k] >= minWindows;
    });
    var sums = Object.create(null);
    eligible.forEach(function (k) { sums[k] = 0; });
    windows.forEach(function (w, i) {
      eligible.forEach(function (k) { sums[k] += infl[i][k] || 0; });
    });
    var words = eligible.sort(function (a, b) {
      return (sums[b] - sums[a]) || (a < b ? -1 : 1);
    }).slice(0, topWords).sort();
    var M = windows.map(function (w, i) {
      return words.map(function (k) { return infl[i][k] || 0; });
    });
    return { words: words, display: disp, M: M, infl: infl,
      eligibleCount: eligible.length, minWindows: minWindows };
  }

  function dynamicThemes(mat, opts, deps) {
    opts = opts || {};
    var evCut = opts.evCut === undefined ? 1.0 : opts.evCut;
    var loadCut = opts.loadCut === undefined ? 0.4 : opts.loadCut;
    var cm = deps.themes.correlationMatrix(mat.M);
    var pairs = deps.themes.jacobiEig(cm.R);
    var eigenvalues = pairs.map(function (p) { return p.value; });
    var kRetain = eigenvalues.filter(function (ev) { return ev > evCut; }).length;
    if (kRetain < 1) { kRetain = 1; }
    var nVar = mat.words.length;
    var loadings = [];
    for (var i = 0; i < nVar; i++) {
      loadings.push(pairs.slice(0, kRetain).map(function (p) {
        return p.vector[i] * Math.sqrt(Math.max(p.value, 0));
      }));
    }
    var rot = kRetain > 1 ? deps.themes.varimax(loadings).loadings : loadings;
    var themes = [];
    for (i = 0; i < kRetain; i++) { themes.push([]); }
    mat.words.forEach(function (w, wi) {
      var best = 0, bestJ = -1;
      for (var j = 0; j < kRetain; j++) {
        if (Math.abs(rot[wi][j]) > Math.abs(best)) { best = rot[wi][j]; bestJ = j; }
      }
      if (bestJ >= 0 && Math.abs(best) >= loadCut) {
        themes[bestJ].push({ word: w, display: mat.display[w] || w,
          loading: round(best, 4) });
      }
    });
    themes.forEach(function (t) {
      t.sort(function (a, b) { return Math.abs(b.loading) - Math.abs(a.loading); });
    });
    return { eigenvalues: eigenvalues.map(function (e) { return round(e, 4); }),
      kRetain: kRetain, themes: themes, evCut: evCut, loadCut: loadCut };
  }

  function themeSeries(mat, themes) {
    return themes.map(function (t) {
      return mat.M.map(function (row, i) {
        if (!t.length) { return 0; }
        var s = 0;
        t.forEach(function (tw) { s += mat.infl[i][tw.word] || 0; });
        return s / t.length;
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * 4: series diagnostics (closed-form only)
   * ------------------------------------------------------------------ */

  function acf(x, maxLag) {
    var mu = mean(x), n = x.length;
    var c0 = 0;
    for (var t = 0; t < n; t++) { c0 += (x[t] - mu) * (x[t] - mu); }
    c0 /= n;
    var out = [];
    for (var k = 1; k <= maxLag; k++) {
      var ck = 0;
      for (t = k; t < n; t++) { ck += (x[t] - mu) * (x[t - k] - mu); }
      out.push(c0 > 0 ? (ck / n) / c0 : 0);
    }
    return out;
  }

  /** PACF via Durbin–Levinson on the biased ACF (statsmodels method='ywm'). */
  function pacf(x, maxLag) {
    var r = acf(x, maxLag);
    var phiPrev = [], out = [];
    for (var k = 1; k <= maxLag; k++) {
      var num = r[k - 1], den = 1;
      for (var j = 1; j < k; j++) {
        num -= phiPrev[j - 1] * r[k - 1 - j];
        den -= phiPrev[j - 1] * r[j - 1];
      }
      var phiKK = den !== 0 ? num / den : 0;
      var phiNew = [];
      for (j = 1; j < k; j++) {
        phiNew.push(phiPrev[j - 1] - phiKK * phiPrev[k - 1 - j]);
      }
      phiNew.push(phiKK);
      phiPrev = phiNew;
      out.push(phiKK);
    }
    return out;
  }

  /** DFT periodogram at Fourier frequencies j/n, j = 1..floor(n/2). */
  function periodogram(x) {
    var n = x.length, mu = mean(x);
    var out = [];
    for (var j = 1; j <= Math.floor(n / 2); j++) {
      var re = 0, im = 0;
      for (var t = 0; t < n; t++) {
        var ang = 2 * Math.PI * j * t / n;
        re += (x[t] - mu) * Math.cos(ang);
        im -= (x[t] - mu) * Math.sin(ang);
      }
      out.push({ freq: round(j / n, 4), period: round(n / j, 2),
        power: round((re * re + im * im) / n, 6) });
    }
    return out;
  }

  function ljungBox(x, h) {
    var n = x.length, r = acf(x, h);
    var q = 0;
    for (var k = 1; k <= h; k++) { q += (r[k - 1] * r[k - 1]) / (n - k); }
    return n * (n + 2) * q;
  }

  /** Yule–Walker AR(p) via Durbin–Levinson (biased autocovariances). */
  function yuleWalker(x, p) {
    var r = acf(x, p);
    var mu = mean(x), n = x.length;
    var c0 = 0;
    for (var t = 0; t < n; t++) { c0 += (x[t] - mu) * (x[t] - mu); }
    c0 /= n;
    var phi = [], sigma2 = c0;
    var phiPrev = [];
    for (var k = 1; k <= p; k++) {
      var num = r[k - 1], den = 1;
      for (var j = 1; j < k; j++) {
        num -= phiPrev[j - 1] * r[k - 1 - j];
        den -= phiPrev[j - 1] * r[j - 1];
      }
      var phiKK = den !== 0 ? num / den : 0;
      var phiNew = [];
      for (j = 1; j < k; j++) {
        phiNew.push(phiPrev[j - 1] - phiKK * phiPrev[k - 1 - j]);
      }
      phiNew.push(phiKK);
      phiPrev = phiNew;
      sigma2 *= (1 - phiKK * phiKK);
    }
    phi = phiPrev;
    return { phi: phi, sigma2: Math.max(sigma2, 1e-300) };
  }

  /** MA(1) by the innovations algorithm (Brockwell & Davis, 1991, §8.3):
   *  v0 = γ0; θ_{m,m−k} = (γ(m−k) − Σ_{j<k} θ_{k,k−j} θ_{m,m−j} v_j)/v_k;
   *  v_m = γ0 − Σ_{j<m} θ_{m,m−j}² v_j. Estimate: θ = θ_{m,1}, σ² = v_m. */
  function innovationsMA1(x) {
    var n = x.length, mu = mean(x);
    var m = Math.min(n - 1, 10);
    var g = []; // autocovariances gamma(0..m), biased
    for (var k = 0; k <= m; k++) {
      var ck = 0;
      for (var t = k; t < n; t++) { ck += (x[t] - mu) * (x[t - k] - mu); }
      g.push(ck / n);
    }
    var v = [Math.max(g[0], 1e-300)];
    var TH = [null]; // TH[m][i] = theta_{m,i}, i = 1..m
    for (var mm = 1; mm <= m; mm++) {
      var row = new Array(mm + 1).fill(0);
      for (k = 0; k < mm; k++) {
        var s = g[mm - k];
        for (var j = 0; j < k; j++) {
          s -= TH[k][k - j] * row[mm - j] * v[j];
        }
        row[mm - k] = s / v[k];
      }
      var vm = g[0];
      for (j = 0; j < mm; j++) { vm -= row[mm - j] * row[mm - j] * v[j]; }
      v.push(Math.max(vm, 1e-300));
      TH.push(row);
    }
    return { theta: TH[m][1], sigma2: v[m] };
  }

  function gaussAICc(n, sigma2, kParams) {
    var ll = -0.5 * n * (Math.log(2 * Math.PI * Math.max(sigma2, 1e-300)) + 1);
    var denom = n - kParams - 1;
    return -2 * ll + (denom > 0 ? 2 * kParams * n / denom : Infinity);
  }

  /** Model identification: WN vs AR(1..3) vs MA(1), AICc (closed-form). */
  function identifyModel(x) {
    var n = x.length, mu = mean(x);
    var c0 = 0;
    for (var t = 0; t < n; t++) { c0 += (x[t] - mu) * (x[t] - mu); }
    c0 /= n;
    var cands = [{ model: 'white noise', k: 1, sigma2: c0, detail: '' }];
    for (var p = 1; p <= 3; p++) {
      if (n - p - 2 <= 0) { break; }
      var yw = yuleWalker(x, p);
      cands.push({ model: 'AR(' + p + ')', k: p + 1, sigma2: yw.sigma2,
        detail: 'phi=[' + yw.phi.map(function (f) { return round(f, 3); }).join(', ') + ']',
        phi: yw.phi });
    }
    if (n >= 5) {
      var ma = innovationsMA1(x);
      // Score the fitted MA(1) by its own conditional-sum-of-squares
      // residuals (e_t = x_t − θ e_{t−1}, e_0 backcast 0) — the innovations
      // v_m is the PROCESS one-step variance and overstates MA(1) fit on
      // non-MA series (caught by the AR-identification test 2026-08-11).
      var ePrev = 0, sse = 0;
      for (var ti = 0; ti < n; ti++) {
        var e = (x[ti] - mu) - ma.theta * ePrev;
        sse += e * e;
        ePrev = e;
      }
      cands.push({ model: 'MA(1)', k: 2, sigma2: Math.max(sse / n, 1e-300),
        detail: 'theta=' + round(ma.theta, 3), theta: ma.theta });
    }
    cands.forEach(function (c) { c.aicc = round(gaussAICc(n, c.sigma2, c.k), 3); });
    var best = cands.reduce(function (a, b) { return b.aicc < a.aicc ? b : a; });
    // 2004 interpretive logic
    var reading;
    if (best.model === 'white noise') {
      reading = 'white noise: many independent drivers, no memory';
    } else if (/^AR/.test(best.model)) {
      reading = best.phi[0] < 0
        ? 'AR with negative coefficient: alternation (the 2004 "crowding-out" reading)'
        : 'AR with positive coefficient: persistence — attention carries over';
    } else {
      reading = 'MA: response-with-memory to shocks';
    }
    return { candidates: cands, best: best, reading: reading };
  }

  /* ------------------------------------------------------------------ *
   * 5–6: PELT change points + stage transitions
   * ------------------------------------------------------------------ */

  /** PELT, normal mean-shift (L2) cost, min segment 2. Penalty visible:
   *  beta = penaltyMult * 2 * sigma2 * ln(n) (BIC default mult 1). */
  function pelt(x, penaltyMult) {
    penaltyMult = penaltyMult === undefined ? 1 : penaltyMult;
    var n = x.length;
    var mu = mean(x), sigma2 = 0;
    for (var i = 0; i < n; i++) { sigma2 += (x[i] - mu) * (x[i] - mu); }
    sigma2 = Math.max(sigma2 / n, 1e-12);
    var beta = penaltyMult * 2 * sigma2 * Math.log(n);
    var cs = [0], cs2 = [0];
    for (i = 0; i < n; i++) { cs.push(cs[i] + x[i]); cs2.push(cs2[i] + x[i] * x[i]); }
    function cost(a, b) {
      var len = b - a, s = cs[b] - cs[a], s2 = cs2[b] - cs2[a];
      return s2 - (s * s) / len;
    }
    var F = new Array(n + 1).fill(Infinity);
    F[0] = -beta;
    var prev = new Array(n + 1).fill(0);
    for (var t = 2; t <= n; t++) {
      for (var s = 0; s <= t - 2; s++) {
        if (s !== 0 && s < 2) { continue; } // min segment length 2
        var v = F[s] + cost(s, t) + beta;
        if (v < F[t]) { F[t] = v; prev[t] = s; }
      }
    }
    var cps = [];
    var tt = n;
    while (tt > 0) {
      var ss = prev[tt];
      if (ss > 0) { cps.unshift(ss); }
      tt = ss;
    }
    return { changePoints: cps, beta: beta, sigma2: sigma2 };
  }

  /** D-V2-14: ≥ k themes with change points within ± 1 window. */
  function stageTransitions(perThemeCps, kCoincide, nW) {
    kCoincide = kCoincide === undefined ? 2 : kCoincide;
    var out = [];
    for (var w = 0; w < nW; w++) {
      var themesHit = [];
      perThemeCps.forEach(function (cps, ti) {
        var hit = cps.some(function (c) { return Math.abs(c - w) <= 1; });
        if (hit) { themesHit.push(ti); }
      });
      // count only windows where at least one theme has an exact change point
      var exact = perThemeCps.some(function (cps) {
        return cps.indexOf(w) !== -1;
      });
      if (exact && themesHit.length >= kCoincide) {
        out.push({ window: w, themes: themesHit });
      }
    }
    return out;
  }

  /* ------------------------------------------------------------------ *
   * 7: lagged cross-correlations + cycle flags
   * ------------------------------------------------------------------ */

  function crossCorr(x, y, lag) { // corr(x[t], y[t+lag]), lag >= 0
    var xs = [], ys = [];
    for (var t = 0; t + lag < x.length; t++) { xs.push(x[t]); ys.push(y[t + lag]); }
    var mx = mean(xs), my = mean(ys);
    var sxy = 0, sx = 0, sy = 0;
    for (var i = 0; i < xs.length; i++) {
      sxy += (xs[i] - mx) * (ys[i] - my);
      sx += (xs[i] - mx) * (xs[i] - mx);
      sy += (ys[i] - my) * (ys[i] - my);
    }
    return sx > 0 && sy > 0 ? sxy / Math.sqrt(sx * sy) : 0;
  }

  function laggedCrossCorrelations(series, maxLag) {
    var n = series.length ? series[0].length : 0;
    var sig = 2 / Math.sqrt(n);
    var links = [];
    for (var a = 0; a < series.length; a++) {
      for (var b = 0; b < series.length; b++) {
        if (a === b) { continue; }
        for (var lag = 0; lag <= maxLag; lag++) {
          if (a > b && lag === 0) { continue; } // lag-0 is symmetric
          var r = crossCorr(series[a], series[b], lag);
          if (Math.abs(r) >= sig) {
            links.push({ from: a, to: b, lag: lag, r: round(r, 4) });
          }
        }
      }
    }
    // cycles: directed lag>0 links; flag any pair a->b and b->a both present
    var cycles = [];
    links.forEach(function (l1) {
      if (l1.lag === 0) { return; }
      links.forEach(function (l2) {
        if (l2.lag === 0) { return; }
        if (l1.from === l2.to && l1.to === l2.from && l1.from < l1.to) {
          cycles.push({ a: l1.from, b: l1.to, lagAB: l1.lag, lagBA: l2.lag });
        }
      });
    });
    var seen = Object.create(null);
    cycles = cycles.filter(function (c) {
      var k = c.a + '|' + c.b;
      if (seen[k]) { return false; }
      seen[k] = 1;
      return true;
    });
    return { links: links, sig: round(sig, 4), cycles: cycles, maxLag: maxLag };
  }

  /* ------------------------------------------------------------------ *
   * 9: Barron et al. (2018) novelty / transience / resonance
   * ------------------------------------------------------------------ */

  function sfDistribution(data) {
    var sf = data.surfaceFrequencies;
    if (!sf || !sf.tokens) { return null; }
    var counts = Object.create(null), tot = 0;
    sf.tokens.forEach(function (t) { counts[t[0]] = t[1]; tot += t[1]; });
    return { counts: counts, tot: tot };
  }

  /** KL(p||q) in bits over the union vocabulary, Laplace alpha. */
  function klBits(p, q, vocab, alpha) {
    var V = vocab.length, s = 0;
    for (var i = 0; i < V; i++) {
      var w = vocab[i];
      var pw = ((p.counts[w] || 0) + alpha) / (p.tot + alpha * V);
      var qw = ((q.counts[w] || 0) + alpha) / (q.tot + alpha * V);
      s += pw * Math.log(pw / qw) / Math.LN2;
    }
    return s;
  }

  function noveltyTransience(windows, w, alpha) {
    w = w === undefined ? 2 : w;
    alpha = alpha === undefined ? 0.01 : alpha;
    var dists = windows.map(function (win) { return sfDistribution(win.data); });
    if (dists.some(function (d) { return d === null; })) { return null; }
    var vocabSet = Object.create(null);
    dists.forEach(function (d) {
      Object.keys(d.counts).forEach(function (k) { vocabSet[k] = 1; });
    });
    var vocab = Object.keys(vocabSet);
    var nW = windows.length;
    return {
      w: w, alpha: alpha, vocabSize: vocab.length,
      rows: windows.map(function (win, i) {
        var before = [], after = [];
        for (var d = 1; d <= w; d++) {
          if (i - d >= 0) { before.push(klBits(dists[i], dists[i - d], vocab, alpha)); }
          if (i + d < nW) { after.push(klBits(dists[i], dists[i + d], vocab, alpha)); }
        }
        var nov = before.length ? mean(before) : null;
        var tra = after.length ? mean(after) : null;
        return { name: win.name,
          novelty: nov === null ? null : round(nov, 4),
          transience: tra === null ? null : round(tra, 4),
          resonanceB: (nov !== null && tra !== null) ? round(nov - tra, 4) : null };
      })
    };
  }

  /* ------------------------------------------------------------------ *
   * Windowing helpers: per-article buckets + within-text segmentation
   * ------------------------------------------------------------------ */

  /**
   * D-V2-14 per-article bucket mode. files: [{name, data}] with dates in
   * names (YYYYMMDD... or YYYY...). Returns pseudo-window objects carrying
   * a MEAN-influence node list per bucket (documents weighted equally);
   * empty buckets per `emptyBucket`: 'skip' drops them from the sequence,
   * 'zero' keeps them with zero influence (reported — materially affects
   * early-sparse corpora).
   */
  function bucketize(files, opts) {
    opts = opts || {};
    var rule = opts.bucketRule || 'year';
    var emptyBucket = opts.emptyBucket || 'skip';
    var dated = [];
    files.forEach(function (f) {
      var m = String(f.name).match(/(\d{4})(\d{2})?/);
      if (!m) { return; }
      var y = +m[1], q = m[2] ? Math.floor((+m[2] - 1) / 3) + 1 : 1;
      dated.push({ f: f, key: rule === 'quarter' ? (m[1] + 'Q' + q) : m[1],
        sort: y * 10 + (rule === 'quarter' ? q : 0) });
    });
    if (!dated.length) { throw new Error('No file names carry a parseable date (YYYY… prefix).'); }
    var groups = Object.create(null), order = [];
    dated.sort(function (a, b) { return a.sort - b.sort || (a.key < b.key ? -1 : 1); });
    dated.forEach(function (d) {
      if (!groups[d.key]) { groups[d.key] = []; order.push(d.key); }
      groups[d.key].push(d.f);
    });
    // fill range for 'zero' handling
    if (emptyBucket === 'zero' && rule === 'year') {
      var years = order.map(function (k) { return +k; });
      var full = [];
      for (var y2 = Math.min.apply(null, years); y2 <= Math.max.apply(null, years); y2++) {
        full.push(String(y2));
      }
      order = full;
    }
    var windows = order.map(function (key) {
      var docs = groups[key] || [];
      // mean influence across the bucket's documents (docs weighted equally)
      var acc = Object.create(null), disp = Object.create(null);
      docs.forEach(function (f) {
        (f.data.network && f.data.network.nodes || []).forEach(function (n) {
          acc[n.word] = (acc[n.word] || 0) + n.influence;
          if (!(n.word in disp)) { disp[n.word] = n.display || n.word; }
        });
      });
      var nodes = Object.keys(acc).map(function (w, i) {
        return { id: i, word: w, display: disp[w],
          influence: docs.length ? acc[w] / docs.length : 0 };
      });
      return { name: key, nDocs: docs.length, empty: docs.length === 0,
        data: { network: { nodes: nodes, edges: [] } } };
    });
    if (emptyBucket === 'skip') {
      windows = windows.filter(function (w) { return !w.empty; });
    }
    return { windows: windows, rule: rule, emptyBucket: emptyBucket,
      emptyCount: windows.filter(function (w) { return w.empty; }).length };
  }

  /** Fixed word-count segmentation of one token array. */
  function fixedWindows(tokens, size) {
    var out = [];
    for (var i = 0; i < tokens.length; i += size) {
      out.push(tokens.slice(i, i + size));
    }
    if (out.length > 1 && out[out.length - 1].length < size / 2) {
      var last = out.pop();
      out[out.length - 1] = out[out.length - 1].concat(last);
    }
    return out;
  }

  /**
   * TextTiling (Hearst, 1997), minimal-faithful: pseudo-sentences of `w`
   * tokens, block comparison of `k` pseudo-sentences by cosine similarity,
   * depth scores, boundaries where depth > mean − sd/2 (Hearst's LC
   * criterion). Labeled a pre-2002 gap-fill per spec.
   */
  function textTiling(tokens, opts) {
    opts = opts || {};
    var w = opts.pseudoSentence || 20;
    var k = opts.blockSize || 10;
    var ps = [];
    for (var i = 0; i < tokens.length; i += w) {
      ps.push(tokens.slice(i, i + w));
    }
    if (ps.length < 2 * k + 1) { return { boundaries: [], gapScores: [] }; }
    function bag(seqs) {
      var b = Object.create(null);
      seqs.forEach(function (s) {
        s.forEach(function (t) { b[t] = (b[t] || 0) + 1; });
      });
      return b;
    }
    function cos(a, b) {
      var dot = 0, na = 0, nb = 0, kx;
      for (kx in a) { na += a[kx] * a[kx]; if (b[kx]) { dot += a[kx] * b[kx]; } }
      for (kx in b) { nb += b[kx] * b[kx]; }
      return na > 0 && nb > 0 ? dot / Math.sqrt(na * nb) : 0;
    }
    var gaps = [];
    for (i = 1; i < ps.length; i++) {
      var left = bag(ps.slice(Math.max(0, i - k), i));
      var right = bag(ps.slice(i, Math.min(ps.length, i + k)));
      gaps.push(cos(left, right));
    }
    // depth scores
    var depths = gaps.map(function (g, gi) {
      var l = g, r = g;
      for (var a = gi - 1; a >= 0 && gaps[a] >= l; a--) { l = gaps[a]; }
      for (var b2 = gi + 1; b2 < gaps.length && gaps[b2] >= r; b2++) { r = gaps[b2]; }
      return (l - g) + (r - g);
    });
    var mu = mean(depths);
    var sd = Math.sqrt(mean(depths.map(function (d) { return (d - mu) * (d - mu); })));
    var cut = mu - sd / 2; // Hearst's LC criterion: depth > mean − sd/2
    var boundaries = [];
    var lastPs = -3;
    depths.forEach(function (d, di) {
      if (d > cut && d > 0 && (di + 1) - lastPs >= 3) { // ≥2 pseudo-sentences apart
        boundaries.push((di + 1) * w); // token index of the boundary
        lastPs = di + 1;
      }
    });
    return { boundaries: boundaries, cutoff: round(cut, 4),
      gapScores: gaps.map(function (g) { return round(g, 4); }),
      depthScores: depths.map(function (d) { return round(d, 4); }),
      pseudoSentence: w, blockSize: k };
  }

  /** DCT low-pass smoothing (Jockers, 2015 arc form): keep `keep` comps. */
  function dctLowPass(x, keep) {
    var n = x.length;
    keep = Math.min(keep === undefined ? 5 : keep, n);
    var coef = [];
    for (var k = 0; k < n; k++) {
      var s = 0;
      for (var t = 0; t < n; t++) {
        s += x[t] * Math.cos(Math.PI * k * (2 * t + 1) / (2 * n));
      }
      coef.push(s * (k === 0 ? Math.sqrt(1 / n) : Math.sqrt(2 / n)));
    }
    var out = [];
    for (var t2 = 0; t2 < n; t2++) {
      var v = 0;
      for (k = 0; k < keep; k++) {
        v += coef[k] * (k === 0 ? Math.sqrt(1 / n) : Math.sqrt(2 / n)) *
          Math.cos(Math.PI * k * (2 * t2 + 1) / (2 * n));
      }
      out.push(round(v, 5));
    }
    return { smoothed: out, kept: keep };
  }

  /* ------------------------------------------------------------------ *
   * Engine
   * ------------------------------------------------------------------ */

  var CAUTION =
    'Methodological caution (Dooley & Corman, 2004, pp. 279–281): when the ' +
    'window size approaches the texts’ production timescale, observed ' +
    'dynamics mix production/institutional effects with environmental ones. ' +
    'Choose windows longer than the production cycle of the underlying texts, ' +
    'or read short-window dynamics as newsroom/authoring process as much as ' +
    'world process.';

  var BARRON_NOTE =
    'Naming note (D-V2-9): novelty/transience/resonance follow Barron, Huang, ' +
    'Spang, & DeDeo (2018); their “resonance” (novelty − transience) is ' +
    'UNRELATED to CRA resonance (WR′). The turnover profile above is the CRA ' +
    'term; this block is the Barron term.';

  /**
   * windows: [{name, data}] in temporal order (data = parsed craData).
   * opts: { evCut, loadCut, minWindowShare, topWords, peltPenaltyMult,
   *         kCoincide, ntrW, mode ('corpus'|'bucket'|'within-text'),
   *         windowNote (free text describing window construction) }
   * deps: { themes, resonance }
   */
  function runDynamics(windows, opts, deps) {
    opts = opts || {};
    if (windows.length < 6) {
      throw new Error('Dynamics needs at least 6 windows (have ' + windows.length + ').');
    }
    var nW = windows.length;
    var mat = influenceMatrix(windows, opts);
    if (mat.words.length < 4) {
      throw new Error('Too few words survive the ≥ half-of-windows admission rule (' +
        mat.words.length + ').');
    }
    var th = dynamicThemes(mat, opts, deps);
    var series = themeSeries(mat, th.themes);
    var maxLagDiag = Math.min(Math.max(2, Math.floor(nW / 3)), nW - 2);
    var penaltyMult = opts.peltPenaltyMult === undefined ? 1 : opts.peltPenaltyMult;

    var diagnostics = series.map(function (s, ti) {
      var lb = ljungBox(s, Math.min(3, nW - 2));
      var idm = identifyModel(s);
      var cp = pelt(s, penaltyMult);
      return {
        theme: ti,
        acf: acf(s, maxLagDiag).map(function (v) { return round(v, 4); }),
        pacf: pacf(s, maxLagDiag).map(function (v) { return round(v, 4); }),
        bartlett: round(2 / Math.sqrt(nW), 4),
        periodogram: periodogram(s),
        ljungBox: { h: Math.min(3, nW - 2), q: round(lb, 3),
          chi2crit05: { 1: 3.841, 2: 5.991, 3: 7.815 }[Math.min(3, nW - 2)],
          significant: lb > ({ 1: 3.841, 2: 5.991, 3: 7.815 }[Math.min(3, nW - 2)]) },
        model: idm,
        changePoints: cp.changePoints,
        changePointLabels: cp.changePoints.map(function (i) { return windows[i].name; }),
        peltBeta: round(cp.beta, 6)
      };
    });

    var transitions = stageTransitions(
      diagnostics.map(function (d) { return d.changePoints; }),
      opts.kCoincide, nW);
    transitions.forEach(function (tr) { tr.label = windows[tr.window].name; });

    var maxLagX = Math.max(1, Math.floor(nW / 4));
    var xc = laggedCrossCorrelations(series, maxLagX);

    // sequential WR' (CRA resonance) — needs window-level networks
    var seqWR = null;
    var hasNetworks = windows.every(function (w) {
      return w.data.network && w.data.network.edges && w.data.network.edges.length > 0;
    });
    if (deps.resonance && hasNetworks) {
      seqWR = [];
      for (var i = 1; i < nW; i++) {
        var wr = deps.resonance.wordResonance(windows[i - 1].data, windows[i].data);
        seqWR.push({ from: windows[i - 1].name, to: windows[i].name,
          wrp: round(wr.WRs, 4) });
      }
    }

    var ntr = noveltyTransience(windows, opts.ntrW, 0.01);

    return {
      parameters: {
        mode: opts.mode || 'corpus',
        windows: nW,
        windowNote: opts.windowNote || 'each loaded file = one window, in loaded order',
        minWindowShare: opts.minWindowShare === undefined ? 0.5 : opts.minWindowShare,
        topWords: mat.words.length,
        eligibleWords: mat.eligibleCount,
        evCut: th.evCut, loadCut: th.loadCut,
        peltPenalty: 'mult ' + penaltyMult + ' × 2σ² ln n (BIC default mult 1)',
        peltPenaltyMult: penaltyMult,
        kCoincide: opts.kCoincide === undefined ? 2 : opts.kCoincide,
        ntrW: opts.ntrW === undefined ? 2 : opts.ntrW
      },
      caution: CAUTION,
      barronNote: BARRON_NOTE,
      windowNames: windows.map(function (w) { return w.name; }),
      words: mat.words,
      display: mat.words.map(function (w) { return mat.display[w] || w; }),
      matrix: mat.M.map(function (r) { return r.map(function (v) { return round(v, 5); }); }),
      eigenvalues: th.eigenvalues.slice(0, 15),
      kRetain: th.kRetain,
      themes: th.themes,
      series: series.map(function (s) { return s.map(function (v) { return round(v, 5); }); }),
      diagnostics: diagnostics,
      stageTransitions: transitions,
      xcorr: xc,
      seqWR: seqWR,
      ntr: ntr
    };
  }

  /* ------------------------------------------------------------------ *
   * Report
   * ------------------------------------------------------------------ */

  function serializeReport(res, citationBlock) {
    var L = [];
    var par = res.parameters;
    L.push('# Crawdad Dynamics: ' + par.windows + ' windows (' + par.mode + ' mode)');
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- Method: windowed CRA per Dooley & Corman (2004), NDPLS 8(3).');
    L.push('- Windows: ' + par.windowNote + '.');
    L.push('- Word admission: present in ≥ ' + (par.minWindowShare * 100) +
      '% of windows; ' + par.eligibleWords + ' eligible, top ' + par.topWords +
      ' by summed influence admitted.');
    L.push('- Themes: PCA + Kaiser-normalized varimax; eigenvalue > ' + par.evCut +
      (par.evCut === 4 ? ' (the 2004 study’s conservative cut)' : '') +
      ', |loading| ≥ ' + par.loadCut + ', max-loading assignment → ' +
      res.kRetain + ' themes.');
    L.push('- Change points: PELT (Killick et al., 2012), penalty ' + par.peltPenalty + '.');
    L.push('- Stage transitions: ≥ ' + par.kCoincide +
      ' themes with change points within ±1 window (Daneke & Dooley 2007 rule).');
    L.push('');
    L.push('> ' + res.caution);
    L.push('');
    L.push('## Dynamic themes');
    L.push('');
    res.themes.forEach(function (t, ti) {
      L.push('- **T' + (ti + 1) + '** (' + t.length + ' words): ' +
        t.slice(0, 12).map(function (w) {
          return w.display + ' (' + w.loading + ')';
        }).join(', ') + (t.length > 12 ? ', …' : ''));
    });
    L.push('');
    L.push('## Theme series (mean influence of theme words per window)');
    L.push('');
    L.push('| Window | ' + res.themes.map(function (t, ti) { return 'T' + (ti + 1); })
      .join(' | ') + ' |');
    L.push('|---|' + res.themes.map(function () { return '---|'; }).join(''));
    res.windowNames.forEach(function (nm, i) {
      L.push('| ' + nm + ' | ' + res.series.map(function (s) { return s[i]; })
        .join(' | ') + ' |');
    });
    L.push('');
    L.push('## Series diagnostics');
    L.push('');
    L.push('| Theme | Model (AICc) | Reading | Ljung–Box Q | ACF(1..3) | PACF(1..3) | Change points |');
    L.push('|---|---|---|---|---|---|---|');
    res.diagnostics.forEach(function (d, ti) {
      L.push('| T' + (ti + 1) + ' | ' + d.model.best.model +
        (d.model.best.detail ? ' ' + d.model.best.detail : '') +
        ' | ' + d.model.reading +
        ' | ' + d.ljungBox.q + (d.ljungBox.significant ? ' *' : '') +
        ' | ' + d.acf.slice(0, 3).join(', ') +
        ' | ' + d.pacf.slice(0, 3).join(', ') +
        ' | ' + (d.changePointLabels.length ? d.changePointLabels.join(', ') : '—') + ' |');
    });
    L.push('');
    L.push('Bartlett band ±' + res.diagnostics[0].bartlett +
      '; * = Ljung–Box significant at .05. AICc candidates per theme are in the machine block.');
    L.push('');
    L.push('## Stage transitions (≥ ' + par.kCoincide + ' themes coinciding)');
    L.push('');
    if (res.stageTransitions.length) {
      res.stageTransitions.forEach(function (tr) {
        L.push('- **' + tr.label + '**: themes ' + tr.themes.map(function (t) {
          return 'T' + (t + 1);
        }).join(', '));
      });
    } else {
      L.push('None under the current penalty and k.');
    }
    L.push('');
    L.push('## Lagged cross-correlations (max lag ' + res.xcorr.maxLag +
      ', |r| ≥ ' + res.xcorr.sig + ')');
    L.push('');
    if (res.xcorr.links.length) {
      L.push('| From | To | Lag | r |');
      L.push('|---|---|---|---|');
      res.xcorr.links.forEach(function (l) {
        L.push('| T' + (l.from + 1) + ' | T' + (l.to + 1) + ' | ' + l.lag + ' | ' + l.r + ' |');
      });
      if (res.xcorr.cycles.length) {
        L.push('');
        L.push('**Cyclic paths** (the 2004 study reads cycles as a production-process ' +
          'signature): ' + res.xcorr.cycles.map(function (c) {
            return 'T' + (c.a + 1) + '⇄T' + (c.b + 1) +
              ' (lags ' + c.lagAB + '/' + c.lagBA + ')';
          }).join('; '));
      }
    } else {
      L.push('None reach the band.');
    }
    L.push('');
    L.push('## Sequential resonance WR′ (turnover profile — CRA term)');
    L.push('');
    if (res.seqWR) {
      L.push('| From | To | WR′ |');
      L.push('|---|---|---|');
      res.seqWR.forEach(function (s) {
        L.push('| ' + s.from + ' | ' + s.to + ' | ' + s.wrp + ' |');
      });
      L.push('');
      L.push('Low WR′ between adjacent windows = rapid content turnover.');
    } else {
      L.push('Not available in this mode (bucket windows carry no bucket-level network).');
    }
    L.push('');
    L.push('## Novelty / transience / resonance (Barron et al., 2018)');
    L.push('');
    if (res.ntr) {
      L.push('KL divergence (bits) over Laplace-smoothed (α = ' + res.ntr.alpha +
        ') unigram distributions from each window’s surface-frequency block ' +
        '(top 2,000 types per window), w = ' + res.ntr.w + '.');
      L.push('');
      L.push('| Window | Novelty | Transience | Resonance (B) |');
      L.push('|---|---|---|---|');
      res.ntr.rows.forEach(function (r) {
        L.push('| ' + r.name + ' | ' + (r.novelty === null ? '—' : r.novelty) +
          ' | ' + (r.transience === null ? '—' : r.transience) +
          ' | ' + (r.resonanceB === null ? '—' : r.resonanceB) + ' |');
      });
      L.push('');
      L.push(res.barronNote);
    } else {
      L.push('Not available: one or more windows lack the surface-frequency block ' +
        '(regenerate with 2.0.0-M1+), or mode is bucket (no bucket-level text).');
    }
    L.push('');
    if (res.arc) {
      L.push('## Within-text valence arc (windowed VADER + DCT low-pass)');
      L.push('');
      L.push('Windowed VADER mean compound per window, smoothed by DCT low-pass ' +
        'keeping ' + res.arc.kept + ' component(s) (Jockers, 2015; arc-shape ' +
        'context: Reagan et al., 2016). Window construction as above.');
      L.push('');
      L.push('| Window | VADER compound | Smoothed |');
      L.push('|---|---|---|');
      res.windowNames.forEach(function (nm, i) {
        L.push('| ' + nm + ' | ' + res.arc.raw[i] + ' | ' + res.arc.smoothed[i] + ' |');
      });
      L.push('');
    }
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-dynamics', schemaVersion: '1.0',
      parameters: res.parameters, windowNames: res.windowNames,
      words: res.words, display: res.display, matrix: res.matrix,
      eigenvalues: res.eigenvalues, kRetain: res.kRetain, themes: res.themes,
      series: res.series, diagnostics: res.diagnostics,
      stageTransitions: res.stageTransitions, xcorr: res.xcorr,
      seqWR: res.seqWR, ntr: res.ntr, arc: res.arc || null }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    String(citationBlock || '').split('\n\n').forEach(function (c) {
      if (c) { L.push('*' + c + '*'); L.push(''); }
    });
    return L.join('\n');
  }

  var api = {
    influenceMatrix: influenceMatrix,
    dynamicThemes: dynamicThemes,
    themeSeries: themeSeries,
    acf: acf, pacf: pacf, periodogram: periodogram, ljungBox: ljungBox,
    yuleWalker: yuleWalker, innovationsMA1: innovationsMA1,
    identifyModel: identifyModel,
    pelt: pelt, stageTransitions: stageTransitions,
    crossCorr: crossCorr, laggedCrossCorrelations: laggedCrossCorrelations,
    klBits: klBits, noveltyTransience: noveltyTransience,
    bucketize: bucketize, fixedWindows: fixedWindows, textTiling: textTiling,
    dctLowPass: dctLowPass,
    runDynamics: runDynamics, serializeReport: serializeReport,
    CAUTION: CAUTION, BARRON_NOTE: BARRON_NOTE
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadDynamics = api; }
})(typeof self !== 'undefined' ? self : this);
