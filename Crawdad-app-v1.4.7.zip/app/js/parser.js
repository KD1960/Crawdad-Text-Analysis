/*
 * Crawdad 2026 — M1 parser module (spec §3.1)
 * Sentence segmentation, POS tagging, and CRA noun-phrase extraction.
 *
 * Engine: wink-nlp + wink-eng-lite-web-model (chosen in the M1 benchmark:
 * F1 = 0.970 on the 20-sentence gold fixture; errors are modifier misses,
 * never head-noun losses — see tests/benchmark-parsers.js).
 *
 * Chunking rule (CRA; WF 2h.i "each unique noun and adjective becomes a
 * node"): center runs are maximal contiguous runs of {ADJ, NOUN, PROPN}.
 * Adjective-only runs (predicate adjectives: "the cat was OLD and WISE") ARE
 * centers per the workflow spec — fixed 2026-07-28 (D-14); previously they
 * were wrongly dropped. DET, PRON (default), NUM, VERB, ADV, etc. break runs
 * and are excluded.
 *
 * Browser: requires vendor/wink-bundle.js loaded first (window.CrawdadWink).
 * Node (tests): pass winkNLP + model to createParser().
 */
(function (root) {
  'use strict';

  function createParser(winkNLP, model, options) {
    var nlp = winkNLP(model);
    var its = nlp.its;
    var keepPronouns = !!(options && options.keepPronouns); // spec §3.1 toggle

    // D-14b dual-tagger verb arbitration: wink's known weakness is tagging
    // past-tense verbs ("chased") as nouns; compromise's known weakness is
    // the reverse (calling real nouns verbs), but NOT for -ed forms (M1
    // benchmark). So: when wink says NOUN/PROPN for a word ending in -ed,
    // ask compromise; if compromise says unambiguously Verb, treat as verb.
    // Scope deliberately narrow: -ed only (not -eed, not -ing: "swimming"
    // is a legitimate gerund center), length >= 5.
    var compromise = (options && options.compromise) ||
                     (typeof root.nlp === 'function' ? root.nlp : null);

    function makeTagChecks(sentText) {
      var map = null; // lazy: only built if a candidate appears
      function tagsFor(w) {
        if (!compromise) { return null; }
        if (map === null) {
          map = {};
          try {
            compromise(sentText).json().forEach(function (s) {
              (s.terms || []).forEach(function (t) {
                var key = (t.text || '').toLowerCase().replace(/[^a-z0-9'-]/g, '');
                if (!key) { return; }
                var set = map[key] = map[key] || {};
                (t.tags || []).forEach(function (g) { set[g] = true; });
              });
            });
          } catch (e) { map = {}; }
        }
        return map[w] || null;
      }
      return {
        // D-14b: wink NOUN, compromise unambiguous Verb -> verb
        saysVerb: function (w) {
          var tags = tagsFor(w);
          return !!(tags && tags.Verb && !tags.Noun);
        },
        // D-14c: wink VERB after a preposition (a position that takes
        // nominals), compromise unambiguous Noun -> noun center
        // ("structures of MEANING"; validation study V1 finding)
        saysNoun: function (w) {
          var tags = tagsFor(w);
          return !!(tags && tags.Noun && !tags.Verb);
        },
        saysAdj: function (w) {
          var tags = tagsFor(w);
          return !!(tags && tags.Adjective && !tags.Adverb && !tags.Verb);
        }
      };
    }

    function isNounPos(pos) { return pos === 'NOUN' || pos === 'PROPN'; }
    function isAdjPos(pos) { return pos === 'ADJ'; }
    function isPronoun(pos) { return pos === 'PRON'; }

    /**
     * Parse text into sentences of CRA noun phrases.
     * Returns { sentences: [ { text, phrases: [ [word, ...], ... ] } ] }
     * Words are lowercased surface forms; stemming happens downstream (§3.5).
     */
    function parse(text, perCall) {
      // perCall.exclude: {word: true} — excluded words BREAK center runs
      // exactly as a verb would (D-14 escape hatch for tagger errors), so the
      // surrounding noun phrases keep their true structure
      var excl = (perCall && perCall.exclude) || null;
      var doc = nlp.readDoc(text);
      var sentences = [];
      doc.sentences().each(function (sent) {
        var phrases = [];
        var tokens = []; // full token/POS stream (for text-level metrics, D-12)
        var cur = [];
        var checks = makeTagChecks(sent.out());
        var prevPos = null;
        function flush() {
          if (cur.length) { phrases.push(cur); } // ADJ-only runs kept (WF 2h.i, D-14)
          cur = [];
        }
        // Collect the raw token stream first so underscore compounds created
        // by tokenization substitutions (spec §4.2) can be re-joined: wink
        // tokenizes "supply_chain" as supply / _ / chain, which silently
        // undid the user's substitution (fix 2026-08-09). Joined compounds
        // are treated as NOUN centers and are exempt from the D-14 dual-
        // tagger checks (they are user-defined tokens, not tagger output).
        var raw = [];
        sent.tokens().each(function (t) {
          raw.push({ text: t.out(), pos: t.out(its.pos) });
        });
        var merged = [];
        for (var ri = 0; ri < raw.length; ri++) {
          var tk = raw[ri];
          if (tk.text === '_' && merged.length &&
              /[a-z0-9]$/i.test(merged[merged.length - 1].text) &&
              ri + 1 < raw.length && /^[a-z0-9]/i.test(raw[ri + 1].text)) {
            merged[merged.length - 1] = {
              text: merged[merged.length - 1].text + '_' + raw[ri + 1].text,
              pos: 'NOUN', compound: true
            };
            ri++; // consume the following word token as well
            continue;
          }
          merged.push(tk);
        }
        merged.forEach(function (t) {
          var pos = t.pos;
          var w = t.text.toLowerCase();
          // keep letters/digits/internal hyphens, apostrophes & underscores only
          w = w.replace(/[^a-z0-9'_-]/g, '');
          // punctuation-only residue (bare "_", "-", "'") is not a word
          if (!/[a-z0-9]/.test(w)) { w = ''; }
          // a token still carrying an underscore is a user-defined compound
          if (w.indexOf('_') !== -1) { pos = 'NOUN'; }
          if (w && pos !== 'PUNCT' && pos !== 'SYM') { tokens.push({ w: w, pos: pos }); }
          // drop single-character tokens (citation initials "j", "r", etc.)
          if (!w || w.length < 2) { flush(); prevPos = pos; return; }
          if (excl && excl[w]) { flush(); prevPos = pos; return; }
          // D-14b: second-opinion check for -ed words wink tagged as nouns
          if (!t.compound && (pos === 'NOUN' || pos === 'PROPN') && w.length >= 5 &&
              /[a-z]ed$/.test(w) && !/eed$/.test(w) && checks.saysVerb(w)) {
            flush(); prevPos = pos; return; // arbitrated as verb: no node
          }
          // D-14c: wink VERB right after a preposition — that position takes
          // nominals; if compromise says unambiguous Noun, rescue as center
          if (pos === 'VERB' && prevPos === 'ADP' && checks.saysNoun(w)) {
            pos = 'NOUN';
          }
          // D-14d: sentence-initial "Prior studies…" pattern — wink tags
          // ADV then VERB; if compromise reads Adjective/Noun unambiguously,
          // rescue (validation study V1: A6, F7)
          if (pos === 'ADV' && prevPos === null && checks.saysAdj(w)) {
            pos = 'ADJ';
          } else if (pos === 'VERB' && prevPos === 'ADJ→' && checks.saysNoun(w)) {
            pos = 'NOUN';
          }
          prevPos = (pos === 'ADJ' && prevPos === null) ? 'ADJ→' : pos;
          if (isNounPos(pos) || isAdjPos(pos) || (keepPronouns && isPronoun(pos))) {
            cur.push(w);
          } else {
            flush();
          }
        });
        flush();
        sentences.push({ text: sent.out(), phrases: phrases, tokens: tokens });
      });
      return { sentences: sentences };
    }

    /** Debug helper: token/POS listing for a sentence (M1 acceptance review). */
    function tagView(text) {
      var doc = nlp.readDoc(text);
      var out = [];
      doc.tokens().each(function (t) {
        out.push({ token: t.out(), pos: t.out(its.pos) });
      });
      return out;
    }

    return { parse: parse, tagView: tagView, engine: 'wink-nlp' };
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { createParser: createParser };   // Node (tests)
  } else {
    if (!root.CrawdadWink) {
      throw new Error('vendor/wink-bundle.js must be loaded before js/parser.js');
    }
    root.CrawdadParser = {
      createParser: function (options) {
        return createParser(root.CrawdadWink.winkNLP, root.CrawdadWink.model, options);
      }
    };
  }
})(typeof self !== 'undefined' ? self : this);
