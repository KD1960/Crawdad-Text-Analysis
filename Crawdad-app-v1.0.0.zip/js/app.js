/*
 * Crawdad 2026 — application shell (M0, spec §5)
 * Screen routing, file selection, _cra.md validation, module menu gating.
 * Analysis modules themselves arrive in M3–M7.
 */
(function () {
  'use strict';

  var S = window.CrawdadSchema;
  var IO = window.CrawdadFileIO;

  /* ---------------- Session state ---------------- */
  var state = {
    genFiles: [],        // { file, status, text, converted, warnings }  (.txt/.md/.pdf/.docx)
    tokFile: null,       // tokenization spreadsheet
    craFiles: []         // { name, text, ok, data, errors }
  };

  /* ---------------- Module registry (spec §5.3) ---------------- */
  var MODULES = [
    { id: 'visualizer',  name: 'Visualizer',            min: 1, max: Infinity,
      desc: 'Draw the CRA network of a text.',          milestone: 'M3' },
    { id: 'comparator',  name: 'Comparator',            min: 2, max: Infinity,
      desc: 'Measure resonance between two texts (pick A and B).', milestone: 'M4' },
    { id: 'classifier',  name: 'Classifier',            min: 5, max: Infinity,
      desc: 'Cluster texts by mutual resonance.',       milestone: 'M5' },
    { id: 'themes',      name: 'Theme Identifier',      min: 5, max: Infinity,
      desc: 'Find manifest themes across texts (PCA).', milestone: 'M6' },
    { id: 'latent',      name: 'Latent Theme Identifier', min: 1, max: Infinity,
      desc: 'Score texts against your own theme dictionary.', milestone: 'M6' },
    { id: 'summarizer',  name: 'Summarizer',            min: 2, max: Infinity,
      desc: 'Rank the most influential words across texts.', milestone: 'M7' }
  ];

  /* ---------------- Screen routing ---------------- */
  var screens = ['landing', 'generate', 'analyze', 'visualize', 'compare', 'classify',
                 'themes', 'latent', 'summarize'];
  function show(name) {
    screens.forEach(function (s) {
      document.getElementById('screen-' + s).hidden = (s !== name);
    });
    document.getElementById('btn-home').hidden = (name === 'landing');
  }

  document.getElementById('choose-generate').addEventListener('click', function () { show('generate'); });
  document.getElementById('choose-analyze').addEventListener('click', function () { show('analyze'); });
  document.getElementById('btn-home').addEventListener('click', function () { show('landing'); });

  /* ---------------- Generate screen ---------------- */
  IO.wireFilePicker({
    zoneEl: document.getElementById('gen-drop'),
    inputEl: document.getElementById('gen-input'),
    accept: IO.isTextSource,
    onFiles: function (files) {
      files.forEach(function (f) {
        var dup = state.genFiles.some(function (g) { return g.file.name === f.name; });
        if (dup) { return; }
        var entry = { file: f, status: 'extracting…', text: null, converted: false, warnings: [] };
        state.genFiles.push(entry);
        window.CrawdadExtract.extractText(f).then(function (r) {
          entry.text = r.text;
          entry.converted = r.converted;
          entry.warnings = r.warnings;
          var chars = r.text.replace(/\s+/g, ' ').trim().length;
          entry.status = (r.converted ? 'converted, ' : 'ready, ') +
            chars.toLocaleString() + ' chars' +
            (r.warnings.length ? ' — ' + r.warnings.join(' ') : '');
          entry.bad = chars === 0 || r.warnings.length > 0;
          renderGenList();
        }).catch(function (err) {
          entry.status = 'error: ' + err.message;
          entry.bad = true;
          renderGenList();
        });
      });
      renderGenList();
    },
    onRejected: function (names) {
      alert('Not accepted (need .txt, .md, .pdf, or .docx source text, not a _cra.md file):\n' + names.join('\n'));
    }
  });

  function renderGenList() {
    var wrap = document.getElementById('gen-filelist-wrap');
    var tbody = document.querySelector('#gen-filelist tbody');
    tbody.innerHTML = '';
    state.genFiles.forEach(function (g, i) {
      var tr = document.createElement('tr');
      var kb = (g.file.size / 1024).toFixed(1) + ' KB';
      tr.innerHTML = '<td>' + esc(g.file.name) + '</td><td>' + kb + '</td>' +
        '<td class="' + (g.bad ? 'bad' : (g.text !== null ? 'ok' : '')) + '">' + esc(g.status) + '</td>';
      var td = document.createElement('td');
      if (g.converted && g.text) {
        var dl = document.createElement('button');
        dl.className = 'linklike'; dl.textContent = 'download .md';
        dl.title = 'Download the extracted text as a Markdown file';
        dl.addEventListener('click', function () {
          var base = g.file.name.replace(/\.(pdf|docx)$/i, '');
          IO.downloadFile(base + '.md', g.text);
        });
        td.appendChild(dl);
      }
      var rm = document.createElement('button');
      rm.className = 'linklike'; rm.textContent = 'remove';
      rm.addEventListener('click', function () {
        state.genFiles.splice(i, 1); renderGenList();
      });
      td.appendChild(rm); tr.appendChild(td);
      tbody.appendChild(tr);
    });
    wrap.hidden = state.genFiles.length === 0;
    updateRunButton();
  }

  function readyFiles() {
    return state.genFiles.filter(function (g) { return g.text && !g.bad; });
  }

  function updateRunButton() {
    var n = readyFiles().length;
    var btn = document.getElementById('gen-run');
    btn.disabled = n === 0;
    document.getElementById('gen-run-hint').textContent =
      n === 0 ? 'Add at least one readable file to enable.'
              : n + ' file' + (n === 1 ? '' : 's') + ' ready.';
  }

  /* ---------------- Generator run (M2) ---------------- */
  var parserInstance = null;

  document.getElementById('gen-run').addEventListener('click', function () {
    var btn = this;
    btn.disabled = true;
    btn.textContent = 'Processing…';

    var opts = {
      stemming: document.getElementById('set-stemming').value,
      keepPronouns: document.getElementById('set-pronouns').checked,
      interSentenceLinking: document.getElementById('set-intersentence').checked,
      tokPairs: state.tokPairs || null,
      tokFileName: state.tokFile ? state.tokFile.name : null
    };

    // Rebuild parser if pronoun setting changed
    if (!parserInstance || parserInstance._keepPronouns !== opts.keepPronouns) {
      parserInstance = window.CrawdadParser.createParser({ keepPronouns: opts.keepPronouns });
      parserInstance._keepPronouns = opts.keepPronouns;
    }

    var deps = {
      parser: parserInstance,
      porter2: window.CrawdadWink.porter2,
      isStopWord: window.CrawdadStopWords.isStopWord,
      schema: window.CrawdadSchema,
      network: window.CrawdadNetwork,
      textclean: window.CrawdadTextClean
    };

    var tbody = document.querySelector('#gen-results tbody');
    tbody.innerHTML = '';
    var logs = [];
    var files = readyFiles();
    state.genResults = []; // { outName, craMd } for bulk actions
    document.getElementById('gen-selall').checked = true;

    // Process sequentially with UI breathing room (no Workers on file://)
    var i = 0;
    function next() {
      if (i >= files.length) {
        document.getElementById('gen-results-wrap').hidden = false;
        document.getElementById('gen-log').textContent = logs.join(' | ');
        btn.disabled = false;
        btn.textContent = 'Run Generator';
        return;
      }
      var g = files[i++];
      var tr = document.createElement('tr');
      try {
        var res = window.CrawdadGenerator.generate(g.file.name, g.text, opts, deps);
        var outName = window.CrawdadGenerator.craFileName(g.file.name);
        state.generated = state.generated || {};
        state.generated[outName] = res.craMd;
        state.sourceTexts = state.sourceTexts || {};
        state.sourceTexts[outName] = g.text; // enables WF 6e cluster aggregation
        state.genResults.push({ outName: outName, craMd: res.craMd });
        logs.push(g.file.name + ': ' + res.log.join('; '));
        var top = res.craData.network.nodes.slice()
          .sort(function (a, b) { return b.influence - a.influence; })
          .slice(0, 5)
          .map(function (n) { return n.display + ' (' + n.influence.toFixed(3) + ')'; })
          .join(', ');
        tr.innerHTML = '<td><input type="checkbox" class="gen-sel" checked data-name="' +
          esc(outName) + '"></td>' +
          '<td>' + esc(outName) + '</td>' +
          '<td>' + res.craData.network.nodes.length + '</td>' +
          '<td>' + res.craData.network.edges.length + '</td>' +
          '<td>' + esc(top) + '</td>';
        var td = document.createElement('td');
        var dl = document.createElement('button');
        dl.className = 'linklike'; dl.textContent = 'download';
        dl.addEventListener('click', function () { IO.downloadFile(outName, res.craMd); });
        var an = document.createElement('button');
        an.className = 'linklike'; an.textContent = 'send to Analyze';
        an.addEventListener('click', function () {
          sendToAnalyze([{ outName: outName, craMd: res.craMd }]);
          show('analyze');
        });
        td.appendChild(dl); td.appendChild(an); tr.appendChild(td);
      } catch (err) {
        tr.innerHTML = '<td></td><td>' + esc(g.file.name) + '</td>' +
          '<td colspan="4" class="bad">' + esc(err.message) + '</td>';
      }
      tbody.appendChild(tr);
      document.getElementById('gen-results-wrap').hidden = false;
      setTimeout(next, 30); // yield to UI between files
    }
    next();
  });

  document.getElementById('gen-tok-input').addEventListener('change', function (e) {
    var f = e.target.files[0];
    if (!f) { return; }
    if (!IO.isSpreadsheet(f.name)) {
      alert('Tokenization file must be .xlsx or .csv'); e.target.value = ''; return;
    }
    state.tokFile = f;
    var label = document.getElementById('gen-tok-name');
    if (/\.csv$/i.test(f.name)) {
      IO.readFileAsText(f).then(function (t) {
        state.tokPairs = window.CrawdadTextClean.parseCsvPairs(t);
        label.textContent = ' Loaded: ' + f.name + ' (' + state.tokPairs.length + ' substitutions)';
      });
    } else {
      var r = new FileReader();
      r.onload = function () {
        try {
          state.tokPairs = window.CrawdadTextClean.parseXlsxPairs(r.result);
          label.textContent = ' Loaded: ' + f.name + ' (' + state.tokPairs.length + ' substitutions)';
        } catch (err) {
          alert('Could not read spreadsheet: ' + err.message);
          state.tokFile = null; state.tokPairs = null;
        }
      };
      r.readAsArrayBuffer(f);
    }
  });

  /* ---------------- Analyze screen ---------------- */
  IO.wireFilePicker({
    zoneEl: document.getElementById('ana-drop'),
    inputEl: document.getElementById('ana-input'),
    accept: IO.isCraFile,
    onFiles: function (files) {
      files.forEach(function (f) {
        IO.readFileAsText(f).then(function (text) {
          var res = S.parseCra(text);
          // replace if same name reloaded
          state.craFiles = state.craFiles.filter(function (c) { return c.name !== f.name; });
          state.craFiles.push({
            name: f.name, text: text, ok: res.ok, data: res.data, errors: res.errors
          });
          renderAnaList();
        }).catch(function (err) {
          alert(err.message);
        });
      });
    },
    onRejected: function (names) {
      alert('Not accepted (need files ending in _cra.md):\n' + names.join('\n'));
    }
  });

  function renderAnaList() {
    var wrap = document.getElementById('ana-filelist-wrap');
    var tbody = document.querySelector('#ana-filelist tbody');
    tbody.innerHTML = '';
    state.craFiles.forEach(function (c, i) {
      var tr = document.createElement('tr');
      var status = c.ok
        ? '<td class="ok">valid</td>'
        : '<td class="bad">invalid</td>';
      var nodes = c.ok ? c.data.network.nodes.length : '—';
      var edges = c.ok ? c.data.network.edges.length : '—';
      tr.innerHTML = '<td>' + esc(c.name) +
        (c.ok ? '' : '<div class="errdetail">' + esc(c.errors.slice(0, 4).join('\n')) + '</div>') +
        '</td>' + status + '<td>' + nodes + '</td><td>' + edges + '</td>';
      var td = document.createElement('td');
      var rm = document.createElement('button');
      rm.className = 'linklike'; rm.textContent = 'remove';
      rm.addEventListener('click', function () {
        state.craFiles.splice(i, 1); renderAnaList();
      });
      td.appendChild(rm); tr.appendChild(td);
      tbody.appendChild(tr);
    });
    wrap.hidden = state.craFiles.length === 0;
    renderModuleMenu();
  }

  function renderModuleMenu() {
    var grid = document.getElementById('module-menu');
    var n = state.craFiles.filter(function (c) { return c.ok; }).length;
    grid.innerHTML = '';
    MODULES.forEach(function (m) {
      var eligible = n >= m.min && n <= m.max;
      var card = document.createElement('div');
      card.className = 'module-card' + (eligible ? '' : ' disabled');
      var req = m.max === m.min ? ('exactly ' + m.min) :
        (m.max === Infinity ? (m.min + ' or more') : (m.min + '–' + m.max));
      card.innerHTML =
        '<h4>' + m.name + '</h4>' +
        '<p>' + m.desc + '</p>' +
        '<span class="req">Requires ' + req + ' valid file' + (m.min === 1 && m.max === Infinity ? '(s)' : 's') +
        ' · have ' + n + '</span>';
      var btn = document.createElement('button');
      var openers = { visualizer: openVisualizer, comparator: openComparator,
                      classifier: openClassifier, themes: openThemes, latent: openLatent,
                      summarizer: openSummarizer };
      var live = openers.hasOwnProperty(m.id); // modules go live as milestones ship
      if (live) {
        btn.disabled = !eligible;
        btn.textContent = 'Run';
        btn.title = eligible ? '' : ('Needs ' + req + ' valid _cra.md file(s).');
        btn.addEventListener('click', openers[m.id]);
      } else {
        btn.disabled = true;
        btn.textContent = eligible ? ('Run (arrives in ' + m.milestone + ')') : 'Run';
        btn.title = eligible
          ? (m.name + ' is delivered in milestone ' + m.milestone + '.')
          : ('Needs ' + req + ' valid _cra.md file(s).');
      }
      card.appendChild(btn);
      grid.appendChild(card);
    });
    document.getElementById('ana-count-hint').textContent =
      n === 0
        ? 'Load valid files to enable analyses. Analysis modules are delivered in milestones M3–M7; this screen enforces each module’s file-count requirements.'
        : n + ' valid file' + (n === 1 ? '' : 's') + ' loaded. Module buttons activate as each module ships (M3–M7).';
  }

  /* ---------------- Generator bulk actions ---------------- */

  function sendToAnalyze(items) {
    items.forEach(function (it) {
      state.craFiles = state.craFiles.filter(function (c) { return c.name !== it.outName; });
      var parsedBack = S.parseCra(it.craMd);
      state.craFiles.push({ name: it.outName, text: it.craMd, ok: parsedBack.ok,
        data: parsedBack.data, errors: parsedBack.errors });
    });
    renderAnaList();
  }

  function selectedGenResults() {
    var picked = {};
    document.querySelectorAll('#gen-results .gen-sel:checked').forEach(function (cb) {
      picked[cb.getAttribute('data-name')] = true;
    });
    return (state.genResults || []).filter(function (r) { return picked[r.outName]; });
  }

  document.getElementById('gen-selall').addEventListener('change', function () {
    var on = this.checked;
    document.querySelectorAll('#gen-results .gen-sel').forEach(function (cb) { cb.checked = on; });
  });

  document.getElementById('gen-send-selected').addEventListener('click', function () {
    var items = selectedGenResults();
    if (!items.length) { alert('No files selected.'); return; }
    sendToAnalyze(items);
    show('analyze');
  });

  document.getElementById('gen-download-selected').addEventListener('click', function () {
    var items = selectedGenResults();
    if (!items.length) { alert('No files selected.'); return; }
    // stagger downloads so the browser doesn't swallow them
    items.forEach(function (it, i) {
      setTimeout(function () { IO.downloadFile(it.outName, it.craMd); }, i * 350);
    });
  });

  /* ---------------- Visualizer screen (M3) ---------------- */
  var vizHandle = null;

  function openVisualizer() {
    var sel = document.getElementById('viz-file');
    sel.innerHTML = '';
    state.craFiles.filter(function (c) { return c.ok; }).forEach(function (c) {
      var o = document.createElement('option');
      o.value = c.name; o.textContent = c.name;
      sel.appendChild(o);
    });
    document.getElementById('viz-canvas').innerHTML = '';
    document.getElementById('viz-download').disabled = true;
    vizHandle = null;
    show('visualize');
  }

  function drawViz() {
    var name = document.getElementById('viz-file').value;
    var entry = state.craFiles.filter(function (c) { return c.name === name && c.ok; })[0];
    if (!entry) { alert('Select a valid file.'); return; }
    var topK = parseInt(document.getElementById('viz-topk').value, 10) || 30;
    var highlight = parseFloat(document.getElementById('viz-highlight').value);
    if (isNaN(highlight)) { highlight = 0.05; }
    try {
      vizHandle = window.CrawdadVisualizer.render(
        document.getElementById('viz-canvas'), entry.data,
        { topK: topK, highlight: highlight });
      document.getElementById('viz-download').disabled = false;
    } catch (err) {
      alert('Could not draw: ' + err.message);
    }
  }

  document.getElementById('viz-render').addEventListener('click', drawViz);
  document.getElementById('viz-file').addEventListener('change', drawViz);
  document.getElementById('viz-back').addEventListener('click', function () { show('analyze'); });
  document.getElementById('viz-download').addEventListener('click', function () {
    if (!vizHandle) { return; }
    var name = document.getElementById('viz-file').value.replace(/_cra\.md$/i, '');
    vizHandle.exportPng(function (err, blob) {
      if (err) { alert(err.message); return; }
      IO.downloadFile('crawdad-network-' + name + '.png', blob, 'image/png');
    });
  });

  /* ---------------- Comparator screen (M4) ---------------- */
  var cmpReport = null;

  function openComparator() {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    ['cmp-a', 'cmp-b'].forEach(function (id, which) {
      var sel = document.getElementById(id);
      sel.innerHTML = '';
      valid.forEach(function (c, i) {
        var o = document.createElement('option');
        o.value = c.name; o.textContent = c.name;
        if (i === which) { o.selected = true; }
        sel.appendChild(o);
      });
    });
    document.getElementById('cmp-results').innerHTML = '';
    document.getElementById('cmp-download').disabled = true;
    cmpReport = null;
    show('compare');
  }

  document.getElementById('cmp-run').addEventListener('click', function () {
    var nameA = document.getElementById('cmp-a').value;
    var nameB = document.getElementById('cmp-b').value;
    if (nameA === nameB) { alert('Choose two different files.'); return; }
    var A = state.craFiles.filter(function (c) { return c.name === nameA && c.ok; })[0];
    var B = state.craFiles.filter(function (c) { return c.name === nameB && c.ok; })[0];
    if (!A || !B) { alert('Both files must be valid.'); return; }

    var rep = window.CrawdadResonance.buildReport(A.data, B.data, S.CITATION);
    cmpReport = { name: 'comparison_' + nameA.replace(/_cra\.md$/i, '') + '_vs_' +
      nameB.replace(/_cra\.md$/i, '') + '.md', markdown: rep.markdown };

    var c = rep.result;
    var html = '<h3>Resonance</h3><table><thead><tr><th>Measure</th><th>Value</th></tr></thead><tbody>' +
      '<tr><td>Word resonance WR (Eq. 2)</td><td>' + c.WR.toExponential(4) + '</td></tr>' +
      "<tr><td>Word resonance WR&prime; (Eq. 3, 0&ndash;1)</td><td><strong>" + c.WRs.toFixed(5) + '</strong></td></tr>' +
      '<tr><td>Pair resonance PR (Eq. 5)</td><td>' + c.PR.toExponential(4) + '</td></tr>' +
      "<tr><td>Pair resonance PR&prime; (Eq. 6, 0&ndash;1)</td><td><strong>" + c.PRs.toFixed(5) + '</strong></td></tr>' +
      '</tbody></table>';

    function wordTable(title, rows, cols) {
      var h = '<h3>' + esc(title) + '</h3><table><thead><tr>' +
        cols.map(function (x) { return '<th>' + x + '</th>'; }).join('') +
        '</tr></thead><tbody>';
      if (!rows.length) { h += '<tr><td colspan="' + cols.length + '">(none)</td></tr>'; }
      rows.forEach(function (r) {
        h += '<tr><td>' + esc(r.display) + '</td>' +
          (r.iA !== undefined
            ? '<td>' + r.iA.toFixed(5) + '</td><td>' + r.iB.toFixed(5) + '</td>'
            : '<td>' + r.i.toFixed(5) + '</td>') + '</tr>';
      });
      return h + '</tbody></table>';
    }
    html += wordTable('Common words (ranked by min(I_A, I_B))', c.common,
      ['Word', 'Influence in A', 'Influence in B']);
    html += wordTable('Unique to ' + c.fileA, c.uniqueA, ['Word', 'Influence']);
    html += wordTable('Unique to ' + c.fileB, c.uniqueB, ['Word', 'Influence']);
    document.getElementById('cmp-results').innerHTML = html;
    document.getElementById('cmp-download').disabled = false;
  });

  document.getElementById('cmp-download').addEventListener('click', function () {
    if (cmpReport) { IO.downloadFile(cmpReport.name, cmpReport.markdown); }
  });
  document.getElementById('cmp-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Classifier screen (M5) ---------------- */
  var clsReport = null;
  var clsCtx = null; // cached run: { names, mats, cls, mds } — enables instant K switching

  function openClassifier() {
    document.getElementById('cls-results').innerHTML = '';
    document.getElementById('cls-mdsplot').innerHTML = '';
    document.getElementById('cls-aggregate').innerHTML = '';
    document.getElementById('cls-download').disabled = true;
    clsReport = null;
    clsCtx = null;
    show('classify');
  }

  document.getElementById('cls-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (valid.length < 5) { alert('Classifier needs 5 or more valid files.'); return; }
    var names = valid.map(function (c) { return c.name; });
    var datas = valid.map(function (c) { return c.data; });
    var C = window.CrawdadClassifier, R = window.CrawdadResonance;

    var mats = C.resonanceMatrices(datas, R);
    var kSel = document.getElementById('cls-k').value;
    var cls = C.classify(mats.wrs, undefined,
      kSel === 'auto' ? {} : { forceK: parseInt(kSel, 10) });

    var mds = null;
    if (document.getElementById('cls-mds').checked) {
      var D = mats.wrs.map(function (row) { return row.map(function (v) { return 1 - v; }); });
      mds = C.classicalMDS(D);
    }

    clsCtx = { names: names, mats: mats, cls: cls, mds: mds };
    renderClassification(cls.best, cls.rule);
  });

  // Live K switching: solutions for every K are already computed, so changing
  // K after a run re-renders instantly from cache (no recomputation).
  document.getElementById('cls-k').addEventListener('change', function () {
    if (!clsCtx) { return; } // nothing run yet
    var v = this.value;
    var cls = clsCtx.cls;
    if (v === 'auto') {
      // restore the rule-selected solution from the original (auto) run
      var auto = window.CrawdadClassifier.classify(clsCtx.mats.wrs);
      clsCtx.cls = auto;
      renderClassification(auto.best, auto.rule);
      return;
    }
    var k = parseInt(v, 10);
    var t = cls.tried.filter(function (x) { return x.k === k; })[0];
    if (!t) { alert('K = ' + k + ' not available (max is ' +
      cls.tried[cls.tried.length - 1].k + ' for this file count).'); return; }
    renderClassification(t, 'K = ' + k + ' selected manually by user (viewing alternative solution).');
  });

  function renderClassification(best, rule) {
    var names = clsCtx.names, mats = clsCtx.mats, cls = clsCtx.cls, mds = clsCtx.mds;
    var C = window.CrawdadClassifier;

    // report reflects the currently viewed solution
    clsReport = {
      name: 'classification_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: C.buildReport(names, mats, { tried: cls.tried, best: best, rule: rule }, mds, S.CITATION)
    };
    document.getElementById('cls-download').disabled = false;

    // ---- results HTML ----
    var html = '<h3>Cluster membership (K = ' + best.k +
      ', mean silhouette ' + best.silhouette.toFixed(3) +
      ', sizes ' + best.sizes.join('/') + ')</h3>' +
      '<p class="hint">' + esc(rule) +
      ' — change K in the selector above to view alternative solutions instantly.</p>' +
      (best.hasSingleton
        ? '<p class="hint" style="color:#b03a2e">Note: this solution contains a singleton ' +
          'cluster — one text stands alone. Check whether it is a true outlier.</p>' : '') +
      '<table><thead><tr><th>Text</th><th>Cluster</th></tr></thead><tbody>' +
      names.map(function (nm, i) {
        return '<tr><td>' + esc(nm) + '</td><td>' + (best.labels[i] + 1) + '</td></tr>';
      }).join('') + '</tbody></table>';
    html += '<h3>Silhouette by K</h3><table><thead><tr><th>K</th><th>Mean silhouette</th>' +
      '<th>Cluster sizes</th><th>Singleton?</th><th></th></tr></thead><tbody>' +
      cls.tried.map(function (t) {
        return '<tr><td>' + t.k + (t.k === best.k ? ' <strong>(viewing)</strong>' : '') +
          '</td><td>' + t.silhouette.toFixed(4) + '</td><td>' + t.sizes.join(', ') +
          '</td><td>' + (t.hasSingleton ? 'yes' : 'no') + '</td><td>' +
          (t.k === best.k ? '' :
            '<button class="linklike cls-view" data-k="' + t.k + '">view</button>') +
          '</td></tr>';
      }).join('') + '</tbody></table>';
    html += "<h3>Word resonance matrix (WR&prime;)</h3>" + C.matrixHtml(names.map(esc), mats.wrs, "WR'");
    document.getElementById('cls-results').innerHTML = html;

    // per-row "view" links switch solutions too
    document.querySelectorAll('#cls-results .cls-view').forEach(function (b) {
      b.addEventListener('click', function () {
        var k = parseInt(this.getAttribute('data-k'), 10);
        document.getElementById('cls-k').value = String(k);
        var t = cls.tried.filter(function (x) { return x.k === k; })[0];
        renderClassification(t, 'K = ' + k + ' selected manually by user (viewing alternative solution).');
      });
    });

    // ---- MDS plot (positions fixed; only colors change with K) ----
    if (mds) { drawMdsPlot(names, mds.points, best.labels); }
    else { document.getElementById('cls-mdsplot').innerHTML = ''; }

    // ---- WF 6e post-analysis options (rebuilt for the viewed K) ----
    var agg = document.getElementById('cls-aggregate');
    agg.innerHTML = '<h3>Cluster aggregation (optional)</h3>';
    for (var k = 0; k < best.k; k++) {
      (function (k) {
        var members = names.filter(function (_, i) { return best.labels[i] === k; });
        var haveSources = members.every(function (nm) {
          return state.sourceTexts && state.sourceTexts[nm];
        });
        var div = document.createElement('div');
        div.style.margin = '6px 0';
        var btn = document.createElement('button');
        btn.className = 'linklike';
        btn.textContent = 'Aggregate cluster ' + (k + 1) + ' (' + members.length +
          ' texts) → generate cluster' + (k + 1) + '_cra.md';
        btn.disabled = !haveSources;
        btn.title = haveSources ? ''
          : 'Available only when the source texts were generated in this session ' +
            '(loading _cra.md files alone does not include the original text).';
        btn.addEventListener('click', function () { aggregateCluster(k, members); });
        div.appendChild(btn);
        if (!haveSources) {
          var sp = document.createElement('span');
          sp.className = 'hint';
          sp.textContent = ' (needs in-session source texts)';
          div.appendChild(sp);
        }
        agg.appendChild(div);
      })(k);
    }
  }

  function aggregateCluster(k, members) {
    // (a) aggregate texts, (b) re-run Generator, (c) new _cra.md, (d) offer Visualizer
    var text = members.map(function (nm) { return state.sourceTexts[nm]; }).join('\n\n');
    var opts = {
      stemming: document.getElementById('set-stemming').value,
      keepPronouns: document.getElementById('set-pronouns').checked,
      interSentenceLinking: document.getElementById('set-intersentence').checked
    };
    if (!parserInstance || parserInstance._keepPronouns !== opts.keepPronouns) {
      parserInstance = window.CrawdadParser.createParser({ keepPronouns: opts.keepPronouns });
      parserInstance._keepPronouns = opts.keepPronouns;
    }
    var deps = {
      parser: parserInstance, porter2: window.CrawdadWink.porter2,
      isStopWord: window.CrawdadStopWords.isStopWord, schema: S,
      network: window.CrawdadNetwork, textclean: window.CrawdadTextClean
    };
    try {
      var res = window.CrawdadGenerator.generate('cluster' + (k + 1) + '.txt', text, opts, deps);
      var outName = 'cluster' + (k + 1) + '_cra.md';
      var parsedBack = S.parseCra(res.craMd);
      state.craFiles = state.craFiles.filter(function (c) { return c.name !== outName; });
      state.craFiles.push({ name: outName, text: res.craMd, ok: parsedBack.ok,
        data: parsedBack.data, errors: parsedBack.errors });
      IO.downloadFile(outName, res.craMd);
      renderAnaList();
      if (confirm(outName + ' generated (' + res.craData.network.nodes.length +
          ' nodes). Open it in the Visualizer now?')) {
        openVisualizer();
        document.getElementById('viz-file').value = outName;
        document.getElementById('viz-render').click();
      }
    } catch (err) { alert('Aggregation failed: ' + err.message); }
  }

  function clusterColors(k) {
    var palette = ['#b03a2e', '#1f618d', '#1e7d46', '#8a6d00', '#6c3483', '#0e6655', '#a04000', '#4d5656'];
    return palette.slice(0, k);
  }

  function drawMdsPlot(names, points, labels) {
    var W = 860, H = 480, pad = 60;
    var xs = points.map(function (p) { return p[0]; });
    var ys = points.map(function (p) { return p[1]; });
    var xmin = Math.min.apply(null, xs), xmax = Math.max.apply(null, xs);
    var ymin = Math.min.apply(null, ys), ymax = Math.max.apply(null, ys);
    function sx(x) { return pad + (xmax === xmin ? 0.5 : (x - xmin) / (xmax - xmin)) * (W - 2 * pad); }
    function sy(y) { return H - pad - (ymax === ymin ? 0.5 : (y - ymin) / (ymax - ymin)) * (H - 2 * pad); }
    var colors = clusterColors(Math.max.apply(null, labels) + 1);
    var svg = ['<h3>MDS plot (classical MDS on 1 − WR&prime;)</h3>',
      '<svg viewBox="0 0 ' + W + ' ' + H + '" style="background:#fff;border:1px solid #d7dde2;max-width:100%">'];
    points.forEach(function (p, i) {
      var x = sx(p[0]), y = sy(p[1]);
      svg.push('<circle cx="' + x + '" cy="' + y + '" r="7" fill="' + colors[labels[i]] + '"/>');
      svg.push('<text x="' + (x + 10) + '" y="' + (y + 4) +
        '" font-size="12" font-family="Georgia,serif" fill="#1f2a33">' +
        esc(names[i].replace(/_cra\.md$/i, '')) + ' (' + (labels[i] + 1) + ')</text>');
    });
    svg.push('</svg>');
    document.getElementById('cls-mdsplot').innerHTML = svg.join('');
  }

  document.getElementById('cls-download').addEventListener('click', function () {
    if (clsReport) { IO.downloadFile(clsReport.name, clsReport.markdown); }
  });
  document.getElementById('cls-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Theme Identifier screen (M6) ---------------- */
  var thmReport = null;

  function openThemes() {
    document.getElementById('thm-results').innerHTML = '';
    document.getElementById('thm-download').disabled = true;
    thmReport = null;
    show('themes');
  }

  document.getElementById('thm-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (valid.length < 5) { alert('Theme Identifier needs 5 or more valid files.'); return; }
    var names = valid.map(function (c) { return c.name.replace(/_cra\.md$/i, ''); });
    var datas = valid.map(function (c) { return c.data; });
    var rep = window.CrawdadThemes.themeReport(datas, names, S.CITATION);
    thmReport = {
      name: 'themes_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: rep.markdown
    };
    document.getElementById('thm-download').disabled = false;

    // reuse the report's HTML tables; convert md bullet section to simple HTML
    var md = rep.markdown.split('## Data (machine-readable')[0];
    var html = md
      .replace(/^# .*$/m, '')
      .replace(/^## (.*)$/gm, '<h3>$1</h3>')
      .replace(/^- \*\*(Theme \d+)\*\*(.*)$/gm, '<p><strong>$1</strong>$2</p>')
      .replace(/^- (.*)$/gm, '<p class="hint">$1</p>')
      .replace(/^\|(.*)\|$/gm, function (line) { return mdRow(line); })
      .replace(/\n{2,}/g, '\n');
    document.getElementById('thm-results').innerHTML =
      html + '<p class="hint">Full detail is in the downloadable report.</p>';
  });

  // minimal md-table row -> HTML (for the top-words table in the results pane)
  var mdRowState = { open: false };
  function mdRow(line) {
    if (/^\|[\s-|]+\|$/.test(line)) { return ''; } // separator row
    var cells = line.slice(1, -1).split('|').map(function (c) { return c.trim(); });
    var isHeader = !mdRowState.open;
    var tag = isHeader ? 'th' : 'td';
    var row = '<tr>' + cells.map(function (c) { return '<' + tag + '>' + c + '</' + tag + '>'; }).join('') + '</tr>';
    if (isHeader) { mdRowState.open = true; return '<table>' + row; }
    return row;
  }

  document.getElementById('thm-download').addEventListener('click', function () {
    if (thmReport) { IO.downloadFile(thmReport.name, thmReport.markdown); }
  });
  document.getElementById('thm-back').addEventListener('click', function () {
    mdRowState.open = false; show('analyze');
  });

  /* ---------------- Latent Theme Identifier screen (M6) ---------------- */
  var latReport = null;
  var latCodeRows = null;

  function openLatent() {
    document.getElementById('lat-results').innerHTML = '';
    document.getElementById('lat-download').disabled = true;
    document.getElementById('lat-run').disabled = !latCodeRows;
    latReport = null;
    show('latent');
  }

  document.getElementById('lat-codes').addEventListener('change', function (e) {
    var f = e.target.files[0];
    if (!f) { return; }
    var label = document.getElementById('lat-codes-name');
    function done(rows) {
      latCodeRows = rows;
      label.textContent = ' Loaded: ' + f.name + ' (' + rows.length + ' rows)';
      document.getElementById('lat-run').disabled = false;
    }
    if (/\.csv$/i.test(f.name)) {
      IO.readFileAsText(f).then(function (t) {
        done(window.CrawdadTextClean.parseCsvPairs(t));
      });
    } else {
      var r = new FileReader();
      r.onload = function () {
        try { done(window.CrawdadTextClean.parseXlsxPairs(r.result)); }
        catch (err) { alert('Could not read spreadsheet: ' + err.message); }
      };
      r.readAsArrayBuffer(f);
    }
  });

  document.getElementById('lat-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (!valid.length) { alert('Load at least one valid _cra.md file first.'); return; }
    if (!latCodeRows || !latCodeRows.length) { alert('Load a latent codes file first.'); return; }

    // stem code words to match the files' stemming setting (warn if mixed)
    var modes = {};
    valid.forEach(function (c) {
      modes[(c.data.parameters && c.data.parameters.stemming) || 'porter'] = true;
    });
    var modeList = Object.keys(modes);
    var mode = modeList[0];
    var stemFn = mode === 'porter' ? window.CrawdadWink.porter2
      : mode === 'minimal' ? window.CrawdadNetwork.minimalStem
      : function (w) { return w; };
    var note = 'Code words stemmed with "' + mode + '" to match the files.' +
      (modeList.length > 1
        ? ' **Warning: loaded files use mixed stemming settings (' + modeList.join(', ') +
          ') — matching may be inconsistent.**' : '');

    var names = valid.map(function (c) { return c.name.replace(/_cra\.md$/i, ''); });
    var datas = valid.map(function (c) { return c.data; });
    var themes = window.CrawdadThemes.parseLatentCodes(latCodeRows, stemFn);
    if (!Object.keys(themes).length) { alert('No themes found in the codes file.'); return; }
    var rep = window.CrawdadThemes.latentReport(datas, names, themes, S.CITATION, note);
    latReport = {
      name: 'latent_themes_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: rep.markdown
    };
    document.getElementById('lat-download').disabled = false;

    var html = '<h3>Theme scores (summed total influence)</h3>' +
      '<table><thead><tr><th>Theme</th>' +
      names.map(function (nm) { return '<th>' + esc(nm) + '</th>'; }).join('') +
      '</tr></thead><tbody>' +
      Object.keys(themes).map(function (t) {
        return '<tr><td>' + esc(t) + '</td>' + rep.result.table[t].map(function (v) {
          return '<td>' + v.toFixed(5) + '</td>'; }).join('') + '</tr>';
      }).join('') + '</tbody></table>' +
      '<p class="hint">' + esc(note.replace(/\*\*/g, '')) + '</p>' +
      '<p class="hint">Coverage: ' + rep.result.coverage.found.length +
      ' code word(s) matched; ' + rep.result.coverage.missing.length + ' unmatched' +
      (rep.result.coverage.missing.length
        ? ' — <span style="color:#b03a2e">' + esc(rep.result.coverage.missing.join(', ')) + '</span>'
        : '') + '.</p>';
    document.getElementById('lat-results').innerHTML = html;
  });

  document.getElementById('lat-download').addEventListener('click', function () {
    if (latReport) { IO.downloadFile(latReport.name, latReport.markdown); }
  });
  document.getElementById('lat-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- Summarizer screen (M7, spec §7.6) ---------------- */
  /* (LLM features unwired 2026-07-09 per Kevin; module retained in js/llm.js) */
  var sumReport = null;

  function openSummarizer() {
    document.getElementById('sum-results').innerHTML = '';
    document.getElementById('sum-download').disabled = true;
    sumReport = null;
    show('summarize');
  }

  document.getElementById('sum-run').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (valid.length < 2) { alert('Summarizer needs 2 or more valid files.'); return; }
    var names = valid.map(function (c) { return c.name.replace(/_cra\.md$/i, ''); });
    var datas = valid.map(function (c) { return c.data; });
    var rep = window.CrawdadThemes.summarizerReport(datas, names, S.CITATION);
    sumReport = {
      name: 'summary_' + new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) + '.md',
      markdown: rep.markdown
    };
    document.getElementById('sum-download').disabled = false;

    var html = '<h3>Most influential words (top ' + rep.wtm.words.length + ')</h3>' +
      '<table><thead><tr><th>#</th><th>Word</th><th>Summed</th>' +
      names.map(function (nm) { return '<th>' + esc(nm) + '</th>'; }).join('') +
      '</tr></thead><tbody>' +
      rep.wtm.words.map(function (wr, wi) {
        return '<tr><td>' + (wi + 1) + '</td><td>' + esc(wr.display) + '</td><td>' +
          wr.sum.toFixed(4) + '</td>' +
          rep.wtm.matrix[wi].map(function (v) { return '<td>' + v.toFixed(4) + '</td>'; }).join('') +
          '</tr>';
      }).join('') + '</tbody></table>';
    document.getElementById('sum-results').innerHTML = html;
  });

  document.getElementById('sum-download').addEventListener('click', function () {
    if (sumReport) { IO.downloadFile(sumReport.name, sumReport.markdown); }
  });
  document.getElementById('sum-back').addEventListener('click', function () { show('analyze'); });

  /* ---------------- E-2: session bundle save/load ---------------- */

  document.getElementById('ana-save-bundle').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (!valid.length) { alert('No valid files loaded.'); return; }
    var zip = new window.JSZip();
    valid.forEach(function (c) { zip.file(c.name, c.text); });
    zip.file('session-info.json', JSON.stringify({
      schema: 'crawdad-session', schemaVersion: '1.0',
      saved: new Date().toISOString(), files: valid.map(function (c) { return c.name; })
    }, null, 1));
    zip.generateAsync({ type: 'blob' }).then(function (blob) {
      IO.downloadFile('crawdad-session-' +
        new Date().toISOString().slice(0, 10) + '.zip', blob, 'application/zip');
    });
  });

  document.getElementById('ana-load-bundle').addEventListener('change', function (e) {
    var f = e.target.files[0];
    if (!f) { return; }
    window.JSZip.loadAsync(f).then(function (zip) {
      var loads = [];
      zip.forEach(function (path, entry) {
        if (/_cra\.md$/i.test(path) && !entry.dir) {
          loads.push(entry.async('string').then(function (text) {
            var res = S.parseCra(text);
            state.craFiles = state.craFiles.filter(function (c) { return c.name !== path; });
            state.craFiles.push({ name: path, text: text, ok: res.ok,
              data: res.data, errors: res.errors });
          }));
        }
      });
      return Promise.all(loads);
    }).then(function () {
      renderAnaList();
      e.target.value = '';
    }).catch(function (err) { alert('Could not read bundle: ' + err.message); });
  });

  /* ---------------- E-3: batch PNG export ---------------- */

  document.getElementById('viz-export-all').addEventListener('click', function () {
    var valid = state.craFiles.filter(function (c) { return c.ok; });
    if (!valid.length) { alert('No valid files loaded.'); return; }
    var topK = parseInt(document.getElementById('viz-topk').value, 10) || 30;
    var highlight = parseFloat(document.getElementById('viz-highlight').value);
    if (isNaN(highlight)) { highlight = 0.05; }
    var i = 0;
    function next() {
      if (i >= valid.length) { return; }
      var c = valid[i++];
      var h = window.CrawdadVisualizer.render(
        document.getElementById('viz-canvas'), c.data, { topK: topK, highlight: highlight });
      h.exportPng(function (err, blob) {
        if (!err) {
          IO.downloadFile('crawdad-network-' + c.name.replace(/_cra\.md$/i, '') + '.png',
            blob, 'image/png');
        }
        setTimeout(next, 500); // stagger downloads
      });
    }
    next();
  });

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch];
    });
  }

  renderModuleMenu();
  show('landing');

  // test hook (harmless in production; used by tests/test-app-shell.js)
  window.__crawdadDebug = { state: state, renderModuleMenu: renderModuleMenu, renderAnaList: renderAnaList };
})();
