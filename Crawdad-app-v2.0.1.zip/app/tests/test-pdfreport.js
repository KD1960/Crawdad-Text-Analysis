/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad V2-M1.1 — readable PDF export tests (D-V2-15).
 * Node:    node tests/test-pdfreport.js  (needs jspdf + jspdf-autotable via NODE_PATH)
 * Browser: open tests/test-pdfreport.html
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var PDF = isNode ? require('../js/pdfreport.js') : root.CrawdadPdfReport;
  var S = isNode ? require('../js/craschema.js') : root.CrawdadSchema;

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }

  function fixture() {
    var d = S.newCraData('speech.txt', null, '2.0.0-M1 (built 2026-08-11)');
    d.source.processedAt = '2026-08-11T00:00:00.000Z';
    d.network.nodes = [
      { id: 0, word: 'king', display: 'king', degree: 2, influence: 0.5 },
      { id: 1, word: 'castl', display: 'castle', degree: 1, influence: 0.2 },
      { id: 2, word: 'moat', display: 'moat', degree: 1, influence: 0.001 }
    ];
    d.network.edges = [
      { source: 0, target: 1, weight: 3 },
      { source: 0, target: 2, weight: 1 }
    ];
    d.summary = { nodeCount: 3, edgeCount: 2, componentCount: 1,
      largestComponentShare: 1, meanInfluence: 0.23367,
      centralization: { degree: 1, betweenness: 1, closeness: 1, eigenvector: 0.5 } };
    d.textMetrics = { sentiment: 0.12, lexicalDensity: 0.52,
      vader: { meanCompound: 0.3, posShare: 0.5, negShare: 0.1 } };
    d.cleaningNotes = ['Removed 2 narrative citation(s) (author name + year).'];
    d.tokenSuggestions = [{ phrase: 'castle moat', replacement: 'castle_moat', count: 3, words: 2 }];
    d.lexiconsUsed = [{ name: 'codes.csv', sha256: 'ab'.repeat(32), type: 'categorical',
      mode: 'exact', entryCount: 2, coverage: 0.35, lowCoverage: true,
      matchedTokens: 35, totalTokens: 100, metrics: { Power: { per1000: 20, n: 2 } } }];
    return d;
  }

  t('model contains all human sections in order', function () {
    var m = PDF.buildModel(fixture());
    var heads = m.sections.map(function (s) { return s.heading; }).join(' | ');
    assert(/Text cleaning/.test(heads), 'cleaning missing: ' + heads);
    assert(/Network summary/.test(heads), 'summary missing');
    assert(/Text metrics/.test(heads), 'metrics missing');
    assert(/Custom dictionary: codes.csv/.test(heads), 'dictionary missing');
    assert(/Influential words/.test(heads), 'influential words missing');
    assert(/Tokenization suggestions/.test(heads), 'suggestions missing');
  });

  t('machine data is absent by construction', function () {
    var m = PDF.buildModel(fixture());
    var js = JSON.stringify(m);
    assert(js.indexOf('"weight"') === -1, 'edge weights leaked into model');
    assert(js.indexOf('"schemaVersion"') === -1, 'schema block leaked');
    assert(js.indexOf('surfaceFrequencies') === -1, 'surface frequencies leaked');
  });

  t('display threshold applies: sub-0.005 word has no table row', function () {
    var m = PDF.buildModel(fixture());
    var inf = m.sections.filter(function (s) { return /Influential/.test(s.heading); })[0];
    var words = inf.rows.map(function (r) { return r[0]; });
    assert(words.indexOf('moat') === -1, 'moat (I=0.001) should be filtered');
    assert(words.indexOf('king') !== -1 && words.indexOf('castle') !== -1, 'rows missing');
  });

  t('both citations + disclaimer travel with the PDF (Design Guide §06)', function () {
    var m = PDF.buildModel(fixture());
    var f = m.footerCitations.join(' ');
    assert(f.indexOf('Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002)') !== -1, 'method citation missing');
    assert(f.indexOf('Crawdad Text Analysis Software (Version 2.0.0-M1)') !== -1, 'software citation missing');
    assert(f.indexOf('Disclaimer') !== -1, 'disclaimer missing');
  });

  t('low-coverage dictionary warning carried into the PDF model', function () {
    var m = PDF.buildModel(fixture());
    var dict = m.sections.filter(function (s) { return /Custom dictionary/.test(s.heading); })[0];
    assert(/WARNING: coverage below 60%/.test(dict.intro), 'warning missing');
    assert(dict.introWarn === true, 'warn flag missing');
  });

  t('pdfFileName appends .pdf to the full _cra.md name (Kevin: name_cra.md.pdf)', function () {
    assert(PDF.pdfFileName('speech_cra.md') === 'speech_cra.md.pdf',
      'got ' + PDF.pdfFileName('speech_cra.md'));
  });

  t('render produces a %PDF document with pages', function () {
    var deps = null;
    if (isNode) {
      var jspdf = require('jspdf');
      var at = require('jspdf-autotable');
      deps = { jsPDF: jspdf.jsPDF, autoTable: at.default || at };
    }
    var doc = PDF.render(PDF.buildModel(fixture()), deps);
    var buf = doc.output('arraybuffer');
    var head = String.fromCharCode.apply(null, new Uint8Array(buf.slice(0, 4)));
    assert(head === '%PDF', 'not a PDF: ' + head);
    assert(doc.getNumberOfPages() >= 1, 'no pages');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'V2-M1.1 PDF report tests: ' + passed + '/' + results.length + ' passed';
  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadPdfTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
