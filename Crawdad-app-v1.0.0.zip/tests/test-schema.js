/*
 * Crawdad 2026 — M0 machine validation: _cra.md schema round-trip tests.
 * Run in Node:  node tests/test-schema.js
 * Or open tests/test-schema.html in a browser.
 */
(function (root) {
  'use strict';

  var S = (typeof module !== 'undefined' && module.exports)
    ? require('../js/craschema.js')
    : root.CrawdadSchema;

  var results = [];
  function t(name, fn) {
    try {
      fn();
      results.push({ name: name, pass: true });
    } catch (e) {
      results.push({ name: name, pass: false, msg: e.message });
    }
  }
  function assert(cond, msg) { if (!cond) { throw new Error(msg || 'assertion failed'); } }

  /* ------- fixture: small valid CRA data object ------- */
  function fixture() {
    var d = S.newCraData('macbeth.txt', null, '0.1.0-M0-test');
    d.source.processedAt = '2026-07-09T00:00:00.000Z'; // deterministic
    d.network.nodes = [
      { id: 0, word: 'king',    display: 'king',    degree: 3, influence: 0.41 },
      { id: 1, word: 'blood',   display: 'blood',   degree: 2, influence: 0.12 },
      { id: 2, word: 'night',   display: 'night',   degree: 2, influence: 0.006 },
      { id: 3, word: 'dagger',  display: 'dagger',  degree: 1, influence: 0.004 }, // below display threshold
      { id: 4, word: 'sleep',   display: 'sleep',   degree: 0, influence: 0 }      // isolate
    ];
    d.network.edges = [
      { source: 0, target: 1, weight: 4 },
      { source: 0, target: 2, weight: 1 },
      { source: 0, target: 3, weight: 2 },
      { source: 1, target: 2, weight: 1 }
    ];
    d.summary = {
      nodeCount: 5, edgeCount: 4,
      centralization: { degree: 0.58, betweenness: 0.41, closeness: 0.5, eigenvector: 0.6 }
    };
    return d;
  }

  /* ------- tests ------- */

  t('valid fixture passes validation', function () {
    var v = S.validateCra(fixture());
    assert(v.ok, v.errors.join('; '));
  });

  t('round-trip: serialize -> parse recovers identical data', function () {
    var d = fixture();
    var md = S.serializeCra(d);
    var back = S.parseCra(md);
    assert(back.ok, back.errors.join('; '));
    assert(JSON.stringify(back.data) === JSON.stringify(d),
      'parsed data differs from original');
  });

  t('display threshold: word below 0.005 absent from human table, present in JSON', function () {
    var md = S.serializeCra(fixture());
    var human = md.split('```json')[0];
    var json = md.split('```json')[1];
    // Threshold governs table ROWS; sub-threshold words may still appear in
    // neighbors' "Connected to" lists (they are real connections).
    assert(!/^\| dagger \|/m.test(human), 'dagger (I=0.004) should have no table row');
    assert(/^\| blood \|/m.test(human), 'blood (I=0.12) should have a table row');
    assert(json.indexOf('dagger') !== -1, 'dagger must remain in machine block');
  });

  t('citation footer present in output (spec §1.4)', function () {
    var md = S.serializeCra(fixture());
    assert(md.indexOf('Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002)') !== -1,
      'citation missing');
  });

  t('reject: file with no JSON block', function () {
    var r = S.parseCra('# Just some markdown\n\nNothing here.');
    assert(!r.ok && r.errors[0].indexOf('No machine-readable JSON block') === 0 || !r.ok,
      'should reject');
  });

  t('reject: corrupt JSON block', function () {
    var r = S.parseCra('```json\n{ not valid json\n```');
    assert(!r.ok, 'should reject corrupt JSON');
  });

  t('reject: edge referencing missing node', function () {
    var d = fixture();
    d.network.edges.push({ source: 0, target: 99, weight: 1 });
    assert(!S.validateCra(d).ok, 'should reject dangling edge');
  });

  t('reject: duplicate undirected edge (either order)', function () {
    var d = fixture();
    d.network.edges.push({ source: 1, target: 0, weight: 1 }); // 0-1 already exists
    assert(!S.validateCra(d).ok, 'should reject duplicate edge');
  });

  t('reject: self-loop', function () {
    var d = fixture();
    d.network.edges.push({ source: 2, target: 2, weight: 1 });
    assert(!S.validateCra(d).ok, 'should reject self-loop');
  });

  t('reject: non-integer or zero edge weight (F_ij must be >= 1)', function () {
    var d = fixture();
    d.network.edges[0].weight = 0;
    assert(!S.validateCra(d).ok, 'weight 0 should fail');
    d = fixture();
    d.network.edges[0].weight = 1.5;
    assert(!S.validateCra(d).ok, 'fractional weight should fail');
  });

  t('reject: influence outside [0,1]', function () {
    var d = fixture();
    d.network.nodes[0].influence = 1.2;
    assert(!S.validateCra(d).ok, 'influence > 1 should fail');
    d = fixture();
    d.network.nodes[0].influence = -0.1;
    assert(!S.validateCra(d).ok, 'negative influence should fail');
  });

  t('reject: duplicate node id', function () {
    var d = fixture();
    d.network.nodes.push({ id: 0, word: 'ghost', degree: 0, influence: 0 });
    assert(!S.validateCra(d).ok, 'duplicate id should fail');
  });

  t('serializeCra refuses invalid data', function () {
    var d = fixture();
    d.network.nodes[0].influence = 5;
    var threw = false;
    try { S.serializeCra(d); } catch (e) { threw = true; }
    assert(threw, 'should throw on invalid data');
  });

  t('wrong schema name rejected', function () {
    var d = fixture();
    d.schema = 'something-else';
    assert(!S.validateCra(d).ok, 'wrong schema name should fail');
  });

  /* ------- report ------- */
  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'M0 schema tests: ' + passed + '/' + results.length + ' passed';

  if (typeof module !== 'undefined' && module.exports) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? '  — ' + r.msg : ''));
    });
    console.log(summary);
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadTestResults = { results: results, summary: summary };
  }
})(typeof self !== 'undefined' ? self : this);
