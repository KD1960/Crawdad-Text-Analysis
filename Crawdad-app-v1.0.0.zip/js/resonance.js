/*
 * Crawdad 2026 — M4: resonance calculations (spec §3.6; JHC Eqs. 2–6, pp. 178–179)
 * Used by Comparator (M4) and Classifier (M5).
 *
 *   WR_AB  = Σ_i Σ_j I_i^A · I_j^B · α_ij          (Eq. 2)
 *   WR'_AB = WR / sqrt(ΣI_A² · ΣI_B²)              (Eq. 3)
 *   P_ij^T = I_i^T · I_j^T · F_ij^T                (Eq. 4)
 *   PR_AB  = Σ β · P_ij^A · P_kl^B                 (Eq. 5)
 *   PR'_AB = PR / sqrt(ΣP_A² · ΣP_B²)              (Eq. 6)
 *
 * β = 1 iff word sets {i,j}/{k,l} are equal (order-free) and both pairs are
 * connected (F ≥ 1) — D-3. Word matching is on stems (network node words).
 */
(function (root) {
  'use strict';

  /* ---------------- word resonance (Eqs. 2–3) ---------------- */

  function influenceMap(craData) {
    var m = {};
    craData.network.nodes.forEach(function (n) { m[n.word] = n.influence; });
    return m;
  }

  function wordResonance(dataA, dataB) {
    var A = influenceMap(dataA), B = influenceMap(dataB);
    var wr = 0, sumA2 = 0, sumB2 = 0, w;
    for (w in A) {
      sumA2 += A[w] * A[w];
      if (B.hasOwnProperty(w)) { wr += A[w] * B[w]; }
    }
    for (w in B) { sumB2 += B[w] * B[w]; }
    var denom = Math.sqrt(sumA2 * sumB2);
    return { WR: wr, WRs: denom > 0 ? wr / denom : 0 };
  }

  /* ---------------- pair resonance (Eqs. 4–6) ---------------- */

  /** Map "wordI|wordJ" (sorted) -> P_ij = I_i · I_j · F_ij, for connected pairs. */
  function pairInfluenceMap(craData) {
    var infl = influenceMap(craData);
    var byId = {};
    craData.network.nodes.forEach(function (n) { byId[n.id] = n.word; });
    var m = {};
    craData.network.edges.forEach(function (e) {
      var wi = byId[e.source], wj = byId[e.target];
      var key = wi < wj ? wi + '|' + wj : wj + '|' + wi;
      var p = infl[wi] * infl[wj] * e.weight;
      // stem collisions across distinct node ids cannot produce duplicate
      // keys (nodes are unique by word), but guard by accumulation anyway
      m[key] = (m[key] || 0) + p;
    });
    return m;
  }

  function pairResonance(dataA, dataB) {
    var PA = pairInfluenceMap(dataA), PB = pairInfluenceMap(dataB);
    var pr = 0, sumA2 = 0, sumB2 = 0, k;
    for (k in PA) {
      sumA2 += PA[k] * PA[k];
      if (PB.hasOwnProperty(k)) { pr += PA[k] * PB[k]; }
    }
    for (k in PB) { sumB2 += PB[k] * PB[k]; }
    var denom = Math.sqrt(sumA2 * sumB2);
    return { PR: pr, PRs: denom > 0 ? pr / denom : 0 };
  }

  /* ---------------- word lists (spec §7.2, D-5) ---------------- */

  function displayMap(craData) {
    var m = {};
    craData.network.nodes.forEach(function (n) { m[n.word] = n.display || n.word; });
    return m;
  }

  /** Common words ranked by min(I_A, I_B) desc — both texts must value the word. */
  function commonWords(dataA, dataB, n) {
    var A = influenceMap(dataA), B = influenceMap(dataB);
    var dA = displayMap(dataA);
    var out = [];
    Object.keys(A).forEach(function (w) {
      if (B.hasOwnProperty(w)) {
        out.push({ word: w, display: dA[w], iA: A[w], iB: B[w],
                   rank: Math.min(A[w], B[w]) });
      }
    });
    out.sort(function (a, b) { return b.rank - a.rank || (a.word < b.word ? -1 : 1); });
    return out.slice(0, n === undefined ? 10 : n);
  }

  /** Words in A absent from B, ranked by I_A desc. */
  function uniqueWords(dataA, dataB, n) {
    var A = influenceMap(dataA), B = influenceMap(dataB);
    var dA = displayMap(dataA);
    var out = [];
    Object.keys(A).forEach(function (w) {
      if (!B.hasOwnProperty(w)) { out.push({ word: w, display: dA[w], i: A[w] }); }
    });
    out.sort(function (a, b) { return b.i - a.i || (a.word < b.word ? -1 : 1); });
    return out.slice(0, n === undefined ? 10 : n);
  }

  /* ---------------- comparison report (spec §7.2) ---------------- */

  function compare(dataA, dataB) {
    var wr = wordResonance(dataA, dataB);
    var pr = pairResonance(dataA, dataB);
    return {
      fileA: dataA.source.filename,
      fileB: dataB.source.filename,
      WR: wr.WR, WRs: wr.WRs, PR: pr.PR, PRs: pr.PRs,
      common: commonWords(dataA, dataB, 10),
      uniqueA: uniqueWords(dataA, dataB, 10),
      uniqueB: uniqueWords(dataB, dataA, 10)
    };
  }

  function fmt(x) { return Number(x).toExponential(4); }
  function fmt5(x) { return Number(x).toFixed(5); }

  function buildReport(dataA, dataB, citation) {
    var c = compare(dataA, dataB);
    var L = [];
    L.push('# Crawdad Comparator: ' + c.fileA + ' vs ' + c.fileB);
    L.push('');
    L.push('- Generated: ' + new Date().toISOString());
    L.push('- Note: word matching is on stemmed forms; both files should be generated with the same parameters.');
    var pa = dataA.parameters || {}, pb = dataB.parameters || {};
    if (pa.stemming !== pb.stemming || pa.interSentenceLinking !== pb.interSentenceLinking) {
      L.push('- **Warning: the two files were generated with different parameters** (' +
        'A: stemming=' + pa.stemming + ', inter-sentence=' + pa.interSentenceLinking +
        '; B: stemming=' + pb.stemming + ', inter-sentence=' + pb.interSentenceLinking + ').');
    }
    L.push('');
    L.push('## Resonance (JHC Eqs. 2-6)');
    L.push('');
    L.push('| Measure | Value |');
    L.push('|---|---|');
    L.push('| Word resonance WR (Eq. 2, unstandardized) | ' + fmt(c.WR) + ' |');
    L.push("| Word resonance WR' (Eq. 3, standardized 0-1) | " + fmt5(c.WRs) + ' |');
    L.push('| Pair resonance PR (Eq. 5, unstandardized) | ' + fmt(c.PR) + ' |');
    L.push("| Pair resonance PR' (Eq. 6, standardized 0-1) | " + fmt5(c.PRs) + ' |');
    L.push('');
    L.push('## Most influential common words (ranked by min(I_A, I_B))');
    L.push('');
    L.push('| Word | Influence in A | Influence in B |');
    L.push('|---|---|---|');
    c.common.forEach(function (w) {
      L.push('| ' + w.display + ' | ' + fmt5(w.iA) + ' | ' + fmt5(w.iB) + ' |');
    });
    if (!c.common.length) { L.push('| (none) | | |'); }
    L.push('');
    L.push('## Most influential words unique to ' + c.fileA);
    L.push('');
    L.push('| Word | Influence |');
    L.push('|---|---|');
    c.uniqueA.forEach(function (w) { L.push('| ' + w.display + ' | ' + fmt5(w.i) + ' |'); });
    if (!c.uniqueA.length) { L.push('| (none) | |'); }
    L.push('');
    L.push('## Most influential words unique to ' + c.fileB);
    L.push('');
    L.push('| Word | Influence |');
    L.push('|---|---|');
    c.uniqueB.forEach(function (w) { L.push('| ' + w.display + ' | ' + fmt5(w.i) + ' |'); });
    if (!c.uniqueB.length) { L.push('| (none) | |'); }
    L.push('');
    L.push('## Data (machine-readable — do not edit)');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify({ schema: 'crawdad-comparison', schemaVersion: '1.0', result: c }, null, 1));
    L.push('```');
    L.push('');
    L.push('---');
    L.push('*' + citation + '*');
    L.push('');
    return { markdown: L.join('\n'), result: c };
  }

  var api = {
    wordResonance: wordResonance,
    pairResonance: pairResonance,
    pairInfluenceMap: pairInfluenceMap,
    commonWords: commonWords,
    uniqueWords: uniqueWords,
    compare: compare,
    buildReport: buildReport
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadResonance = api; }
})(typeof self !== 'undefined' ? self : this);
