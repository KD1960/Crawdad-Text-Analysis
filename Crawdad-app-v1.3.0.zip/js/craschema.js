/*
 * Crawdad 2026 — CRA file schema (spec §4.1)
 * Serializes/parses/validates `filename_cra.md` files.
 *
 * A _cra.md file has two sections:
 *   A. Human-readable summary (display threshold: influence > 0.005)
 *   B. Machine-readable fenced ```json block with the COMPLETE network.
 * Downstream modules parse ONLY the JSON block; the display threshold
 * never affects computation (decision 2026-07-09).
 *
 * Plain script (no ES modules) so the app runs from file:// with no
 * build step (spec §2, M8). Also loadable in Node for tests.
 */
(function (root) {
  'use strict';

  var SCHEMA_NAME = 'crawdad-cra';
  var SCHEMA_VERSION = '1.1'; // 1.1: optional textMetrics block (D-12)
  var DISPLAY_THRESHOLD = 0.005; // spec WF 2j-iii: display-only
  var CITATION =
    'Please cite: Corman, S., Kuhn, T., McPhee, R., & Dooley, K. (2002). ' +
    'Studying complex discursive systems: Centering Resonance Analysis of ' +
    'organizational communication. Human Communication Research, 28(2), 157-206.';

  /* ------------------------------------------------------------------ *
   * Validation
   * ------------------------------------------------------------------ */

  /**
   * Validate a CRA data object. Returns { ok: boolean, errors: string[] }.
   * Structural integrity only; numeric plausibility checks are warnings-level
   * errors here because downstream math depends on them.
   */
  function validateCra(data) {
    var errors = [];
    function err(msg) { errors.push(msg); }

    if (!data || typeof data !== 'object') {
      return { ok: false, errors: ['Not an object.'] };
    }
    if (data.schema !== SCHEMA_NAME) {
      err('schema must be "' + SCHEMA_NAME + '" (got "' + data.schema + '").');
    }
    if (typeof data.schemaVersion !== 'string') {
      err('schemaVersion missing.');
    }
    if (!data.source || typeof data.source.filename !== 'string') {
      err('source.filename missing.');
    }
    if (!data.parameters || typeof data.parameters !== 'object') {
      err('parameters block missing.');
    }
    if (data.textMetrics !== undefined && data.textMetrics !== null &&
        typeof data.textMetrics !== 'object') {
      err('textMetrics must be an object when present.');
    }

    var net = data.network;
    if (!net || !Array.isArray(net.nodes) || !Array.isArray(net.edges)) {
      err('network.nodes / network.edges missing.');
      return { ok: errors.length === 0, errors: errors };
    }

    var ids = {};
    net.nodes.forEach(function (n, i) {
      if (typeof n.id !== 'number' && typeof n.id !== 'string') {
        err('node[' + i + ']: id missing.');
      } else if (ids.hasOwnProperty(n.id)) {
        err('node[' + i + ']: duplicate id "' + n.id + '".');
      } else {
        ids[n.id] = true;
      }
      if (typeof n.word !== 'string' || n.word.length === 0) {
        err('node[' + i + ']: word missing.');
      }
      if (typeof n.influence !== 'number' || isNaN(n.influence) ||
          n.influence < 0 || n.influence > 1) {
        err('node[' + i + '] ("' + n.word + '"): influence must be a number in [0,1].');
      }
      if (typeof n.degree !== 'number' || n.degree < 0 || n.degree % 1 !== 0) {
        err('node[' + i + '] ("' + n.word + '"): degree must be a non-negative integer.');
      }
    });

    var seenEdge = {};
    net.edges.forEach(function (e, i) {
      if (!ids.hasOwnProperty(e.source)) {
        err('edge[' + i + ']: source "' + e.source + '" is not a node id.');
      }
      if (!ids.hasOwnProperty(e.target)) {
        err('edge[' + i + ']: target "' + e.target + '" is not a node id.');
      }
      if (e.source === e.target) {
        err('edge[' + i + ']: self-loop not allowed.');
      }
      if (typeof e.weight !== 'number' || e.weight < 1 || e.weight % 1 !== 0) {
        err('edge[' + i + ']: weight (F_ij) must be an integer >= 1.');
      }
      // undirected: canonical key to catch duplicates in either order
      var k = e.source < e.target ? e.source + '|' + e.target : e.target + '|' + e.source;
      if (seenEdge[k]) { err('edge[' + i + ']: duplicate undirected edge ' + k + '.'); }
      seenEdge[k] = true;
    });

    return { ok: errors.length === 0, errors: errors };
  }

  /* ------------------------------------------------------------------ *
   * Serialization  (data object -> _cra.md text)
   * ------------------------------------------------------------------ */

  function fmt(x, places) {
    return Number(x).toFixed(places === undefined ? 5 : places);
  }

  function serializeCra(data) {
    var v = validateCra(data);
    if (!v.ok) {
      throw new Error('Refusing to serialize invalid CRA data:\n' + v.errors.join('\n'));
    }
    var net = data.network;
    var byId = {};
    net.nodes.forEach(function (n) { byId[n.id] = n; });

    // neighbor map for the human-readable table
    var nbrs = {};
    net.nodes.forEach(function (n) { nbrs[n.id] = []; });
    net.edges.forEach(function (e) {
      nbrs[e.source].push(byId[e.target].word);
      nbrs[e.target].push(byId[e.source].word);
    });

    var s = data.summary || {};
    var c = s.centralization || {};
    var lines = [];

    lines.push('# CRA Analysis: ' + data.source.filename);
    lines.push('');
    lines.push('- Processed: ' + (data.source.processedAt || 'unknown'));
    lines.push('- App version: ' + (data.source.appVersion || 'unknown'));
    lines.push('- Parameters: stemming=' + data.parameters.stemming +
      ', pronouns=' + (data.parameters.pronouns ? 'retained' : 'dropped') +
      ', inter-sentence linking=' + (data.parameters.interSentenceLinking ? 'on' : 'off (JHC 2002)') +
      ', tokenization file=' + (data.parameters.tokenizationFile || 'none'));
    lines.push('');
    lines.push('## Network summary');
    lines.push('');
    lines.push('| Measure | Value |');
    lines.push('|---|---|');
    lines.push('| Nodes | ' + net.nodes.length + ' |');
    lines.push('| Edges | ' + net.edges.length + ' |');
    ['degree', 'betweenness', 'closeness', 'eigenvector'].forEach(function (m) {
      var cap = m.charAt(0).toUpperCase() + m.slice(1);
      var note = (m === 'closeness' && s.closenessNote) ? s.closenessNote : '';
      lines.push('| ' + cap + ' centralization | ' +
        (c[m] === undefined || c[m] === null ? 'n/a' : fmt(c[m])) + note + ' |');
    });
    if (s.meanInfluence !== undefined) {
      lines.push('| Mean influence | ' + fmt(s.meanInfluence) + ' |');
    }
    if (s.componentCount !== undefined) {
      lines.push('| Network fragmentation | ' + s.componentCount + ' component(s); largest holds ' +
        fmt(s.largestComponentShare, 3) + ' of nodes |');
    }
    // ---- text-level metrics (D-12) ----
    if (data.textMetrics) {
      var tm = data.textMetrics;
      lines.push('');
      lines.push('## Text metrics');
      lines.push('');
      lines.push('| Metric | Value | Method |');
      lines.push('|---|---|---|');
      if (tm.sentiment !== null && tm.sentiment !== undefined) {
        lines.push('| Sentiment (-1 to +1; mean/sentence) | ' + tm.sentiment +
          ' | AFINN-165 (Nielsen, 2011), rescaled from ±5 |');
      }
      if (tm.genderedLanguage) {
        lines.push('| Gendered language index (+1 masc, -1 fem) | ' + tm.genderedLanguage.index +
          ' (M ' + tm.genderedLanguage.masculinePer1000 + '/1k, F ' +
          tm.genderedLanguage.femininePer1000 + '/1k) | Gaucher, Friesen, & Kay (2011) stems |');
      }
      if (tm.abstractness !== null && tm.abstractness !== undefined) {
        lines.push('| Abstractness (0 concrete - 1 abstract) | ' + tm.abstractness +
          ' | HEURISTIC: abstract-suffix nouns (see Brysbaert et al., 2014 for norms) |');
      }
      if (tm.agreeableness) {
        lines.push('| Agreeableness index (+1 agree, -1 disagree) | ' + tm.agreeableness.index +
          ' (A ' + tm.agreeableness.agreePer1000 + '/1k, D ' +
          tm.agreeableness.disagreePer1000 + '/1k) | HEURISTIC marker counts |');
      }
      if (tm.lexicalDiversity) {
        lines.push('| Lexical diversity MTLD | ' + tm.lexicalDiversity.mtld +
          ' (TTR ' + tm.lexicalDiversity.ttr + ', ' + tm.lexicalDiversity.types + ' types / ' +
          tm.lexicalDiversity.tokens + ' tokens) | McCarthy & Jarvis (2010) |');
      }
      if (tm.lexicalDensity !== null && tm.lexicalDensity !== undefined) {
        lines.push('| Lexical density (content words / all words) | ' + tm.lexicalDensity +
          ' | Ure (1971) |');
      }
      if (tm.readability) {
        lines.push('| Flesch Reading Ease | ' + tm.readability.fleschReadingEase +
          ' (FK grade ' + tm.readability.fleschKincaidGrade + '; ' +
          tm.readability.meanWordsPerSentence + ' words/sentence) | Kincaid et al. (1975) |');
      }
      if (tm.cohesion) {
        lines.push('| Cohesion: adjacent-sentence noun overlap | ' + tm.cohesion.adjacentNounOverlap +
          ' (global ' + tm.cohesion.globalNounOverlap + ') | Coh-Metrix-style (Graesser et al., 2004) |');
      }
      if (tm.hedging) {
        lines.push('| Certainty index (+1 boosted, -1 hedged) | ' + tm.hedging.certaintyIndex +
          ' (hedges ' + tm.hedging.hedgesPer1000 + '/1k, boosters ' +
          tm.hedging.boostersPer1000 + '/1k) | Hyland (2005) hedges/boosters |');
      }
      if (tm.pronounRates) {
        lines.push('| Pronoun rates per 1k (I / we / you / third) | ' +
          tm.pronounRates.firstSingularPer1000 + ' / ' + tm.pronounRates.firstPluralPer1000 +
          ' / ' + tm.pronounRates.secondPer1000 + ' / ' + tm.pronounRates.thirdPer1000 +
          ' | counted before CRA pronoun drop |');
      }
      if (tm.wordLength) {
        lines.push('| Word length (mean chars; share >= 7 chars) | ' + tm.wordLength.meanChars +
          '; ' + tm.wordLength.longWordShare + ' | sophistication proxy |');
      }
      if (tm.passiveRate !== null && tm.passiveRate !== undefined) {
        lines.push('| Passive voice (share of sentences) | ' + tm.passiveRate +
          ' | HEURISTIC: be-verb + participle pattern |');
      }
      if (tm.formality !== null && tm.formality !== undefined) {
        lines.push('| Formality F-score (~50 neutral; higher = formal) | ' + tm.formality +
          ' | Heylighen & Dewaele (1999) |');
      }
    }
    lines.push('');
    lines.push('## Influential words (influence > ' + DISPLAY_THRESHOLD + ')');
    lines.push('');
    lines.push('| Word | Degree | Influence | Connected to |');
    lines.push('|---|---|---|---|');
    net.nodes
      .filter(function (n) { return n.influence > DISPLAY_THRESHOLD; })
      .sort(function (a, b) { return b.influence - a.influence; })
      .forEach(function (n) {
        lines.push('| ' + (n.display || n.word) + ' | ' + n.degree + ' | ' +
          fmt(n.influence) + ' | ' + nbrs[n.id].sort().join(', ') + ' |');
      });
    lines.push('');
    lines.push('## Data (machine-readable — do not edit)');
    lines.push('');
    lines.push('```json');
    lines.push(JSON.stringify(data, null, 1));
    lines.push('```');
    lines.push('');
    lines.push('---');
    lines.push('*' + CITATION + '*');
    lines.push('');
    return lines.join('\n');
  }

  /* ------------------------------------------------------------------ *
   * Parsing  (_cra.md text -> data object)
   * ------------------------------------------------------------------ */

  /**
   * Parse a _cra.md file. Returns { ok, data, errors }.
   * Only the fenced JSON block is authoritative (spec §4.1).
   */
  function parseCra(text) {
    if (typeof text !== 'string') {
      return { ok: false, data: null, errors: ['Input is not text.'] };
    }
    var m = text.match(/```json\s*\n([\s\S]*?)\n```/);
    if (!m) {
      return {
        ok: false, data: null,
        errors: ['No machine-readable JSON block found. This is not a valid Crawdad _cra.md file (spec §4.1).']
      };
    }
    var data;
    try {
      data = JSON.parse(m[1]);
    } catch (e) {
      return { ok: false, data: null, errors: ['JSON block is corrupt: ' + e.message] };
    }
    var v = validateCra(data);
    return { ok: v.ok, data: v.ok ? data : data, errors: v.errors };
  }

  /* ------------------------------------------------------------------ *
   * Helpers for building a fresh data object (used by Generator in M2)
   * ------------------------------------------------------------------ */

  function newCraData(filename, parameters, appVersion) {
    return {
      schema: SCHEMA_NAME,
      schemaVersion: SCHEMA_VERSION,
      source: {
        filename: filename,
        processedAt: new Date().toISOString(),
        appVersion: appVersion || 'dev'
      },
      parameters: parameters || {
        stemming: 'porter',            // D-2 default
        pronouns: false,               // JHC p. 175 default
        interSentenceLinking: true,    // D-1 default
        tokenizationFile: null,
        stopWordList: 'default'
      },
      network: { nodes: [], edges: [] },
      summary: {}
    };
  }

  var api = {
    SCHEMA_NAME: SCHEMA_NAME,
    SCHEMA_VERSION: SCHEMA_VERSION,
    DISPLAY_THRESHOLD: DISPLAY_THRESHOLD,
    CITATION: CITATION,
    validateCra: validateCra,
    serializeCra: serializeCra,
    parseCra: parseCra,
    newCraData: newCraData
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;           // Node (tests)
  } else {
    root.CrawdadSchema = api;       // Browser
  }
})(typeof self !== 'undefined' ? self : this);
