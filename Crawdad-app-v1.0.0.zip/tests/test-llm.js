/*
 * Crawdad 2026 — M7 validation: Summarizer + LLM features.
 * Node:    node tests/test-llm.js
 * Browser: open tests/test-llm.html
 *
 * LLM tests use a MOCK transport (no key, no network): the machine gate for
 * M7 is that L-features degrade gracefully with no key and that prompts obey
 * the spec's hygiene rules (L-4 sends computed tables only).
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var LLM = isNode ? require('../js/llm.js') : root.CrawdadLLM;
  var T = isNode ? require('../js/themes.js') : root.CrawdadThemes;

  var results = [];
  var queue = Promise.resolve();
  function t(name, fn) { // supports promise-returning tests, run sequentially
    queue = queue.then(function () {
      return Promise.resolve().then(fn).then(function () {
        results.push({ name: name, pass: true });
      }, function (e) {
        results.push({ name: name, pass: false, msg: e.message });
      });
    });
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }

  function mkData(words, fname) {
    var nodes = [], i = 0;
    Object.keys(words).forEach(function (w) {
      nodes.push({ id: i++, word: w, display: w, degree: 0, influence: words[w] });
    });
    return { schema: 'crawdad-cra', schemaVersion: '1.0', source: { filename: fname },
      parameters: { stemming: 'porter' }, summary: {}, network: { nodes: nodes, edges: [] } };
  }

  /* ---------- Summarizer (spec §7.6) ---------- */

  t('summarizer: table equals Theme Identifier step (b) — summed influence, per-text columns', function () {
    var datas = [mkData({ scm: 0.1, cost: 0.05 }, 'a'), mkData({ scm: 0.1 }, 'b'),
                 mkData({ scm: 0.2, cost: 0.15 }, 'c')];
    var rep = T.summarizerReport(datas, ['a', 'b', 'c'], 'CITE-SENTINEL');
    assert(rep.wtm.words[0].word === 'scm', 'scm should rank first (sum 0.4)');
    assert(Math.abs(rep.wtm.words[0].sum - 0.4) < 1e-12, 'sum: ' + rep.wtm.words[0].sum);
    assert(rep.markdown.indexOf('| 1 | scm | 0.40000 | 0.10000 | 0.10000 | 0.20000 |') !== -1,
      'table row wrong');
    assert(rep.markdown.indexOf('CITE-SENTINEL') !== -1, 'citation');
    assert(/```json/.test(rep.markdown), 'JSON block');
  });

  /* ---------- graceful degradation (M7 machine gate) ---------- */

  t('no key: isEnabled false and calls reject with a helpful message', function () {
    LLM.configure({ apiKey: null, fetchFn: function () {
      throw new Error('network must not be touched without a key');
    } });
    assert(!LLM.isEnabled(), 'should be disabled');
    return LLM.narrativeSummary('# x').then(
      function () { throw new Error('should have rejected'); },
      function (e) {
        assert(e.message.indexOf('No API key') === 0, 'message: ' + e.message);
      });
  });

  /* ---------- mock transport ---------- */

  var captured = [];
  function mockFetch(reply) {
    return function (url, opts) {
      captured.push({ url: url, opts: opts, body: JSON.parse(opts.body) });
      return Promise.resolve({
        ok: true,
        json: function () {
          return Promise.resolve({ content: [{ text: reply }] });
        }
      });
    };
  }

  t('request shape: endpoint, key header, model, browser-access header', function () {
    captured.length = 0;
    LLM.configure({ apiKey: 'test-key-123', model: 'claude-sonnet-5',
      fetchFn: mockFetch('hello') });
    return LLM.callModel('sys', 'usr', 100).then(function (text) {
      assert(text === 'hello', 'reply');
      var c = captured[0];
      assert(c.url.indexOf('api.anthropic.com/v1/messages') !== -1, 'endpoint');
      assert(c.opts.headers['x-api-key'] === 'test-key-123', 'key header');
      assert(c.opts.headers['anthropic-dangerous-direct-browser-access'] === 'true', 'browser header');
      assert(c.body.model === 'claude-sonnet-5', 'model');
      assert(c.body.system === 'sys' && c.body.messages[0].content === 'usr', 'payload');
    });
  });

  t('L-4 prompt hygiene: JSON data block stripped; only tables sent; output labeled', function () {
    captured.length = 0;
    LLM.configure({ apiKey: 'k', fetchFn: mockFetch('A fine summary.') });
    var md = '# Report\n\n| a | b |\n|---|---|\n| 1 | 2 |\n\n' +
      '## Data (machine-readable — do not edit)\n\n```json\n{"SECRET_RAW":"stuff"}\n```\n';
    return LLM.narrativeSummary(md).then(function (out) {
      var sent = captured[0].body.messages[0].content;
      assert(sent.indexOf('SECRET_RAW') === -1, 'JSON block leaked into prompt');
      assert(sent.indexOf('| a | b |') !== -1, 'tables missing from prompt');
      assert(out.indexOf(LLM.DISCLAIMER) === 0, 'disclaimer missing');
    });
  });

  t('L-3 labels: parses strict-JSON reply; tolerates surrounding prose', function () {
    LLM.configure({ apiKey: 'k',
      fetchFn: mockFetch('Here you go:\n[{"name":"Theme 1","label":"Supply Chains"}]') });
    return LLM.suggestLabels([{ name: 'Theme 1', words: ['supply', 'chain'] }])
      .then(function (labels) {
        assert(labels.length === 1 && labels[0].label === 'Supply Chains', JSON.stringify(labels));
      });
  });

  t('L-1/L-2 prep: refuses over-length text with clear error (no silent truncation)', function () {
    LLM.configure({ apiKey: 'k', fetchFn: mockFetch('x') });
    var big = new Array(LLM.PREP_CHAR_LIMIT + 2).join('a');
    return LLM.prepText(big, true, false).then(
      function () { throw new Error('should have rejected'); },
      function (e) { assert(e.message.indexOf('too long') !== -1, e.message); });
  });

  t('L-1/L-2 prep: prompt states selected operations only', function () {
    captured.length = 0;
    LLM.configure({ apiKey: 'k', fetchFn: mockFetch('cleaned') });
    return LLM.prepText('Some text.', true, false).then(function () {
      var sys = captured[0].body.system;
      assert(sys.indexOf('boilerplate') !== -1, 'clean op missing');
      assert(sys.indexOf('pronoun') === -1, 'pronoun op should be absent');
    });
  });

  t('API error surfaces status and body snippet', function () {
    LLM.configure({ apiKey: 'k', fetchFn: function () {
      return Promise.resolve({ ok: false, status: 401,
        text: function () { return Promise.resolve('{"error":"invalid x-api-key"}'); } });
    } });
    return LLM.callModel('s', 'u').then(
      function () { throw new Error('should have rejected'); },
      function (e) {
        assert(e.message.indexOf('401') !== -1 && e.message.indexOf('invalid') !== -1, e.message);
      });
  });

  /* ---------- report ---------- */
  queue.then(function () {
    LLM.configure({ apiKey: null, fetchFn: undefined });
    var passed = results.filter(function (r) { return r.pass; }).length;
    var summary = 'M7 summarizer+LLM tests: ' + passed + '/' + results.length + ' passed';
    if (isNode) {
      results.forEach(function (r) {
        console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
      });
      console.log(summary);
      process.exit(passed === results.length ? 0 : 1);
    } else {
      root.CrawdadLlmTestResults = { results: results, summary: summary };
      if (root.CrawdadLlmTestDone) { root.CrawdadLlmTestDone(); }
    }
  });
})(typeof self !== 'undefined' ? self : this);
