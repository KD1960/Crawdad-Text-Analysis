/*
 * Crawdad 2026 — M1 parser tests.
 * Node:    node tests/test-parser.js   (needs wink-nlp + model in node_modules)
 * Browser: open tests/test-parser.html
 */
(function (root) {
  'use strict';

  var isNode = (typeof module !== 'undefined' && module.exports);
  var FIXTURE, parser;

  if (isNode) {
    FIXTURE = require('./fixture-parser.js');
    var P = require('../js/parser.js');
    parser = P.createParser(require('wink-nlp'), require('wink-eng-lite-web-model'), { compromise: require('compromise') });
  } else {
    FIXTURE = root.CrawdadParserFixture;
    parser = root.CrawdadParser.createParser();
  }

  var results = [];
  function t(name, fn) {
    try { fn(); results.push({ name: name, pass: true }); }
    catch (e) { results.push({ name: name, pass: false, msg: e.message }); }
  }
  function assert(c, m) { if (!c) { throw new Error(m || 'assertion failed'); } }

  /* ---- fixture F1 gate ---- */
  function toBag(phrases) {
    var bag = {};
    phrases.forEach(function (p) { p.forEach(function (w) { bag[w] = (bag[w] || 0) + 1; }); });
    return bag;
  }

  var tot = { tp: 0, predN: 0, goldN: 0 };
  var perSentence = [];
  FIXTURE.forEach(function (fx, idx) {
    var pred = parser.parse(fx.s).sentences[0].phrases;
    var g = toBag(fx.gold), p = toBag(pred), k;
    var tp = 0, pn = 0, gn = 0;
    for (k in p) { pn += p[k]; if (g[k]) { tp += Math.min(g[k], p[k]); } }
    for (k in g) { gn += g[k]; }
    tot.tp += tp; tot.predN += pn; tot.goldN += gn;
    perSentence.push({
      i: idx + 1, s: fx.s,
      gold: JSON.stringify(fx.gold), pred: JSON.stringify(pred),
      match: JSON.stringify(fx.gold) === JSON.stringify(pred)
    });
  });
  var P_ = tot.tp / tot.predN, R_ = tot.tp / tot.goldN;
  var F1 = 2 * P_ * R_ / (P_ + R_);

  t('fixture F1 >= 0.95 (got ' + F1.toFixed(3) + ')', function () {
    assert(F1 >= 0.95, 'F1 regression: ' + F1.toFixed(3));
  });
  t('fixture precision >= 0.95 (got ' + P_.toFixed(3) + ')', function () {
    assert(P_ >= 0.95, 'precision regression');
  });
  t('no head-noun losses on domain-critical phrases', function () {
    // "supply chain management" must retain all three words (compromise failed this)
    var pred = parser.parse('Supply chain management improves organizational performance.')
      .sentences[0].phrases;
    var flat = [].concat.apply([], pred);
    ['supply', 'chain', 'management', 'performance'].forEach(function (w) {
      assert(flat.indexOf(w) !== -1, 'lost "' + w + '"');
    });
  });
  t('pronouns dropped by default', function () {
    var pred = parser.parse('She sold the house.').sentences[0].phrases;
    var flat = [].concat.apply([], pred);
    assert(flat.indexOf('she') === -1, 'pronoun leaked');
    assert(flat.indexOf('house') !== -1, 'noun lost');
  });
  t('keepPronouns option retains pronouns', function () {
    var p2 = isNode
      ? require('../js/parser.js').createParser(require('wink-nlp'), require('wink-eng-lite-web-model'), { keepPronouns: true, compromise: require('compromise') })
      : root.CrawdadParser.createParser({ keepPronouns: true });
    var flat = [].concat.apply([], p2.parse('She sold the house.').sentences[0].phrases);
    assert(flat.indexOf('she') !== -1, 'pronoun not retained');
  });
  t('determiners never appear in phrases', function () {
    var pred = parser.parse('The committee approved the new policy during the pandemic.')
      .sentences[0].phrases;
    var flat = [].concat.apply([], pred);
    assert(flat.indexOf('the') === -1 && flat.indexOf('a') === -1, 'determiner leaked');
  });
  t('predicate adjectives are centers (WF 2h.i, D-14 regression)', function () {
    // Kevin's bug report 2026-07-28: "Dog was hungry" must yield node "hungry"
    var r = parser.parse('Dog was hungry. Cat was old and wise.');
    var flat = [].concat.apply([], [].concat.apply([],
      r.sentences.map(function (s) { return s.phrases; })));
    ['hungry', 'old', 'wise'].forEach(function (w) {
      assert(flat.indexOf(w) !== -1, 'predicate adjective lost: ' + w);
    });
  });

  t('multi-sentence segmentation', function () {
    var r = parser.parse('The king slept. The queen watched the castle.');
    assert(r.sentences.length === 2, 'expected 2 sentences, got ' + r.sentences.length);
  });
  t('empty/whitespace input yields no phrases', function () {
    var r = parser.parse('   ');
    var n = r.sentences.reduce(function (a, s) { return a + s.phrases.length; }, 0);
    assert(n === 0, 'phantom phrases from empty input');
  });

  t('underscore compounds survive parsing (tokenization fix 2026-08-09)', function () {
    // wink tokenizes "supply_chain" as supply / _ / chain; the parser must
    // re-join it so tokenization-file substitutions are not silently undone
    var r = parser.parse('We study supply_chain management decisions.');
    var flat = [];
    r.sentences[0].phrases.forEach(function (p) { p.forEach(function (w) { flat.push(w); }); });
    assert(flat.indexOf('supply_chain') !== -1, 'compound missing: ' + flat.join(','));
    assert(flat.indexOf('chain') === -1, 'compound was split: ' + flat.join(','));
  });
  t('multi-underscore compound joins fully', function () {
    var r = parser.parse('The supply_chain_management literature is growing.');
    var flat = [];
    r.sentences[0].phrases.forEach(function (p) { p.forEach(function (w) { flat.push(w); }); });
    assert(flat.indexOf('supply_chain_management') !== -1, 'got: ' + flat.join(','));
  });
  t('bare underscore token is not a word', function () {
    var r = parser.parse('The cat _ sat here.');
    var toks = r.sentences[0].tokens.map(function (t2) { return t2.w; });
    assert(toks.indexOf('_') === -1, 'bare underscore leaked into token stream');
  });

  var passed = results.filter(function (r) { return r.pass; }).length;
  var summary = 'M1 parser tests: ' + passed + '/' + results.length +
    ' passed | fixture P=' + P_.toFixed(3) + ' R=' + R_.toFixed(3) + ' F1=' + F1.toFixed(3);

  if (isNode) {
    results.forEach(function (r) {
      console.log((r.pass ? 'PASS' : 'FAIL') + '  ' + r.name + (r.msg ? ' — ' + r.msg : ''));
    });
    console.log(summary);
    console.log('\nPer-sentence (X = differs from gold):');
    perSentence.forEach(function (d) {
      console.log((d.match ? '  ' : 'X ') + 'S' + d.i + ' ' + d.s);
      if (!d.match) { console.log('    gold: ' + d.gold + '\n    pred: ' + d.pred); }
    });
    process.exit(passed === results.length ? 0 : 1);
  } else {
    root.CrawdadParserTestResults = { results: results, summary: summary, perSentence: perSentence };
  }
})(typeof self !== 'undefined' ? self : this);
