/*
 * Crawdad 2026 — stop-word list (spec §3.5).
 * Applied AFTER POS filtering, so this is a safety net for tokens the
 * tagger mis-labels as nouns/adjectives. User-editable in a later milestone.
 */
(function (root) {
  'use strict';

  var STOP_WORDS = [
    // articles/determiners & pronouns (belt-and-suspenders; POS filter handles most)
    'a', 'an', 'the', 'this', 'that', 'these', 'those', 'it', 'its', 'he', 'she',
    'him', 'her', 'his', 'hers', 'they', 'them', 'their', 'theirs', 'we', 'us',
    'our', 'ours', 'you', 'your', 'yours', 'i', 'me', 'my', 'mine', 'who', 'whom',
    'whose', 'which', 'what', 'one', 'ones', 'oneself', 'itself', 'himself',
    'herself', 'themselves', 'ourselves', 'yourself', 'myself', 'someone',
    'somebody', 'something', 'anyone', 'anybody', 'anything', 'everyone',
    'everybody', 'everything', 'noone', 'nobody', 'nothing', 'none', 'other',
    'others', 'another', 'such', 'same', 'each', 'either', 'neither', 'both',
    'all', 'any', 'some', 'few', 'many', 'much', 'more', 'most', 'several',
    'lot', 'lots', 'etc',
    // common function words occasionally mis-tagged
    'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'do', 'does', 'did',
    'have', 'has', 'had', 'can', 'could', 'will', 'would', 'shall', 'should',
    'may', 'might', 'must', 'not', 'no', 'yes', 'so', 'too', 'very', 'also',
    'just', 'only', 'then', 'than', 'there', 'here', 'when', 'where', 'why',
    'how', 'because', 'if', 'while', 'about', 'above', 'below', 'over', 'under',
    'again', 'further', 'once', 'own',
    // academic/citation abbreviations (backstop; cleaning removes most)
    'al', 'et', 'eg', 'ie', 'cf', 'ibid', 'viz', 'pp', 'vol', 'vols', 'ed',
    'eds', 'fig', 'figs', 'ch', 'sec', 'doi', 'http', 'https', 'www', 'com',
    'org', 'edu'
  ];

  var SET = {};
  STOP_WORDS.forEach(function (w) { SET[w] = true; });

  var api = {
    list: STOP_WORDS,
    isStopWord: function (w) { return SET[w] === true; }
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadStopWords = api; }
})(typeof self !== 'undefined' ? self : this);
