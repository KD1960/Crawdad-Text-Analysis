/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad 2026 — deterministic text cleaning + tokenization substitutions
 * (spec §6 step 2-3, §4.2). LLM-assisted cleaning is a separate optional
 * feature (§10 L-1); everything here is rule-based and reproducible.
 */
(function (root) {
  'use strict';

  /**
   * Rule-based cleaning:
   *  - strip markdown/HTML artifacts (headings, emphasis, links, code, tables, images)
   *  - repair words hyphenated across line breaks ("organiza-\ntion")
   *  - drop lines that are page numbers or repeated running headers/footers
   *  - normalize whitespace
   * Returns { text, notes: string[] } — notes describe what was removed.
   */
  function cleanText(raw) {
    var notes = [];
    var text = String(raw);

    // Normalize line endings
    text = text.replace(/\r\n?/g, '\n');

    // Unicode normalization (fix 2026-10-28, parser diagnostics): Word/PDF
    // text carries curly apostrophes/quotes, non-breaking and typographic
    // spaces, and soft hyphens. Left alone, a curly possessive ("firm’s")
    // loses its apostrophe at the parser's character filter and sheds a bare
    // "s" into the token stream, and an NBSP can hide a citation from the
    // rules below. Normalized BEFORE every other rule so the rules see one
    // spelling.
    var uniCount = (text.match(/[‘’ʼ“”   -   　­​⁠﻿]/g) || []).length;
    if (uniCount) {
      text = text
        .replace(/[‘’ʼ]/g, "'")
        .replace(/[“”]/g, '"')
        .replace(/[   -   　]/g, ' ')
        .replace(/[­​⁠﻿]/g, '');
      notes.push('Normalized ' + uniCount + ' typographic character(s) (curly quotes/apostrophes, non-breaking spaces, soft hyphens).');
    }

    // Trailing bibliography (fix 2026-08-09): a heading-like line reading
    // "References" / "Bibliography" / "Works Cited" / "Literature Cited" in
    // the last 60% of the document drops everything from that line to the
    // end (resuming at an "Appendix" heading if one follows). Reference
    // lists otherwise flood the network with author-name nodes.
    var refLines = text.split('\n');
    var refRe = /^\s*(?:#{1,6}\s*)?(?:[*_]{1,2})?\s*(?:[IVX]{1,4}\.?\s+|\d{1,2}\.?\s+)?(references|bibliography|works\s+cited|literature\s+cited|references\s+cited)\s*(?:[*_]{1,2})?\s*:?\s*$/i;
    // Unconditional cut when the heading sits in the last 60% of lines; from
    // the 20% mark a match must be corroborated by reference-looking content
    // (>= 3 of the next 10 non-empty lines carry a 4-digit year) — long
    // reference lists can occupy most of a document (Kevin's report
    // 2026-08-11), but a mid-document heading alone is not proof.
    var refStartLoose = Math.floor(refLines.length * 0.2);
    var refStartStrict = Math.floor(refLines.length * 0.4);
    function corroborated(idx) {
      var seen = 0, withYear = 0;
      for (var j = idx + 1; j < refLines.length && seen < 10; j++) {
        var ln = refLines[j].trim();
        if (!ln) { continue; }
        seen++;
        if (/\b(1[5-9]\d{2}|20\d{2})[a-z]?\b/.test(ln)) { withYear++; }
      }
      return withYear >= 3;
    }
    var refIdx = -1;
    for (var rl = refLines.length - 1; rl >= refStartLoose; rl--) {
      if (!refRe.test(refLines[rl])) { continue; }
      if (rl >= refStartStrict || corroborated(rl)) { refIdx = rl; } // earliest wins
    }
    if (refIdx !== -1) {
      var appRe = /^\s*(?:#{1,6}\s*)?(?:[*_]{1,2})?\s*appendix\b/i;
      var appIdx = -1;
      for (var al = refIdx + 1; al < refLines.length; al++) {
        if (appRe.test(refLines[al])) { appIdx = al; break; }
      }
      var kept = refLines.slice(0, refIdx);
      var dropped = (appIdx === -1 ? refLines.length : appIdx) - refIdx;
      if (appIdx !== -1) { kept = kept.concat(refLines.slice(appIdx)); }
      text = kept.join('\n');
      notes.push('Removed reference list: ' + dropped + ' line(s) from "' +
        refLines[refIdx].trim().slice(0, 40) + '"' +
        (appIdx !== -1 ? ' (kept appendix that follows)' : ' to end of text') + '.');
    }

    // Narrative citations (Kevin's report 2026-08-11): author name run,
    // optional "et al.", then a parenthetical year — the WHOLE construct is
    // removed so author surnames stop becoming network nodes.
    // e.g. "Dooley et al. (2026)", "Corman, Kuhn, McPhee, & Dooley (2002)",
    // "Dooley and Corman (2004)". Name run capped at 5 tokens.
    // 2026-10-28 (parser diagnostics): name tokens now accept Latin-1 /
    // Latin-Extended capitals ("Müller"), surnames may carry lowercase or
    // capitalized particles ("van der Berg", "VAN DER BERG", "de Vries"),
    // and every et-al pattern accepts the "et. al." typo and "et al" without
    // a period.
    var NAME_PARTICLE = "(?:[Vv][Aa][Nn](?:[Dd][Ee][NnRr])?|[Vv][Oo][Nn]|[Dd][Ee][Ll][Ll][Aa]|[Dd][Ee][LlNnRr]?|[Dd][IiAaUu]|[Ll][AaEe]|[Tt][Ee][NnRr])";
    var NAME_TOKEN = "[A-Z\\u00C0-\\u00DE\\u0100-\\u017F][A-Za-z\\u00C0-\\u00FF\\u0100-\\u017F'\\u2019-]+";
    var NAME_ONE = "(?:" + NAME_PARTICLE + "\\s+){0,3}" + NAME_TOKEN;
    var NAME_RUN = NAME_ONE + "(?:\\s*,\\s*(?:(?:and|&)\\s+)?" + NAME_ONE + "|\\s+(?:and|&)\\s+" + NAME_ONE + "){0,5}";
    var ETAL = "et\\.?\\s*al\\.?";
    var narrRe = new RegExp('\\b' + NAME_RUN +
      "\\s*,?\\s*(?:" + ETAL + ",?\\s*)?\\(\\s*(?:1[5-9]\\d{2}|20\\d{2})[a-z]?[^)]{0,30}\\)", 'g');
    var narr = (text.match(narrRe) || []).length;
    if (narr) {
      text = text.replace(narrRe, ' ');
      notes.push('Removed ' + narr + ' narrative citation(s) (author name + year).');
    }
    // Author name(s) directly attached to "et al." without a year; a
    // possessive ("Kleindorfer et al.'s review") is consumed too, so no
    // orphaned "'s" is left in the sentence
    var etalNameRe = new RegExp("\\b(?:" + NAME_ONE + "\\s*,?\\s+){1,4}" + ETAL + "(?:['\\u2019]s)?", 'g');
    var etalNames = (text.match(etalNameRe) || []).length;
    if (etalNames) {
      text = text.replace(etalNameRe, ' ');
      notes.push('Removed ' + etalNames + ' "Name et al." citation fragment(s).');
    }
    // Bracketed author-year citations, e.g. [Dooley 2026] — requires a
    // capitalized name inside the bracket, so editorial brackets like
    // "[of 1850]" in historical transcripts are left alone (golden-corpus
    // check 2026-08-11)
    var brAYRe = /\[[^\[\]]{0,40}\b[A-Z][a-z][A-Za-z'\u2019-]*\b[^\[\]]{0,40}\b(1[5-9]\d{2}|20\d{2})[a-z]?\b[^\[\]]{0,40}\]/g;
    var brAY = (text.match(brAYRe) || []).length;
    if (brAY) {
      text = text.replace(brAYRe, ' ');
      notes.push('Removed ' + brAY + ' bracketed author-year citation(s).');
    }

    // Numbered bracket citations, e.g. [12] or [3, 7] or [1-4]
    var brackets = (text.match(/\[\s*\d{1,3}(?:\s*[-–—,;]\s*\d{1,3})*\s*\]/g) || []).length;
    if (brackets) {
      text = text.replace(/\[\s*\d{1,3}(?:\s*[-–—,;]\s*\d{1,3})*\s*\]/g, ' ');
      notes.push('Removed ' + brackets + ' numbered bracket citation(s).');
    }
    // DOIs, e.g. "doi:10.1093/..." or bare "10.1177/0001839212437859"
    var dois = (text.match(/\bdoi:\s*\S+|\b10\.\d{4,9}\/[^\s,;)\]]+/gi) || []).length;
    if (dois) {
      text = text.replace(/\bdoi:\s*\S+|\b10\.\d{4,9}\/[^\s,;)\]]+/gi, ' ');
      notes.push('Removed ' + dois + ' DOI(s).');
    }

    // Period-marked titles and abbreviations (fix 2026-10-28, parser
    // diagnostics: "Dr.", "Mr.", "Inc.", "Jan.", "St.", "approx." became
    // network nodes, some with non-trivial influence). Matched ONLY with
    // their trailing period, so bare words and names ("Jan Smith", "the inc")
    // are untouched. Case-sensitive for forms that collide with common
    // lowercase words ("No.", "Co."); lowercase accepted only where safe.
    var ABBR_RE = /\b(?:Dr|Mr|Mrs|Ms|Messrs|Prof|Rev|Hon|Sen|Rep|Gov|Capt|Gen|Col|Maj|Sgt|Lt|Jr|Sr|St|Mt|Ft|Inc|Corp|Ltd|LLC|Co|Bros|Dept|Univ|Assn|Fig|Figs|Eq|Eqs|Sec|Vol|Vols|No|Nos|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec|[Aa]pprox|ca|pp|Ph\.?\s?D|[AaPp]\.\s?[Mm])\.(?=[\s,;:)\]'"]|$)/g;
    var abbrs = (text.match(ABBR_RE) || []).length;
    if (abbrs) {
      text = text.replace(ABBR_RE, ' ');
      notes.push('Removed ' + abbrs + ' period-marked title/abbreviation token(s) (Dr., Inc., Jan., Ph.D., a.m., ...).');
    }

    // Academic citation artifacts (would otherwise become spurious nodes,
    // e.g. "al" from "et al."). The pattern tolerates the common "et. al."
    // typo and the period-less "et al" (2026-10-28), and strips a possessive
    // left dangling by the removal ("et al.'s model" -> "model").
    var etal = (text.match(/\bet\.?\s*al\.?(?:['’]s)?/gi) || []).length;
    if (etal) {
      text = text.replace(/\bet\.?\s*al\.?(?:['’]s)?/gi, '');
      notes.push('Removed ' + etal + ' "et al." citation fragment(s).');
    }
    // Bare URLs and web addresses (validation study V1 finding: URL fragments
    // otherwise become spurious network nodes)
    var urls = (text.match(/\b(?:https?:\/\/|www\.)\S+|\b[\w-]+(?:\.[\w-]+)*\.(?:com|org|edu|gov|net|io)(?:\/\S*)?/gi) || []).length;
    if (urls) {
      text = text.replace(/\b(?:https?:\/\/|www\.)\S+|\b[\w-]+(?:\.[\w-]+)*\.(?:com|org|edu|gov|net|io)(?:\/\S*)?/gi, ' ');
      notes.push('Removed ' + urls + ' bare URL(s)/web address(es).');
    }

    // Parenthetical citations containing a year, e.g. "(Grosz, Weinstein, & Joshi, 1995)"
    var cites = (text.match(/\([^()]*\b(1[5-9]\d{2}|20\d{2})[a-z]?\b[^()]*\)/g) || []).length;
    if (cites) {
      text = text.replace(/\([^()]*\b(1[5-9]\d{2}|20\d{2})[a-z]?\b[^()]*\)/g, ' ');
      notes.push('Removed ' + cites + ' parenthetical citation(s) containing a year.');
    }

    // Repair hyphenation across line breaks BEFORE other line surgery
    var hyphens = (text.match(/([a-z])-\n\s*([a-z])/g) || []).length;
    if (hyphens) {
      text = text.replace(/([a-z])-\n\s*([a-z])/g, '$1$2');
      notes.push('Rejoined ' + hyphens + ' line-break hyphenation(s).');
    }

    // Markdown/HTML artifacts
    text = text
      .replace(/```[\s\S]*?```/g, ' ')            // fenced code blocks
      .replace(/^\s{0,3}#{1,6}\s+/gm, '')         // heading markers (keep heading text)
      .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')      // images
      .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')    // links -> link text
      .replace(/^[|].*[|]\s*$/gm, ' ')            // markdown table rows
      .replace(/^[-=*_]{3,}\s*$/gm, ' ')          // horizontal rules
      .replace(/[*_]{1,3}([^*_]+)[*_]{1,3}/g, '$1') // emphasis
      .replace(/<[^>\n]{1,80}>/g, ' ');           // inline HTML tags

    var lines = text.split('\n');

    // Detect repeated running headers/footers: identical non-trivial lines
    // appearing 4+ times (e.g., journal headers on every PDF page).
    var freq = Object.create(null);
    lines.forEach(function (ln) {
      var key = ln.trim();
      if (key.length >= 8) { freq[key] = (freq[key] || 0) + 1; }
    });
    var headerKeys = Object.keys(freq).filter(function (k) { return freq[k] >= 4; });
    if (headerKeys.length) {
      notes.push('Removed repeated running header/footer line(s): ' +
        headerKeys.map(function (k) { return '"' + k.slice(0, 60) + '" x' + freq[k]; }).join('; '));
    }
    var headerSet = Object.create(null);
    headerKeys.forEach(function (k) { headerSet[k] = true; });

    var pageNums = 0;
    lines = lines.filter(function (ln) {
      var s = ln.trim();
      if (headerSet[s]) { return false; }
      if (/^\d{1,4}$/.test(s)) { pageNums++; return false; }  // bare page numbers
      return true;
    });
    if (pageNums) { notes.push('Removed ' + pageNums + ' bare page-number line(s).'); }

    text = lines.join('\n')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    return { text: text, notes: notes };
  }

  /* ------------------------------------------------------------------ *
   * Tokenization substitution file (spec §4.2)
   * ------------------------------------------------------------------ */

  /** Parse a simple CSV (2 columns, optional quotes). Returns [[find, replace], ...] */
  function parseCsvPairs(csvText) {
    var pairs = [];
    String(csvText).replace(/\r\n?/g, '\n').split('\n').forEach(function (line) {
      if (!line.trim()) { return; }
      var cells = [];
      var re = /("([^"]*)"|[^,]*)(,|$)/g, m;
      while (cells.length < 2 && (m = re.exec(line)) !== null) {
        cells.push((m[2] !== undefined ? m[2] : m[1]).trim());
        if (m[3] === '') { break; }
      }
      if (cells.length >= 2 && cells[0]) { pairs.push([cells[0], cells[1]]); }
    });
    return pairs;
  }

  /** Parse .xlsx via SheetJS (vendor/xlsx.full.min.js), first sheet, cols A/B. */
  function parseXlsxPairs(arrayBuffer) {
    if (!root.XLSX) { throw new Error('SheetJS not loaded (vendor/xlsx.full.min.js missing).'); }
    var wb = root.XLSX.read(arrayBuffer, { type: 'array' });
    var ws = wb.Sheets[wb.SheetNames[0]];
    var rows = root.XLSX.utils.sheet_to_json(ws, { header: 1, raw: false });
    var pairs = [];
    rows.forEach(function (r) {
      if (r && r[0] !== undefined && r[1] !== undefined && String(r[0]).trim()) {
        pairs.push([String(r[0]).trim(), String(r[1]).trim()]);
      }
    });
    return pairs;
  }

  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  /**
   * Apply substitutions: case-insensitive, longest-find-first, whole-word
   * boundaries (spec §4.2). Returns { text, counts: {find: n} }.
   */
  function applySubstitutions(text, pairs) {
    var counts = {};
    var sorted = pairs.slice().sort(function (a, b) { return b[0].length - a[0].length; });
    sorted.forEach(function (p) {
      var re = new RegExp('\\b' + escapeRe(p[0]) + '\\b', 'gi');
      var n = 0;
      text = text.replace(re, function () { n++; return p[1]; });
      if (n) { counts[p[0]] = n; }
    });
    return { text: text, counts: counts };
  }

  /* ------------------------------------------------------------------ *
   * Tokenization suggestions (2026-08-09)
   * ------------------------------------------------------------------ */

  /**
   * Suggest multi-word tokenization candidates from adjacent co-occurrence
   * of center words WITHIN noun phrases (parser output, surface forms —
   * substitutions apply to raw text, so suggestions must be surface forms).
   * A pair/triple of words that repeatedly appears adjacent in the same
   * noun phrase is a candidate single concept ("supply chain").
   *
   * V2-M2 (spec §3.3): candidates are ranked by NPMI (Bouma, 2009) rather
   * than raw count, with log-Dice (Rychlý, 2008) reported alongside; raw
   * count still shown. Counting convention (Manning & Schütze / Bouma):
   * N = tokens in the within-phrase center stream; p(w)=f(w)/N and
   * p(ngram)=f(ngram)/N over that same stream. For trigrams the Bouma
   * normalization generalizes to PMI3 / (-2 ln p(xyz)) and log-Dice to
   * 14 + log2(3 f / (fx+fy+fz)) — both documented generalizations.
   *
   * parsedSentences: parser.parse().sentences
   * opts: { minCount (default 3), maxSuggestions (default 20),
   *         isStopWord (fn), existingPairs ([[find, replace], ...]) }
   * Returns { suggestions: [{ phrase, replacement, count, words, npmi,
   *           logDice, wordCounts }], nTokens } — suggestions sorted by
   * NPMI desc. Candidates only — whether a phrase denotes one concept is
   * the analyst's judgment.
   */
  function suggestTokenizations(parsedSentences, opts) {
    opts = opts || {};
    var minCount = opts.minCount || 3;
    var maxSuggestions = opts.maxSuggestions || 20;
    var isStop = opts.isStopWord || function () { return false; };
    var already = Object.create(null);
    (opts.existingPairs || []).forEach(function (p) {
      already[String(p[0]).toLowerCase().replace(/\s+/g, ' ').trim()] = true;
    });

    var counts = Object.create(null); // "w1 w2" or "w1 w2 w3" -> n
    var uni = Object.create(null);    // token -> count over the phrase stream
    var nTokens = 0;
    function bump(words) {
      for (var i = 0; i < words.length; i++) {
        if (words[i].length < 2 || isStop(words[i]) ||
            words[i].indexOf('_') !== -1) { return; } // already a compound
      }
      var key = words.join(' ');
      if (already[key]) { return; }
      counts[key] = (counts[key] || 0) + 1;
    }
    (parsedSentences || []).forEach(function (s) {
      (s.phrases || []).forEach(function (p) {
        for (var u = 0; u < p.length; u++) {
          uni[p[u]] = (uni[p[u]] || 0) + 1; nTokens++;
        }
        for (var i = 0; i + 1 < p.length; i++) {
          bump([p[i], p[i + 1]]);
          if (i + 2 < p.length) { bump([p[i], p[i + 1], p[i + 2]]); }
        }
      });
    });

    function assoc(key) {
      // NPMI (Bouma, 2009) + log-Dice (Rychlý, 2008) from the same stream
      var ws = key.split(' ');
      var f = counts[key];
      var fw = ws.map(function (w) { return uni[w] || 0; });
      var n = ws.length;
      var pJoint = f / nTokens;
      var logPProd = 0;
      for (var i = 0; i < n; i++) { logPProd += Math.log(fw[i] / nTokens); }
      var pmi = Math.log(pJoint) - logPProd;
      var npmi = pmi / (-(n - 1) * Math.log(pJoint));
      var sumF = fw.reduce(function (a, b) { return a + b; }, 0);
      var logDice = 14 + Math.log(n * f / sumF) / Math.LN2;
      return { npmi: round4(npmi), logDice: round4(logDice), wordCounts: fw };
    }
    function round4(x) { return Math.round(x * 1e4) / 1e4; }

    var out = Object.keys(counts)
      .filter(function (k) { return counts[k] >= minCount; })
      .map(function (k) {
        var a = assoc(k);
        return {
          phrase: k,
          replacement: k.replace(/\s+/g, '_'),
          count: counts[k],
          words: k.split(' ').length,
          npmi: a.npmi,
          logDice: a.logDice,
          wordCounts: a.wordCounts
        };
      })
      .sort(function (a, b) {
        return b.npmi - a.npmi || b.count - a.count ||
          (a.phrase < b.phrase ? -1 : 1);
      });
    return { suggestions: out.slice(0, maxSuggestions), nTokens: nTokens };
  }

  var api = {
    cleanText: cleanText,
    parseCsvPairs: parseCsvPairs,
    parseXlsxPairs: parseXlsxPairs,
    applySubstitutions: applySubstitutions,
    suggestTokenizations: suggestTokenizations
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadTextClean = api; }
})(typeof self !== 'undefined' ? self : this);
