/* browser wrapper for fixture-vader.json */
(function(root){root.CrawdadVaderFixture=[
 {
  "text": "VADER is smart, handsome, and funny.",
  "ref": {
   "neg": 0.0,
   "neu": 0.254,
   "pos": 0.746,
   "compound": 0.8316
  }
 },
 {
  "text": "VADER is smart, handsome, and funny!",
  "ref": {
   "neg": 0.0,
   "neu": 0.248,
   "pos": 0.752,
   "compound": 0.8439
  }
 },
 {
  "text": "VADER is very smart, handsome, and funny.",
  "ref": {
   "neg": 0.0,
   "neu": 0.299,
   "pos": 0.701,
   "compound": 0.8545
  }
 },
 {
  "text": "VADER is VERY SMART, handsome, and FUNNY.",
  "ref": {
   "neg": 0.0,
   "neu": 0.246,
   "pos": 0.754,
   "compound": 0.9227
  }
 },
 {
  "text": "VADER is VERY SMART, handsome, and FUNNY!!!",
  "ref": {
   "neg": 0.0,
   "neu": 0.233,
   "pos": 0.767,
   "compound": 0.9342
  }
 },
 {
  "text": "VADER is VERY SMART, uber handsome, and FRIGGIN FUNNY!!!",
  "ref": {
   "neg": 0.0,
   "neu": 0.294,
   "pos": 0.706,
   "compound": 0.9469
  }
 },
 {
  "text": "VADER is not smart, handsome, nor funny.",
  "ref": {
   "neg": 0.646,
   "neu": 0.354,
   "pos": 0.0,
   "compound": -0.7424
  }
 },
 {
  "text": "The book was good.",
  "ref": {
   "neg": 0.0,
   "neu": 0.508,
   "pos": 0.492,
   "compound": 0.4404
  }
 },
 {
  "text": "At least it isn't a horrible book.",
  "ref": {
   "neg": 0.0,
   "neu": 0.678,
   "pos": 0.322,
   "compound": 0.431
  }
 },
 {
  "text": "The book was only kind of good.",
  "ref": {
   "neg": 0.0,
   "neu": 0.697,
   "pos": 0.303,
   "compound": 0.3832
  }
 },
 {
  "text": "The plot was good, but the characters are uncompelling and the dialog is not great.",
  "ref": {
   "neg": 0.327,
   "neu": 0.579,
   "pos": 0.094,
   "compound": -0.7042
  }
 },
 {
  "text": "Today SUX!",
  "ref": {
   "neg": 0.779,
   "neu": 0.221,
   "pos": 0.0,
   "compound": -0.5461
  }
 },
 {
  "text": "Today only kinda sux! But I'll get by, lol",
  "ref": {
   "neg": 0.127,
   "neu": 0.556,
   "pos": 0.317,
   "compound": 0.5249
  }
 },
 {
  "text": "Make sure you :) or :D today!",
  "ref": {
   "neg": 0.0,
   "neu": 0.294,
   "pos": 0.706,
   "compound": 0.8633
  }
 },
 {
  "text": "Not bad at all",
  "ref": {
   "neg": 0.0,
   "neu": 0.513,
   "pos": 0.487,
   "compound": 0.431
  }
 },
 {
  "text": "The company failed to make an interest payment on a $90 million bond.",
  "ref": {
   "neg": 0.191,
   "neu": 0.636,
   "pos": 0.173,
   "compound": -0.0772
  }
 },
 {
  "text": "Iridium was forced to file for Chapter 11 bankruptcy protection.",
  "ref": {
   "neg": 0.25,
   "neu": 0.75,
   "pos": 0.0,
   "compound": -0.4588
  }
 },
 {
  "text": "Motorola projected that it could attain 5 million users by the end of the 1990s.",
  "ref": {
   "neg": 0.0,
   "neu": 1.0,
   "pos": 0.0,
   "compound": 0.0
  }
 },
 {
  "text": "The satellites were launched successfully, a colossal engineering accomplishment.",
  "ref": {
   "neg": 0.0,
   "neu": 0.598,
   "pos": 0.402,
   "compound": 0.5719
  }
 },
 {
  "text": "Investors were wary, and the stock plummeted amid mounting losses.",
  "ref": {
   "neg": 0.231,
   "neu": 0.769,
   "pos": 0.0,
   "compound": -0.4019
  }
 },
 {
  "text": "It is not a terrible outcome, but hardly a success either.",
  "ref": {
   "neg": 0.0,
   "neu": 0.584,
   "pos": 0.416,
   "compound": 0.7513
  }
 },
 {
  "text": "The service was never so expensive as critics claimed.",
  "ref": {
   "neg": 0.235,
   "neu": 0.765,
   "pos": 0.0,
   "compound": -0.3535
  }
 },
 {
  "text": "Without doubt the strongest quarter in the company's history.",
  "ref": {
   "neg": 0.0,
   "neu": 0.583,
   "pos": 0.417,
   "compound": 0.6136
  }
 },
 {
  "text": "There is no good reason to doubt the guarantee.",
  "ref": {
   "neg": 0.38,
   "neu": 0.465,
   "pos": 0.155,
   "compound": -0.4416
  }
 },
 {
  "text": "The board did not approve the restructuring plan.",
  "ref": {
   "neg": 0.0,
   "neu": 1.0,
   "pos": 0.0,
   "compound": 0.0
  }
 },
 {
  "text": "Analysts were skeptical yet cautiously optimistic about the merger.",
  "ref": {
   "neg": 0.198,
   "neu": 0.603,
   "pos": 0.198,
   "compound": 0.0
  }
 },
 {
  "text": "This was the least profitable venture in Motorola's portfolio.",
  "ref": {
   "neg": 0.231,
   "neu": 0.769,
   "pos": 0.0,
   "compound": -0.3412
  }
 },
 {
  "text": "At least the litigation is over.",
  "ref": {
   "neg": 0.265,
   "neu": 0.735,
   "pos": 0.0,
   "compound": -0.2023
  }
 },
 {
  "text": "The product was kind of a disaster, to be honest.",
  "ref": {
   "neg": 0.266,
   "neu": 0.519,
   "pos": 0.214,
   "compound": -0.2023
  }
 },
 {
  "text": "No fewer than nineteen partners joined the consortium.",
  "ref": {
   "neg": 0.239,
   "neu": 0.761,
   "pos": 0.0,
   "compound": -0.296
  }
 },
 {
  "text": "The rocket didn't explode, which was a relief.",
  "ref": {
   "neg": 0.0,
   "neu": 0.693,
   "pos": 0.307,
   "compound": 0.4767
  }
 },
 {
  "text": "AMAZING performance, yet the reviews were HARDLY enthusiastic???",
  "ref": {
   "neg": 0.0,
   "neu": 0.408,
   "pos": 0.592,
   "compound": 0.8662
  }
 },
 {
  "text": "The deal is dead. Long live the deal!!",
  "ref": {
   "neg": 0.411,
   "neu": 0.589,
   "pos": 0.0,
   "compound": -0.7081
  }
 },
 {
  "text": "Rarely has a project been so celebrated and so doomed.",
  "ref": {
   "neg": 0.261,
   "neu": 0.464,
   "pos": 0.275,
   "compound": 0.064
  }
 },
 {
  "text": "They could scarcely afford the repayment, let alone growth.",
  "ref": {
   "neg": 0.172,
   "neu": 0.603,
   "pos": 0.224,
   "compound": 0.1531
  }
 },
 {
  "text": "the shit hit the fan and everything went wrong",
  "ref": {
   "neg": 0.447,
   "neu": 0.4,
   "pos": 0.153,
   "compound": -0.6597
  }
 },
 {
  "text": "That presentation was the bomb, seriously impressive work.",
  "ref": {
   "neg": 0.0,
   "neu": 0.294,
   "pos": 0.706,
   "compound": 0.9186
  }
 },
 {
  "text": "Their so-called strategy was a kiss of death for the brand.",
  "ref": {
   "neg": 0.357,
   "neu": 0.643,
   "pos": 0.0,
   "compound": -0.6124
  }
 },
 {
  "text": "A pretty bad ass satellite system, to die for really.",
  "ref": {
   "neg": 0.387,
   "neu": 0.314,
   "pos": 0.298,
   "compound": -0.4019
  }
 },
 {
  "text": "Uh-uh, no way, that plan won't succeed.",
  "ref": {
   "neg": 0.276,
   "neu": 0.525,
   "pos": 0.198,
   "compound": -0.1877
  }
 },
 {
  "text": "The outcome was neither good nor bad.",
  "ref": {
   "neg": 0.488,
   "neu": 0.512,
   "pos": 0.0,
   "compound": -0.5824
  }
 },
 {
  "text": "Hardly anyone believed the hype, but the technology mostly worked.",
  "ref": {
   "neg": 0.0,
   "neu": 1.0,
   "pos": 0.0,
   "compound": 0.0
  }
 },
 {
  "text": "Never so happy as when the network finally worked!",
  "ref": {
   "neg": 0.0,
   "neu": 0.614,
   "pos": 0.386,
   "compound": 0.7213
  }
 },
 {
  "text": "It wasn't just good, it was extraordinarily good!!",
  "ref": {
   "neg": 0.202,
   "neu": 0.505,
   "pos": 0.293,
   "compound": 0.2681
  }
 },
 {
  "text": "Costs increased considerably, margins shrank, morale collapsed.",
  "ref": {
   "neg": 0.228,
   "neu": 0.543,
   "pos": 0.228,
   "compound": 0.0
  }
 },
 {
  "text": "A somewhat disappointing quarter despite record subscriber growth.",
  "ref": {
   "neg": 0.459,
   "neu": 0.541,
   "pos": 0.0,
   "compound": -0.6238
  }
 },
 {
  "text": "The CEO resigned amid the fiasco and tension on the board.",
  "ref": {
   "neg": 0.487,
   "neu": 0.513,
   "pos": 0.0,
   "compound": -0.765
  }
 },
 {
  "text": "sort of okay I guess",
  "ref": {
   "neg": 0.0,
   "neu": 0.678,
   "pos": 0.322,
   "compound": 0.2263
  }
 },
 {
  "text": "Was the launch successful? Was it worth it?? Who knows???",
  "ref": {
   "neg": 0.0,
   "neu": 0.546,
   "pos": 0.454,
   "compound": 0.7691
  }
 },
 {
  "text": "Absolutely, positively the worst decision in corporate history.",
  "ref": {
   "neg": 0.31,
   "neu": 0.427,
   "pos": 0.263,
   "compound": -0.1706
  }
 }
];})(typeof self!=='undefined'?self:this);
