/*
 * Crawdad Text Analysis Software
 * Copyright 2026 Kevin J. Dooley
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License; see LICENSE in
 * the distribution root. Distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/*
 * Crawdad 2026 — M2: CRA network construction and influence (spec §3.2–§3.4)
 *
 * Linking rules:
 *   L1  center words within an utterance linked sequentially
 *   L2  all pairs within any noun phrase of >= 3 words
 *   L3  last center word of sentence s linked to first of s+1 (D-1;
 *       disable via options.interSentenceLinking = false for "JHC 2002" mode)
 *
 * Network: symmetric, undirected, VALUED — F_ij counts link occurrences.
 * Influence: normalized betweenness (Eq. 1) on the BINARIZED graph (§3.3).
 */
(function (root) {
  'use strict';

  /* ---------------- word normalization (spec §3.5) ---------------- */

  function minimalStem(w) {
    // JHC p. 175: plural -> singular only. Conservative: -es / -s (not -ss).
    if (/[a-z]es$/.test(w) && w.length > 3) { return w.slice(0, -2); }
    if (/[a-z]s$/.test(w) && !/ss$/.test(w) && w.length > 2) { return w.slice(0, -1); }
    return w;
  }

  // Irregular plural -> singular exceptions, applied before the stemmer
  // (fix 2026-10-28, parser diagnostics: porter2 stems the two members of
  // crisis/crises, criterion/criteria, child/children, man/men, foot/feet
  // differently, so each pair yielded two network nodes; JHC p. 175's
  // intent is plural -> singular). The table is deliberately short and
  // restricted to forms with a single reading; plurals that collide with
  // other lemmas (axes, bases, media, people, dice) are excluded.
  var IRREGULAR_PLURALS = {
    analyses: 'analysis', crises: 'crisis', theses: 'thesis',
    hypotheses: 'hypothesis', diagnoses: 'diagnosis', syntheses: 'synthesis',
    emphases: 'emphasis', parentheses: 'parenthesis', oases: 'oasis',
    criteria: 'criterion', phenomena: 'phenomenon', strata: 'stratum',
    data: 'datum', curricula: 'curriculum', memoranda: 'memorandum',
    children: 'child', men: 'man', women: 'woman', feet: 'foot',
    teeth: 'tooth', geese: 'goose', mice: 'mouse', oxen: 'ox',
    indices: 'index', matrices: 'matrix', appendices: 'appendix',
    vertices: 'vertex', apices: 'apex'
  };
  function singularizeIrregular(w) {
    return Object.prototype.hasOwnProperty.call(IRREGULAR_PLURALS, w)
      ? IRREGULAR_PLURALS[w] : w;
  }

  /**
   * Normalize parsed sentences: stop-word removal + stemming.
   * sentences: [{ text, phrases: [[surfaceWord,...],...] }]
   * Returns { sentences: [...same shape, stemmed...], displayForms: {stem: surface} }
   */
  function normalize(sentences, options, deps) {
    var stemMode = (options && options.stemming) || 'porter';
    var stemFn;
    if (stemMode === 'porter') {
      if (!deps || !deps.porter2) { throw new Error('Porter2 stemmer not provided.'); }
      stemFn = function (w) { return deps.porter2(singularizeIrregular(w)); };
    } else if (stemMode === 'minimal') {
      stemFn = function (w) { return minimalStem(singularizeIrregular(w)); };
    } else { // 'none'
      stemFn = function (w) { return w; };
    }
    var isStop = (deps && deps.isStopWord) || function () { return false; };

    var surfaceCounts = Object.create(null); // stem -> {surface: count} (null-proto: vocabulary keys, D-V2 fix 2026-08-09)
    var out = sentences.map(function (s) {
      var phrases = s.phrases.map(function (p) {
        return p.filter(function (w) { return !isStop(w); })
                .map(function (w) {
                  // user-defined compounds from tokenization substitutions
                  // ("supply_chain") are kept verbatim — stemming a joined
                  // token would corrupt the user's chosen form (2026-08-09)
                  var st = w.indexOf('_') === -1 ? stemFn(w) : w;
                  surfaceCounts[st] = surfaceCounts[st] || Object.create(null);
                  surfaceCounts[st][w] = (surfaceCounts[st][w] || 0) + 1;
                  return st;
                });
      }).filter(function (p) { return p.length > 0; });
      return { text: s.text, phrases: phrases };
    });

    var displayForms = Object.create(null);
    Object.keys(surfaceCounts).forEach(function (st) {
      var best = null, bestN = -1;
      Object.keys(surfaceCounts[st]).forEach(function (sf) {
        if (surfaceCounts[st][sf] > bestN) { best = sf; bestN = surfaceCounts[st][sf]; }
      });
      displayForms[st] = best;
    });
    return { sentences: out, displayForms: displayForms };
  }

  /* ---------------- network construction ---------------- */

  function buildNetwork(normSentences, options) {
    var inter = !!(options && options.interSentenceLinking === true); // default off (D-17)
    var idOf = Object.create(null), words = []; // null-proto: "constructor" as a word broke node ids (Iridium 1999 corpus, 2026-08-09)
    var edgeW = {}; // "i|j" (i<j) -> weight

    function nodeId(w) {
      if (idOf[w] === undefined) { idOf[w] = words.length; words.push(w); }
      return idOf[w];
    }
    function addLink(a, b) {
      if (a === b) { return; } // self-links impossible in CRA; guard stem collisions
      var i = Math.min(a, b), j = Math.max(a, b);
      var k = i + '|' + j;
      edgeW[k] = (edgeW[k] || 0) + 1;
    }

    var prevSentLastWord = null;
    normSentences.forEach(function (s) {
      // flatten center-word stream for this utterance
      var stream = [];
      s.phrases.forEach(function (p) { p.forEach(function (w) { stream.push(nodeId(w)); }); });
      if (stream.length === 0) { return; } // sentence w/o centers: no bridge (see note)

      // L1: sequential within utterance
      for (var i = 1; i < stream.length; i++) { addLink(stream[i - 1], stream[i]); }

      // L2: all pairs within noun phrases of >= 3 words
      s.phrases.forEach(function (p) {
        if (p.length >= 3) {
          for (var a = 0; a < p.length; a++) {
            for (var b = a + 1; b < p.length; b++) {
              // sequential pairs already added by L1; add only NON-adjacent pairs
              if (b - a > 1) { addLink(idOf[p[a]], idOf[p[b]]); }
            }
          }
        }
      });

      // L3: bridge from previous sentence (D-1)
      if (inter && prevSentLastWord !== null) { addLink(prevSentLastWord, stream[0]); }
      prevSentLastWord = stream[stream.length - 1];
    });

    var edges = Object.keys(edgeW).map(function (k) {
      var p = k.split('|');
      return { source: +p[0], target: +p[1], weight: edgeW[k] };
    });
    return { words: words, edges: edges };
  }

  /* ---------------- Brandes betweenness (unweighted, undirected) ------ */

  function adjacency(nNodes, edges) {
    var adj = [];
    for (var i = 0; i < nNodes; i++) { adj.push([]); }
    edges.forEach(function (e) {
      adj[e.source].push(e.target);
      adj[e.target].push(e.source);
    });
    return adj;
  }

  /** Normalized betweenness per Eq. 1: raw pair-sum / [(N-1)(N-2)/2]. */
  function influence(nNodes, edges) {
    var adj = adjacency(nNodes, edges);
    var bc = new Array(nNodes).fill(0);
    for (var s = 0; s < nNodes; s++) {
      var S = [];
      var P = []; for (var i = 0; i < nNodes; i++) { P.push([]); }
      var sigma = new Array(nNodes).fill(0); sigma[s] = 1;
      var dist = new Array(nNodes).fill(-1); dist[s] = 0;
      var Q = [s], qi = 0;
      while (qi < Q.length) {
        var v = Q[qi++]; S.push(v);
        var nb = adj[v];
        for (var k = 0; k < nb.length; k++) {
          var w = nb[k];
          if (dist[w] < 0) { dist[w] = dist[v] + 1; Q.push(w); }
          if (dist[w] === dist[v] + 1) { sigma[w] += sigma[v]; P[w].push(v); }
        }
      }
      var delta = new Array(nNodes).fill(0);
      while (S.length) {
        var w2 = S.pop();
        for (var m = 0; m < P[w2].length; m++) {
          var v2 = P[w2][m];
          delta[v2] += (sigma[v2] / sigma[w2]) * (1 + delta[w2]);
        }
        if (w2 !== s) { bc[w2] += delta[w2]; }
      }
    }
    // undirected: each unordered pair counted twice
    var denom = (nNodes - 1) * (nNodes - 2) / 2;
    return bc.map(function (b) { return denom > 0 ? (b / 2) / denom : 0; });
  }

  /* ---------------- summary centralities (spec §4.1 A, D-4) ----------- */
  /* Reported in the human summary only; NOT used in downstream math.     */

  function summaryStats(nNodes, edges, infl) {
    var N = nNodes;
    if (N < 3) { return { note: 'network too small for centralization indices' }; }
    var adj = adjacency(N, edges);
    var deg = adj.map(function (a) { return a.length; });

    // Degree centralization (Freeman), normalized degrees d/(N-1), denom (N-2)/(N-1)*(N-1)= (N-2)
    var dmax = Math.max.apply(null, deg);
    var degC = deg.reduce(function (acc, d) { return acc + (dmax - d); }, 0) / ((N - 1) * (N - 2));

    // Betweenness centralization on normalized influence, denom (N-1)
    var bmax = Math.max.apply(null, infl);
    var betC = infl.reduce(function (acc, b) { return acc + (bmax - b); }, 0) / (N - 1);

    // Closeness: computed on the largest connected component (disconnected
    // graphs are expected — JHC p. 177); standardized c_i=(n_c-1)/sum(dist)
    var comp = largestComponent(N, adj);
    var cloC = null, cloNote = '';
    if (comp.length >= 3) {
      var idx = {}; comp.forEach(function (v, i) { idx[v] = i; });
      var n = comp.length;
      var clo = comp.map(function (v) {
        var d = bfsDist(v, adj);
        var sum = 0;
        comp.forEach(function (u) { if (u !== v) { sum += d[u]; } });
        return (n - 1) / sum;
      });
      var cmax = Math.max.apply(null, clo);
      cloC = clo.reduce(function (acc, c) { return acc + (cmax - c); }, 0) /
             (((n - 2) * (n - 1)) / (2 * n - 3));
      if (n < N) { cloNote = ' (largest component, ' + n + '/' + N + ' nodes)'; }
    }

    // Eigenvector by power iteration, max-normalized; star-graph max denom
    var eig = powerIteration(N, adj);
    var emax = Math.max.apply(null, eig);
    var eigC = null;
    if (emax > 0) {
      var e = eig.map(function (x) { return x / emax; });
      var denomStar = (N - 1) * (1 - 1 / Math.sqrt(N - 1));
      eigC = e.reduce(function (acc, x) { return acc + (1 - x); }, 0) / denomStar;
    }

    // CRA-native fragmentation: coherent texts yield one dominant component
    // (JHC p. 177 expects disconnection in low-coherence texts)
    var seen2 = new Array(N).fill(false), nComp = 0;
    for (var s2 = 0; s2 < N; s2++) {
      if (seen2[s2]) { continue; }
      nComp++;
      var Q2 = [s2], qi2 = 0; seen2[s2] = true;
      while (qi2 < Q2.length) {
        var v2b = Q2[qi2++];
        adj[v2b].forEach(function (w2b) {
          if (!seen2[w2b]) { seen2[w2b] = true; Q2.push(w2b); }
        });
      }
    }

    return {
      componentCount: nComp,
      largestComponentShare: round5(comp.length / N),
      centralization: {
        degree: round5(degC),
        betweenness: round5(betC),
        closeness: cloC === null ? null : round5(cloC),
        eigenvector: eigC === null ? null : round5(eigC)
      },
      closenessNote: cloNote,
      meanInfluence: round5(infl.reduce(function (a, b) { return a + b; }, 0) / N)
    };
  }

  function bfsDist(s, adj) {
    var dist = new Array(adj.length).fill(-1); dist[s] = 0;
    var Q = [s], qi = 0;
    while (qi < Q.length) {
      var v = Q[qi++];
      adj[v].forEach(function (w) {
        if (dist[w] < 0) { dist[w] = dist[v] + 1; Q.push(w); }
      });
    }
    return dist;
  }

  function largestComponent(N, adj) {
    var seen = new Array(N).fill(false), best = [];
    for (var s = 0; s < N; s++) {
      if (seen[s]) { continue; }
      var comp = [], Q = [s], qi = 0; seen[s] = true;
      while (qi < Q.length) {
        var v = Q[qi++]; comp.push(v);
        adj[v].forEach(function (w) { if (!seen[w]) { seen[w] = true; Q.push(w); } });
      }
      if (comp.length > best.length) { best = comp; }
    }
    return best;
  }

  function powerIteration(N, adj) {
    var x = new Array(N).fill(1 / Math.sqrt(N)), it, i;
    for (it = 0; it < 200; it++) {
      var y = new Array(N).fill(0);
      for (i = 0; i < N; i++) {
        adj[i].forEach(function (j) { y[i] += x[j]; });
      }
      var norm = Math.sqrt(y.reduce(function (a, v) { return a + v * v; }, 0));
      if (norm === 0) { return new Array(N).fill(0); }
      var diff = 0;
      for (i = 0; i < N; i++) { y[i] /= norm; diff += Math.abs(y[i] - x[i]); }
      x = y;
      if (diff < 1e-12) { break; }
    }
    return x.map(Math.abs);
  }

  function round5(x) { return Math.round(x * 1e5) / 1e5; }

  /* ---------------- V2-M2 node statistics (spec §3.3 synergy note) ----- */

  /**
   * Weighted PageRank on the (undirected, valued) CRA network.
   * Matches networkx.pagerank(G, alpha, weight='weight') on the same graph:
   * undirected edges become two directed arcs; the transition matrix is
   * row-stochastic over incident edge weights; dangling (isolated) nodes
   * redistribute uniformly. Power iteration to machine convergence so the
   * result is the fixed point, not an early stop (oracle: networkx, 1e-9).
   */
  function pageRank(nNodes, edges, alpha) {
    alpha = alpha === undefined ? 0.85 : alpha;
    var N = nNodes;
    if (N === 0) { return []; }
    // adjacency with weights (undirected -> both directions)
    var nbr = [], i;
    for (i = 0; i < N; i++) { nbr.push([]); }
    var wsum = new Array(N).fill(0);
    edges.forEach(function (e) {
      nbr[e.source].push([e.target, e.weight]);
      nbr[e.target].push([e.source, e.weight]);
      wsum[e.source] += e.weight;
      wsum[e.target] += e.weight;
    });
    var dangling = [];
    for (i = 0; i < N; i++) { if (wsum[i] === 0) { dangling.push(i); } }

    var x = new Array(N).fill(1 / N);
    var p = 1 / N;
    for (var it = 0; it < 1000; it++) {
      var xNew = new Array(N).fill(0);
      var dangleSum = 0;
      for (i = 0; i < dangling.length; i++) { dangleSum += x[dangling[i]]; }
      for (i = 0; i < N; i++) {
        if (wsum[i] === 0) { continue; }
        var share = x[i] / wsum[i];
        var nb = nbr[i];
        for (var k = 0; k < nb.length; k++) { xNew[nb[k][0]] += share * nb[k][1]; }
      }
      var err = 0;
      for (i = 0; i < N; i++) {
        xNew[i] = alpha * (xNew[i] + dangleSum * p) + (1 - alpha) * p;
        err += Math.abs(xNew[i] - x[i]);
      }
      x = xNew;
      if (err < N * 1e-15) { break; }
    }
    return x;
  }

  /** Strength = weighted degree: sum of incident F_ij (Opsahl et al., 2010). */
  function strength(nNodes, edges) {
    var s = new Array(nNodes).fill(0);
    edges.forEach(function (e) {
      s[e.source] += e.weight;
      s[e.target] += e.weight;
    });
    return s;
  }

  /* ---------------- top-level: parsed sentences -> CRA data ---------- */

  /**
   * Build the complete CRA network data from parser output.
   * deps: { porter2, isStopWord }
   * Returns { nodes, edges, summary, displayForms }
   */
  function buildCra(parsedSentences, options, deps) {
    var norm = normalize(parsedSentences, options, deps);
    var net = buildNetwork(norm.sentences, options);
    var infl = influence(net.words.length, net.edges);
    var adj = adjacency(net.words.length, net.edges);

    var pr = pageRank(net.words.length, net.edges);   // V2-M2 node stats
    var str = strength(net.words.length, net.edges);  // (additive; V1 fields unchanged)
    var nodes = net.words.map(function (w, i) {
      return {
        id: i,
        word: w,
        display: norm.displayForms[w] || w,
        degree: adj[i].length,
        strength: str[i],
        influence: round5(infl[i]),
        pageRank: round5(pr[i])
      };
    });
    var summary = summaryStats(net.words.length, net.edges, infl);
    summary.nodeCount = nodes.length;
    summary.edgeCount = net.edges.length;
    return { nodes: nodes, edges: net.edges, summary: summary };
  }

  var api = {
    normalize: normalize,
    buildNetwork: buildNetwork,
    influence: influence,
    pageRank: pageRank,       // V2-M2
    strength: strength,       // V2-M2
    summaryStats: summaryStats,
    buildCra: buildCra,
    minimalStem: minimalStem,
    singularizeIrregular: singularizeIrregular
  };

  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.CrawdadNetwork = api; }
})(typeof self !== 'undefined' ? self : this);
